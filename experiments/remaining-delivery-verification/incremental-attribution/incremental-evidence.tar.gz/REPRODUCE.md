本轮基线1d48c13e12包含所有之前修复，候选ecce1d87d9。先核验SHA256SUMS.json。源码、原始日志和脚本在evidence/与source/；candidate.bundle包含相对main700e1983的整个Lab分支，包括此前修复；incremental.patch仅展示相对本轮基线1d48c13e的新增变化。Bundle需要其声明的基线Git对象。不要自动合并main。

在Lab独立构建后依次运行：

```sh
node packages/main/tests/validation-queue-lease-loss.test.mjs
node packages/main/tests/activity-implementation-witness.test.mjs
node packages/main/tests/validation-abort-composition.test.mjs
node packages/main/tests/verifier-causal-preflight.test.mjs
node scripts/verify-runtime-fact-contract.mjs
```

统计脚本analyze.py、analysis_core.py和test_analysis.py需要放在同一证据目录。analyze.py读取冻结的activity-window.jsonl、activity-manifest.json、Story CLI输出、原始队列日志并重算；默认会写派生文件，请在新复制目录运行，不覆盖交付包。原始采集脚本collect-census.py只用于重新采集一个新的观察窗口，不是复现旧窗口的时间机器。

baseline-runtime-overlay.mjs是为了核查既有回归失败的功能源码覆盖；它依赖本地Git历史、构建目录和TypeScript。受控标记确认baseline CLI代码在session_brief子进程实际执行。它既不是另一版本完整发行包，也不用于速度比较。

原生Lab RED/GREEN记录和原始Claude审计同时保存。不要把未签名实验记录当成正式Story DONE/发布证明。其他正在运行的会话尚未迁移；这些文件不授权接管其他owner。
