import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join} from 'node:path';
import {withOfficialValidationExecution} from '../../packages/main/dist/core/validation-execution-lock.js';
import {acquireOwnerLease} from '../../packages/main/dist/core/story-owner-lease.js';
const root=mkdtempSync(join(tmpdir(),'pos-abort-composition-'));
const original=AbortSignal.any;let launched=false,error=null;
try {
 const storyDir=join(root,'.proof-or-stop/story/actives/B-compat');
 acquireOwnerLease(storyDir,{command:'validate',cwd:root});
 AbortSignal.any=undefined;
 try {await withOfficialValidationExecution({root,workspaceRoot:root,command:'validate',storyId:'B-compat',ownerLeaseDir:storyDir,abortSignal:new AbortController().signal},()=>{launched=true;});}catch(e){error=e.message;}
 console.log(JSON.stringify({scope:'Feature-absence compatibility probe; not a different Node binary',launched,error}));
 if(error||!launched){console.error('ABORT_COMPOSITION_COMPAT_RED');process.exitCode=1;}else console.log('ABORT_COMPOSITION_COMPAT_GREEN');
}finally{AbortSignal.any=original;rmSync(root,{recursive:true,force:true});}
