from pathlib import Path
import subprocess,json,hashlib,time,datetime,concurrent.futures
L=Path.cwd();O=L/'output/incremental-attribution';R=L.parent.parent;entry=L/'bin/proof-or-stop.js'
listing=json.loads((O/'story-list.json').read_text())['stories'];wt=subprocess.check_output(['git','worktree','list','--porcelain'],text=True);roots={}
for block in wt.strip().split('\n\n'):
 d=dict(x.split(' ',1) for x in block.splitlines() if ' ' in x)
 if d.get('branch','').startswith('refs/heads/story/'):roots[d['branch'].split('/')[-1]]=d['worktree']
(O/'census').mkdir(exist_ok=True)
def collect(row):
 sid=row['storyId'];root=roots.get(sid,str(R));args=['node',str(entry),'--root',root,'story_get','--storyId',sid,'--detail'];start=time.monotonic();cp=subprocess.run(args,capture_output=True,text=True,timeout=45)
 (O/'census'/f'{sid}.stdout').write_text(cp.stdout);(O/'census'/f'{sid}.stderr').write_text(cp.stderr)
 try:data=json.loads(cp.stdout);idx=data.get('index')
 except ValueError:idx=None
 return {'storyId':sid,'listedPhase':row['phase'],'root':root,'resolutionSource':'registered-story-worktree' if sid in roots else 'main-metadata','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-start,'exitCode':cp.returncode,'stdoutSha256':hashlib.sha256(cp.stdout.encode()).hexdigest(),'index':idx,'actualPhase':idx.get('phase') if idx else None}
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for future in concurrent.futures.as_completed([pool.submit(collect,row) for row in listing]):
  try:results.append(future.result())
  except Exception as e:results.append({'collectionError':str(e)})
  if len(results)%50==0:print('collected',len(results),flush=True)
(O/'story-census.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'listed':len(listing),'rows':len(results),'readable':sum(x.get('index') is not None for x in results),'unreadable':sum(x.get('index') is None for x in results)}),flush=True)
