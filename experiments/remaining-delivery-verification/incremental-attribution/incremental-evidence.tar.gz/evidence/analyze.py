from pathlib import Path
import json,datetime,collections,statistics,hashlib
from analysis_core import identity_observations
O=Path(__file__).parent
rows=[json.loads(s) for s in (O/'activity-window.jsonl').read_text().splitlines()];manifest=json.loads((O/'activity-manifest.json').read_text())
def stamp(x):
 try:return datetime.datetime.fromisoformat(x.replace('Z','+00:00')).timestamp()
 except (ValueError,TypeError,AttributeError):return None
START,END=stamp(manifest['windowStart']),stamp(manifest['cutoff'])
def union(intervals):
 total=0;end=None
 for a,b in sorted(intervals):
  total+=max(0,b-max(a,end if end is not None else a));end=max(b,end if end is not None else b)
 return total
classified=[];invalid=[]
for row in rows:
 if row.get('source') not in ['cli','codex','antigravity']:continue
 a,b=stamp(row.get('startTime')),stamp(row.get('endTime'))
 if a is None or b is None or b<a:invalid.append(row);continue
 a,b=max(a,START),min(b,END)
 if b<a:continue
 args=row.get('args');args=args if isinstance(args,dict) else {};sid=row.get('storyId') or args.get('storyId') or args.get('story');sid=sid if isinstance(sid,str) else None
 classified.append({**row,'sid':sid,'a':a,'b':b,'seconds':b-a})
bytool=collections.defaultdict(list);bystory=collections.defaultdict(list)
for row in classified:bytool[row.get('tool') or row.get('command') or 'unknown'].append(row);bystory[row['sid']].append(row)
def metrics(group):return {'calls':len(group),'failedCalls':sum(x.get('status')=='fail' for x in group),'summedSeconds':sum(x['seconds'] for x in group),'unionSeconds':union([(x['a'],x['b']) for x in group])}
tools=sorted([{'command':k,**metrics(v)} for k,v in bytool.items()],key=lambda x:-x['summedSeconds'])
recent=[x for x in classified if x['a']>=END-86400]
# A missing implementation witness is UNKNOWN, not proof that an invocation used the wrong binary.
identity={'window':'last 24 hours of frozen activity window','commandRecords':len(recent),'withSessionId':sum(isinstance(x.get('session'),str) and bool(x['session']) for x in recent),'withEntrypoint':sum(isinstance(x.get('entrypoint'),str) and bool(x['entrypoint']) for x in recent),**identity_observations(recent),'uniqueObservedSessionLabels':len(set(x['session'] for x in recent if isinstance(x.get('session'),str) and x['session'])),'roleCounts':dict(collections.Counter(str(x.get('role')) for x in recent)),'globalAdoptionRate':None,'limitation':'Recent log session labels are not a census of live owner/reviewer hosts. No loaded implementation digest means unknown adoption, not noncompliance.'}
summary={'window':{'start':manifest['windowStart'],'cutoff':manifest['cutoff']},'scope':'Observed command occupancy only; not causal task execution or recovered historical queue/review time','timedCommandRecords':len(classified),'recordsWithoutValidIntervals':len(invalid),'allCommandUnionSeconds':union([(x['a'],x['b']) for x in classified]),'allCommandSummedSeconds':sum(x['seconds'] for x in classified),'perCommand':tools,'identityCoverage':identity,'limitations':['Parallel command sums overlap; do not add command unions into total wall time.','A log error saying commandExecutions=0 may originate at a later child launch boundary; this literal is not a verified whole-command child count.','Subphase queue, model review, execution, recovery intervals are absent in these logs; they remain unknown.','Activity capture has bounded local sources; absent records are not zero work.']}
(O/'attribution.json').write_text(json.dumps(summary,indent=2)+'\n')
source=[]
for x in sorted(classified,key=lambda x:-x['seconds'])[:30]:source.append({k:x.get(k) for k in ['sid','tool','startTime','endTime','seconds','status','error','_source','_line']})
(O/'long-command-sources.json').write_text(json.dumps(source,indent=2)+'\n')
if (O/'story-census.json').exists():
 census=json.loads((O/'story-census.json').read_text());cohort=[]
 for s in census:
  idx=s.get('index')
  if not isinstance(idx,dict):continue
  sid=s['storyId'];created=stamp(idx.get('createdAt'));ended=stamp(idx.get('endedAt'));phase=idx.get('phase');active=phase not in ['DONE','DISCARDED','IDEA']
  if not (active or (created is not None and START<=created<=END) or (ended is not None and START<=ended<=END) or bystory.get(sid)):continue
  lifetime=(ended-created) if ended is not None and created is not None and ended>=created else None
  spanA=max(START,created) if created is not None else None;spanB=min(END,ended if ended is not None else END)
  intervals=[(max(x['a'],spanA),min(x['b'],spanB)) for x in bystory[sid] if spanA is not None and min(x['b'],spanB)>=max(x['a'],spanA)]
  covered=union(intervals);span=spanB-spanA if spanA is not None and spanB>=spanA else None
  cohort.append({'storyId':sid,'phase':phase,'root':s['root'],'registeredStoryWorktree':s['resolutionSource']=='registered-story-worktree','capturedAt':s['capturedAt'],'liveHostStatus':'not measured','createdAt':idx.get('createdAt'),'endedAt':idx.get('endedAt'),'lifetimeSeconds':lifetime,'observedWindowSpanSeconds':span,'timedCommandUnionSecondsInSpan':covered,'unclassifiedSpanSeconds':None if span is None else span-covered,'commandMetrics':metrics(bystory[sid]),'phaseEntryCounts':dict(collections.Counter(x.get('phase') for x in idx.get('events',[]) if x.get('action')=='advance'))})
 (O/'story-attribution.json').write_text(json.dumps({'rows':cohort,'unreadableStoryIds':[x.get('storyId') for x in census if x.get('index') is None],'scope':'Unclassified span includes work not logged, pauses and waiting; it is not claimed waste. Terminal lifetime is descriptive and not a same-task A/B.','limitations':['Nonterminal metadata rows are not a live-session census.','Six reads refused obsolete active configuration and remain unknown.','CLI index reads were rolling observations during a build of lease/logging changes; query handler/store sources were unchanged. They are not an implementation-adoption experiment.']},indent=2)+'\n')
comparisons={}
for arm in ['red','green']:
 p=O/f'native-{arm}.log'
 if arm=='green' and (O/'queue-final-green.log').exists():p=O/'queue-final-green.log'
 if not p.exists():continue
 rr=[json.loads(x[len('QUEUE_RESULT '):]) for x in p.read_text().splitlines() if x.startswith('QUEUE_RESULT ')]
 comparisons[arm]={'logPath':p.name,'logSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rr,'byKind':{kind:{'n':len(xs),'medianAfterTriggerMs':statistics.median(x['afterTriggerMs'] for x in xs),'medianOutcomeMs':statistics.median(x['outcomeMs'] for x in xs),'callbacks':sum(x['callback'] for x in xs),'markers':sum(x['marker'] for x in xs)} for kind in ['lost','healthy','abort'] if (xs:=[x for x in rr if x['kind']==kind])}}
(O/'queue-comparison.json').write_text(json.dumps({'baseline':'1d48c13e126db2ad0ceab850a346afffbfb5d476','scope':'Time to deliberate expected refusal after private lease revocation, not Story completion time','candidateHead':json.loads((O/'final-checks.json').read_text())['head'] if (O/'final-checks.json').exists() else None,'arms':comparisons,'defaultHeartbeatMs':30000,'experimentHeartbeatMs':20,'limitations':['Three fixed RED then GREEN replicates on shared host; no general latency SLA.','Default renewal cadence is30seconds, so production detection can take that long plus scheduling delay.','The repair cancels capacity wait after renewal failure; it does not terminate already-running child processes.']},indent=2)+'\n')
print(json.dumps({'timedCommandRecords':len(classified),'topCommands':tools[:5],'identityCoverage':identity},indent=2))
