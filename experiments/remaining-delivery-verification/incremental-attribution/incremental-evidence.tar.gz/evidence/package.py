from pathlib import Path
import shutil,json,hashlib,tarfile,re,subprocess
L=Path.cwd();O=L/'output/incremental-attribution';E=Path('/Users/jek/.codex/artifacts/proof-or-stop-incremental-closure-20260910');P=L/'experiments/remaining-delivery-verification/incremental-attribution'
for name in ['claude-audit','claude-followup']:
 A=O/name
 for line in (A/'stream.jsonl').read_text().splitlines():
  try:e=json.loads(line)
  except ValueError:continue
  if not isinstance(e,dict) or not isinstance(e.get('message'),dict) or not isinstance(e['message'].get('content'),list):continue
  for c in e['message']['content']:
   if not isinstance(c,dict) or c.get('type')!='tool_result' or not isinstance(c.get('content'),str):continue
   match=re.search(r'Full output saved to: ([^\n]+)',c['content'])
   if not match:continue
   source=Path(match.group(1).strip());assert str(source).startswith('/Users/jek/.claude/projects/');dest=A/'persisted-tool-output'/source.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(source,dest)
shutil.copytree(O,E/'evidence',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
files=subprocess.check_output(['git','diff','--name-only','1d48c13e12','ecce1d87d9'],text=True).splitlines()
for rel in files:
 source=L/rel
 if source.is_file():dest=E/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
report=(E/'report.md').read_text();(P/'REPORT.md').write_text(report+'\n便携完整证据在同目录的incremental-evidence.tar.gz；原Lab路径失效时，请使用归档内evidence对应文件。\n')
(E/'REPRODUCE.md').write_text((E/'REPRODUCE.md').read_text().replace('Git bundle为相对该基线的增量，需已有基线对象。','candidate.bundle包含相对main700e1983的整个Lab分支，包括此前修复；incremental.patch仅展示相对本轮基线1d48c13e的新增变化。Bundle需要其声明的基线Git对象。'))
files=sorted(p for p in E.rglob('*') if p.is_file())
manifest={str(p.relative_to(E)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
# No keys, dependencies or working runtime clones enter this explicit evidence directory.
assert not any(p.is_symlink() for p in files)
(E/'EVIDENCE_SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=P/'incremental-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files+[E/'EVIDENCE_SHA256SUMS.json']:tf.add(p,arcname=str(p.relative_to(E)),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 members={m.name:m for m in tf.getmembers()};assert set(members)==set(manifest)|{'EVIDENCE_SHA256SUMS.json'}
 for name,expected in manifest.items():
  data=tf.extractfile(members[name]).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],name
info={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(manifest),'baseline':'1d48c13e126db2ad0ceab850a346afffbfb5d476','candidate':'ecce1d87d94cf4f2ea9981d42afbaa4e1d54c07a','claudeVerdict':'PASS','scope':'Incremental queue cancellation and durable implementation observations; no overall Story speed or global adoption claim'}
(P/'evidence-package.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
