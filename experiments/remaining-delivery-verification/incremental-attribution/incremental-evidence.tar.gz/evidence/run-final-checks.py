from pathlib import Path
import subprocess,hashlib,json,time,datetime
L=Path.cwd();O=L/'output/incremental-attribution';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();rows=[]
commands=[('queue-final-green.log',['node','packages/main/tests/validation-queue-lease-loss.test.mjs']),('identity-final-green.log',['node','packages/main/tests/activity-implementation-witness.test.mjs']),('compat-final-green.log',['node','packages/main/tests/validation-abort-composition.test.mjs']),('runtime-contract-final.log',['node','scripts/verify-runtime-fact-contract.mjs']),('causal-preflight-final.log',['node','packages/main/tests/verifier-causal-preflight.test.mjs']),('residue-final.json',['node','scripts/verify-proof-or-stop-identity-cutover.mjs','--print-residue'])]
files=['packages/main/dist/core/story-owner-lease.js','packages/main/dist/core/validation-execution-lock.js','packages/main/dist/cli-engine.js','packages/main/tests/validation-queue-lease-loss.test.mjs','packages/main/tests/activity-implementation-witness.test.mjs','packages/main/tests/validation-abort-composition.test.mjs']
hashes=lambda:{x:hashlib.sha256((L/x).read_bytes()).hexdigest() for x in files}
before=hashes()
for name,args in commands:
 p=O/name
 if p.exists():p.rename(O/(name+'.pre-final'))
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with p.open('w') as f:result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'log':name,'args':args,'head':head,'startedAt':started,'seconds':time.monotonic()-t,'exitCode':result.returncode,'logSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'final-checks.json').write_text(json.dumps({'head':head,'inputHashes':before,'inputsUnchanged':hashes()==before,'rows':rows},indent=2)+'\n');print(json.dumps({'head':head,'inputsUnchanged':hashes()==before,'results':[{k:x[k] for k in ['log','seconds','exitCode']} for x in rows]}),flush=True)
if any(x['exitCode'] for x in rows) or hashes()!=before:raise SystemExit(1)
