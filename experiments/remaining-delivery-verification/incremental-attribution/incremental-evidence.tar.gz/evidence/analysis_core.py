import re,os,collections

def identity_observations(rows):
 counts=collections.Counter();with_digest=0;verified=0
 for row in rows:
  item=row.get('implementation');legacy=row.get('implementationDigest')
  if item is None:
   if isinstance(legacy,str) and re.fullmatch('[a-f0-9]{64}',legacy):counts['legacy-unverified']+=1;with_digest+=1
   else:counts['absent']+=1
   continue
  if not isinstance(item,dict):counts['malformed']+=1;continue
  digest=item.get('digest');valid_digest=isinstance(digest,str) and re.fullmatch('[a-f0-9]{64}',digest) is not None
  with_digest+=int(valid_digest)
  if item.get('status')=='unverified' and not digest:counts['unverified']+=1
  elif item.get('status')=='verified-at-entry' and valid_digest and item.get('schema')=='execution-implementation.v1' and isinstance(item.get('entrypoint'),str) and os.path.isabs(item['entrypoint']) and type(item.get('pid')) is int and item['pid']>0:
   counts['verified-at-entry']+=1;verified+=1
  else:counts['malformed']+=1
 return {'withImplementationDigest':with_digest,'recordedVerifiedAtEntry':verified,'implementationStatusCounts':dict(counts)}
