import {execFileSync,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
const root=process.cwd(),out=resolve(root,'output/incremental-attribution');
const names=['cli-engine','core/story-owner-lease','core/validation-execution-lock','core/runtime-fact-registry'];
const overrides={};
for(const name of names){
 const source=execFileSync('git',['show',`1d48c13e12:packages/main/src/${name}.ts`],{encoding:'utf8'});
 overrides[pathToFileURL(resolve(root,`packages/main/dist/${name}.js`)).href]=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
}
const hook=resolve(out,'baseline-runtime-loader.mjs');
writeFileSync(hook,`import {registerHooks} from 'node:module';\nconst sources=${JSON.stringify(overrides)};\nregisterHooks({load(url,context,next){if(Object.hasOwn(sources,url))return {format:'module',source:sources[url],shortCircuit:true};return next(url,context);}});\n`);
const marker=resolve(out,'baseline-child-execution-marker.jsonl');
writeFileSync(marker,'');
const engineUrl=pathToFileURL(resolve(root,'packages/main/dist/cli-engine.js')).href;
overrides[engineUrl]="import {appendFileSync as labBaselineAppend} from 'node:fs';\n"+overrides[engineUrl]+`\nlabBaselineAppend(${JSON.stringify(marker)},JSON.stringify({pid:process.pid,argv:process.argv.slice(1),baseline:'1d48c13e12'})+'\\n');\n`;
writeFileSync(hook,`import {registerHooks} from 'node:module';\nconst sources=${JSON.stringify(overrides)};\nregisterHooks({load(url,context,next){if(Object.hasOwn(sources,url))return {format:'module',source:sources[url],shortCircuit:true};return next(url,context);}});\n`);
const args=['packages/main/dist/tasks/story-owner-lease-smoke.js'];
const result=spawnSync(process.execPath,args,{cwd:root,env:{...process.env,NODE_OPTIONS:`--import ${hook}`},encoding:'utf8',timeout:120000,maxBuffer:4*1024*1024});
writeFileSync(resolve(out,'owner-lease-baseline-overlay-controlled.log'),result.stdout+result.stderr);
const markers=readFileSync(marker,'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));
if(!markers.some(row=>row.argv.includes('session_brief')&&row.pid!==process.pid))throw new Error('baseline engine child positive control missing');
const evidence={childExecutionPositiveControl:markers,scope:'Functional baseline source overlay for regression classification, not a timing or byte-identical shipped binary comparison',baseline:'1d48c13e126db2ad0ceab850a346afffbfb5d476',replacedModules:names,args,exitCode:result.status,error:result.error?.message??null};writeFileSync(resolve(out,'owner-lease-baseline-overlay-controlled.json'),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence));
