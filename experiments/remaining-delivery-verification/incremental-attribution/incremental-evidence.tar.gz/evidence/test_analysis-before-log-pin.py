import json
from pathlib import Path
from analysis_core import identity_observations
O=Path(__file__).parent
actual=[json.loads(line[len('ACTIVITY_OBSERVATION '):])['recorded'] for line in (O/'identity-native-green.log').read_text().splitlines() if line.startswith('ACTIVITY_OBSERVATION ')]
assert len(actual)==2
rows=[{'implementation':x} for x in actual]
assert identity_observations(rows)['recordedVerifiedAtEntry']==2
r=identity_observations(rows+[{}, {'implementation':{'status':'unverified'}},{'implementation':{'status':'verified-at-entry','digest':'f'*64}}, {'implementation':'invalid'}, {'implementationDigest':'a'*64}])
assert r=={'withImplementationDigest':4,'recordedVerifiedAtEntry':2,'implementationStatusCounts':{'verified-at-entry':2,'absent':1,'unverified':1,'malformed':2,'legacy-unverified':1}},r
assert identity_observations([{},{}])['recordedVerifiedAtEntry']==0
print(json.dumps({'actualDurableRows':2,'malformedOrUnverifiedDoNotCountAsVerified':True,'result':r}))
print('ANALYSIS_IDENTITY_GREEN')
