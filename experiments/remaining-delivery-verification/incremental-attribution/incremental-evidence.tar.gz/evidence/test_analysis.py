import json,hashlib
from pathlib import Path
from analysis_core import identity_observations
O=Path(__file__).parent
claim=json.loads((O/'analysis-red-green.json').read_text())
source=(O/claim['sourceLog']).read_bytes()
assert hashlib.sha256(source).hexdigest()==claim['sourceSha256']
actual=[json.loads(line[len('ACTIVITY_OBSERVATION '):])['recorded'] for line in source.decode().splitlines() if line.startswith('ACTIVITY_OBSERVATION ')]
assert len(actual)==2
rows=[{'implementation':x} for x in actual]
assert identity_observations(rows)['recordedVerifiedAtEntry']==2
r=identity_observations(rows+[{}, {'implementation':{'status':'unverified'}},{'implementation':{'status':'verified-at-entry','digest':'f'*64}}, {'implementation':'invalid'}, {'implementationDigest':'a'*64}])
assert r=={'withImplementationDigest':4,'recordedVerifiedAtEntry':2,'implementationStatusCounts':{'verified-at-entry':2,'absent':1,'unverified':1,'malformed':2,'legacy-unverified':1}},r
assert identity_observations([{},{}])['recordedVerifiedAtEntry']==0
print(json.dumps({'actualDurableRows':2,'malformedOrUnverifiedDoNotCountAsVerified':True,'result':r}))
print('ANALYSIS_IDENTITY_GREEN')
