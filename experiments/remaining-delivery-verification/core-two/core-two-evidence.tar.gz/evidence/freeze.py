from pathlib import Path
import subprocess,shutil,json,time
r=Path.cwd();out=r/'output/core-two-repair';dst=out/'red-runtime'
start=time.monotonic()
subprocess.run(['git','clone','--quiet','--shared','--no-checkout',str(r),str(dst)],check=True)
subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=dst,check=True)
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],input='/*\n!/.remember/logs/autonomous/\n',text=True,cwd=dst,check=True)
subprocess.run(['git','checkout','--quiet','HEAD'],cwd=dst,check=True)
main=subprocess.check_output(['git','rev-parse','main'],cwd=r,text=True).strip()
subprocess.run(['git','branch','main',main],cwd=dst,check=True)
for package in ['main','utils','lab']:
 d=r/'packages'/package/'dist'
 if d.exists():shutil.copytree(d,dst/'packages'/package/'dist')
(dst/'node_modules').symlink_to(r/'node_modules',target_is_directory=True)
(dst/'packages/main/node_modules').symlink_to(r/'packages/main/node_modules',target_is_directory=True)
(out/'red-preparation.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'main':main,'root':str(dst),'prepareSeconds':time.monotonic()-start,'distIndependentlyCopied':True},indent=2)+'\n')
print('FROZEN '+str(dst),flush=True)
with (out/'red-full.log').open('w') as log:
 t=time.monotonic();p=subprocess.run(['node','packages/main/tests/canonical-new-story-artifacts.test.mjs','--group=identity-cutover'],cwd=dst,stdout=log,stderr=subprocess.STDOUT)
(out/'red-full-execution.json').write_text(json.dumps({'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t,'argv':['node','packages/main/tests/canonical-new-story-artifacts.test.mjs','--group=identity-cutover'],'root':str(dst)},indent=2)+'\n')
print('BASELINE_COMPLETE '+str(p.returncode),flush=True)
