from pathlib import Path
import subprocess,shutil,json,time,sys
r=Path.cwd();o=r/'output/core-two-repair';arm=sys.argv[1];dst=o/(arm+'-runtime')
if arm=='red':
 for suffix in ['full.log','full-execution.json']:
  old=o/(arm+'-'+suffix)
  if old.exists():old.rename(o/(arm+'-prior-'+str(time.time_ns())+'-'+suffix))
common=Path(subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=r,text=True).strip())
if not common.is_absolute():common=r/common
key=dst/'.git/proof-or-stop-finding-ledger-v1.key'
shutil.copyfile(common/'proof-or-stop-finding-ledger-v1.key',key);key.chmod(0o600)
try:
 with (o/(arm+'-full.log')).open('w') as log:
  t=time.monotonic();p=subprocess.run(['node','packages/main/tests/canonical-new-story-artifacts.test.mjs','--group=identity-cutover'],cwd=dst,stdout=log,stderr=subprocess.STDOUT)
 (o/(arm+'-full-execution.json')).write_text(json.dumps({'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t,'argv':['node','packages/main/tests/canonical-new-story-artifacts.test.mjs','--group=identity-cutover'],'root':str(dst),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=dst,text=True).strip()},indent=2)+'\n')
 print(arm+'_COMPLETE '+str(p.returncode),flush=True)
finally:key.unlink(missing_ok=True)
