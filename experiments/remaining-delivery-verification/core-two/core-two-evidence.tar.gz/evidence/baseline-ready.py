from pathlib import Path
import subprocess,json,time
r=Path.cwd();o=r/'output/core-two-repair';dst=o/'red-runtime';start=time.monotonic()
subprocess.run(['git','sparse-checkout','disable'],cwd=dst,check=True)
with (o/'baseline-build.log').open('w') as log:subprocess.run(['node','scripts/ensure-dist.mjs'],cwd=dst,stdout=log,stderr=subprocess.STDOUT,check=True)
with (o/'baseline-lab-build.log').open('w') as log:subprocess.run(['npm','--prefix','packages/lab','run','build'],cwd=dst,stdout=log,stderr=subprocess.STDOUT,check=True)
p=subprocess.run(['node','scripts/verify-proof-or-stop-identity-cutover.mjs','--print-residue'],cwd=dst,capture_output=True,text=True)
(o/'main-baseline-preflight.log').write_text(p.stdout+p.stderr)
assert p.returncode==0 and json.loads(p.stdout)==[],p.stdout+p.stderr
(o/'red-final-preparation.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=dst,text=True).strip(),'seconds':time.monotonic()-start,'fullSourcePresent':True,'ownBuild':True,'sourcePreflightPass':True},indent=2)+'\n')
print('MAIN_BASELINE_READY',flush=True)
subprocess.run(['python3','output/core-two-repair/run-full.py','red'],cwd=r,check=True)
