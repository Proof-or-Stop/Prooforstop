from pathlib import Path
import subprocess,shutil,json,time
r=Path.cwd();o=r/'output/core-two-repair';receipt=o/'red-full-execution.json'
while not receipt.exists():time.sleep(5)
red=json.loads(receipt.read_text());assert red['exitCode']==0 and red['head']=='442f6f38b6c6cb5f89521ddf9f79cabdd065a5c4',red
print('BASELINE_PASS; preparing candidate',flush=True)
dst=o/'green-runtime';t=time.monotonic()
subprocess.run(['git','clone','--quiet','--shared',str(r),str(dst)],check=True)
main=subprocess.check_output(['git','rev-parse','main'],cwd=r,text=True).strip()
subprocess.run(['git','branch','main',main],cwd=dst,check=True)
(dst/'node_modules').symlink_to(r/'node_modules',target_is_directory=True)
(dst/'packages/main/node_modules').symlink_to(r/'packages/main/node_modules',target_is_directory=True)
with (o/'candidate-build.log').open('w') as log:
 for argv in [['node','scripts/ensure-dist.mjs'],['npm','--prefix','packages/lab','run','build']]:subprocess.run(argv,cwd=dst,stdout=log,stderr=subprocess.STDOUT,check=True)
p=subprocess.run(['node','scripts/verify-proof-or-stop-identity-cutover.mjs','--print-residue'],cwd=dst,capture_output=True,text=True)
(o/'candidate-frozen-preflight.log').write_text(p.stdout+p.stderr)
assert p.returncode==0 and json.loads(p.stdout)==[],p.stdout+p.stderr
(o/'green-preparation.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=dst,text=True).strip(),'seconds':time.monotonic()-t,'fullSourcePresent':True,'ownBuild':True,'sourcePreflightPass':True},indent=2)+'\n')
print('CANDIDATE_READY; starting same complete command',flush=True)
subprocess.run(['python3','output/core-two-repair/run-full.py','green'],cwd=r,check=True)
