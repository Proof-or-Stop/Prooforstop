from pathlib import Path
import json,re,hashlib,statistics
r=Path.cwd();o=r/'output/core-two-repair'
rows={}
for arm in ['red','green']:
 receipt=json.loads((o/(arm+'-full-execution.json')).read_text());log=(o/(arm+'-full.log')).read_text()
 assert receipt['exitCode']==0 and not any(x.startswith('FAIL') for x in log.splitlines()),arm+' must pass completely'
 mutations=[]
 for line in log.splitlines():
  if line.startswith('PASS exact public identity mutation '):
   m=re.fullmatch(r'PASS exact public identity mutation (.+) \((consumer-source|origin-only)\) elapsedMs=(\d+)',line);assert m,line
   mutations.append({'id':m[1],'kind':m[2],'ms':int(m[3])})
 assert len(mutations)==250 and len({(x['id'],x['kind']) for x in mutations})==250
 controls=[re.sub(r' elapsedMs=\d+','',line) for line in log.splitlines() if line.startswith('PASS ') and not line.startswith('PASS exact public identity mutation ') and not line.startswith('PASS canonical public operation timing ')]
 observers=[json.loads(line.split(' ',1)[1]) for line in log.splitlines() if line.startswith('IDENTITY_OBSERVER_STATS ')]
 rows[arm]={**receipt,'mutationCases':len(mutations),'caseIdentityDigest':hashlib.sha256(json.dumps(sorted((x['id'],x['kind']) for x in mutations)).encode()).hexdigest(),'mutationSumMs':sum(x['ms'] for x in mutations),'mutationMedianMs':statistics.median(x['ms'] for x in mutations),'controls':controls,'observerStats':observers,'logSha256':hashlib.sha256((o/(arm+'-full.log')).read_bytes()).hexdigest()}
assert rows['red']['caseIdentityDigest']==rows['green']['caseIdentityDigest']
assert rows['red']['controls']==rows['green']['controls'],'all canonical and non-mutation PASS controls must match'
assert rows['red']['argv']==rows['green']['argv']
ratio=rows['green']['elapsedSeconds']/rows['red']['elapsedSeconds']
result={'scope':'One complete identity-cutover command pair on this shared host; main baseline then candidate; no Story lead-time or population estimate','rows':rows,'same250Cases':True,'sameOtherControls':True,'reductionPercent':(1-ratio)*100,'performancePilotPass':ratio<=.85,'thresholdReductionPercent':15,'limitations':['One pair, fixed order, shared-host load not controlled.','Preparation is reported separately; failed/cancelled attempts are experiment cost, not successful baseline observations.','Baseline and candidate source differ by the reviewed Lab repair and earlier query repair; no validation command, timeout or registered mutation is dropped.']}
(o/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'redSeconds':rows['red']['elapsedSeconds'],'greenSeconds':rows['green']['elapsedSeconds'],'reductionPercent':result['reductionPercent'],'pilotPass':result['performancePilotPass']}))
