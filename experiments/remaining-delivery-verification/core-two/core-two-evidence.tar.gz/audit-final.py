from pathlib import Path
import subprocess,json,time,os,signal,hashlib
out=Path(__file__).parent/'claude-final-data-audit';out.mkdir(exist_ok=True)
r=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910')
files=['packages/main/tests/support/private-mutation-observer.mjs','packages/main/tests/core-two-repair.test.mjs','packages/main/tests/canonical-new-story-artifacts.test.mjs','packages/main/src/core/execution-implementation.ts','packages/main/src/core/runtime-fact-registry.ts','scripts/implementation-session.mjs','docs/validation-performance.md','scripts/verify-proof-or-stop-identity-cutover.mjs','scripts/verify-runtime-fact-contract.mjs']
def hashes():return {x:hashlib.sha256((r/x).read_bytes()).hexdigest() for x in files}
before=hashes();(out/'input-manifest.json').write_text(json.dumps(before,indent=2)+'\n')
diff=subprocess.check_output(['git','diff','e97ec3b89c','--',*files],cwd=r,text=True);(out/'candidate.diff').write_text(diff)
commands=[f'node {r}/packages/main/tests/core-two-repair.test.mjs','proof-or-stop --implementation-identity','proof-or-stop-codex --implementation-identity',f'proof-or-stop --root {r} aux_doc_list',f'proof-or-stop-codex --root {r} aux_doc_list',f'node {r}/scripts/verify-proof-or-stop-identity-cutover.mjs --print-residue',f'python3 {out.parent}/verify-archive.py']
prompt=f'''Independently audit FINAL DATA and the last small source follow-up for the user's two core Lab repairs. No repository edits, new Stories, full-suite replay, or timing reruns. Sources are at {r}. Read {r}/output/core-two-repair/comparison.json, red-full-execution.json, green-full-execution.json, BOTH entire red-full.log and green-full.log, run-full.py, derive-comparison.py and PLAN.md at experiments/remaining-delivery-verification/core-two. Also read binding-timing.json and owner-final-witnesses.json in {out.parent}. Do not merely run the developer's derivation: use your own inline python3 -c (allowed) to recompute total seconds, all250 consumer/origin case identities, other PASS controls, case elapsed sums, candidate observer snapshot counts and overhead timing medians from original records. Verify complete exit0 logs and no lost cases; the before/after comparison is one same-command pair on this shared host, main442f6f38 then candidate d23b898be9. Performance threshold was frozen at15percent before any valid pair. Original failed/cancelled preparation attempts remain in output/core-two-repair; they are not successful timing samples. Snapshot500 on baseline is derived from250 passed cases and two source calls; candidate count is instrumented. Never label that baseline count a new physical IO measurement. Source/preparation overheads and fixed-order/shared-host confounds must remain visible, and this is NOT whole-Story delivery-time proof or fleet migration.
Run each of these exact commands without pipelines: {json.dumps(commands)}. You were launched through epoch-3.json. Independently verify ordinary/Codex witness digest membership and implementation inventory agreement with their own entry pins; compare your actual child witnesses to owner-final-witnesses.json. No clearing inherited bindings except the deliberate isolated negative children inside core-two-repair.test.mjs. This proves enrolled Lab owner/reviewer CLI use, not all foreign sessions or continuous loaded-code immutability.
Prior source audit and follow-up are in {out.parent}/claude-audit and claude-followup. Follow-up verdict PASS accepted A-1/B-1/B-2 with a residual low F-1. The ONLY subsequent logic change rejects incomplete single-entry cohort manifests before host launch; its regression and doc were updated. Inspect implementation-session.mjs ~35-48 and core-two-repair.test.mjs 'incomplete cohort'/'both canonical host' controls to close that residual. verify-archive.py prints derived occurrence counts now. The archive contains exactly six old raw transcript files matching prior Git bytes; no source scan predicate was relaxed. Read source diffs if needed via candidate.diff. Confirm no new unresolved applicability findings. Return PASS or NEEDS-REVISION, specific findings, calculations you personally performed, exact applicable scope and limits, within900words/10minutes. Please include measured reduction and candidate full snapshot count in summary so the user can verify the conclusion.'''
(out/'prompt.txt').write_text(prompt)
schema={'type':'object','properties':{'verdict':{'type':'string','enum':['PASS','NEEDS-REVISION']},'findings':{'type':'array','items':{'type':'object','properties':{'id':{'type':'string'},'severity':{'type':'string'},'location':{'type':'string'},'problem':{'type':'string'},'correction':{'type':'string'}},'required':['id','severity','location','problem','correction']}},'executed':{'type':'array','items':{'type':'string'}},'limitations':{'type':'array','items':{'type':'string'}},'summary':{'type':'string'}},'required':['verdict','findings','executed','limitations','summary']}
claude=['claude','--print','--verbose','--output-format','stream-json','--no-session-persistence','--permission-mode','dontAsk','--allowedTools','Read,Glob,Grep,Bash(python3 -c *),'+','.join('Bash('+c+')' for c in commands),'--tools','Read,Glob,Grep,Bash','--add-dir',str(r),'--json-schema',json.dumps(schema)]
args=['node',str(r/'scripts/implementation-session.mjs'),'exec',str(out.parent/'epoch-3.json'),'--',*claude]
t=time.monotonic()
with (out/'stream.jsonl').open('w') as log,(out/'stderr.log').open('w') as err:
 p=subprocess.Popen(args,cwd=out,stdin=subprocess.PIPE,stdout=log,stderr=err,text=True,start_new_session=True)
 try:p.communicate(prompt,timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
events=[]
for line in (out/'stream.jsonl').read_text().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
final=next((x for x in reversed(events) if x.get('type')=='result'),{})
audit=final.get('structured_output')
if audit:(out/'audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
result={'exitCode':p.returncode,'seconds':time.monotonic()-t,'inputsUnchanged':hashes()==before,'auditPresent':audit is not None,'verdict':audit.get('verdict') if audit else None}
(out/'execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
