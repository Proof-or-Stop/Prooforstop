from pathlib import Path
import os,subprocess,json,time,hashlib,statistics
r=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910');o=Path(__file__).parent;manifest=o/'epoch-3.json';m=json.loads(manifest.read_text());env=dict(os.environ)
for k in ['PROOF_OR_STOP_IMPLEMENTATION_MANIFEST','PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST','PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN']:env.pop(k,None)
rows=[]
for entry in m['entrypoints']:
 for pair,order in enumerate([['disabled','required'],['required','disabled'],['disabled','required']],1):
  for mode in order:
   e=dict(env)
   if mode=='required':e['PROOF_OR_STOP_IMPLEMENTATION_MANIFEST']=str(manifest)
   start=time.monotonic();p=subprocess.run(['node',entry['entrypoint'],'--version'],cwd=r,env=e,capture_output=True,text=True);seconds=time.monotonic()-start
   assert p.returncode==0,p.stderr
   witnesses=[json.loads(x.split(' ',1)[1]) for x in p.stderr.splitlines() if x.startswith('IMPLEMENTATION_SESSION_WITNESS ')]
   assert len(witnesses)==(1 if mode=='required' else 0)
   if witnesses:assert witnesses[0]['digest']==entry['digest']
   rows.append({'entrypoint':entry['entrypoint'],'pair':pair,'mode':mode,'seconds':seconds,'exitCode':p.returncode,'stdoutSha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'witness':witnesses[0] if witnesses else None})
assert len({x['stdoutSha256'] for x in rows})==1
medians={entry['entrypoint']:{mode:statistics.median(x['seconds'] for x in rows if x['entrypoint']==entry['entrypoint'] and x['mode']==mode) for mode in ['disabled','required']} for entry in m['entrypoints']}
result={'scope':'Binding overhead in the candidate runtime, disabled vs required; reconstructed activation comparison, not old vs new shipped binaries. Three alternating pairs per entry; same --version result. No repair-speed or Story-time claim.','mediansSeconds':medians,'rows':rows}
(o/'binding-timing.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(medians))
