from pathlib import Path
import subprocess,json,time,os,signal,hashlib
out=Path(__file__).parent/'claude-followup';out.mkdir(exist_ok=True)
r=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910')
files=['packages/main/tests/support/private-mutation-observer.mjs','packages/main/tests/core-two-repair.test.mjs','packages/main/tests/canonical-new-story-artifacts.test.mjs','packages/main/src/core/execution-implementation.ts','packages/main/src/core/runtime-fact-registry.ts','scripts/implementation-session.mjs','docs/validation-performance.md','scripts/verify-proof-or-stop-identity-cutover.mjs','scripts/verify-runtime-fact-contract.mjs']
def hashes():return {x:hashlib.sha256((r/x).read_bytes()).hexdigest() for x in files}
before=hashes();(out/'input-manifest.json').write_text(json.dumps(before,indent=2)+'\n')
diff=subprocess.check_output(['git','diff','e97ec3b89c','--',*files],cwd=r,text=True);(out/'candidate.diff').write_text(diff)
commands=[f'node {r}/packages/main/tests/core-two-repair.test.mjs','proof-or-stop --implementation-identity',f'proof-or-stop-codex --root {r} aux_doc_list',f'node {r}/scripts/verify-proof-or-stop-identity-cutover.mjs --print-residue',f'python3 {out.parent}/verify-archive.py']
prompt=f'''Perform a bounded independent follow-up of the prior three findings in {out.parent}/claude-audit/audit.json. Inspect current source, not just developer claims. No edits. Run these exact commands without pipelines: {json.dumps(commands)}. Your host is launched through epoch-2.json. Verify actual ordinary and canonical Codex command witnesses each match their own manifest entry. The two entry wrapper bytes differ; the captured implementation inventories must agree. Run core-two-repair.test.mjs: expected 20 controls including dangling symlinks, same-version helper mutation in a private copy, wrong entry/digest/manifest, both canonical host shims, and refusal to overwrite capture.
B-1 repair: manifest now explicitly contains both canonical entries with independent digests; core chooses the actual entry, keeps explicit-pin conflicts, required pin prevents old runtimes ignoring manifest, launcher makes both PATH shims. Check for lost checks or unsafe fallback.
A-1 repair: realpath failures conservatively take fresh snapshots, with actual dangling-symlink control.
B-2 disposition: docs explicitly call argument SHA-256 a correlation token and disclose dictionary guesses; no confidentiality is claimed. Developer did not add a public salt because a published digest/nonce would not prevent dictionary guessing. Assess whether that precise disclosure resolves the presentation issue rather than demanding cosmetic security.
Additional coupled changes require review: three existing exact source hashes in verify-proof-or-stop-identity-cutover.mjs are updated only to bind the reviewed test and runtime-contract changes, without deleting any case or relaxing verifier rules. Six old raw provider/query transcripts introduced by earlier Lab work were incorrectly scanned as active product commands. They are archived byte-for-byte with original paths and SHA256, leaving reports readable. verify-archive.py independently compares archive contents with git ccbc0a1784 and validates the three current source witness hashes; --print-residue must report []. This is source/evidence packaging repair, not permission to omit runtime tests. All original failures/cancellations are retained.
Complete baseline/candidate identity-cutover timing is still running separately. Do NOT certify a speed percentage or 250-case execution result now. Check code that still runs all250 and always checks full after-state; full data gets a final audit later. Return PASS or NEEDS-REVISION, concrete findings, actual commands executed, and remaining limits, under700words and10minutes. All project paths are beneath {r}.'''
(out/'prompt.txt').write_text(prompt)
schema={'type':'object','properties':{'verdict':{'type':'string','enum':['PASS','NEEDS-REVISION']},'findings':{'type':'array','items':{'type':'object','properties':{'id':{'type':'string'},'severity':{'type':'string'},'location':{'type':'string'},'problem':{'type':'string'},'correction':{'type':'string'}},'required':['id','severity','location','problem','correction']}},'executed':{'type':'array','items':{'type':'string'}},'limitations':{'type':'array','items':{'type':'string'}},'summary':{'type':'string'}},'required':['verdict','findings','executed','limitations','summary']}
claude=['claude','--print','--verbose','--output-format','stream-json','--no-session-persistence','--permission-mode','dontAsk','--allowedTools','Read,Glob,Grep,'+','.join('Bash('+c+')' for c in commands),'--tools','Read,Glob,Grep,Bash','--add-dir',str(r),'--json-schema',json.dumps(schema)]
args=['node',str(r/'scripts/implementation-session.mjs'),'exec',str(out.parent/'epoch-2.json'),'--',*claude]
t=time.monotonic()
with (out/'stream.jsonl').open('w') as log,(out/'stderr.log').open('w') as err:
 p=subprocess.Popen(args,cwd=out,stdin=subprocess.PIPE,stdout=log,stderr=err,text=True,start_new_session=True)
 try:p.communicate(prompt,timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
events=[]
for line in (out/'stream.jsonl').read_text().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
final=next((x for x in reversed(events) if x.get('type')=='result'),{})
audit=final.get('structured_output')
if audit:(out/'audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
result={'exitCode':p.returncode,'seconds':time.monotonic()-t,'inputsUnchanged':hashes()==before,'auditPresent':audit is not None,'verdict':audit.get('verdict') if audit else None}
(out/'execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
