from pathlib import Path
import json,tarfile,hashlib,subprocess,re
r=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910');d=r/'experiments/remaining-delivery-verification';m=json.loads((d/'historical-raw-transcripts.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((d/m['archive']).read_bytes())==m['sha256']
with tarfile.open(d/m['archive']) as t:
 assert {x.name for x in t.getmembers()}==set(m['files'])
 for x in t.getmembers():
  b=t.extractfile(x).read();assert sha(b)==m['files'][x.name]
  assert b==subprocess.check_output(['git','show','ccbc0a1784:'+x.name],cwd=r)
s=(r/'scripts/verify-proof-or-stop-identity-cutover.mjs').read_text()
a=sha((r/'packages/main/tests/canonical-new-story-artifacts.test.mjs').read_bytes());b=sha((r/'scripts/verify-runtime-fact-contract.mjs').read_bytes());assert s.count(a)==2 and s.count(b)==1
print(json.dumps({'archiveExactFiles':len(m['files']),'matchesPriorGitBytes':True,'testSourceHashOccurrences':s.count(a),'runtimeContractHashOccurrences':s.count(b)}))
