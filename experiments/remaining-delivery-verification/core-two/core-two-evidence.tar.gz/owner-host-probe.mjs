import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const manifest=JSON.parse(readFileSync(process.env.PROOF_OR_STOP_IMPLEMENTATION_MANIFEST,'utf8'));
const root='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910';
const results=[];
for(const executable of ['proof-or-stop','proof-or-stop-codex']) {
 const args=['--root',root,'aux_doc_list'];const started=performance.now();
 const result=spawnSync(executable,args,{encoding:'utf8',maxBuffer:2*1024*1024});
 const witnesses=result.stderr.split('\n').filter(s=>s.startsWith('IMPLEMENTATION_SESSION_WITNESS ')).map(s=>JSON.parse(s.slice('IMPLEMENTATION_SESSION_WITNESS '.length)));
 if(result.status!==0||witnesses.length!==1)throw new Error('actual owner CLI admission failed: '+result.stderr);
 const witness=witnesses[0];
 if(!manifest.entrypoints.some(row=>row.entrypoint===witness.entrypoint&&row.digest===witness.digest))throw new Error('wrong admitted identity');
 if(witness.argvDigest!==createHash('sha256').update(JSON.stringify(args)).digest('hex'))throw new Error('wrong argument correlation');
 results.push({executable,args,seconds:(performance.now()-started)/1000,exitCode:result.status,witness,stdoutSha256:createHash('sha256').update(result.stdout).digest('hex')});
}
console.log(JSON.stringify({scope:'actual developer CLI commands in the enrolled Lab host; runtime diagnostics, not signed Story role credentials',results},null,2));
