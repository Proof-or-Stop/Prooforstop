**本地核验入口**

工作区：`/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910`。
本包保留已实际执行的准备/运行脚本、原始日志、失败/取消记录和全部三轮Claude审查。

先核对包的`SHA256SUMS.json`，再在Lab运行：

```sh
node packages/main/tests/core-two-repair.test.mjs
node scripts/verify-runtime-fact-contract.mjs
node scripts/verify-process-fact-contract.mjs
npm run lab:worktree -- status remaining-delivery-verification-20260910
```

接入新的、明确批准的实现 epoch（必须选尚不存在的文件）：

```sh
node scripts/implementation-session.mjs capture /tmp/my-new-implementation-epoch.json
node scripts/implementation-session.mjs exec /tmp/my-new-implementation-epoch.json -- proof-or-stop-codex --version
node scripts/implementation-session.mjs exec /tmp/my-new-implementation-epoch.json -- claude
```

这是显式启动接入，不能改写已有宿主进程的环境。实现变化后旧清单拒绝；不要自动重写清单掩盖变化。

完整基准的原命令为：

```sh
node packages/main/tests/canonical-new-story-artifacts.test.mjs --group=identity-cutover
```

应在独立的完整Git副本中分别检出main442f6f38和候选d23b898be9；安装/复用匹配锁文件的依赖，独立构建main、utils和Lab包。不能共享可写dist，不能将整个源副本设为稀疏检出后直接运行全源码验证。测试内部已有受限稀疏夹具，其范围无需改变。

原试验的两个冻结副本仍在Lab的`output/core-two-repair/red-runtime`及`green-runtime`。
测试信任文件在执行前从本仓库Git公共目录复制到私有副本，结束后删除，文件内容不入包。没有保留对应信任根的新克隆不能伪称完全复现了历史签名用例。

实际执行的脚本见包内`evidence/baseline-ready.py`、`run-full.py`和`run-candidate-when-ready.py`。它们包含本次固定工作区路径，且会写试验文件；复跑请使用新的输出目录并调整这些路径，不要覆盖本包。完整基准至少需要两条长命令的时间；不要把20项短回归当成完整耗时复现。

原数据独立核算可读取`evidence/derive-comparison.py`；它仅重算已记录结果。Claude的独立Python计算和实际CLI调用在`claude-final-data-audit/stream.jsonl`中。基线500次快照为执行结构推导，候选315次为实际计数，不能混写。

`candidate.bundle`是相对main442f6f38的本地分支增量，不含私有密钥、依赖或构建副本。不要自动合并main或发布版本；当前任务只授权Lab修复和验证。
