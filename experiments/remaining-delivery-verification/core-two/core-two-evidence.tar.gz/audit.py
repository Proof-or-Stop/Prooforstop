from pathlib import Path
import subprocess,json,time,os,signal,hashlib
out=Path(__file__).parent/'claude-audit';out.mkdir(exist_ok=True)
r=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-remaining-delivery-verification-20260910')
files=['packages/main/tests/support/private-mutation-observer.mjs','packages/main/tests/core-two-repair.test.mjs','packages/main/tests/canonical-new-story-artifacts.test.mjs','packages/main/src/core/execution-implementation.ts','packages/main/src/core/runtime-fact-registry.ts','scripts/implementation-session.mjs','docs/validation-performance.md']
def hashes():return {x:hashlib.sha256((r/x).read_bytes()).hexdigest() for x in files}
before=hashes();(out/'input-manifest.json').write_text(json.dumps(before,indent=2)+'\n')
diff=subprocess.check_output(['git','diff','e97ec3b89c','--',*files],cwd=r,text=True);(out/'candidate.diff').write_text(diff)
commands=[f'node {r}/packages/main/tests/core-two-repair.test.mjs','proof-or-stop --implementation-identity',f'proof-or-stop --root {r} aux_doc_list']
prompt=f'''Independently audit these two bounded Lab repairs. You are the reviewer; the developer must repair your applicable findings. Read {out}/candidate.diff and the helper, session launcher, execution-implementation source and regression test listed in input-manifest.json (absolute paths beneath {r}). No code edits. Run each of these EXACT shell commands, with no pipelines: {json.dumps(commands)}. You were launched through the candidate implementation-session transport, so ordinary proof-or-stop commands MUST show IMPLEMENTATION_SESSION_WITNESS, and the actual digest must equal {json.loads((out.parent/'epoch-1.json').read_text())['digest']}. Check your actual command output, not this expected string alone. Do not clear inherited pin variables, use global fallback, create Stories, or change any repository state. The node regression intentionally clears inherited pins only inside its isolated negative-control children.
Audit A: the expensive identity test now reuses an immutable complete baseline for ignored compiled-file injections only, with full after-state hashing EVERY operation; tracked/project/config inputs retain before+after. Are any checked mutations or canonical public operations lost? Review exact caller integration at canonical-new-story-artifacts.test.mjs ~3460-3630; it still executes all 250 cases. Detect between-operation drift, tracked ignored files, symlinks, and protected state corruption. No stat-only hash cache, sparse omission expansion or test deletion was introduced. Full old/new same-suite timing is running separately; do NOT certify a speed percentage yet.
Audit B: durable explicit manifest binding, inherited required pin, absolute CLI PATH shim, actual admitted digest diagnostic, stale/foreign/missing refusal, no implicit repinning or takeover. This covers enrolled local owner/reviewer child commands, NOT all existing foreign Story sessions, hostile hosts, continuously immutable loaded code, or signed Story role authority. Inspect errors, bypass via ordinary usage, and argument confidentiality. Parent admission alone cannot prove reviewer adoption. Return PASS or NEEDS-REVISION with concrete applicable findings and what you personally executed. Limit response to 700 words, under 10 minutes. Original scenario RED had 8 snapshots for4 operations and accepted wrong/missing manifests; expanded checks should now pass. All original 250 real identity cases and full output will be audited after timing completes; report that boundary clearly.'''
(out/'prompt.txt').write_text(prompt)
schema={'type':'object','properties':{'verdict':{'type':'string','enum':['PASS','NEEDS-REVISION']},'findings':{'type':'array','items':{'type':'object','properties':{'id':{'type':'string'},'severity':{'type':'string'},'location':{'type':'string'},'problem':{'type':'string'},'correction':{'type':'string'}},'required':['id','severity','location','problem','correction']}},'executed':{'type':'array','items':{'type':'string'}},'limitations':{'type':'array','items':{'type':'string'}},'summary':{'type':'string'}},'required':['verdict','findings','executed','limitations','summary']}
claude=['claude','--print','--verbose','--output-format','stream-json','--no-session-persistence','--permission-mode','dontAsk','--allowedTools','Read,Glob,Grep,'+','.join('Bash('+c+')' for c in commands),'--tools','Read,Glob,Grep,Bash','--add-dir',str(r),'--json-schema',json.dumps(schema)]
args=['node',str(r/'scripts/implementation-session.mjs'),'exec',str(out.parent/'epoch-1.json'),'--',*claude]
t=time.monotonic()
with (out/'stream.jsonl').open('w') as log,(out/'stderr.log').open('w') as err:
 p=subprocess.Popen(args,cwd=out,stdin=subprocess.PIPE,stdout=log,stderr=err,text=True,start_new_session=True)
 try:p.communicate(prompt,timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
events=[]
for line in (out/'stream.jsonl').read_text().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
final=next((x for x in reversed(events) if x.get('type')=='result'),{})
audit=final.get('structured_output')
if audit:(out/'audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
result={'exitCode':p.returncode,'seconds':time.monotonic()-t,'inputsUnchanged':hashes()==before,'auditPresent':audit is not None,'verdict':audit.get('verdict') if audit else None}
(out/'execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
