本包是未集成的Proof-or-Stop五项Lab候选与工程证据，不是正式Story DONE或发布许可。

先读report.md、evidence/evidence-scope.md和evidence/claude-completion-audit/report.md。所有原始失败与范围限制保留；不要相加各阶段百分比，不要推导48%或全部Story已提速。

源码基线为cf21df09c273074d7aa3227a5f436c6f5badf47a，候选commit见verification.json。可在一个新的私有checkout中从该基线运行git apply --check candidate.patch，再应用补丁；或者在已有基线对象的私有仓库中读取candidate.bundle。不要对主工作区执行这些步骤。package-verification.json（包外）记录解包与补丁重建结果，包内verification.json记录源码重建；SHA256SUMS校验包内每个文件。

不附本地签名私钥，也不把源机器的本地签名记录变成可跨机器使用的正式授权。复现实验使用自己的临时夹具和签名；历史回执/签名是保留证据，不要导入真实Story。Claude私有思考文本已移除，明确报告、工具调用/返回、时间戳与用量仍保留。sanitization-manifest.json记录源文件与分发文件校验值，说明清理差异。

详见REPRODUCE.md。Node 26为计时环境；固定依赖与Node版本后，在私有副本准备main/utils/graph/lab构建物。默认实验证据脚本位于experiments/five-item-proof。共享运行时必须只读；完整134条验证会运行真实构建与本地writer，因此必须使用单独可写的私有副本。长51分钟试验是真的长运行，不要误当快速单测。

最终全量结果在evidence/full-ordered-comparison/。run-ordered-green.mjs保留此前完整通过的RED，用新的50ca私有副本运行修正构建顺序后的GREEN。两个完整计时均从准备好的构建物开始；cold-prefix.json单独记录删除私有main/dist后实际前三条命令的冷启动。不要把已取消的旧GREEN当最终结果，也不要把前三条冷启动写成全134条冷启动。REPRODUCE.md中的full-complete-comparison.mjs是此前基准驱动；最终补充驱动及取消原因以本段和最终报告为准。

实验固定CF/0.3.284，不跟随当前main。另一个任务期间将main推进至0.3.285，本Lab没有被集成。freeze-runtime.py现在接受明确基线参数；不要把浮动main当作本包的RED基线。

外部实验脚本保存了原机器绝对路径以证明来源。跨机器重跑时应按文档用新的私有路径生成runtime.json/固定入口，而不是假装旧路径仍存在。review-roster-check.py和score-reviews-v2.mjs支持传入解包后的review-benchmark目录；二者可直接重新核验保留的20次审查，无需再调用20次模型。审查校准仍是探索性有限夹具，其历史方法学不能由重新打包修正。

任何main集成、Lab finish、版本升级和push均需另一次明确的集成请求，本包不会执行它们。
