# Build-order sequencing audit — root resource configuration (Lab five-item proof)

Independent bounded audit. Runtime under test: frozen read-only root
`/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-repeat-complete-fmb27fyi/repo`
(134 commands, identical first-three resource rows to Lab source
`.worktrees/Lab-five-item-proof-20260908` @ `f43a8a93ac`).

No mutation of main / Story / Lab source / dist / config / git. No subagents, no full suite,
no production patch. All outputs are in this directory:

| file | content |
|---|---|
| `build-order-control-adapted.mjs` | my adaptation of the sibling reproducer (paths adapted, negative checks added) |
| `build-order-control-adapted.log` | its run log |
| `build-order-audit-results.json` | full per-trial timelines + symbolic 134-row analysis |
| `report.md` | this report |

The sibling `../build-order-control.mjs`, `../build-order-results.json`, `../build-order-control.log`
were read only and are unchanged, as are all other prior results.

## 1. Verdict

**The regression is real and independently reproduced.** The failure is a genuine scheduling
defect in the root resource declarations, not an artifact of the sibling reproducer.

**It is applicable to production.** There is no independent build-freshness precondition
anywhere in the CLI that would make the declaration order irrelevant.

**The existing full 134-command GREEN run does not prove build-order correctness** — it runs
against a prebuilt `packages/main/dist`, which is exactly the condition under which this defect
is invisible. See §5.

## 2. Proven failure

Real `executeValidationPlan` from the frozen root's compiled dist, `jobs: 4`, resource rows copied
verbatim from actual root commands 0/1/2, with bounded substitutes for the command bodies
(read-only precheck 250 ms → build writes a fresh stamp → consumer asserts the stamp is fresh).

Scenario `ok`, RED = actual rows unmodified:

```
ok  RED   allPass=false  codes=[0,0,1]  consumerStartedBeforeBuild=true
    row0 precheck 10:37:23.322Z   row1 build 10:37:23.632Z   row2 consumer 10:37:23.345Z
```

The consumer started **287 ms before the build** and failed with
`consumer must read completed build`.

Scenario `ok`, GREEN = row 0 plus one explicit local exclusive barrier claim:

```
ok  GREEN allPass=true   codes=[0,0,0]  consumerStartedBeforeBuild=false
    row0 10:37:23.724Z → row1 10:37:24.038Z → row2 10:37:24.097Z   (strictly sequential)
```

## 3. Mechanism (read from source, not inferred from timing)

1. `resolveValidationCommandResourceClaims` (`packages/main/src/core/validation-executor.ts:1768-1796`):
   a command that declares **any** resources gets a **shared** `validate-plan-barrier` claim
   prepended; only a command declaring **zero** resources gets the exclusive barrier by default.
2. Root row 0 (`node scripts/verify-lab-worktree.mjs`) declares `packages/main/src` shared and
   `scripts` shared → it receives a **shared** barrier. Row 1 (`npm --prefix packages/main run build`)
   declares the **exclusive** barrier plus exclusive `packages/main/dist`, `packages/utils/dist`, `scripts`.
3. `claimsConflict` (`keyed-scheduler.ts`) conflicts iff canonical keys are equal and either side is
   exclusive. Confirmed symbolically over the real config: the build conflicts with **133/133** other
   commands, and **0** of the 134 rows declare an empty resource set.
4. `runScheduled` admission (`keyed-scheduler.ts:164-215`) is
   `const index = pending.findIndex(compatible)` where `compatible` compares only against
   **currently running** entries. Blocked entries are *skipped*, not head-of-line blocking, and the
   plan sets no `priority`. So while row 0 runs, row 1 is blocked by the barrier and the scheduler
   advances to the first compatible pending entry — row 2.

Symbolic result over all 134 actual rows (`build-order-audit-results.json` → `symbolic`):

| | commands that may start before the build |
|---|---|
| RED (current config) | **122** — indices 2, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, … |
| GREEN (row 0 exclusive barrier) | **0** |

After the build, 121 commands remain mutually compatible with row 2 — later readers still run in
parallel, so the fix costs only the serialization that already existed around the build.

## 4. Applicability: is there an independent build-freshness precondition?

No. Checked directly rather than assumed:

- `validation-executor.ts` contains no build-before-plan step and no dist staleness/mtime guard
  (searched for `run build`, `stale`, `freshness`, `mtime` — no hits).
- Row 0 `scripts/verify-lab-worktree.mjs` does **not** build this checkout. It creates `mkdtemp`
  fixture repos and writes its own `package.json` / `build.cjs` / `ensure-dist.mjs` into them; the
  `npm run build` it triggers is inside the fixture. `resource-audit.json` entry 0 classifies it
  `reader-with-isolated-fixtures`, consistent with what the script does.
- Consequently nothing but plan sequencing keeps the ~121 compiled `packages/main/dist/**` commands
  from reading a stale `dist`, and sequencing is currently not established by the declarations.

## 5. Why the current full 134 GREEN must not be cited as proof of build-order correctness

The prepared run starts from an already-current `packages/main/dist`. A consumer that starts before
the build then reads *correct* bytes anyway, so the defect produces no failure. The prepared-dist
run therefore cannot distinguish "ordered correctly" from "unordered but lucky". Only a run from an
absent/known-stale `packages/main/dist` would exercise the precondition. I do not certify the
existing 134-command GREEN as evidence of build ordering, and this report does not disturb it.

## 6. Added negative checks (missing / failed / old build)

New in this audit; all use the same actual resource rows.

| scenario | RED | GREEN |
|---|---|---|
| `ok` — build publishes fresh stamp | allPass=**false** `[0,0,1]` | allPass=**true** `[0,0,0]` |
| `missing` — build produces no artifact | allPass=**true** `[0,0,0]` | allPass=**false** `[0,0,1]` |
| `failed` — build exits 2 | allPass=false `[0,2,1]` | allPass=false `[0,2,1]` |
| `old` — build writes an outdated stamp | allPass=false `[0,0,1]` | allPass=false `[0,0,1]` |

Three things worth stating explicitly:

- **`missing`/RED passing is a second, independent demonstration of the same defect**, in the more
  dangerous direction: the existence check ran before the build removed the artifact and therefore
  reported PASS on a build output that did not exist. The current ordering can make checks pass
  vacuously, not only fail.
- **`failed`/GREEN keeps `[0,2,1]`.** The barrier does not mask a failing build; under `run-all` the
  build's exit code 2 and the consumer's failure are both reported.
- **`old`/GREEN still fails.** GREEN is not vacuous — it does not make consumers pass regardless of
  what the build produced. It only fixes *when* they run.

In every GREEN arm `consumerStartedBeforeBuild=false`; in every RED arm it is `true`.

## 7. Recommended fix (smallest correct change)

**Add one claim to `proof-or-stop.config.json` command index 0 only**, keeping its two existing
shared claims:

```json
{ "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" }
```

so row 0 becomes:

```json
"resources": [
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/src", "access": "shared" },
  { "class": "fixed-path", "key": "scripts", "access": "shared" }
]
```

Every row carries at least a shared barrier claim, so row 0 then excludes all 133 others, the build
follows alone, and rows 2+ resume full parallelism. This is sufficient: no API, scheduler or global
refactor is needed, because the first precheck's own exclusive barrier is what establishes
precheck → build sequencing.

**Preferred over reordering the build to index 0.** Reordering also fixes the symptom, but it moves
the 290 s build ahead of the cheap 180 s infra precheck (losing the fail-fast gate), it perturbs the
plan indices that existing audit records and evidence are keyed to, and it leaves the general hazard
in place for any future first-position read-only command. The barrier claim preserves the required
`first precheck → build → other checks` shape exactly.

### Contract / audit consequences (conservative supersession record)

`resource-audit-policy.mjs::verifyResourceAudit` asserts
`deepEqual(command.resources, supersession?.effectiveResources ?? entry.suggestedResources)`.
Entry `commandIndex: 0` is currently `recommendation: "safe-to-declare-shared"` with the two shared
claims as `suggestedResources`, so adding the barrier without a record trips `RESOURCE_AUDIT_DRIFT: 0`.
Add to entry 0:

```json
"supersededBy": {
  "classification": "exclusive-local-writer",
  "reference": "<this audit / build-order ticket>",
  "effectiveResources": [
    { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
    { "class": "fixed-path", "key": "packages/main/src", "access": "shared" },
    { "class": "fixed-path", "key": "scripts", "access": "shared" }
  ]
}
```

Both originally suggested claims are retained, so `RESOURCE_AUDIT_WITHDRAWN_CLAIM` stays clear.
Note the honest wrinkle the record must carry: **command 0 is still read-only**; the existing
`exclusive-local-writer` label is the only classification the policy accepts and here it means a
*scheduling* precondition (must precede the build), not a claim that the command writes. I recommend
reusing the existing label plus an explicit observation string rather than extending the policy enum,
so the policy file itself is untouched.

Counter update in `experiments/five-item-proof/resource-config.mjs` (predicted from the policy's
counting rules; **not executed here**): the summary assertion becomes
`{auditedReaders: 21, effectivelySharedReaders: 14, supersededReaders: 7}` — entry 0 moves from
effectively-shared to superseded — and the limitations text ("six were superseded … fifteen
effectively shared") needs the same one-for-one adjustment. The writer-barrier list
`[1,3,6,40,79,80,81,82,83,105,125]` is unaffected and was verified still intact; optionally add `0`
to that list to lock the fix against silent removal.

### Constraints honored by the recommendation

All 134 commands retained; timeouts unchanged (row 0 = 180000, row 1 = 290000, row 2 = default);
all 11 routine writer barriers still present; no build-sharing exclusion changed; no production
patch applied in this audit.

## 8. Target verification after the fix (no new broad wave)

1. `node experiments/five-item-proof/resource-config.mjs` with the updated counters — proves the
   audit contract, the supersession record and the retained writer barriers.
2. Re-run `build-order-control-adapted.mjs` taking row 0 **unmodified** from the patched config with
   no injected barrier: the `ok` arm must pass and `consumerStartedBeforeBuild` must be `false`.
   This is the direct target check.
3. Keep the negative arm: with the barrier removed, `ok` must return to `allPass=false` and
   `missing` must return to the vacuous `allPass=true`. Guards against silent regression.
4. Cheap static assertion worth adding to the config test: over all 134 canonicalized rows, no
   command is compatible with command 0 (the `racersBeforeBuildGREEN === 0` check in this audit).
5. Any claim that the **full** suite proves build ordering requires one run started from an
   absent/stale `packages/main/dist`. Until then, state the prebuilt-dist limitation explicitly.

## 9. Scope limits of this audit

- The live trials substitute bounded scripts for the three real command bodies. They prove the
  **scheduling behaviour of the actual declared resource rows** through the actual executor; they do
  not re-execute `verify-lab-worktree.mjs`, `npm run build`, or `milestone-status.test.mjs`.
  Coverage of the real declarations across the whole plan comes from the symbolic 134-row pass,
  which uses the production `resolveValidationCommandResourceClaims` / `canonicalizeEntries` /
  `claimsConflict` on the real config (canonicalization reads the filesystem and git only).
- Ordering timestamps come from the executor's own `runtimeTrace`, at `jobs: 4`.
- Unrelated unproven OS-level risks were not assessed, as instructed.
- Tool-call budget: this audit used 5 investigative calls plus this report write (6 total); the
  extra call was needed because one command's output exceeded the inline limit and had to be
  re-read in condensed form.
