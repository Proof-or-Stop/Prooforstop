// Independent adaptation of ../build-order-control.mjs. Same real executor and real
// root resource rows; adds missing-build / failed-build / stale-build negative checks
// and a symbolic admission pass over all 134 actual commands.
// Writes ONLY into this audit directory.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync,rmSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {execFileSync} from 'node:child_process';
const art=import.meta.dirname;
const FROZEN='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-repeat-complete-fmb27fyi/repo';
const LAB='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const root=existsSync(join(FROZEN,'proof-or-stop.config.json'))?FROZEN:LAB;
const {executeValidationPlan,resolveValidationCommandResourceClaims}=await import(root+'/packages/main/dist/core/validation-executor.js');
const {canonicalizeEntries,claimsConflict}=await import(root+'/packages/main/dist/core/keyed-scheduler.js');
const cfg=JSON.parse(readFileSync(join(root,'proof-or-stop.config.json'),'utf8'));
console.log('runtimeRoot',root,'commands',cfg.validate.commands.length);
assert.equal(cfg.validate.commands.length,134,'ALL_134_RETAINED');
assert.deepEqual(cfg.validate.commands.slice(0,3).map(c=>[c.command,...c.args]),[['node','scripts/verify-lab-worktree.mjs'],['npm','--prefix','packages/main','run','build'],['node','packages/main/tests/milestone-status.test.mjs']]);
const BARRIER={class:'fixed-path',key:'.proof-or-stop/runtime/validate-plan-barrier',access:'exclusive'};

// ---- Part 1: live executor trials on the actual first three resource rows ----
const scenarios={
 'ok':          [`setTimeout(()=>console.log('PRECHECK_DONE'),250)`,`require('fs').writeFileSync('build.txt','fresh');console.log('BUILD_DONE')`,`require('assert').strictEqual(require('fs').readFileSync('build.txt','utf8'),'fresh','consumer must read completed build');console.log('CONSUMER_PASS')`],
 'missing':     [`setTimeout(()=>console.log('PRECHECK_DONE'),250)`,`require('fs').rmSync('build.txt',{force:true});console.log('BUILD_PRODUCED_NOTHING')`,`const fs=require('fs');require('assert').ok(fs.existsSync('build.txt'),'consumer must fail on missing build output');console.log('CONSUMER_PASS')`],
 'failed':      [`setTimeout(()=>console.log('PRECHECK_DONE'),250)`,`console.log('BUILD_FAILED');process.exit(2)`,`require('assert').strictEqual(require('fs').readFileSync('build.txt','utf8'),'fresh','consumer must fail after a failed build');console.log('CONSUMER_PASS')`],
 'old':         [`setTimeout(()=>console.log('PRECHECK_DONE'),250)`,`require('fs').writeFileSync('build.txt','stale');console.log('BUILD_WROTE_OLD_STAMP')`,`require('assert').strictEqual(require('fs').readFileSync('build.txt','utf8'),'fresh','consumer must fail on an old build stamp');console.log('CONSUMER_PASS')`],
};
const trials=[];
for(const [scenario,scripts] of Object.entries(scenarios)) for(const mode of ['RED','GREEN']){
 const fixture=mkdtempSync(join(tmpdir(),'pos-bo-audit-'));
 try{
  execFileSync('git',['init','-q'],{cwd:fixture});writeFileSync(join(fixture,'build.txt'),'stale');
  const commands=cfg.validate.commands.slice(0,3).map((c,i)=>({label:'actual-resource-row-'+i,command:process.execPath,args:['-e',scripts[i]],timeoutMs:3000,resources:c.resources}));
  if(mode==='GREEN')commands[0].resources=[...commands[0].resources,BARRIER];
  const result=await executeValidationPlan({provider:'claude-build-order-audit',commands},fixture,undefined,undefined,{jobs:4});
  const t=result.commands.map(c=>({label:c.label,code:c.code,startedAt:c.runtimeTrace?.startedAt,endedAt:c.runtimeTrace?.endedAt,firstLine:(c.output||'').split('\n')[0]}));
  const consumerBeforeBuild=new Date(t[2].startedAt)<new Date(t[1].startedAt);
  trials.push({scenario,mode,allPass:result.allPass,codes:result.commands.map(c=>c.code),consumerStartedBeforeBuild:consumerBeforeBuild,timeline:t});
  console.log(scenario.padEnd(8),mode.padEnd(5),'allPass='+result.allPass,'codes='+JSON.stringify(result.commands.map(c=>c.code)),'consumerBeforeBuild='+consumerBeforeBuild);
 }finally{rmSync(fixture,{recursive:true,force:true});}
}
const get=(s,m)=>trials.find(t=>t.scenario===s&&t.mode===m);
assert.equal(get('ok','RED').allPass,false,'RED must fail the fresh-build consumer');
assert.equal(get('ok','RED').consumerStartedBeforeBuild,true,'RED must start the consumer before the build');
assert.equal(get('ok','GREEN').allPass,true,'GREEN must pass');
assert.equal(get('ok','GREEN').consumerStartedBeforeBuild,false,'GREEN must order consumer after build');
for(const s of ['missing','failed','old']){assert.equal(get(s,'GREEN').allPass,false,'GREEN must still fail scenario '+s);assert.equal(get(s,'GREEN').consumerStartedBeforeBuild,false,'ordering must hold in '+s);}

// ---- Part 2: symbolic admission over all 134 actual rows (read-only canonicalization) ----
const claimsOf=(c,n,extra=[])=>resolveValidationCommandResourceClaims(extra.length?{...c,resources:[...(c.resources??[]),...extra]}:c,n).claims;
const canon=canonicalizeEntries(cfg.validate.commands.map((c,i)=>({name:String(i),resources:claimsOf(c,String(i))})),root);
const green0=canonicalizeEntries([{name:'0-green',resources:claimsOf(cfg.validate.commands[0],'0-green',[BARRIER])}],root)[0];
const build=canon[1];
const conflictsWithBuild=canon.filter((e,i)=>i!==1&&claimsConflict(e,build)).length;
const racersRed=canon.map((e,i)=>({e,i})).filter(({e,i})=>i>1&&!claimsConflict(e,canon[0])).map(({i})=>i);
const racersGreen=canon.map((e,i)=>({e,i})).filter(({e,i})=>i>1&&!claimsConflict(e,green0)).map(({i})=>i);
const parallelAfterBuild=canon.map((e,i)=>({e,i})).filter(({e,i})=>i>2&&!claimsConflict(e,canon[2])).length;
const noResourceRows=cfg.validate.commands.map((c,i)=>[i,c.resources]).filter(([,r])=>r===undefined||r.length===0).map(([i])=>i);
const hasBarrier=c=>resolveValidationCommandResourceClaims(c,'w').claims.some(r=>r.class==='fixed-path'&&r.key==='.proof-or-stop/runtime/validate-plan-barrier'&&r.access==='exclusive');
const writerBarriers=[1,3,6,40,79,80,81,82,83,105,125].filter(i=>hasBarrier(cfg.validate.commands[i]));
const symbolic={conflictsWithBuild,totalCommands:canon.length,racersBeforeBuildRED:racersRed.length,racersBeforeBuildREDsample:racersRed.slice(0,12),racersBeforeBuildGREEN:racersGreen,parallelWithCommand2AfterBuild:parallelAfterBuild,rowsWithNoDeclaredResources:noResourceRows,retainedWriterBarriers:writerBarriers,timeoutsFirst3:cfg.validate.commands.slice(0,3).map(c=>c.timeoutMs)};
console.log('SYMBOLIC',JSON.stringify(symbolic));
assert.equal(conflictsWithBuild,133,'build must exclude every other command via the barrier');
assert.ok(racersRed.length>0,'RED must admit at least one non-build command alongside command 0');
assert.equal(racersGreen.length,0,'GREEN command 0 must exclude every later command');
writeFileSync(join(art,'build-order-audit-results.json'),JSON.stringify({runtimeRoot:root,scope:'Independent adaptation: real executor + real root rows 0-2, plus missing/failed/old-build negative checks and symbolic admission over all 134 actual rows.',trials,symbolic},null,2)+'\n');
console.log('ADAPTED_BUILD_ORDER_AUDIT_CONFIRMED');
