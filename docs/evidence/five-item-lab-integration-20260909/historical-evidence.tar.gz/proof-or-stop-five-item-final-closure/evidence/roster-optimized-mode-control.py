import importlib.util, sys, pathlib
source=pathlib.Path(sys.argv[1]);base=pathlib.Path(sys.argv[2]);s=importlib.util.spec_from_file_location('roster_subject',source);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
c,o,rows=m.read_roster(base)
try:m.validate(c,None,rows)
except AssertionError:
 print('ROSTER_OPTIMIZED_MODE_GREEN: missing owner refused with Python optimization enabled');sys.exit(0)
print('ROSTER_OPTIMIZED_MODE_RED: imported validator accepted a missing owner under -O; standalone self-controls are a separate defense');sys.exit(1)
