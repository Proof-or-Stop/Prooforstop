import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,symlinkSync,rmSync,existsSync} from 'node:fs';
import {execFileSync,spawnSync} from 'node:child_process';
import {join,dirname} from 'node:path';
import {tmpdir} from 'node:os';
import {performance} from 'node:perf_hooks';
const art=import.meta.dirname,info=JSON.parse(readFileSync(join(art,'root-repeat-complete-runtime.json'),'utf8')),root=info.path,out=join(art,'root-command-repeat-complete');mkdirSync(out,{recursive:true});
const {StoryStore}=await import(root+'/packages/main/dist/core/store.js');
const {listRuntimeArtifactIgnorePatterns}=await import(root+'/packages/main/dist/core/runtime-artifact-registry.js');
const {persistSyntheticAdmittedWindowForTest}=await import(root+'/packages/main/dist/core/certification-window.js');
const {deriveCertificationDomainInputHashes}=await import(root+'/packages/main/dist/handlers/certification-window.js');
const {sharedValidationReuseAllowed}=await import(root+'/packages/main/dist/core/shared-validation-execution.js');
const {resetConfigCache}=await import(root+'/packages/main/dist/core/config.js');
const config=JSON.parse(readFileSync(join(root,'proof-or-stop.config.json'),'utf8'));
const eligible=config.validate.commands.filter(sharedValidationReuseAllowed);assert.equal(eligible.length,1);const command=eligible[0];
assert.deepEqual(command.args,['packages/main/dist/tasks/tool-executed-evidence-receipt-smoke.js']);
const doneOverlap=config.doneRequiredCommands.filter(c=>JSON.stringify([c.command,c.args])===JSON.stringify([command.command,command.args]));assert.equal(doneOverlap.length,0);
const tracer=join(out,'trace-command.mjs');
writeFileSync(tracer,`import {appendFileSync} from 'node:fs';if(process.argv[1]?.endsWith('/tasks/tool-executed-evidence-receipt-smoke.js'))appendFileSync(process.env.FIVE_ITEM_EXECLOG,JSON.stringify({event:'actual-suite-process-start',pid:process.pid,argv:process.argv,at:Date.now()})+'\\n');\n`);
const trials=[];
for(const [pair,modes] of [[1,['RED','GREEN']],[2,['GREEN','RED']]])for(const mode of modes){
 const fixture=mkdtempSync(join(tmpdir(),'pos-root-repeat-')),log=join(out,pair+'-'+mode+'-processes.jsonl');
 let keepFixture=true;
 const git=args=>execFileSync('git',args,{cwd:fixture,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
 const write=(rel,body)=>{mkdirSync(dirname(join(fixture,rel)),{recursive:true});writeFileSync(join(fixture,rel),body);};
 try{
  write('proof-or-stop.config.json',JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives',requirementsDir:'docs/requirements',validate:{dynamic:{mode:'observe'},sharedExecution:mode==='GREEN',commands:[command]}}));
  write('packages/main/package.json',JSON.stringify({name:'@proof-or-stop/core',version:'0.0.0-private-fixture'}));
  symlinkSync(join(root,'packages/main/dist'),join(fixture,'packages/main/dist'),'dir');write('src/add.mjs','export const add=(a,b)=>a+b;\n');write('.gitignore',listRuntimeArtifactIgnorePatterns().join('\n')+'\n');
  git(['init','-q','-b','story/B-labconsumer']);git(['config','user.email','lab@example.test']);git(['config','user.name','Private Lab fixture']);git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);resetConfigCache();
  const store=new StoryStore(fixture),storyId='B-labconsumer';store.writeStory(storyId,{storyId,name:'root-command-repeat-complete',title:'Repeat the exact root-registered eligible command',type:'chore',phase:'TEST',priority:'medium',createdAt:new Date().toISOString()});store.writeChecklist(storyId,{items:[]});persistSyntheticAdmittedWindowForTest({store,storyId,projectRoot:fixture,causalInputHashes:deriveCertificationDomainInputHashes(fixture,'HEAD',fixture)});git(['add','.']);git(['commit','-qm','private admission fixture']);
  const started=performance.now(),runs=[];
  for(let n=1;n<=2;n++){
   const target=join(out,pair+'-'+mode+'-'+n+'.json');const env={...process.env,PROOF_OR_STOP_SESSION_ID:'root-repeat-owner',FIVE_ITEM_EXECLOG:log,NODE_OPTIONS:((process.env.NODE_OPTIONS??'')+' --import='+tracer).trim()};
   const result=spawnSync(process.execPath,[join(root,'experiments/five-item-proof/consumer-worker.mjs'),'routine',fixture,target],{cwd:fixture,encoding:'utf8',timeout:240000,env});writeFileSync(target+'.log',result.stdout+result.stderr);assert.equal(result.status,0,result.stdout+result.stderr);const body=JSON.parse(readFileSync(target,'utf8'));runs.push(body);if(!body.allPass)break;
  }
  const processes=existsSync(log)?readFileSync(log,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];const allPass=runs.length===2&&runs.every(r=>r.allPass);if(allPass)assert.equal(processes.length,mode==='GREEN'?1:2,'actual root-suite process count must match reuse claim');
  const row={pair,mode,elapsedMs:performance.now()-started,processes,successfulConsumers:runs.filter(r=>r.allPass).length,allPass,fixture,runs};trials.push(row);writeFileSync(join(out,'results.json'),JSON.stringify({runtime:info,command,trials,rootDoneExactOverlap:0,rootDoneReuseEligible:config.doneRequiredCommands.filter(sharedValidationReuseAllowed).length,scope:'Exact root-registered command and policy, two real routine handler processes, private synthetic admission fixture. No arbitrary witness wrapper and no invented DONE overlap. Full DONE suite/build excluded by policy; this proves applicable repeated routine validation only.'},null,2)+'\n');console.log('ROOT_REPEAT',pair,mode,row.elapsedMs,processes.length,row.allPass);keepFixture=!allPass;
 }finally{if(!keepFixture)rmSync(fixture,{recursive:true,force:true});resetConfigCache();}
}
assert.ok(trials.length===4&&trials.every(r=>r.allPass),'Incomplete or failing trials remain in results; do not claim complete paired success');console.log('ROOT_COMMAND_REPEAT_GREEN');
