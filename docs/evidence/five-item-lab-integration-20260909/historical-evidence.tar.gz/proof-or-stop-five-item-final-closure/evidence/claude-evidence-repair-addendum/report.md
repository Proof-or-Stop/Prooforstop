# Evidence-repair addendum audit — independent Claude CLI

**Scope.** Bounded re-audit of four repair claims raised against the prior sibling reports
(`claude-evidence-audit/report.md`, `claude-final-mechanisms-audit/report.md` findings N6–N9).
Read-only on the Lab worktree; all writes confined to this audit directory and private temp
fixtures. No builds, no full suite, no Story/config/dist/source/git mutation. **The full 134-case
run was not audited here** and no prior negative report is retracted.

## 0. Provenance handshake

| item | value |
|---|---|
| Lab worktree | `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908` |
| HEAD at audit start | `9d4d4b93d3` + 3 uncommitted modifications |
| HEAD at audit end | `f3d0c9c5f0` — *"test: require complete roster evidence and exercise interrupted mirror recovery"* |
| frozen runtime used | `/var/folders/…/pos-frozen-root-reuse-o31fjlkk/repo` |

The three modifications were committed as `f3d0c9c5f0` by the driving session *during* this audit.
That is a bookkeeping change only: `git diff --stat 9d4d4b93d3..HEAD` is byte-for-byte the same set
I inspected uncommitted —

```
 docs/validation-performance.md                     |   2 +-
 experiments/five-item-proof/checkpoint-owner-recovery.mjs |  26 +++++
 experiments/five-item-proof/review-roster-check.py |  117 +++++++++--------
```

**Verified: every source change after `9d4d4b93d3` is evidence harness or documentation.** No file
under `packages/`, `dist/`, config, or Story data changed. The frozen runtime remains `9d4d4b93d3`,
so the controls below exercise the *unmodified* implementation.

---

## 1. Roster checker — `assert` → `require`, all 20 positions, optional output path

**VERDICT: REPAIRED AND INDEPENDENTLY REPRODUCED.**

### What changed

`review-roster-check.py` now defines `require(condition, message)` (`:5–7`) which raises
`AssertionError` unconditionally. **`grep -c '^\s*assert '` → 0**: not one bare `assert` statement
remains in the file. Every one of the 9 validation predicates in `validate()` (`:10–38`) routes
through `require`. The output path is `sys.argv[2]` with the old location as fallback (`:87`), so a
verifier can write outside the artifact tree.

### Reproduction under `-O` (my directory)

```
python3 -O review-roster-check.py <review-benchmark> <my-dir>/roster-verified-audit.json   → exit 0
{'owner': 1, 'reviewers': 20, 'participants': 21,
 'completeFullIdentityMatch': True, 'actualCliExitZero': 20}
controls: 27   all rejected: True
position controls: 20   indices [0 … 19]
```

`diff` against the driver's `roster-verified-v2.json`: **byte-identical.** The artifact is
reproducible by a third party from the retained inputs.

The prior audit's "single-row control coverage" finding is closed: the loop at `:82–85` perturbs
`fileCount` at **every** roster index 0–19 and each perturbation is refused, so full-identity
checking is demonstrated per-position, not just for `rows[0]`.

### Independent import under `-O` — and a correction to the prior claim

I loaded the module via `importlib` under `python3 -O` (`__debug__ = False` confirmed at runtime)
and called `validate()` directly:

```
NO-OWNER REJECTED under -O:        missing or mismatched owner identity
MISSING-REVIEWER REJECTED under -O: missing or extra reviewer
```

**Accuracy note, as instructed.** The earlier audit stated that under `python -O` the *whole CLI*
"would emit the same passing `roster-verified.json` with zero checks performed." That was too
broad. Even the old standalone script kept a non-`assert` self-control: `refused()` raises a bare
`AssertionError('bad roster accepted: …')` when a known-bad roster is accepted, and that raise is
**not** removed by `-O`. So the old script's *CLI path* would have failed loudly under `-O`, not
emitted a silent PASS. The reproducible RED was narrower and is the one that actually mattered:
**an importing consumer calling `validate()` under `-O` got no checking at all** — and
`score-reviews-v2.mjs:8` is exactly such a consumer, invoking the checker with `python3 -O`. The
repair is therefore load-bearing for the real integration, and the prior finding was right about the
defect while overstating its blast radius on the standalone CLI.

---

## 2. Scorer v2 / `scored-results-v2.json` — identity provenance only

**VERDICT: SUPPORTED. Only identity provenance and methodology changed; no finding or timing
content moved.** I did not rerun the scorer (it writes outside this audit directory); I compared
artifacts and source directly.

### Source delta (`score-reviews.mjs` → `score-reviews-v2.mjs`) — 4 hunks, all identity/provenance

| hunk | change |
|---|---|
| `+:6,8–10` | imports `execFileSync`; runs the roster checker under `python3 -O`; asserts `completeFullIdentityMatch===true` and `actualCliExitZero===reviewers` |
| `:49` | `identityParticipants: 1+waves.reduce(…)` → `identityParticipants: roster.participants`; adds `identityRoster` and `methodology` |
| `:51` | writes `scored-results-v2.json` (original artifact untouched); assertion message reworded to "finite fixture" |

No change to defect classification, wave arithmetic, `arm()`, summaries, or details.

### Artifact delta — key-by-key comparison

```
onlyA: []      onlyB: ['identityRoster', 'methodology']
scope IDENTICAL   RED IDENTICAL   GREEN IDENTICAL
identityDigests IDENTICAL   summaries IDENTICAL   details IDENTICAL   passed IDENTICAL
identityParticipants: A=21, B=21
```

Every finding and every timing field is **byte-identical**. The `21` figure is unchanged in value
but changed in *provenance*: formerly a hardcoded `1 + reviews.length` computed without ever opening
`owner-identity.json`; now the return value of a roster validation that reads the owner identity,
matches it against the contract's `runtimeDigest`, and confirms 20 witnessed CLI exit-zero
handshakes. **The prior D4 finding is repaired in the artifact a reader would cite** — this is the
one substantive improvement, and it is confined to identity.

### Limitations that are NOT erased and must still be quoted

- **Post-hoc oracle.** The original scoring oracle was authored after 19/20 reviewer outputs
  existed. `methodology` in v2 says so explicitly. v2 does not and cannot repair this.
- **Preregistration is mutable-mtime-bound.** No content hash, VCS commit or signed timestamp ties
  `preregistered.json` to a point in time. The qualifier rests on evidence weaker than the claim it
  qualifies.
- **Confounded ordering.** All RED waves precede all GREEN waves; arm is an output-path component
  only. The 51.99 s residual is a bound on interpretation, not a measured treatment effect.
- **Exploratory, finite.** Ten-function pure-helper fixture, 8 planted defects, 2 clean controls.
  **No production or universal recall claim is supported**, and no Story-level speed figure (in
  particular the 39.6 % implied by 175.042/442.139) is claimable.

v2 raises identity rigour. It does **not** convert an exploratory calibration into a preregistered
experiment.

---

## 3. Checkpoint owner recovery — N6 and N7

Executed against the frozen `9d4d4b93d3` runtime:

```
CHECKPOINT_TEST_RUNTIME=<frozen> node experiments/five-item-proof/checkpoint-owner-recovery.mjs
→ 10/10 PASS, CHECKPOINT_OWNER_RECOVERY_GREEN 10
```

(Log: `checkpoint-owner-recovery-audit.log`; results JSON: `checkpoint-rerun/`. Matches the driver's
own `owner-second-rename-green.log` exactly.)

### N7 — second-rename EIO — **CLOSED, and the control is genuine**

`checkpoint-owner-recovery.mjs:76–92` does what the prior audit asked for and did not settle for the
external `cpSync`+`renameSync` crash simulation. It rebinds `fs.renameSync` and calls
`syncBuiltinESMExports()` so the **already-imported dist module** sees the patched binding — this is
real injection into the production code path, not a re-implementation. The predicate is narrow
(`source.startsWith(mirror+'.replacement-') && target===mirror`), so it fails **only** the second
rename, after the first succeeded. The binding is restored in a `finally` and re-synced, and
`failures===1` asserts the injection fired exactly once.

Post-failure state asserted, all four points the finding demanded:

- **Original bytes quarantined** — exactly one `.quarantine-` directory, and its
  `000000000001.json` still holds the injected corrupt bytes verbatim.
- **Anchor retained** — `git rev-parse <ref>` equals the pre-attempt anchor.
- **No leaked replacement** — zero `.replacement-` directories remain; mirror absent (the
  fail-closed window N7 described is confirmed to exist).
- **Canonical projection valid** — `store.readChecklist()` deep-equals the snapshot, i.e. the
  authoritative record survives failed publication.
- **Owner retry succeeds** — a fresh `inspect`+`apply` restores the mirror and reaches
  `generation: 2` **without rerunning any verification command** (the control also asserts
  `verificationEvidence === undefined`, so nothing was fabricated).

**Disposition on evidence, not severity:** N7 was correctly classified as an untested fail-closed
boundary. It is now tested, the boundary behaves as designed, and recovery is one governed retry —
not a lost story. **N7 is closed.** The transient "no mirror at all" window is real and remains a
property of the design; it is now documented and evidenced rather than unknown.

### N6 — empty/partial duplicate removal — **CLOSED AS INTENTIONAL, correctly scoped**

The doc change (`docs/validation-performance.md:332`) adds: *"Empty generated directories and
partial sets containing only verified duplicates are deliberately removable: the complete authority
has already been restored."* The control at `:93–97` asserts exactly that — an empty
`.replacement-…` and a partial one (one of the retained generation files) are both removed — while
the pre-existing control at `:70–74` still asserts an unknown file (`operator-note.txt`) is
**retained**.

This resolves N6 the honest way: the guard was never losing data (the finding said so), and the
defect was that the code comment asserted an invariant it satisfied vacuously. The contract is now
stated as what the code actually guarantees — *only contained duplicate records require a
preservation check; emptiness and partialness are safe because the authoritative record is already
fully restored* — and both halves (dispose duplicates / retain unknown) are under control. I confirm
the narrowed contract is sound: nothing is deleted that has not been byte-verified against a
retained generation, and directories with nothing to verify hold nothing to lose. **N6 is closed as
documented intent, not as a silent behaviour change** — the implementation is byte-identical to the
frozen runtime.

---

## 4. N8 and N9 — residual process-model risks

**VERDICT: NO CONCRETE APPLICABLE COUNTEREXAMPLE FOUND UNDER THE DECLARED PROCESS MODEL. BOTH ARE
RETAINED AS OPEN RESIDUAL RISKS. NEITHER IS FIXED, AND NO PRODUCTION PATCH WAS APPLIED.**

Declared model, stated so the residual is falsifiable: standalone controlled *cooperating* Node
workers; hostile `setsid` escapes and kernel-uninterruptible processes are explicitly **not**
covered; the parent full-validation invocation retains its `timeoutMs: 1200000` cap.

### Evidence that bounds, but does not eliminate, the risk

Retained `quorum-signal-green.log`: **12/12 PASS**, including `SIGINT cancels and reaps all
descendants` and `SIGTERM cancels and reaps all descendants`, plus 7 `owned process reaped
worker/descendant` assertions covering failure-driven cancellation. All owned children *and*
descendants are confirmed dead in every arm. *(I read the retained log; I did not re-execute the
quorum controls this session — that is carried evidence, not a fresh reproduction.)*

### N8 — pgid reuse after reap

`terminate()` (`quorum-case-parallel.ts:17–22`) issues `process.kill(-pid,'SIGKILL')` from the
`exit` handler (`:44–49`), i.e. after libuv has already `waitpid`'d the direct child, and swallows
only `ESRCH`. The hazard is structurally real: the guard cannot distinguish "group already gone"
from "pgid recycled by an unrelated group."

**No bounded reproducible control exists under this model.** Triggering it requires the OS to
allocate that exact pid to a *new group leader* inside the microseconds between `waitpid` and the
`kill`. On darwin/Linux pids are handed out sequentially, so this needs a full pid-space wraparound
inside that window — I cannot force it without either a hostile pid-burner racing the reap (outside
the declared model, and still nondeterministic) or faking the pid, which would test my fixture
rather than the code. I therefore **retain N8 as an unreproduced residual** and do not call it fixed.

**On the prior audit's suggested fix — I do not endorse it.** Moving the group kill from `exit` to
`close` would make things *worse* for N8: `close` fires no earlier than `exit` and typically later
(after stdio teardown), so it **widens** the post-reap window in which the pgid is reusable. The
sound fix shapes are to record descendant pids explicitly and signal those, or to use a
kernel-level ownership handle — neither is available portably on darwin, and neither is worth
demanding as ritual against an undemonstrated race. **No change requested.**

### N9 — never-close after group SIGKILL

Installing `SIGINT`/`SIGTERM` handlers (`:29`) makes those signals non-fatal for the parallel run's
duration; termination then depends on every shard's `close` firing, with no internal timeout or
escalation (a second Ctrl-C re-enters `onSignal`).

**No applicable counterexample under the declared model.** SIGKILL to the group is unblockable for
cooperating Node workers, so every pipe holder dies and `close` fires — which is what the 12
controls observe, well inside their 3 s bound. A hang requires precisely the excluded cases: a
descendant that escaped the group via `setsid` and inherited the pipe, or a process wedged in
uninterruptible sleep. Those are out of scope by declaration, and I do **not** certify universal OS
isolation.

The honest residual: **under full validation the 1,200,000 ms row cap bounds any hang externally,
but a direct standalone invocation of the task has no such bound and no internal escalation.** That
is a genuine, if small, reduction in operator control versus default signal disposition. **N9
retained as an unreproduced residual — not fixed.** A bounded wait-then-hard-exit around the
post-signal `Promise.all` would close it cheaply and without the N8 downside, but it is a
recommendation, not a gate.

---

## Verdict

| item | disposition |
|---|---|
| 1 — roster checker `require`, 20 positions, output path | **Repaired, independently reproduced under `-O`, artifact byte-identical.** Prior claim about the standalone CLI restated more narrowly (see §1). |
| 2 — scorer v2 / `scored-results-v2.json` | **Identity provenance only.** All findings and timings byte-identical; `21` now derived from validated owner+roster. Exploratory limits intact. |
| 3 — N6, N7 | **Both closed on evidence.** 10/10 controls green on the frozen runtime; second-rename EIO genuinely injected into the production binding; cleanup contract narrowed to what the code guarantees. |
| 4 — N8, N9 | **Both retained as open residual risks.** No concrete applicable counterexample under the declared process model; no production patch; the previously suggested `close`-side kill is declined as widening the window. |

**What this audit does not establish.** The full 134-case suite was not audited. No claim is made
about all Stories, about production defect recall, or about any 48 %/39.6 % speed figure. Prior
negative reports stand as written. Residual risks N8 and N9 remain open, and the calibration in §2
remains an exploratory finite fixture with a post-hoc oracle and mutable-mtime preregistration.
