# Independent Claude verification — frozen Lab commit 09596536ad

Verifier: Claude CLI, independent of the Codex implementer.
Lab worktree: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`
Frozen commit: `09596536adc0c115fbe851b1766aa6432c89ac55` ("fix: deduplicate capacity claims and preserve publication retries"),
test commits `335c2bbe10` and `6dbef67d53`.
Worktree at start: clean except untracked `AGENTS.override.md`. I wrote no source, dist, main, Story or fixture state,
built nothing, committed nothing, spawned no subagents, and wrote only inside this output directory.

## Verdict

All three narrow targets hold on the frozen commit. I found **no new defect that violates them**.
One cosmetic documentation nit and five scope limits are recorded below; none is acceptance-blocking,
and I did not widen into unproved unrelated API concerns.

## Implementation identity

`sh pinned-lab-cli.sh --implementation-identity` → exit 0.

```
actual b2c35d959cc331fec5a301bfdb2dc3baceb5355d0c9094b18c3575133c36b1ed
frozen b2c35d959cc331fec5a301bfdb2dc3baceb5355d0c9094b18c3575133c36b1ed
match true
fileCount 1637 1637 pkg 0.3.284 0.3.284
fileDiffs 0
```

The digest equals `frozen-implementation-identity.json` and all 1637 per-file digests are identical, so every
dist import below is the pinned implementation, not a rebuild. (Saved: `implementation-identity.json`.)

## Required commands (all exits recorded in `exits.txt`)

| command | exit | log |
|---|---|---|
| `node experiments/five-item-proof/last-closure.mjs` | 0 | `last-closure.log` |
| `node experiments/five-item-proof/publication-restart.mjs` | 0 | `publication-restart.log` |
| `node scripts/verify-runtime-fact-contract.mjs` | 0 | `verify-runtime-fact-contract.log` |
| `sh pinned-lab-cli.sh --implementation-identity` | 0 | `implementation-identity.json` |
| `node claude-negative-control.mjs` (mine) | 1 | `claude-negative-control.log` |
| `node claude-negative-control-2.mjs` (mine, corrected) | 0 | `claude-negative-control-2.log` |
| `node real-capacity-config.mjs` (offered bounded experiment, copied here) | 0 | `real-capacity-config.log` |

Literal tails:

```
CAPACITY_CLAIMS_DEDUP_GREEN {"claims":17,"commands":134}
completed receipt publication retries without another child PASS
BATCH_RETRY_SELECTOR_GREEN
RESOURCE_AUDIT_SUPERSESSION_AND_MUTATION_GUARDS_GREEN
FINAL_REVIEW_REGRESSIONS_GREEN
LAST_CLOSURE_REGRESSIONS_GREEN
CROSS_PROCESS_PUBLICATION_RECOVERY_GREEN
Runtime fact contract verified (entrypoint-authority, cli-entrypoint, global-core-realpath, project-local-bin, node-version, package-version, validate-source, external-reference-policy)
```

`last-closure.mjs` runs `capacity-claim-dedup.mjs` and `final-review-regressions.mjs`, and the latter runs
`batch-retry-selector.mjs` and `resource-audit-contract.mjs` — i.e. the three targets' own regressions are all
inside that one exit-0 run.

## Target 1 — 195 aggregate claims collapse to 17 exact normalized claims

`declaredValidationCapacity` (`packages/main/src/core/validation-execution-lock.ts:831-848`) keeps its original
per-command normalization (validate → resolve cwd → carry class/key/access/ownership) and only appends
`[...new Map(resources.map(c => [JSON.stringify(c), c])).values()]`.

Independently recomputed, not read from Codex output (`claude-negative-control.log`):

```
PASS raw aggregate is 195 and collapses to 17 exact normalized claims :: raw=195 distinct=17 commands=134
PASS every retained claim is first-occurrence order preserved and no key is dropped :: 13 distinct keys
PASS dedup does not weaken a real-config exclusive conflict :: 6 exclusive claims retained
PASS invalid claim in a later command still throws after an all-duplicate command :: validation precedes dedup
PASS a command declaring nothing still disables overlap :: {} returned
PASS ownership-only difference is NOT collapsed :: [{"class":"fixed-path",...,"access":"exclusive"},{"class":"fixed-path",...,"access":"exclusive","ownership":"runner-cleanable"}]
```

I rebuilt the pre-dedup aggregate from the source rule over the real `proof-or-stop.config.json`: 195 records
(1 injected workspace-root exclusive claim + 194 declared across 134 commands), whose *distinct* set is exactly 17,
and the function's output set equals that distinct set element-for-element. So the collapse is exactly
"remove exact duplicates", never a merge of unequal claims. Specifically preserved:

- **validation** — `validateResourceClaims` runs per command *before* dedup, so an invalid class in a later
  command still throws even when an earlier command is nothing but duplicates.
- **ownership** — a plain exclusive claim and a `runner-cleanable` exclusive claim on the same resolved key stay
  two separate claims; only the exact `runner-cleanable` duplicate collapses.
- **resolved cwd** — different command `cwd` values resolve to different keys and never collapse
  (`capacity-claim-dedup.mjs` asserts this on `a/probe` vs `b/probe`; my run confirms no key is dropped).
- **shared vs exclusive** — access is part of the dedup key; the deduped real set still yields
  `claimsConflict === true` for two concurrent real invocations and retains all 6 exclusive claims.
- **maxConcurrent** — still `VALIDATION_EXECUTION_RUNTIME_REQUIREMENTS.declaredInvocationCapacity === 2`;
  an undeclared command still returns `{}` (overlap disabled).

`scripts/verify-runtime-fact-contract.mjs` now also pins the semantics (`duplicateResourceClaims:
'one-per-exact-normalized-claim'`) and executes a live dedup assertion against dist; it passed.

Real admission was exercised, not just the pure function. The offered bounded experiment, copied here and run by me
(`real-capacity-config.log`, `real-capacity-config/results.json`, `sourceCommit 09596536ad`):

```
RED 1 1433.5009170000003 -8
GREEN 1 949.0972500000007 611
GREEN 2 853.1861250000002 538
RED 2 1430.216625 -9
ACTUAL_FULL_DECLARATION_CAPACITY_GREEN
```

Two real child processes in two temporary linked worktrees, admitted through all 134 declarations (the 17-claim
set), each completing 4 real assertion suites: GREEN overlaps (611 ms, 538 ms), the pre-declaration baseline
serializes (overlap −8 ms, −9 ms), in both orderings. Counters are from the child processes' own enter/exit/suite
events, not a ledger cache.

## Target 2 — transient first receipt write retries the same receipt with one child

`executeCausalEvidence` now routes both publications through one helper defined after the reuse early-return:

```ts
const publishCompleted = (write: () => void): void => {
  for (let attempt = 0; attempt < 2; attempt++) {
    try { write(); return; }
    catch (error) { if (attempt === 1) throw error; }
  }
};
```

used for `writeCausalSelectorOutput` (unchanged behavior, refactored out of an inline loop) and — new — for
`writeCausalEvidenceReceipt`, still guarded by `args.receiptStore && receipt.reusable`.

Codex's own regression asserts pass/`calls=1`/`writes=2` and the stored `receiptHash`. My independent controls go
further (`claude-negative-control.log`, `claude-negative-control-2.log`):

```
PASS the retry republishes the SAME signed receipt, not a re-derived one :: receiptHash abab1c91172f identical across both attempts
PASS two consecutive transient faults refuse; there is never a third write or a second child :: writes=2 childCalls=1 published=0
PASS transient output AND receipt faults in one run: one child, two writes each :: childCalls=1 outputWrites=2 receiptWrites=2
PASS a FAILING run is still never published as a reusable receipt :: writes=0 on fail
PASS after a permanent receipt fault the next execution still runs the command (no phantom reuse) :: firstCalls=1 disposition=executed thenReused childCalls=1
```

- Both write attempts receive a **byte-identical deep-equal receipt** (same `receiptHash`, same `executedAt`,
  still `verifyCausalEvidenceReceipt`-valid) — a retry republishes, it does not re-sign or re-time.
- The bound is exactly two attempts: with faults on writes 1 and 2 and a store that would have accepted write 3,
  the call refuses, no third write occurs, the child ran once and nothing is published.
- A permanent receipt fault leaves no publication, so the next execution runs the command again
  (`disposition=executed`) rather than becoming a phantom cache hit; the subsequent execution is then `reused`
  with no additional child.
- Non-PASS results are still never published (`writes=0`), and the output-first ordering is unchanged.

Existing complete-output retry / fallback / late-join behavior is intact: all four `batch-retry-selector.mjs`
checks pass in my run (including "late caller joins the in-flight retry" with `calls=2`, and the three-selector
fallback with `{"fallbackCalls":3}`), and `publication-restart.mjs` reports
`CROSS_PROCESS_PUBLICATION_RECOVERY_GREEN`. Reading the source, publication happens inside the single shared
`executeFresh` promise the batch memoizes, so N batch subscribers still produce at most one publication attempt
pair, not 2N writes.

## Target 3 — config + supersession cannot withdraw an audited claim

`resource-audit-policy.mjs` adds, for every superseded reviewed entry, a subset check that each
`entry.suggestedResources` claim still appears in `supersededBy.effectiveResources`
(`RESOURCE_AUDIT_WITHDRAWN_CLAIM`). I did not settle for the single fixture case Codex added; I enumerated
**every** withdrawal (`claude-negative-control.log`):

```
PASS withdrawing a claim from config+supersession is refused on every superseded entry :: 3:3 6:1 40:4 79:4 81:1 105:3
```

That is all 6 superseded entries × each of their 16 audited claims: for every one, deleting it from both
`proof-or-stop.config.json` and `supersededBy.effectiveResources` is refused. The prior counts are unchanged
(`auditedReaders=21`, `effectivelySharedReaders=15`, `supersededReaders=6`), and the two pre-existing guards
(unapproved extra claim, removed writer barrier) still throw `RESOURCE_AUDIT_DRIFT`.

## Finding (cosmetic, non-blocking)

**N-1 — missing space in the shipped doc sentence.** `docs/validation-performance.md:280` reads
`claims (195 records become17 for the current routine configuration); access,`. The numbers are correct (I
independently recomputed 195 → 17); only the rendering is wrong. Non-blocking, no gate consumes it.

## Limits of this verification

1. **The audit fixture is unsigned, so the retention guard is a within-artifact consistency check.** I proved the
   bound: a *third* coordinated edit that also deletes the claim from `entry.suggestedResources` is accepted:
   `PASS LIMIT: a third coordinated edit of suggestedResources is NOT detected (unsigned audit fixture) ::
   accepted; withdrawn claim was {"class":"fixed-path","key":"packages/main/dist","access":"shared"}`.
   This is outside the stated target (which is config + supersession) and I am reporting it as a boundary, not a
   defect — but the claim "the original audited resources cannot be withdrawn" is only true against edits that
   leave `suggestedResources` intact.
2. **`experiments/five-item-proof/capacity-config.mjs` was not executed.** It is not part of `last-closure.mjs`
   and I did not run it. Reading it, its assertions (`maxConcurrent=2`, writer-vs-reader conflicts, disjoint
   worktrees not conflicting, a shared `git-common-dir` claim present) can only be preserved by removing exact
   duplicates, and my real-admission experiment exercises the same 17-claim set across two linked worktrees — but
   that is reasoning plus adjacent evidence, not a run of that suite.
3. **A republished receipt leaves no durable trace.** `publishCompleted` swallows the first error; nothing in the
   receipt distinguishes "published on attempt 1" from "published on attempt 2" (`commandReruns` stays 0, which is
   correct — no command reran). Auditing a transient storage fault after the fact is not possible from the receipt.
4. **Batch late-join × receipt-retry was not executed as a combination.** I verified it from the frozen source
   (shared `executeFresh` promise), and each half separately at runtime.
5. **The capacity experiment is bounded.** Two worktrees, 4 real suites each, admitted through all 134
   declarations. It is not two complete 134-command runs, not whole-Story elapsed time, and says nothing about
   any running owner/reviewer session migrating or about generic task splitting; I make none of those claims.
   Its counters come from the child processes' own events.
6. **Two checks in my first control file failed on my own wrong expectations, not on the implementation**, and I
   am recording that rather than hiding it: I used `ownership:'story'` (only `runner-cleanable` is valid, on an
   exclusive owned class) and expected the fresh disposition label `'fresh'` (it is `'executed'`).
   `claude-negative-control-2.mjs` reruns both correctly and passes; `claude-negative-control.mjs` therefore exits
   1 by design and its log is kept unedited.
7. Everything above is bound to dist digest `b2c35d95…`; after `runtime-phase-done.json` I ran nothing further,
   so a later rebuild by the benchmark invalidates none of these results but is also not covered by them.
