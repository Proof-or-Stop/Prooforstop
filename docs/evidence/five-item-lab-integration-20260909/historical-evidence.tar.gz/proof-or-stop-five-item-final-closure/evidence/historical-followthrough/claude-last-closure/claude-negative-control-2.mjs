// Corrected reruns of the two claude-negative-control.mjs checks whose EXPECTATIONS
// (not the implementation) were wrong: ownership must be 'runner-cleanable' on an
// exclusive owned class, and the fresh disposition label is 'executed'.
import assert from 'node:assert/strict';
import {executeCausalEvidence,preflightCausalEvidence,DEFAULT_CAUSAL_SELECTOR_POLICY,computeCausalReceiptHash,verifyCausalEvidenceReceipt,CAUSAL_AUTHORITY_KEY_FILE,createCausalEvidenceBatch} from '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
import {declaredValidationCapacity} from '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/validation-execution-lock.js';
const root='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const failed=[];
const check=async(name,fn)=>{try{const n=await fn();console.log('PASS '+name+' :: '+n);}catch(e){failed.push(name);console.log('FAIL '+name+' :: '+e.message);}};

await check('ownership-only difference is NOT collapsed',()=>{
  const owned={class:'fixed-path',key:'probe',access:'exclusive'};
  const r=declaredValidationCapacity([{label:'x',resources:[owned,{...owned,ownership:'runner-cleanable'},{...owned,ownership:'runner-cleanable'},owned]}],root).resources;
  assert.equal(r.length,3,'workspace + plain exclusive + runner-cleanable exclusive; got '+JSON.stringify(r));
  assert.equal(r.filter(c=>c.ownership==='runner-cleanable').length,1,'the runner-cleanable duplicate collapses to exactly one');
  assert.equal(r.filter(c=>c.key.endsWith('/probe')&&!c.ownership).length,1,'the un-owned claim on the same key is retained separately');
  return JSON.stringify(r.slice(1));
});
await check('after a permanent receipt fault the next execution still runs the command (no phantom reuse)',async()=>{
  const identity={storyId:'B-claude-control-2',cwd:root,command:{executable:process.execPath,args:['-e','opaque witness']},inputs:{materialHash:'m'},storyFilesHash:'s',effectiveEnvironment:{},runtimeVersion:process.version,toolVersion:'test',selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY,computeCausalReceiptHash,verifyCausalEvidenceReceipt,CAUSAL_AUTHORITY_KEY_FILE,createCausalEvidenceBatch};
  const facts={cli:{available:true,path:process.execPath},worktree:{expected:root,actual:root},gitIndex:{readable:true,path:root+'/index',contentDigest:'i'},gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},writerLease:{available:true,valid:true},providerCapability:{required:['bounded-output'],available:['bounded-output']},resources:{required:{slots:1},available:{slots:1}},evidenceTarget:{writable:true,path:root},sideChannel:{available:true,maxOutputChars:12000,maxProgressEvents:1}};
  const preflight=preflightCausalEvidence(facts,()=>true,identity);
  const memory=()=>{const d=new Map();return {readCausalEvidenceReceipt:(_s,k)=>d.get(k)??null,writeCausalEvidenceReceipt:(_s,r)=>d.set(r.executionKey,structuredClone(r)),_d:d};};
  let firstCalls=0;const broken={...memory(),writeCausalEvidenceReceipt:()=>{throw new Error('PERMANENT');}};
  await assert.rejects(()=>executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:broken,selector:'OK',run:async()=>{firstCalls++;return {code:0,output:'OK'};}}),/PERMANENT/);
  let secondCalls=0;const good=memory();
  const out=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:good,selector:'OK',run:async()=>{secondCalls++;return {code:0,output:'OK'};}});
  assert.equal(firstCalls,1);assert.equal(secondCalls,1);assert.equal(out.verdict.result,'pass');
  assert.notEqual(out.disposition,'reused','a refused publication must never become a cache hit');
  const again=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:good,selector:'OK',run:async()=>{secondCalls++;return {code:0,output:'OK'};}});
  assert.equal(again.disposition,'reused','the successfully published receipt is reusable');
  assert.equal(secondCalls,1,'the reuse path must not launch another child');
  return 'firstCalls=1 disposition='+out.disposition+' thenReused childCalls='+secondCalls;
});
console.log(JSON.stringify({failed}));
if(failed.length)process.exitCode=1;
