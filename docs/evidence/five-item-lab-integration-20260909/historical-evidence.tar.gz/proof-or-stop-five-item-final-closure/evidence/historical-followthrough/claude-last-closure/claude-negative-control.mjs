// Independent Claude negative control for the three targets of 09596536ad.
// Reads the frozen Lab dist only; writes nothing outside stdout.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {executeCausalEvidence,preflightCausalEvidence,DEFAULT_CAUSAL_SELECTOR_POLICY,computeCausalReceiptHash,verifyCausalEvidenceReceipt,CAUSAL_AUTHORITY_KEY_FILE,createCausalEvidenceBatch} from '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
import {declaredValidationCapacity} from '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/validation-execution-lock.js';
import {canonicalizeEntries,claimsConflict} from '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/keyed-scheduler.js';
const root='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const results=[];
const check=async(name,fn)=>{try{const note=await fn();results.push({name,ok:true,note});console.log('PASS '+name+(note?' :: '+note:''));}catch(e){results.push({name,ok:false,note:e.message});console.log('FAIL '+name+' :: '+e.message);}};

// ---------- Target 1: capacity claim dedup ----------
const config=JSON.parse(readFileSync(root+'/proof-or-stop.config.json','utf8'));
const commands=config.validate.commands;
await check('raw aggregate is 195 and collapses to 17 exact normalized claims',()=>{
  // Recompute the pre-dedup aggregate independently from the source normalization rule.
  const raw=[{class:'fixed-path',key:resolve(root),access:'exclusive'}];
  for(const c of commands){const cwd=resolve(root,c.cwd??'.');for(const claim of c.resources)raw.push({class:claim.class,key:claim.class==='fixed-port'?claim.key:resolve(cwd,claim.key),access:claim.access,...(claim.ownership?{ownership:claim.ownership}:{})});}
  const distinct=new Set(raw.map(r=>JSON.stringify(r)));
  const actual=declaredValidationCapacity(commands,root);
  assert.equal(raw.length,195,'expected 195 raw claims, got '+raw.length);
  assert.equal(distinct.size,17);
  assert.equal(actual.resources.length,17);
  assert.deepEqual(new Set(actual.resources.map(r=>JSON.stringify(r))),distinct,'deduped set must equal the distinct raw set');
  assert.equal(actual.maxConcurrent,2);
  return 'raw='+raw.length+' distinct=17 commands='+commands.length;
});
await check('every retained claim is first-occurrence order preserved and no key is dropped',()=>{
  const actual=declaredValidationCapacity(commands,root);
  const keys=new Set(actual.resources.map(r=>r.key));
  for(const c of commands){const cwd=resolve(root,c.cwd??'.');for(const claim of c.resources){const k=claim.class==='fixed-port'?claim.key:resolve(cwd,claim.key);assert.ok(keys.has(k),'dropped key '+k);}}
  assert.ok(actual.resources[0].key===resolve(root)&&actual.resources[0].access==='exclusive','workspace exclusive claim must survive at index 0');
  return keys.size+' distinct keys';
});
await check('ownership-only difference is NOT collapsed',()=>{
  const base={class:'fixed-path',key:'probe',access:'shared'};
  const r=declaredValidationCapacity([{label:'x',resources:[base,{...base,ownership:'story'},{...base,ownership:'story'}]}],root).resources;
  assert.equal(r.length,3,'workspace + shared + shared-with-ownership');
  assert.equal(r.filter(c=>c.ownership==='story').length,1);
  return JSON.stringify(r.slice(1));
});
await check('dedup does not weaken a real-config exclusive conflict',()=>{
  const actual=declaredValidationCapacity(commands,root);
  const exclusives=actual.resources.filter(r=>r.access==='exclusive');
  assert.ok(exclusives.length>=1);
  for(const ex of exclusives){
    const pair=canonicalizeEntries([{name:'holder',resources:actual.resources},{name:'other',resources:[{class:ex.class,key:ex.class==='fixed-port'?ex.key:'.',access:'shared'}]}],root);
    // a shared reader of the workspace root still conflicts with the exclusive workspace claim
    if(ex.key===resolve(root))assert.ok(claimsConflict(...pair),'workspace exclusive must still conflict after dedup');
  }
  const self=canonicalizeEntries([{name:'a',resources:actual.resources},{name:'b',resources:actual.resources}],root);
  assert.ok(claimsConflict(...self),'two deduped real invocations must still conflict');
  return exclusives.length+' exclusive claims retained';
});
await check('invalid claim in a later command still throws after an all-duplicate command',()=>{
  const base={class:'fixed-path',key:'probe',access:'shared'};
  assert.throws(()=>declaredValidationCapacity([{label:'dupes',resources:[base,base,base]},{label:'bad',resources:[{...base,class:'unknown'}]}],root),/unknown resource class/);
  return 'validation precedes dedup';
});
await check('a command declaring nothing still disables overlap',()=>{
  assert.deepEqual(declaredValidationCapacity([{label:'a',resources:[{class:'fixed-path',key:'p',access:'shared'}]},{label:'b'}],root),{});
  return '{} returned';
});

// ---------- Target 2: completed receipt publication retry ----------
const identity={storyId:'B-claude-control',cwd:root,command:{executable:process.execPath,args:['-e','opaque witness']},inputs:{materialHash:'m'},storyFilesHash:'s',effectiveEnvironment:{},runtimeVersion:process.version,toolVersion:'test',selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY,computeCausalReceiptHash,verifyCausalEvidenceReceipt,CAUSAL_AUTHORITY_KEY_FILE,createCausalEvidenceBatch};
const facts={cli:{available:true,path:process.execPath},worktree:{expected:root,actual:root},gitIndex:{readable:true,path:root+'/index',contentDigest:'i'},gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},writerLease:{available:true,valid:true},providerCapability:{required:['bounded-output'],available:['bounded-output']},resources:{required:{slots:1},available:{slots:1}},evidenceTarget:{writable:true,path:root},sideChannel:{available:true,maxOutputChars:12000,maxProgressEvents:1}};
const preflight=preflightCausalEvidence(facts,()=>true,identity);
const memory=()=>{const data=new Map();return {readCausalEvidenceReceipt:(_s,k)=>data.get(k)??null,writeCausalEvidenceReceipt:(_s,r)=>data.set(r.executionKey,structuredClone(r)),_data:data};};

await check('the retry republishes the SAME signed receipt, not a re-derived one',async()=>{
  const seen=[];let calls=0,writes=0;const backing=memory();
  const store={readCausalEvidenceReceipt:backing.readCausalEvidenceReceipt,writeCausalEvidenceReceipt:(s,r)=>{writes++;seen.push(structuredClone(r));if(writes===1)throw new Error('TRANSIENT');backing.writeCausalEvidenceReceipt(s,r);}};
  const out=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector:'OK',run:async()=>{calls++;return {code:0,output:'OK'};}});
  assert.equal(calls,1);assert.equal(writes,2);
  assert.deepEqual(seen[0],seen[1],'both attempts must carry byte-identical receipts');
  assert.equal(seen[0].receiptHash,out.receipt.receiptHash);
  assert.ok(verifyCausalEvidenceReceipt(seen[1]),'republished receipt still verifies');
  return 'receiptHash '+out.receipt.receiptHash.slice(0,12)+' identical across both attempts';
});
await check('two consecutive transient faults refuse; there is never a third write or a second child',async()=>{
  let calls=0,writes=0;const backing=memory();
  const store={readCausalEvidenceReceipt:backing.readCausalEvidenceReceipt,writeCausalEvidenceReceipt:(s,r)=>{writes++;if(writes<=2)throw new Error('TRANSIENT_TWICE');backing.writeCausalEvidenceReceipt(s,r);}};
  await assert.rejects(()=>executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector:'OK',run:async()=>{calls++;return {code:0,output:'OK'};}}),/TRANSIENT_TWICE/);
  assert.equal(writes,2,'the transaction bound is exactly two writes, got '+writes);
  assert.equal(calls,1,'a storage fault must never re-enter the runner');
  assert.equal(backing._data.size,0,'no receipt may be published after refusal');
  return 'writes=2 childCalls=1 published=0';
});
await check('after a permanent receipt fault the next execution still runs the command (no phantom reuse)',async()=>{
  let firstCalls=0;const broken={...memory(),writeCausalEvidenceReceipt:()=>{throw new Error('PERMANENT');}};
  await assert.rejects(()=>executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:broken,selector:'OK',run:async()=>{firstCalls++;return {code:0,output:'OK'};}}),/PERMANENT/);
  let secondCalls=0;const good=memory();
  const out=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:good,selector:'OK',run:async()=>{secondCalls++;return {code:0,output:'OK'};}});
  assert.equal(firstCalls,1);assert.equal(secondCalls,1);assert.equal(out.verdict.result,'pass');assert.equal(out.disposition,'fresh');
  return 'disposition='+out.disposition;
});
await check('transient output AND receipt faults in one run: one child, two writes each',async()=>{
  let calls=0,ow=0,rw=0;const outputs=new Map();const backing=memory();
  const store={readCausalEvidenceReceipt:backing.readCausalEvidenceReceipt,writeCausalEvidenceReceipt:(s,r)=>{rw++;if(rw===1)throw new Error('T_RECEIPT');backing.writeCausalEvidenceReceipt(s,r);},readCausalSelectorOutput:(_s,k)=>outputs.get(k),writeCausalSelectorOutput:(_s,k,o)=>{ow++;if(ow===1)throw new Error('T_OUTPUT');outputs.set(k,o);}};
  const out=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector:'OK',run:async()=>{calls++;return {code:0,output:'OK'+'x'.repeat(20000)};}});
  assert.equal(out.verdict.result,'pass');assert.equal(calls,1);assert.equal(ow,2);assert.equal(rw,2);
  return 'childCalls=1 outputWrites=2 receiptWrites=2';
});
await check('a FAILING run is still never published as a reusable receipt',async()=>{
  let writes=0;const backing=memory();
  const store={readCausalEvidenceReceipt:backing.readCausalEvidenceReceipt,writeCausalEvidenceReceipt:(s,r)=>{writes++;backing.writeCausalEvidenceReceipt(s,r);}};
  const out=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector:'OK',run:async()=>({code:1,output:'OK'})});
  assert.equal(out.verdict.result,'fail');assert.equal(writes,0,'non-PASS must not be published, got '+writes);
  return 'writes=0 on fail';
});

// ---------- Target 3: audited claim retention ----------
const audit=JSON.parse(readFileSync(root+'/experiments/five-item-proof/resource-audit.json','utf8'));
const {verifyResourceAudit}=await import(root+'/experiments/five-item-proof/resource-audit-policy.mjs');
await check('withdrawing a claim from config+supersession is refused on every superseded entry',()=>{
  const superseded=audit.entries.filter(e=>e.recommendation==='safe-to-declare-shared'&&e.supersededBy);
  assert.ok(superseded.length===6,'expected 6 superseded entries, got '+superseded.length);
  for(const e of superseded){
    for(let i=0;i<e.suggestedResources.length;i++){
      const c=structuredClone(config),a=structuredClone(audit);
      const removed=e.suggestedResources[i];const keep=r=>JSON.stringify(r)!==JSON.stringify(removed);
      c.validate.commands[e.commandIndex].resources=c.validate.commands[e.commandIndex].resources.filter(keep);
      const ae=a.entries.find(x=>x.commandIndex===e.commandIndex);ae.supersededBy.effectiveResources=ae.supersededBy.effectiveResources.filter(keep);
      assert.throws(()=>verifyResourceAudit(c,a),/RESOURCE_AUDIT_WITHDRAWN_CLAIM|RESOURCE_AUDIT_DRIFT|RESOURCE_AUDIT_SUPERSESSION_INVALID/,'entry '+e.commandIndex+' claim '+i+' was silently withdrawable');
    }
  }
  return superseded.map(e=>e.commandIndex+':'+e.suggestedResources.length).join(' ');
});
await check('LIMIT: a third coordinated edit of suggestedResources is NOT detected (unsigned audit fixture)',()=>{
  const e=audit.entries.find(x=>x.commandIndex===3&&x.supersededBy);
  const c=structuredClone(config),a=structuredClone(audit);
  const removed=e.suggestedResources[0];const keep=r=>JSON.stringify(r)!==JSON.stringify(removed);
  c.validate.commands[3].resources=c.validate.commands[3].resources.filter(keep);
  const ae=a.entries.find(x=>x.commandIndex===3);
  ae.supersededBy.effectiveResources=ae.supersededBy.effectiveResources.filter(keep);
  ae.suggestedResources=ae.suggestedResources.filter(keep);
  const summary=verifyResourceAudit(c,a);
  assert.equal(summary.auditedReaders,21);
  return 'accepted; withdrawn claim was '+JSON.stringify(removed);
});
console.log(JSON.stringify({total:results.length,failed:results.filter(r=>!r.ok).map(r=>r.name)}));
if(results.filter(r=>!r.ok).length)process.exitCode=1;
