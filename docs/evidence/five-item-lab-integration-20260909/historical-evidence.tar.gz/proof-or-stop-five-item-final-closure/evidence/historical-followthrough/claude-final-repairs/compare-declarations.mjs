import {readFileSync} from 'node:fs';
const before=JSON.parse(readFileSync(process.argv[2])),after=JSON.parse(readFileSync(process.argv[3]));
const argv=c=>[c.command,...(c.args??[])].join(' ');
const B=before.validate.commands,A=after.validate.commands;
console.log('counts',B.length,A.length);
const bar=r=>r.class==='fixed-path'&&r.key==='.proof-or-stop/runtime/validate-plan-barrier'&&r.access==='exclusive';
let changed=0,newDecl=0,reverted=0;
A.forEach((a,i)=>{
  const b=B[i]; if(argv(a)!==argv(b))console.log('ARGV DRIFT at',i,argv(b),'->',argv(a));
  const br=b.resources??null, ar=a.resources??null;
  if(JSON.stringify(br)===JSON.stringify(ar))return; changed++;
  if(!br){newDecl++;return;}
  reverted++;
  console.log('--- REVERTED idx',i,argv(a));
  console.log('  before:',JSON.stringify(br));
  console.log('  after :',JSON.stringify(ar));
});
console.log({changed,newDecl,revertedExisting:reverted});
console.log('after: commands with exclusive barrier:',A.map((c,i)=>[i,c]).filter(([,c])=>(c.resources??[]).some(bar)).map(([i])=>i).join(','));
console.log('after: commands with NO resources:',A.map((c,i)=>[i,c]).filter(([,c])=>!c.resources).map(([i])=>i).join(',')||'none');
const keys=new Set();A.concat(after.doneRequiredCommands).forEach(c=>(c.resources??[]).forEach(r=>keys.add(r.class+' | '+r.key+' | '+r.access)));
console.log('distinct claims:');[...keys].sort().forEach(k=>console.log('  '+k));
console.log('DONE:',JSON.stringify(after.doneRequiredCommands.map(c=>({argv:argv(c),reuse:c.fullBaselineReusePolicy,res:c.resources})),null,1));
