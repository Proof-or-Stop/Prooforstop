# Independent verification — b97fe91cb7, ef11c14a10, a6f1b91d0a

Reviewer: independent Claude session, 2026-09-09. **Not a formal Story review.**
Lab under review: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`
at HEAD `a6f1b91d0ab09b0210f1fcd609b42ecf76955bd7` (branch `codex/lab-five-item-proof-20260908`).

Nothing in the Lab was modified. `git status --porcelain` before and after my run shows the
same single pre-existing untracked file (`AGENTS.override.md`) and no other entries. No builds,
no agents, no Story mutation, no `main`/`dist`/source writes. Every file I created is under
`/Users/jek/.codex/artifacts/proof-or-stop-five-item-followthrough-20260909/claude-final-repairs/`.

Evidence classes are kept separate: **[EXEC]** = a command I ran, with its exit code;
**[READ]** = source/diff/config analysis only.

Context read as background (not re-derived): `writer-resource-review.md`,
`claude-retention-identity/report.md`.

---

## 1. Commands run, with actual exits [EXEC]

Run from the Lab root, in the order given, no environment overrides:

| # | Command | Exit | stdout (final marker) | stderr |
|---|---|---|---|---|
| 1 | `node experiments/five-item-proof/exit-legacy-output.mjs` | **0** | `EXIT_ONLY_REUSE_AND_LEGACY_SYNTHETIC_REFUSAL_GREEN` (3 PASS lines) | empty |
| 2 | `node experiments/five-item-proof/output-retention-contract.mjs` | **0** | `OUTPUT_RETENTION_COMPATIBILITY_BOUND_AND_SYNTHETIC_MARKER_GREEN` | empty |
| 3 | `node experiments/five-item-proof/capacity-config.mjs` | **0** | `ALL_REAL_CAPACITY_DECLARATIONS_GREEN` (~7 s; builds a real two-worktree git fixture) | empty |
| 4 | `node packages/main/tests/validate-resource-claims.test.mjs` | **0** | `validate-resource-claims: PASS (34 assertions)` | empty |
| 5 | `node experiments/five-item-proof/shared-config.mjs` | **0** | `MEASURED_HEAVY_COMMAND_REUSE_ENABLED_WITH_EXCLUSIONS` | empty |

Full stdout is in `run-*.log` in this directory. Notable lines from #4:

```
VI-OK B7DFF-CHK002-CONFIGURED-PLAN-CLASSIFIED configured plan: 134 commands, 134 declared, 0 exclusive by fail-closed default
VI-OK B7DFF-CHK005-AUDITED-BARRIERS-HELD 10 commands retain an effective exclusive local barrier
VI-OK B7DFF-CHK005-COLLISION-PROBE-BITES declaring an audited repo-shared writer is reported by the probe rather than silently accepted
```

`packages/main/dist/core/causal-evidence.js` (mtime 02:50) is newer than
`packages/main/src/core/causal-evidence.ts` (02:49) and contains
`causal_legacy_selector_output_unproven` and the `durableOutput` line without the
`selector.length > 0` term, so the prebuilt `dist` I exercised does correspond to the
reviewed source. [EXEC/READ]

## 2. My own negative controls [EXEC]

`negative-control.mjs` in this directory (read-only against the Lab `dist`; its git fixture is
a throwaway repo under `$TMPDIR`). Exit **0**, log in `negative-control.log`:

```
NC-OK BARRIER-LOAD-BEARING 11 writers conflict with all 133 others only because of the exclusive barrier (e.g. idx1 vs idx2)
NC-OK CROSS-WORKTREE shared git-common-dir:/private/.../base/.git with 25 disjoint exclusive local keys per side; conflict returns on exclusive metadata
NC-OK PORT-GLOBAL fixed-port 43127 conflicts across roots; removing it removes the conflict
NC-OK LEGACY-REFUSAL plain<=12000 compatible; >12000, gap marker, and redaction markers all refuse
```

What each control rules out:

- **The barrier is load-bearing, not incidental.** `capacity-config.mjs`'s
  `WRITER_MUST_CONFLICT_WITH_EVERY_LOCAL_READER` could in principle pass because of some other
  claim. I rebuilt the plan with the barrier's `access` flipped `exclusive` to `shared` on all
  11 writers: **0 of 11** still conflict with every other entry, and index 1 becomes
  overlappable with a concrete plain reader (index 2). The assertion is not vacuous.
- **Cross-worktree compatibility is not vacuous.** In the two-worktree fixture the
  `git-common-dir` canonical keys are equal, non-`undefined`, resolve to an existing
  directory, and `realpath` to the *base repo's* `.git` — not to either worktree root
  (`canonicalizeEntries` shells out to `git rev-parse --git-common-dir`,
  `keyed-scheduler.ts:121-124`). Each side contributes 25 exclusive `fixed-path` keys and none
  is shared with the other. Flipping the shared metadata claim to `exclusive` makes
  `claimsConflict` fire, so "no conflict" is a real result rather than an empty claim set.
- **TCP 43127 is machine-wide.** `canonicalizeEntries` keys `fixed-port` by port number only
  (no root prefix), so the DONE full-suite entry conflicts with itself across two unrelated
  roots; deleting the port claim removes that conflict. The port is the load-bearing claim.
- **Legacy selector refusal.** Synthetic v1-shaped receipts: a 12,000-char probe returns bytes;
  12,001 refuses; a probe carrying `<causal-output-gap>` refuses *even with `outputLength`
  forged down to 9*; `<redacted>` in either `outputProbe` or `outputTail` refuses; a genuine
  `selectorProbe` still short-circuits. All refusals carry
  `causal_legacy_selector_output_unproven`.

---

## 3. Findings on the five points I was asked to check

### 3.1 Real resource capacity declarations are exact keys — holds [EXEC/READ]

All 134 routine commands and both DONE commands now carry `resources`
(`compare-declarations.mjs`: `commands with NO resources: none`). Every declared claim across
the whole config is a literal key — no globs, wildcards or patterns. The complete distinct
claim set is 18 entries, e.g. `fixed-path | packages/main/dist | exclusive`,
`fixed-path | packages/main/dist | shared`, `git-common-dir | . | shared`,
`fixed-port | 43127 | exclusive`. `validateResourceClaims` rejects unknown classes at
declaration time and the test proves it does so for the real config file
(`CHK002-UNKNOWN-CLASS-REFUSED-IN-CONFIG`).

This completeness is load-bearing, not cosmetic: `declaredValidationCapacity`
(`validation-execution-lock.ts:834`) returns `{}` — no resources, no `maxConcurrent` — if
*any* command lacks `resources`. Declaring all 134 is what makes `maxConcurrent: 2`
(`runtime-fact-registry.ts:169`) reachable at all. The capacity aggregate also adds
`fixed-path <workspaceRoot> exclusive` (`:835`), so two invocations in the *same* worktree
still serialize; only distinct worktrees share the two-invocation capacity. The call site is
real (`verifier.ts:1553`, guarded on not-channel/concept/lint/validate-file).

### 3.2 Exit-only reuse defect and legacy synthetic-display refusal — both correct [READ/EXEC]

The defect is real and the fix is minimal. Before: `selector === ''` plus output over 12,000
chars made `durableOutput` false, which produced a `selectorWitness` whose `selectorDigest` is
the digest of the empty string and whose `matched` is trivially `true`; `reusable` is
`&& !selectorWitness`, so **every verbose exit-only check was permanently non-reusable**
(`causal-evidence.ts:759-765,780`). Dropping the `args.selector.length > 0` term is exactly the
right cut.

The two halves of this commit are interdependent, which is worth stating explicitly: the new
legacy guard refuses any legacy receipt with `outputLength > 12,000` and no `selectorProbe`.
Without the `durableOutput` fix, exit-only runs would keep producing precisely such receipts,
and a later selector-bearing consumer would refuse them. Shipping either half alone would be
worse than shipping both.

The refusal predicate is **complete with respect to truncation**, which I checked rather than
assumed: `boundedOutputProbe` (`:579-586`) is the only truncating path and it always splices
the literal `\n<causal-output-gap>\n`, so a truncated probe cannot be marker-free. The
`outputLength > CAUSAL_MAX_OUTPUT_CHARS` clause is a second, independent net (raw
pre-redaction length). `git log -S` shows `CAUSAL_MAX_OUTPUT_CHARS = 12_000` and
`causal-output-gap` were both introduced in `1d95b4a5c8` and never changed, so no in-lineage
receipt was produced under a different bound or a different marker — the hole I went looking
for (an older marker with a smaller bound slipping past both clauses) does not exist here. It
would exist for receipts produced by an out-of-tree fork; that is not this repo's risk.

Both failure directions are conservative: real output containing the literal string
`<redacted>` or `<causal-output-gap>` is refused (false refusal, requires a rerun), never
accepted. `exit-legacy-output.mjs` is a fair test — it re-signs the forged legacy receipt with
the fixture's own authority key and asserts `verifyCausalEvidenceReceipt` passes *before*
consumption, so the refusal is attributable to selector policy and not to a broken signature.

### 3.3 Explicit local exclusive barrier conflicts with every local reader — holds [EXEC]

Indices `1,3,6,40,79,80,81,82,83,105,125` carry
`fixed-path .proof-or-stop/runtime/validate-plan-barrier exclusive`; every other command
carries the same key as `shared`. Each of the 11 conflicts with all 133 others, and section 2
shows the barrier is the sole reason. Because the key is a `fixed-path` resolved against the
worktree root, it serializes *within* a checkout and does not leak across checkouts — the
commit message's claim ("preserves serialization … does not turn a local build into a global
writer") is accurate.

Measured effect of the whole scheme: **7,503 of 8,911 command pairs are compatible and 123 of
134 commands can overlap with at least one other.** [EXEC]

### 3.4 Two linked worktrees share Git metadata with compatible routine claims — holds [EXEC]

See section 2. `capacity-config.mjs` now builds a genuine `git init` plus two
`git worktree add` fixture instead of the previous bare `/tmp/lab-capacity-{a,b}` paths, which
is a real improvement: the earlier form could not have distinguished "shares metadata but is
compatible" from "has no metadata claim at all". My independent version adds the checks the
Lab's assertion leaves implicit (key is non-`undefined`, is a real directory, is the base
`.git`, and an exclusive metadata claim would in fact conflict).

### 3.5 DONE retains TCP 43127 and all build/forbidden exclusions — holds [EXEC/READ]

`doneRequiredCommands[1]` (`npm test`) keeps `fixed-port 43127 exclusive` plus
`fixed-path . exclusive` (whole worktree) plus the new barrier; `npm --prefix packages/main run build`
keeps exclusive `packages/main/dist` and `packages/utils/dist`. Neither is reusable:
`shared-config.mjs` asserts `doneRequiredCommands.every(c => !sharedValidationReuseAllowed(c))`
and that each of six policy shapes (`fullBaselineReusePolicy: forbidden`,
`closurePolicy: never-reuse`, `riskTier: gate`, `riskTier: validation-infra`,
`requiresBuildProof`, `providesBuildProof`) independently overrides the opt-in
(`shared-validation-execution.ts:26-36`). `commands[125].env.GRAPH_VERIFY_PORT === '0'` keeps
graph checks on OS-assigned ports while retaining exclusive `packages/graph`.

### 3.6 The six conservative reversions — reviewed, not assumed [EXEC/READ]

I diffed `b97fe91cb7^:proof-or-stop.config.json` against the current file rather than trusting
the older 21-reader report. Exactly 11 commands changed: **5 new declarations** (previously
undeclared, now barrier plus claims) and **6 reversions** of existing shared-reader
declarations, which keep every prior shared claim and gain the exclusive barrier (plus
`git-common-dir . shared` where it was missing):

| idx | command | prior classification |
|---|---|---|
| 3 | `packages/main/dist/tasks/retired-authority-vocabulary-guard-smoke.js` | safe-to-declare-shared |
| 6 | `packages/main/dist/tasks/command-catalog-smoke.js` | safe-to-declare-shared |
| 40 | `packages/main/dist/tasks/quorum-submit-smoke.js` | safe-to-declare-shared |
| 79 | `packages/main/tests/red/red-b49d4-registration-derivation.mjs` | safe-to-declare-shared |
| 81 | `packages/main/tests/red/red-1734-lock-liveness.mjs` | safe-to-declare-shared |
| 105 | `packages/main/dist/tasks/proofstory-acceptance-rollout-smoke.js --issuer-mutations` | safe-to-declare-shared |

The direction of the change is strictly safer (more serialization, never less), and no `argv`
drifted. Cross-referencing `experiments/five-item-proof/resource-audit.json` confirms all six
are members of the 21 `safe-to-declare-shared` entries, so **the effective overlappable audited
reader set is 15, not 21**. See finding F1.

### 3.7 Narrow heavy-command opt-in — holds, with one claim I verified [EXEC/READ]

Exactly one command is eligible (`sharedValidationReuseAllowed`), it is the measured heavy
`tool-executed-evidence-receipt-smoke.js`, and its `executionInputs` names its own dist
artifact. The `sharedExecution: true` flag is **not decorative** — `verifier.ts:1554` gates
shared execution on `args.story && (dynamicMode === 'off' || config.validate.sharedExecution === true)`,
and dynamic mode is `observe`, so the flag is the enabling condition. Note the scope this
implies: shared execution applies only to story-scoped `validate`, not to a bare `validate`.

I checked the commit's own claim that the root full-suite inventory does not contain this
command: root `package.json` defines `test:tool-executed-evidence-receipt-smoke` but **no other
root script references it** (it is not in the `test:serial-reference` chain), and the name does
not appear in `full-suite-runner.ts`'s resource-policy inventory. The claim holds. [EXEC]

The command-artifact binding is genuine rather than nominal: `executeSharedValidationCommand`
hashes each `executionInputs` file after `realpathSync`, and additionally binds the
implementation digest, `git status --porcelain=v1 -uall` plus `git diff --binary HEAD`, and
refuses outright on a dirty workspace, re-checking all of it before run, before consumption and
before publication.

---

## 4. Concrete flaws in these diffs

Ranked. None makes the reviewed behaviour unsound; F1 is the one I would fix before this
configuration is cited as evidence elsewhere.

**F1 — The audit-drift guard can no longer see the reversions it is supposed to police.**
`resource-config.mjs:19` was relaxed from
`assert.deepEqual(command.resources, entry.suggestedResources)` to a subset check. The
relaxation was necessary (the barrier is a legitimate addition), but as written it now accepts
**any** extra claim on an audited reader — including an exclusive barrier that revokes the
overlap the audit recommended. That is exactly what happened to six entries, and the guard
stayed green. Meanwhile the machine-readable evidence overstates the result:
`resource-audit.json` was not touched by `b97fe91cb7` and still records all 21 as
`safe-to-declare-shared`, and `resource-config.mjs:45` still writes `auditedReaders: 21` into
`results.json` while its sibling field was correctly updated to
`remainingRoutineWriterBarriers: 11`. Only the prose in `docs/validation-performance.md`
records the supersession. Narrow fix: add a `supersededBy` field to those six audit entries,
keep `deepEqual` against `suggestedResources` for the *non-barrier* claims, and emit
`auditedReaders: 21, effectivelySharedReaders: 15`.

**F2 — `ef11c14a10` widens the blast radius of a selector-store write failure to exit-only
commands.** With `args.selector.length > 0` removed, any exit-only check whose output exceeds
12,000 chars (common for verbose suites) now writes up to 1 MiB of selector bytes at
`causal-evidence.ts:797`. That call is not wrapped, so an `ENOSPC`/`EACCES`/`EIO` there throws
out of `executeCausalEvidence` *after* the child has already run and passed, converting a
completed PASS into a thrown validation error for a class of commands that previously never
touched that store at all. This is fail-closed and no evidence is corrupted (the receipt is
published only after the bytes are), so it is a robustness regression, not a correctness one.
Worth a targeted decision: either catch the write failure and fall back to the non-reusable
witness, or state the fail-closed behaviour in `docs/validation-performance.md`.

**F3 — The other half of the same defect class is still dormant (deliberate, conservative).**
For exit-only checks the `selectorWitness` is evidentially empty: `selectorDigest` is the
digest of `''` and `matched` is unconditionally `true`. When output exceeds 1 MiB or the store
lacks selector methods, that meaningless witness is still what sets `reusable: false`
(`:764-765,780`), even though nothing about a selector is being proven and the signed receipt
already carries the exit code. The one-token fix would be
`selectorWitness = longOutput && !selectorOutput && args.selector.length > 0`. I flag this as a
residual limitation rather than a defect — the current behaviour matches what
`docs/validation-performance.md` claims ("the 1 MiB and legacy-store fallback remains
non-reusable"), and it fails closed.

**F4 — Two assertions became vacuous under "134 declared, 0 by default" and should be
re-pointed.** (a) `resource-config.mjs:18` asserts
`resolveValidationCommandResourceClaims(...).exclusiveByDefault === false` under the label
`AUDITED_READERS_STILL_SERIAL`; now that all 134 commands are declared this is true of every
command in the config regardless of its claims, so it can no longer fail — and the label reads
backwards relative to what it checks. (b) The test's "both paths are exercised by the real
config" was replaced by `declared.length === commands.length && byDefault.length === 0`, which
is the right assertion for the new invariant, but it means the fail-closed default path is no
longer exercised by the real config. It *is* still exercised by the synthetic entries in
`CHK002-UNDECLARED-SINGLE-EXCLUSIVE-CLAIM` / `CHK002-UNDECLARED-NEVER-OVERLAPS`, so coverage is
retained — just note that the real config no longer contributes it.

**F5 (cosmetic) — `b97fe91cb7` reformats untouched config entries.** The 249-line
`proof-or-stop.config.json` diff includes pure re-indentation of `args`/`focus` arrays on
commands whose behaviour did not change (e.g. `verify-lab-worktree.mjs`), which inflates the
reviewable surface of a security-relevant config diff. I confirmed by structural comparison
that no `argv` changed anywhere in the file.

**Residual risk I looked for and could not turn into a defect:** the barrier is per-worktree,
so the only cross-worktree claim held by the 11 writers and both DONE commands is
`git-common-dir . shared`. Two worktrees can therefore run repo-shared writers concurrently
against one Git object/ref store. I found no command in the reviewed set that writes there
outside Git's own locking, and per-worktree indexes are not shared, so I record this as a
bounded assumption of the model rather than a flaw in these diffs.

---

## 5. Scope limits

- **This is not a formal Story review** and it creates no Story credential.
- I ran the five specified commands plus my own negative control. I did **not** run
  `resource-config.mjs` (it executes four real assertion suites in six RED/GREEN pairs), the
  full suite, any build, or any agent. F1 and F4(a) are therefore `[READ]` conclusions about
  that file's guards, verified against `resource-audit.json` and the config by direct
  comparison, not by executing it.
- **All 134-command timing is a separate experiment.** Nothing here shows that the 134 commands
  pass, that they run faster, or that whole-Story elapsed time improves. The 7,503 compatible
  pairs in section 3.3 are a property of the declared claim graph, not a measured schedule.
- The **two-consumer heavy-command reuse experiment is conditional reuse only**; it does not
  show that the root full-suite inventories duplicate that work, and 0/2 DONE eligibility is
  intended policy.
- **Active owner/reviewer session migration is not claimed** and I verified nothing about it.
- I exercised the prebuilt `packages/main/dist` as-is (confirmed newer than the reviewed source
  and containing the reviewed changes). I did not rebuild, so I cannot rule out that some
  *other* part of `dist` is stale relative to `src`.
- Legacy-refusal completeness (section 3.2) is established for receipts produced by this
  repository's lineage, via `git log -S` on the bound and the marker. Receipts from a forked
  build using a different truncation marker and a smaller probe bound would not be caught.
- The retention/pruning policy for the newly written exit-only selector objects
  (`output-artifact-policy.mjs`) was not re-verified in this session.

## 6. Files in this directory

| File | What it is |
|---|---|
| `report.md` | this report |
| `run-*.log` | verbatim stdout/stderr of the five mandated commands |
| `negative-control.mjs`, `negative-control.log` | my independent controls and their output (exit 0) |
| `compare-declarations.mjs` | structural before/after comparison of the config declarations |
| `config-before.json` | `b97fe91cb7^:proof-or-stop.config.json`, extracted for that comparison |
