// Independent negative controls for b97fe91cb7 / ef11c14a10 / a6f1b91d0a.
// Read-only against the Lab: builds its own throwaway git fixture in $TMPDIR.
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,mkdirSync,rmSync,existsSync,statSync,realpathSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
const LAB='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const {declaredValidationCapacity}=await import(resolve(LAB,'packages/main/dist/core/validation-execution-lock.js'));
const {resolveValidationPlanEntries}=await import(resolve(LAB,'packages/main/dist/core/validation-executor.js'));
const {canonicalizeEntries,claimsConflict}=await import(resolve(LAB,'packages/main/dist/core/keyed-scheduler.js'));
const {readCausalSelectorOutput}=await import(resolve(LAB,'packages/main/dist/core/causal-evidence.js'));
const config=JSON.parse(readFileSync(resolve(LAB,'proof-or-stop.config.json')));
const commands=config.validate.commands.map((c,i)=>({...c,label:String(i)}));
const BARRIER='.proof-or-stop/runtime/validate-plan-barrier';
const say=(id,msg)=>console.log(`NC-OK ${id} ${msg}`);

// NC1 — the barrier is what makes writers conflict locally (not something else).
{
  const entries=canonicalizeEntries(resolveValidationPlanEntries({provider:'real-config',commands}),LAB);
  const writers=[1,3,6,40,79,80,81,82,83,105,125];
  const readers=entries.map((e,i)=>i).filter(i=>!writers.includes(i));
  for(const w of writers) assert.ok(entries.every((o,i)=>i===w||claimsConflict(entries[w],o)),'baseline writer conflict '+w);
  const weakened=commands.map((c,i)=>writers.includes(i)
    ?{...c,resources:c.resources.map(r=>r.key===BARRIER?{...r,access:'shared'}:r)}:c);
  const weak=canonicalizeEntries(resolveValidationPlanEntries({provider:'real-config',commands:weakened}),LAB);
  const stillAll=writers.filter(w=>weak.every((o,i)=>i===w||claimsConflict(weak[w],o)));
  assert.equal(stillAll.length,0,'downgrading the barrier must break every writer conflict; still-conflicting: '+stillAll);
  // and it must break against a plain reader specifically
  const r=readers.find(i=>!claimsConflict(weak[1],weak[i]));
  assert.ok(r!==undefined,'a concrete reader becomes overlappable once the barrier is shared');
  say('BARRIER-LOAD-BEARING',`11 writers conflict with all 133 others only because of the exclusive barrier (e.g. idx1 vs idx${r})`);
}

// NC2 — two real linked worktrees: shared git metadata, disjoint local keys, no conflict;
//        and the compatibility result is not vacuous.
const fixture=mkdtempSync(resolve(tmpdir(),'claude-nc-'));
try{
  const base=resolve(fixture,'base'),left=resolve(fixture,'left'),right=resolve(fixture,'right');mkdirSync(base);
  const git=a=>execFileSync('git',a,{cwd:base,stdio:'pipe'});
  git(['init','-q']);git(['-c','user.name=NC','-c','user.email=nc@example.test','commit','--allow-empty','-qm','nc']);
  git(['worktree','add','-q','-b','l',left]);git(['worktree','add','-q','-b','r',right]);
  const cap=dir=>canonicalizeEntries([{name:dir,resources:declaredValidationCapacity(commands,dir).resources}],dir)[0];
  const a=cap(left),b=cap(right);
  assert.ok(!claimsConflict(a,b),'disjoint worktree routine capacity must not conflict');
  const gcd=k=>k.resources.filter(x=>x.class==='git-common-dir').map(x=>x.canonicalKey);
  assert.ok(gcd(a).length>0&&gcd(b).length>0,'git-common-dir claims must exist (not vacuously undefined)');
  const [ka]=gcd(a),[kb]=gcd(b);
  assert.equal(ka,kb,'both worktrees canonicalize to ONE git common dir');
  const dir=ka.replace(/^git-common-dir:/,'');
  assert.ok(existsSync(dir)&&statSync(dir).isDirectory(),'the shared canonical key is a real directory: '+dir);
  assert.equal(realpathSync(dir),realpathSync(resolve(base,'.git')),'the shared key is the base repo .git, not either worktree root');
  const rootKeys=k=>k.resources.filter(x=>x.class==='fixed-path'&&x.access==='exclusive').map(x=>x.canonicalKey);
  assert.ok(rootKeys(a).every(x=>!rootKeys(b).includes(x)),'no exclusive local key is shared between the two worktrees');
  // vacuity probe: if the shared metadata claim were exclusive, the two worktrees WOULD conflict.
  const exA={...a,resources:a.resources.map(x=>x.class==='git-common-dir'?{...x,access:'exclusive'}:x)};
  assert.ok(claimsConflict(exA,b),'the cross-worktree compatibility check would fire on an exclusive git-common-dir');
  say('CROSS-WORKTREE',`shared ${ka} with ${rootKeys(a).length} disjoint exclusive local keys per side; conflict returns on exclusive metadata`);

  // NC3 — fixed-port stays machine-wide: same port, two different roots, still conflicts.
  const full=config.doneRequiredCommands[1];
  const p=(name,dir)=>canonicalizeEntries([{name,resources:full.resources}],dir)[0];
  assert.ok(claimsConflict(p('l',left),p('r',right)),'TCP 43127 must conflict across unrelated roots');
  assert.ok(full.resources.some(r=>r.class==='fixed-port'&&r.key==='43127'&&r.access==='exclusive'),'DONE full suite keeps exclusive 43127');
  const noPort={...full,resources:full.resources.filter(r=>r.class!=='fixed-port')};
  assert.ok(!claimsConflict(canonicalizeEntries([{name:'l',resources:noPort.resources}],left)[0],
                            canonicalizeEntries([{name:'r',resources:noPort.resources}],right)[0]),
    'without the port claim the cross-root conflict disappears (so the port is the load-bearing claim)');
  say('PORT-GLOBAL','fixed-port 43127 conflicts across roots; removing it removes the conflict');
}finally{rmSync(fixture,{recursive:true,force:true});}

// NC4 — legacy selector refusal: complete plain text passes, truncated/redacted refuses,
//        and a forged short outputLength does not defeat the marker check.
{
  const rc=(probe,tail,len)=>({storyId:'s',selectorOutput:undefined,selectorProbe:undefined,outputProbe:probe,outputTail:tail,outputLength:len});
  assert.equal(readCausalSelectorOutput(rc('plain complete','plain complete',14)),'plain complete');
  const exactly=('x').repeat(12000);
  assert.equal(readCausalSelectorOutput(rc(exactly,exactly.slice(-100),12000)),exactly,'12,000 boundary stays compatible');
  const throws=r=>{try{readCausalSelectorOutput(r);return null;}catch(e){return e.message;}};
  assert.match(throws(rc(exactly,exactly.slice(-100),12001)),/causal_legacy_selector_output_unproven/,'over-bound length refuses');
  assert.match(throws(rc('head\n<causal-output-gap>\ntail','tail',9)),/causal_legacy_selector_output_unproven/,'forged short outputLength does not defeat the gap marker');
  assert.match(throws(rc('token: <redacted>','x',17)),/causal_legacy_selector_output_unproven/,'redaction marker in probe refuses');
  assert.match(throws(rc('clean','tail <redacted>',5)),/causal_legacy_selector_output_unproven/,'redaction marker in tail refuses');
  assert.equal(readCausalSelectorOutput({...rc('ignored','x',99999),selectorProbe:'proven'}),'proven','a real selector probe still wins');
  say('LEGACY-REFUSAL','plain<=12000 compatible; >12000, gap marker, and redaction markers all refuse');
}
console.log('CLAUDE_INDEPENDENT_NEGATIVE_CONTROLS_GREEN');
