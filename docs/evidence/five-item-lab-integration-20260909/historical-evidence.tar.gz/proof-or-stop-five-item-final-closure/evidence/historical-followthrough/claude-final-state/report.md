# Independent final verification — Lab five-item followthrough

Verifier: Claude CLI, independent of the developing session. Date 2026-09-09.
Worktree: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`,
HEAD `0d3c962a65`, runtime frozen (main/utils content-prepared, `packages/lab` built).
Previous good runtime: `09596536ad`. Base main: `cf21df09c273074d7aa3227a5f436c6f5badf47a` (0.3.284).

Nothing was modified: no source, dist, main, Story state, other worktree, build, commit or
integration. No subagents. All outputs written only under `claude-final-state/`.
Earlier core-fix coverage remains in `claude-last-closure/report.md`; this report covers the
final graph work, the runtime targets, and independent re-derivation of the benchmark.

## 1. Executed runtime targets — exact exits

All commands run from the Lab worktree against the frozen runtime. Raw output retained beside
this report.

| # | Command | Exit | Observed | Log |
|---|---|---|---|---|
| 1 | `node packages/main/dist/tasks/retired-authority-vocabulary-guard-smoke.js --lab-graph-loader-proof` | **0** | `LAB_GRAPH_LOADER_PROOF_GREEN {"filesChecked":1,"mutantsChecked":14}` | `guard-lab-proof.log` |
| 2 | same, plus `--unexpected` | **1** | `AssertionError: Lab proof does not accept combined or ambiguous selection` (actual argv `['--lab-graph-loader-proof','--unexpected']`) | `guard-lab-proof-extra-arg.log` |
| 3 | same, **no arguments** | **1** | `AssertionError: the exact approved loader call site must remain allowed: packages/main/src/tasks/prompt-full-context-envelope-smoke.ts`, line 2159, `unapproved non-literal dynamic module load`, token `…895187c6121e3be076bc1528950ad147452dd89da922ca43cd02be2923d5cb50` | `guard-no-arg.log` |
| 4 | `node packages/main/dist/tasks/cli-surface-smoke.js` | **0** | `cli surface smoke passed` | `cli-surface-smoke.log` |
| 5 | `node experiments/five-item-proof/last-closure.mjs` | **0** | ends `LAST_CLOSURE_REGRESSIONS_GREEN`; also `CAPACITY_CLAIMS_DEDUP_GREEN {"claims":17,"commands":134}`, `BATCH_RETRY_SELECTOR_GREEN`, `RESOURCE_AUDIT_SUPERSESSION_AND_MUTATION_GUARDS_GREEN`, `FINAL_REVIEW_REGRESSIONS_GREEN` | `last-closure.log` |
| 6 | `pinned-final-lab-cli.sh --version` | **0** | `Proof-or-Stop 0.3.284` | `pinned-final-version.log` |
| 7 | `pinned-final-lab-cli.sh --implementation-identity` | **0** | empty stderr; see §2 | `pinned-final-identity.json` |
| 8 | negative control: old `pinned-lab-cli.sh --version` | **1** | `IMPLEMENTATION_PIN_MISMATCH: expected=b2c35d95… actual=9f47a7be…` | `old-pin-negative-control.log` |

**Run 3 matches the recorded main baseline.** Against
`baseline-failure-controls/retired-guard-on-main.log` the assertion message, offending file,
line 2159, label and the `typescript-printer-remove-comments-sha256-v1` token are identical.
The only differences are the private-clone path prefix and the compiled line offsets
(`5212`/`5590` here vs `5195`/`5560` there), consistent with the ~17 added lines of the Lab
block. So the default failure is the pre-existing, unrelated
`prompt-full-context-envelope-smoke.ts` source pin, not anything this work introduced.

**Boundary on run 3:** the default entry aborts at `assertLoaderArgumentProvenance`, so guards
sequenced after that point did not execute in this run. That is also true of the main baseline.
It is a blocked run, not a partial pass, and the run emitted no PASS/GREEN marker of any kind.

**Run 8 is a true negative control.** The refusal names the digest mismatch explicitly and, after
path normalisation, is byte-identical to the recorded `owner-old-pin-refusal.log`. The old pin
refuses the currently prepared runtime, as intended.

## 2. Implementation identity — summary fields only

Output redirected to a file; only the summary is reproduced here (the artifact carries 1,656
file entries and is not reprinted).

```
digest    9f47a7be17e4a160055c48867c071a8e1e3651c09feede66c41bd879b4ad989f
fileCount 1656
labFiles  23   (entries whose path contains "lab", e.g. core/cli/lab-entrypoint.js)
```

These are identical to `final-implementation-identity.json`. Stronger: the two files are
byte-identical (`sha256 d1369413313577b77d13…`). The fingerprint differing from the earlier
frozen measurement is expected and disclosed — Lab package preparation and new test bytes are
in the pinned set; the old pin correctly refuses the new runtime (run 8), which is the property
that makes the change visible rather than silent.

## 3. Final graph work — reviewed against the actual diff

`09596536ad..HEAD` is 3 commits / 3 files / +88 −59:
`packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts`,
`experiments/five-item-proof/README.md`, `docs/validation-performance.md`. No handler, no
config, no gate wiring, no dist source. `handlers/graph.ts` itself is **unchanged** in this
range; only its two pins were renewed.

**The two renewed pins.** Both `DYNAMIC_CODE_GENERATION_FINGERPRINT_EXEMPTIONS` and
`BENIGN_NON_LITERAL_LOADER_SOURCE_FINGERPRINTS` move `handlers/graph.ts` from
`5c518f19…` to `986652de…`. I verified the stated justification against
`git diff cf21df09..HEAD -- packages/main/src/handlers/graph.ts` rather than accepting the
comment: the change adds a `GraphServer` interface with optional `address?()`, reads
`server.address?.()` on the same server object already returned by `startServer`, closes that
server and throws when the reported port is not an integer in 1..65535, and substitutes
`listeningPort` for `port` in the two URL branches. It introduces no `import()`, `require()`,
`createRequire`, `eval`, `Function` or `spawn` site, and no caller-chosen module path.
`resolveGraphPackage` is untouched.

`graph-surface-proof.log` supports this and is itself sound: `graph-surface-proof.mjs` derives
its "before" from `git show cf21df09:packages/main/src/handlers/graph.ts` (not a hard-coded
blob), deep-compares the five loader/`createRequire`/`spawnSync` call sites and the full
`resolveGraphPackage` producer body, and asserts the before/after canonical fingerprints equal
the old and new pin values exactly. Its scan filter matches an identifier list, so
`server.address` / `server.close` fall outside its captured set — the log's own `note` says so
in those words, and I closed that gap by reading the diff. Because run 1 passes with the new
pin, the pinned value is the guard's own canonical fingerprint of the current file, not an
independently asserted number.

**The focused proof does not weaken the controls.** `assertLoaderArgumentProvenance` gained an
optional `onlyFile` selector plus `filesChecked`/`mutantsChecked` counters; the flag block
asserts `deepEqual(argv.slice(2), ['--lab-graph-loader-proof'])`, runs
`assertDynamicCodeGenerationPositiveControls()` in full (not file-scoped), then asserts coverage
is exactly `{filesChecked:1, mutantsChecked:14}` — so silently dropping or skipping a mutant,
including the mutants whose fingerprints were refreshed, fails the proof. The marker
`LAB_GRAPH_LOADER_PROOF_GREEN` is distinct and is never emitted by the default entry. The
default entry is unchanged (run 3 is byte-equivalent to the main baseline failure).

## 4. Benchmark — recomputed from raw JSON

Recomputed independently from `full-config-comparison/results.json`; numbers written to
`benchmark-recomputation.json`.

* Manifest: baseline `cf21df09…`, **candidate `09596536…` in both arms**, config sha
  `50253a31…`, Node v26.8.1, 15 CPUs, peak concurrency 4 in both arms.
* Both arms: 134 events over 134 unique indices, **128 passed**, **6 failed**, and the failure
  index sets are identical — `{3, 105, 106, 126, 130, 133}`.
* Raw elapsed: RED `1255613.881791 ms` = **1255.614 s**; GREEN `1214496.165416 ms` =
  **1214.496 s**. (The prompt's "1255.613881791 ms" is off by 1000×, as it flags; I used the raw
  field.) Overall difference **41117.716 ms = 3.27 %**.
* **Attribution check, index 40** (`quorum-submit-smoke.js`, the exclusive
  `validate-plan-barrier` claim): RED `641357.466 ms`, GREEN `600967.051 ms`, difference
  **40390.415 ms = 98.23 % of the entire overall difference**, and only 6.3 % of that single
  command's own duration.
* The sum of per-command durations **increased** under GREEN, 1,940,214.7 ms → 2,154,462.7 ms
  (+11.0 %), while wall clock moved 3.27 %.

**Conclusion:** essentially the whole aggregate delta is one unpaired ~10-minute command varying
by 6 % of itself, while individual commands got slower under more overlap. With one pair, the
same candidate code in both arms, and six failures in each, this benchmark supports no
performance attribution — not a whole-Story claim, not 48 %, not any percentage. It shows only
that changing resource declarations did not break the inventory result set.

## 5. Failure controls — all six benchmark failures accounted for

* **Index 3** — the retired-guard `prompt-full-context-envelope` source pin, reproduced on
  branch `main` in the private clone (`retired-guard-on-main.log`) and reproduced by me here
  (run 3). Pre-existing and unrelated.
* **Indices 105, 106, 130, 133** — exactly the four rows of
  `prepared-main-regressions.json` (`proofstory-acceptance-rollout-smoke --issuer-mutations`,
  `proofstory-acceptance-basis-smoke`, `validation-tier-planner-smoke`,
  `validation-protocol-smoke`), recorded at head `cf21df09…`, branch `main`, with
  `mainUtilsContentPrepared` and `labBuilt` true, all exit 1. Three of the four prepared-main
  logs are byte-identical to the Lab logs; `proofstory-acceptance-rollout-smoke` differs in
  content while both exit 1 with the same assertion target — its output embeds run-varying
  material, so the exit and identity match but not the bytes.
* **Index 126** — `cli-surface-smoke`, the missing Lab extension. `named-main-controls.json`
  separates `named-main-with-missing-lab` (code 1) from `cli-prepared-on-main` (code 0), and
  preserves the note that the initial detached-clone failure was an authority-layout **fixture**
  error, not a reproduction. That distinction is intact in the artifact and I did not disturb it.
  My run 4 exits 0 on the prepared runtime, confirming the defect was missing preparation.

None of the six is attributable to the candidate.

## 6. Defects found by this verification

**None new.** Every executed target produced its expected exit and marker, the re-pin
justification survives comparison with the real diff, the identity artifact is byte-identical
to the recorded one, and the negative controls (combined argument, old pin) both refuse.

Two things worth stating rather than filing as defects, because both are already documented:
the focused proof exits 0 before the remainder of the guard, so it must never be substituted for
the default entry in any gate — nothing in this diff wires the flag into one; and the default
entry's abort at the loader-provenance stage means guards ordered after it were not exercised in
either run.

## 7. What the report may truthfully claim

Supported:
* The scoped graph defects are repaired and bound to the reviewed port implementation; the two
  canonical-AST pins were renewed with a justification verified against the actual source diff,
  not just the comment.
* `--lab-graph-loader-proof` executes the dynamic-code positive/drift controls and all 14 Graph
  provenance mutants (including repinned ones) over exactly one file, emits a unique Lab marker,
  and refuses combined or ambiguous selection.
* The default no-argument guard still runs the original guards and is still blocked by the
  pre-existing, unrelated `prompt-full-context-envelope` source pin, matching the main baseline.
* `cli-surface-smoke`, `last-closure.mjs`, the pinned version and implementation identity all
  pass on the frozen prepared runtime; the superseded pin correctly refuses it.

Not supported, and must not be stated:
* No passing full guard and no passing 134-command inventory — 6 failures in both arms.
* No performance attribution of any size from the benchmark, including 48 %, and no whole-Story
  or lead-time claim.
* No Story authority, release, integration or host rollout. This verification deliberately did
  not widen into unrelated baseline failures, global host rollout, generic decomposition or
  general API security.
