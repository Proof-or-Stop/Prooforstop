# P1 acceptance-history repair — independent verification

Scope: `git diff 37e50cd185..HEAD` (single commit `6d99d14d96`) in
`/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`.
Committed P1 diff is the authority; tests ran against the frozen `packages/main/dist`
(mtime 2026-09-09 01:31, contains `createIntentRevision` + `verification-intent-checkpoint.js`).
No build, no source/config/dist/Story edits, no subagents. Fixtures were disposable
`mkdtemp` repos; all logs/scripts written under this artifact directory.

**This audit covers P1 only. It does not certify the five-item follow-through as complete.**

## 1. Owner test suite — all green (actual exits captured)

| command | exit | key markers |
|---|---|---|
| `node experiments/five-item-proof/acceptance-revision.mjs` | 0 | `GOVERNED_PLAN_REVISION_GREEN`, `ACTUAL_CLI_APPEND_GREEN`, `ACCEPTANCE_CHANNEL_GREEN` |
| `node experiments/five-item-proof/acceptance-checkpoint.mjs` | 0 | `CHECKPOINT_HISTORY_DELETION_REFUSED; CANONICAL_PROJECTION_FAILS_CLOSED; ACTUAL_CLI_RECOVERY_GREEN; INTERRUPTED_PUBLICATION_RECOVERED` |
| `node packages/main/dist/tasks/verification-intent-repair-smoke.js` | 0 | `verification-intent-repair-smoke PASS` |
| `node experiments/five-item-proof/publication-restart.mjs` | 0 | `CROSS_PROCESS_PUBLICATION_RECOVERY_GREEN` |

Logs: `acceptance-revision.log`, `acceptance-checkpoint.log`, `repair-smoke.log`,
`publication-restart.log`.

## 2. Findings

### F1 — Trust-boundary edge: deleting the checkpoint directory fails **open**, not closed (top item)
Reproduction: `adversarial-erasure.mjs` (log `adversarial-erasure.log`), case **B**.
Sequence: append a signed must-level intent (`NEW`) via `verification_intent_append`;
then (i) strip `verificationIntentAmendments` and the appended lane from `checklist.json`
and (ii) `rm -rf .git/proof-or-stop-intent-checkpoints`.

Observed: `store.readChecklist` → **ACCEPTED**, `amendments=GONE`,
`missingRequired` drops 2 → 1, item keeps `status: "done"`;
`proof-or-stop checklist_get` exits **0** and prints the reduced checklist as if the
amendment never existed. That is exactly the "old coverage silently fresh" outcome.

Mechanism: `assertIntentCheckpointProjection` only enforces a checkpoint when the
in-file data still carries `verificationIntentAmendments`
(`verification-intent-checkpoint.ts:44-46`). Nothing *committed* records that a
checkpoint generation ever existed, so the pair (no history, no checkpoint) is
indistinguishable from a never-amended story.

Assessment under the stated model: the brief stipulates that local checkpoint metadata is
trusted, so this is **not a violation inside the sanctioned threat model** — but it is the
precise boundary, and it is asymmetric in the unsafe direction. The signing key's absence
fails closed (bad signature); the checkpoint's absence fails open (clean read). The
protected asset lives only in untracked `.git/` state, so any ordinary re-init, mirror,
`git worktree` rebuild from a bare copy, or archive/restore that omits `.git` silently
destroys the evidence rather than reporting it.
Suggested hardening: persist a signed, *committed* pointer (story-file
`intentCheckpointGeneration` + digest) so a missing checkpoint is detectable from tracked
state; then absence becomes `AMENDMENT_CHECKPOINT_MISSING`, matching case C below.

### F2 — Fresh clones cannot read an amended checklist at all (availability; pre-existing class)
Case **C**: after committing the story files, `git clone` the fixture and run
`checklist_get` in the clone → exit **1**, `AMENDMENT_CHECKPOINT_MISSING`;
`.git/proof-or-stop-intent-checkpoints` is absent in the clone (confirmed
`C_clone_has_checkpoint=false`).

This is a refusal, not corruption: nothing is written and the source repo is unaffected.
It is also not introduced by P1 in substance — the Ed25519 signing key lives in the same
untracked `git-common-dir`, so pre-P1 a cloned amendment already failed with
`AMENDMENT_INVALID_SIGNATURE_OR_BINDING`. P1 changes the error, not the reachability.
Flagging it because it means an amended Story is repo-local by construction: no reviewer
on a clone can read the checklist, and `verification_intent_recover` cannot help there
(no checkpoint to restore).

### F3 — Two cosmetic defects, no behavioral impact
`machine.ts:163-164` and `machine.ts:885` call `rethrowIntentAmendmentIntegrityError(error)`
**twice in a row**; the second call is dead. Harmless (idempotent), but it is a visible
copy-paste artifact in the exact code path the item is about.

No other exploitable defect found. Specifically I could not produce any state where a
refused write left permanent corruption: every refusal path
(`AMENDMENT_HISTORY_REMOVAL_REFUSED`, `AMENDMENT_CURRENT_INTENT_MISMATCH`,
`AMENDMENT_CHECKPOINT_PROJECTION_MISMATCH`, `AMENDMENT_REPLAN_REQUIRED`,
`AMENDMENT_OWNER_*`, `*_STALE_OR_MISSING`) throws **before** `writeJson`, and the owner
suite re-asserts byte-identical `checklist.json` after each refusal.

## 3. Claim-by-claim verdicts

1. **Original signed history survives a legal INIT/PLAN revision** — HOLDS.
   `acceptance-revision.mjs` asserts `amendments.length === 2` with
   `amendments[0]` deep-equal to the pre-revision record; `createIntentRevision`
   chains `previousSignature`/`beforeHash` to the prior record and
   `assertIntentAmendments` rejects a revision that is not preceded by an existing record
   (`!previous → AMENDMENT_INVALID_REVISION`).
2. **Role/phase/scope boundaries preserved** — HOLDS. `createIntentRevision` refuses
   outside INIT/PLAN (`AMENDMENT_REPLAN_REQUIRED`), requires a ≥30-char reason, owner
   lease validity and a non-stale lease (`AMENDMENT_OWNER_REQUIRED`,
   `AMENDMENT_OWNER_GENERATION_REQUIRED`); appends still refuse outside DEV (test asserts
   `/DEV/`). Append records additionally pin `scopeHash === previous.scopeHash`, so an
   append can no longer ride a scope change.
3. **Status reopens; old coverage is not silently fresh** — HOLDS. The revision path forces
   `status='pending'`, clears `startTime`/`endTime`, and
   `buildVerificationCoverage` still reports `missingRequired = 2`. The new
   `AMENDMENT_REVISION_STATUS_REFUSED` guard blocks combining a completion status with an
   acceptance edit in one call. (Reopening is enforced; a *later*, separate
   `status='done'` call remains gated by coverage, not by this guard — correct by design.)
4. **Whole-field deletion detected by signed Git-metadata checkpoints** — HOLDS *while the
   checkpoint exists*. Verified independently (case A): stripping the field yields
   `AMENDMENT_CHECKPOINT_PROJECTION_MISMATCH` from `readChecklist`, from
   `buildCanonicalStory`, and from the real CLI (`checklist_get` exit 1). Qualified by F1.
5. **Interrupted projection restorable through the actual CLI without re-running commands** —
   HOLDS. `acceptance-checkpoint.mjs` injects a `writeJson` failure after the checkpoint
   write, then restores via `node dist/cli.js verification_intent_recover` (exit 0) and the
   recovered checklist contains the `RECOVERED` intent with `missingRequired = 4`.
   `publication-restart.mjs` confirms the same across a separate process (exit 0).
   `restoreIntentCheckpoint` writes only `checkpoint.data`; it never manufactures a PASS.
6. **Same-owner / active-phase / stale-digest guards** — HOLDS. `verification_intent_recover`
   refuses in DONE/DISCARDED (`AMENDMENT_RECOVERY_ACTIVE_STORY_REQUIRED`), requires a valid
   owner lease and no delegated-agent authority, requires a ≥30-char reason for `apply`,
   and a wrong `expectedCheckpointDigest` throws `AMENDMENT_CHECKPOINT_STALE_OR_MISSING`
   (test asserts `/STALE/`). Default (no `apply`) reports `writes:0`.
7. **Canonical equivalent JSON key ordering accepted** — HOLDS. The suite rewrites every
   amendment record with reversed key order, writes it, and re-reads deep-equal to the
   pristine document; the switch from `JSON.stringify` to `digestCanonicalJson` in
   `store.writeChecklist` is what makes the removal check order-insensitive.
8. **Errors cannot degrade to an empty checklist in canonical projections / gate fallbacks** —
   HOLDS for the paths I could reach. `IntentAmendmentIntegrityError` carries `code` and is
   re-thrown by `rethrowIntentAmendmentIntegrityError` in `machine.ts`, `guard-utils.ts`,
   `checklist.ts`; `cli-engine.ts:1003` rethrows anything that is not
   `StoryArtifactMissingError`. Independently: under a corrupted checklist,
   `checklist_get` exits 1 and `story_advance REVIEW` is refused (exit 1). I found no
   remaining `catch {}` around `readChecklist` that substitutes `{items: []}`.
   Caveat: signature-verification infra failures return `false` (→ typed
   `AMENDMENT_INVALID_SIGNATURE_OR_BINDING`), so they also fail closed.

## 4. Not covered
Concurrency under real parallel writers beyond the single cross-process restart test;
non-Git projects (`checkpointPath` returns `undefined` → `AMENDMENT_CHECKPOINT_GIT_REQUIRED`
on write) were not exercised; the ~40 unrelated `catch` → `rethrow…` edits outside
checklist/store/machine/guard-utils were read, not executed; no full test suite was run.

## 5. Artifacts
`acceptance-revision.log`, `acceptance-checkpoint.log`, `repair-smoke.log`,
`publication-restart.log`, `adversarial-erasure.mjs` + `.log`,
`adversarial-erasure2.mjs` + `.log`.
