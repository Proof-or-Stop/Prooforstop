import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,cpSync,existsSync,readdirSync} from 'node:fs';
import {execFileSync,spawnSync} from 'node:child_process';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
const LAB='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const D=LAB+'/packages/main/dist';
const {StoryStore}=await import(D+'/core/store.js');
const {createChecklistHandlers}=await import(D+'/handlers/checklist.js');
const {acquireOwnerLease}=await import(D+'/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(D+'/core/digest.js');
const {resetConfigCache}=await import(D+'/core/config.js');
const {buildVerificationCoverage}=await import(D+'/core/verification.js');
process.env.PROOF_OR_STOP_SESSION_ID='claude-adversarial';
const cli=D+'/cli.js';
const root=mkdtempSync(join(tmpdir(),'claude-adv-'));const storyId='B-adv-lab';
const git=a=>execFileSync('git',a,{cwd:root,encoding:'utf8',stdio:'pipe'}).trim();
const run=(cmd,payload,cwd=root)=>{const r=spawnSync(process.execPath,[cli,cmd,JSON.stringify(payload)],{cwd,encoding:'utf8',env:process.env,timeout:60000});
  return {cmd,status:r.status,out:(r.stdout||'').trim().slice(0,700),err:(r.stderr||'').trim().slice(0,700)};};
try{
 mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const subject=true;\n');
 writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
 writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
 git(['init','-q','-b','work']);git(['config','user.name','Lab']);git(['config','user.email','lab@example.test']);git(['add','.']);git(['commit','-qm','fx']);git(['branch','main']);resetConfigCache();
 const store=new StoryStore(root);
 store.writeStory(storyId,{storyId,title:'Adv',name:'adv',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
 const original={id:'CHK-001',title:'Boundary',context:'ctx',status:'done',startTime:null,endTime:null,files:{modify:['src/subject.js'],create:[],test:[]},verificationIntent:{happy:[{id:'OLD',desc:'Original requirement',type:'cli',priority:'must'}],edge:[],adversarial:[]},verificationEvidence:[]};
 store.writeChecklist(storyId,{items:[original]});
 acquireOwnerLease(store.storyDirPath(storyId),{command:'fixture',cwd:root});
 const h=createChecklistHandlers({store,root,scanRoot:root});
 h.verification_intent_append({storyId,itemId:'CHK-001',expectedIntentHash:digestCanonicalJson(original.verificationIntent),reason:'Discovered boundary strengthens coverage within the existing item scope for audit.',addition:{edge:[{id:'NEW',desc:'The identified boundary must pass',type:'cli',priority:'must'}]}});
 const pristine=store.readChecklist(storyId);
 const ckDir=join(root,'.git','proof-or-stop-intent-checkpoints');
 const ckSub=join(ckDir,readdirSync(ckDir)[0]);
 console.log('SETUP_OK checkpoint files='+JSON.stringify(readdirSync(ckSub)));

 // (A) strip signed history from checklist.json, checkpoint intact -> gate CLIs must fail closed
 const stripped=structuredClone(pristine);delete stripped.items[0].verificationIntentAmendments;stripped.items[0].verificationIntent.edge=[];stripped.items[0].status='done';
 store.writeJson(storyId,'checklist.json',stripped);
 for(const c of [['checklist_get',{storyId}],['story_advance',{storyId,phase:'REVIEW'}],['done_oracle',{storyId}],['session_brief',{storyId}],['checklist_progress',{storyId}]]) console.log('A '+JSON.stringify(run(...c)));

 // (B) attacker also removes the signed checkpoint history entirely
 cpSync(ckDir,root+'/ck-backup',{recursive:true});rmSync(ckDir,{recursive:true,force:true});
 let bRead='ACCEPTED_NO_ERROR';try{const d=store.readChecklist(storyId);bRead='ACCEPTED items='+d.items.length+' amendments='+(d.items[0].verificationIntentAmendments?'yes':'GONE')+' missingRequired='+buildVerificationCoverage(d).missingRequired;}catch(e){bRead='REFUSED '+(e.code||e.message);}
 console.log('B_readChecklist '+bRead);
 console.log('B '+JSON.stringify(run('checklist_get',{storyId})));
 cpSync(root+'/ck-backup',ckDir,{recursive:true});

 // (C) fresh clone portability: committed story files, git-metadata checkpoint+key not carried
 store.writeJson(storyId,'checklist.json',pristine);
 git(['add','-A']);git(['commit','-qm','story']);
 const clone=mkdtempSync(join(tmpdir(),'claude-adv-clone-'));
 execFileSync('git',['clone','-q',root,clone],{encoding:'utf8',stdio:'pipe'});
 console.log('C_clone_has_checkpoint='+existsSync(join(clone,'.git','proof-or-stop-intent-checkpoints')));
 console.log('C '+JSON.stringify(run('checklist_get',{storyId},clone)));
 rmSync(clone,{recursive:true,force:true});
}finally{rmSync(root,{recursive:true,force:true});resetConfigCache();}
