# Heavy-validation reuse: independent pre-implementation review

Reviewer: Claude CLI (independent). Date: 2026-09-09.
Subject worktree: `.worktrees/Lab-five-item-proof-20260908`, branch `codex/lab-five-item-proof-20260908` (read-only inspection; no source/config/Git/Story/lease changes made).
Concurrent acceptance-history WIP was ignored per instruction.

## Verdict

**The "duplicated heavy validation" premise is largely false for this repository as configured.** At most **6 of 65** DONE full-suite members and **6 of 134** routine commands are the same script with the same argv and cwd — and none of them are heavy. Every expensive member is in the *no-counterpart* set. The correct minimal integration is **no execution-reuse bridge**; the real, cheap win is registering full-suite membership into the one canonical command inventory that already exists.

## Measured facts (not assumptions)

**Routine** — `proof-or-stop.config.json` → `validate.commands`: **134** entries. 132 are direct `node <path>`; 2 are `npm --prefix … run …`. None declares a `cwd` (all root). Targets: 72 `packages/main/dist/tasks/*.js`, 58 `packages/main/tests/*.mjs`, 2 `scripts/*.mjs`, 2 other. Policy distribution: `assurance` = 59 `full-only` / 54 `story-selectable` / 21 undeclared; `fullBaselineReusePolicy` = 59 `forbidden` / 54 `not-applicable` / 21 undeclared; `riskTier` = 59 `validation-infra`, 49 `shared`, 3 `local`, 2 `gate`, 21 undeclared. **`executionReuse`: 0. `executionInputs`: 0.** 3 declare `env`.

**DONE** — `doneRequiredCommands` has exactly **two** entries: `npm --prefix packages/main run build` (`providesBuildProof: packages-main-build`) and `npm test` (`requiresBuildProof: packages-main-build`, timeout 7 200 000 ms).

**`npm test`** = `pretest` (`node scripts/ensure-dist.mjs`) then `node packages/main/dist/tasks/full-suite-runner.js`. Membership = `test:serial-reference` (**63**) + `test:serial-reference-prefix` (**2**) = **65** entries. No member has a `pre*`/`post*` lifecycle script; no member script is compound; 13 members are one-level `npm --prefix packages/main run …` wrappers.

**Overlap** (resolved through the wrappers, comparing absolute script path + trailing argv + resolved cwd):

| class | count |
|---|---|
| identical script + argv + cwd | **6** |
| same script, different argv or cwd | **5** |
| no routine counterpart at all | **54** |

The 6: `test:production-test-seam-guard`, `test:codex-heartbeat-timeout`, `test:validation-tier-planner`, `test:single-owner-extraction`, `test:validation-protocol`, `test:narrowing-repin`. All are cheap `repoRead` members with default 120 s budgets. The heavy members — `test:brief-output` (450 s budget), `test:experience-arm-isolation-e2e` (~397 s standalone, per the source comment), `test:proofstory-acceptance-rollout` (300 s, `isolatedHeavy`), `test:e2e` (180 s), `test:experiments` — are **all** in the 54.

## Essential counterexamples (similar name, different execution)

1. `test:proofstory-acceptance-rollout` runs `node packages/main/dist/tasks/proofstory-acceptance-rollout-smoke.js` with **no args**; the routine entry for the same file passes **`--issuer-mutations`**. Different assertion set behind one name.
2. Four members run under `npm --prefix packages/main`, so their cwd is `packages/main` and their script arg is `dist/tasks/…` / `tests/…`, while routine runs the same file from the repo root: `test:retired-authority-vocabulary-guard`, `test:scope-shrinkage-withdrawal-floor-smoke`, `test:withdrawn-disposition-smoke`, `test:milestone-status`. cwd is part of the project's own complete runtime tuple (`validation-command-identity.ts:496-516`), and for the `gitroot-cwd` / `wrapper-root` family the cwd *is* the assertion.
3. **Even the 6 are not identical executions.** The runner spawns `/usr/bin/time -p -o <tmp> npm run <name>` (`full-suite-runner.ts:511-518`) with an env overlay `TMPDIR`/`TMP`/`TEMP` = per-member temp root, plus `PROOF_OR_STOP_FULL_SUITE_TEMP_ROOT` and `…_OWNERSHIP_TOKEN`. Routine spawns `node` directly with ambient TMPDIR and none of those. Bounded probe in an isolated temp fixture: **20 `npm_*` variables in the child under `npm run`, 0 under direct `node`** (`npm_lifecycle_event`, `npm_node_execpath`, …).
4. **The identity cannot currently see difference 3.** `effectiveValidationCommandEnvironment` (`validation-command-environment.ts:132-157`) snapshots the *executor's* `process.env` plus the declared overlay — not what `npm` will inject into the grandchild. Two genuinely different executions would therefore produce the *same* `effectiveEnvironmentDigest`. Any "same script path ⇒ same result" cache is unsound on this codebase for exactly this reason.
5. **A routine receipt is not a full-suite result.** The runner derives `assertionInventory` from the `PROOF_OR_STOP_FULL_SUITE_SUMMARY=` marker plus `observedOutputSignatures` plus a `terminal-exit:` token (`full-suite-runner.ts:63-84, 554-571`), and enforces owned-target preflight/residue: a member that exits 0 but leaves an owned resource behind is rewritten to `FAIL` (`:500-508, 529-535`). It also records `cleanupManifest`, `cleanupOutcomes`, cpu accounting and `canonicalMemberAssertionId`. Substituting a routine result silently drops that residue gate.

## The reuse machinery already exists — and already refuses this, twice over

- `shared-validation-execution.ts:27-35` (`sharedValidationReuseAllowed`) requires `executionReuse === 'exact-inputs'`, non-empty `executionInputs`, not `fullBaselineReusePolicy: 'forbidden'`, not `closurePolicy: 'never-reuse'`, `riskTier` ∉ {`gate`,`validation-infra`}, and **no** `requiresBuildProof`/`providesBuildProof`/`proof`.
- **0 of 134** routine commands declare `executionReuse`/`executionInputs` → the producer path is dormant.
- **Both** DONE commands are permanently ineligible (one provides, one requires the build proof). So `handlers/done-required-validation.ts:40` `commitsAdmissionForReuse` is always `false` today, and DONE always takes `refuseHeavyCertificationUnlessAdmitted`.
- Routine publication is behind a second switch: `handlers/verifier.ts:1553` enables `sharedExecution` only when `args.story && (dynamicMode === 'off' || config.validate.sharedExecution === true)`. Config sets `validate.dynamic.mode = 'observe'` and defines no `validate.sharedExecution`. Both switches are off.

The protocol itself is sound where it is wired: `shared-validation-execution.ts:69` declines on any dirty/untracked workspace; `:72-74` freezes preflight facts and re-checks probe + workspace + input files + implementation digest; `:92` and `:102` re-check before consumption and before publication; `:47` binds `executionImplementationIdentity().digest` so a caller cannot opt into reuse while opting out of runtime implementation identity; `:106` refuses a non-PASS or non-reusable receipt.

## Built-byte and no-run controls that must survive any change

- `full-suite-runner.ts:622` — `execFileSync(node, ['scripts/verify-full-suite-build-binding.mjs'])` before the suite runs.
- `scripts/full-suite-build-binding.mjs` `verifyBuildBinding` recomputes sha256 over **all of `packages/main/src` (+ its `tsconfig.json` and `package.json`) and all of `packages/main/dist`**, comparing *both* to the manifest. This is **not** a manifest-bytes hash: dist is validated against source. Bounded self-test executed in its own `mkdtemp` fixture: `full-suite-build-binding-self-test: PASS (stale source and tampered dist rejected)`. Residual limit worth stating: it proves src and dist were *recorded together by a build*, not that dist is the compiler output of src — its strength depends on `writeBuildBinding` being called immediately after `tsc` in `build-main-with-binding.mjs`.
- `scripts/ensure-dist.mjs` — content-bound rebuild under a lock, skips only when the binding verifies.
- Membership fails closed on three authorities: `parseSerialReference` / `entriesFromSerialReference` (`unknownPolicy`, `stalePolicy`, `missingScripts`) / `validateInventory` (`full-suite-runner.ts:244-282`).
- DONE freshness and coverage: `done-required-validation.ts:1090-1101` (storyId, status, `policy-drift`, `command-set-drift`, receipt coverage, command-spec digest coverage), `:1110-1114` (`stale-material`, `stale-storyFilesHash`), `:1115-1116` (`validateSelfHostBuildProof`, execution-identity coverage), `isPackagesMainBuild` `:562-585`.
- Dirty control on the opt-in path: `handlers/done-required-validation.ts:66-70` throws `SHARED_DONE_REQUIRES_CLEAN_WORKSPACE`.

## Recommended minimal safe integration

**Recommendation: do not build a routine↔DONE execution-reuse bridge.** The ceiling is 6 cheap members (<10 % of suite membership, well under that by wall-clock). Making it sound would require binding the launcher (`npm` vs `node`) and the runner's TMPDIR/ownership overlay into the execution identity, and reproducing the runner's assertion-inventory and residue post-processing in the routine receipt. That is more code, on the DONE gate, than it saves.

If the owner proceeds anyway, the only safe sequence is, in this order and nothing more:

1. **Config only, case by case:** reconcile the 5 near-misses *where the assertion set is genuinely the same*. `test:proofstory-acceptance-rollout` vs the routine `--issuer-mutations` entry is a real argv divergence to decide deliberately. Do **not** "normalize" the wrapper-root / gitroot-cwd family — their cwd is the assertion under test.
2. **Annotate only the reconciled entries** with `executionReuse: 'exact-inputs'` and explicit `executionInputs`, activating the already-audited path at `validation-executor.ts:1328`. Leave every `full-only` / `forbidden` / `validation-infra` / `gate` entry untouched.
3. **Do not flip `validate.sharedExecution`** while `validate.dynamic.mode = 'observe'` until `effectiveValidationCommandEnvironment` (or the identity around it) captures the *child's* launcher and env overlay. Otherwise counterexample 4 makes the digest blind to a real difference.
4. Accept that DONE still gains nothing: its unit of execution is `npm test`, which carries `requiresBuildProof` and is excluded by design.

**Explicitly rejected** (each would break a gate the repository currently holds): a whole-full-suite result cache; relaxing or removing `requiresBuildProof` / `providesBuildProof` / `fullBaselineReusePolicy: 'forbidden'` / the `gate`+`validation-infra` tier exclusions to widen eligibility; and any synthetic arithmetic consumer standing in as a production proof.

## On "one canonical full test plan in both consumers"

The mechanism already exists: `assurance` ∈ {`always`,`story-selectable`,`full-only`}, `fullBaselineReusePolicy` ∈ {`exact-current-epoch-only`,`forbidden`,`not-applicable`}, and receipts admissible only when `producedBy === 'canonical-full-baseline'` (`story-aware-validation.ts:764`, `834-880`; `:874-877` makes `full-only` + `forbidden` execute unconditionally).

But the evidence says merging the *plans* costs rather than saves. The two sets are **near-disjoint, not duplicated**: 54 of 65 full-suite members have no routine counterpart, and 128 of 134 routine commands are not members. A literal single plan means ~193 distinct executions in both places. The 59 routine `full-only` + `forbidden` commands already declare "run every time, never reuse", so folding them into the DONE suite adds 59 unconditional executions to a 7200 s budget.

**The version worth doing** is one canonical *inventory* with consumer-specific selection — which the code is already shaped for (`buildValidationCommandInventory` + `commandSetDigest`, `buildDynamicValidationPlanInternal` selection rows). The concrete gap: **full-suite membership is a fourth authority the validation inventory never sees.** Those 54 members have no command id, no closure certificate, no risk tier, no relevance input, and no `commandSetDigest` coverage — so `command-set-drift` at `done-required-validation.ts:1093` cannot detect a change in what `npm test` actually runs beyond the `npm test` string itself. Registering the 65 members as inventory entries (`assurance: 'full-only'`, appropriate `fullBaselineReusePolicy`) would give one canonical inventory, tighten drift detection, and keep each consumer's assertion set intact — without merging any execution. That is the highest-value actionable item in this review.

## Limits of this review

No `npm test`, no routine `validate`, no DONE gate, and no build was run; **nothing here should be read as declaring the root pipeline complete**. The only executions were two bounded probes: an `npm run` vs `node` environment comparison in a throwaway `/tmp` fixture, and `verify-full-suite-build-binding.mjs --self-test`, which operates entirely inside its own `mkdtemp` root. Overlap figures come from parsing `package.json`, `packages/main/package.json` and `proof-or-stop.config.json` and resolving npm wrappers one level, which covers all 13 wrapper members observed. No active Story JSON was read; no web access. The concurrent acceptance-history WIP was not inspected.
