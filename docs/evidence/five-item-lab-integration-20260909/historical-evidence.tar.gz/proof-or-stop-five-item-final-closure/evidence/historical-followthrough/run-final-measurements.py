from pathlib import Path
import json,subprocess,time,os,hashlib
art=Path('/Users/jek/.codex/artifacts/proof-or-stop-five-item-followthrough-20260909')
lab=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908')
ready=art/'claude-last-closure/runtime-phase-done.json'
while not ready.exists(): time.sleep(3)
handshake=json.loads(ready.read_text());assert handshake.get('runtimeWorkFinished') is True,handshake
print('Claude runtime phase finished; source remains frozen',flush=True)
out=art/'final-heavy';out.mkdir(exist_ok=True)
paths=['packages/main/dist/core/causal-evidence.js','packages/main/dist/core/shared-validation-execution.js','packages/main/dist/handlers/checklist.js','packages/main/dist/tasks/tool-executed-evidence-receipt-smoke.js','proof-or-stop.config.json']
binding={'candidateCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab,text=True).strip(),'files':{p:hashlib.sha256((lab/p).read_bytes()).hexdigest() for p in paths},'note':'One final pair after publication/capacity fixes; do not pool with predecessor three-pair measurements.'}
(out/'source-bindings.json').write_text(json.dumps(binding,indent=2))
env={**os.environ,'FIVE_ITEM_PAIRS':'1','FIVE_ITEM_PROOF_OUTPUT':str(out)}
with (out/'run.log').open('w') as f:r=subprocess.run(['node','experiments/five-item-proof/real-suite-consumers.mjs'],cwd=lab,env=env,stdout=f,stderr=subprocess.STDOUT)
(art/'measurement-stage.json').write_text(json.dumps({'stage':'heavy_complete','exitCode':r.returncode}))
print('FINAL_HEAVY_EXIT',r.returncode,flush=True);assert r.returncode==0
for p,d in binding['files'].items():assert hashlib.sha256((lab/p).read_bytes()).hexdigest()==d,p
print('Starting all134 resource comparison',flush=True)
with (art/'full-config-run.log').open('w') as f:r=subprocess.run(['node',str(art/'full-config-benchmark.mjs')],cwd=lab,stdout=f,stderr=subprocess.STDOUT)
(art/'measurement-stage.json').write_text(json.dumps({'stage':'full_config_complete','exitCode':r.returncode}))
print('FULL_CONFIG_EXIT',r.returncode,flush=True);assert r.returncode==0
