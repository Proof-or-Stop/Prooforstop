import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const lab='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const ts=createRequire(lab+'/package.json')('typescript');
const file='packages/main/src/handlers/graph.ts';
const baseline=execFileSync('git',['show','cf21df09c273074d7aa3227a5f436c6f5badf47a:'+file],{cwd:lab,encoding:'utf8'}),candidate=fs.readFileSync(lab+'/'+file,'utf8');
const printer=ts.createPrinter({removeComments:true,newLine:ts.NewLineKind.LineFeed});
function scan(text){const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS),calls=[],producers=[];
 function visit(n){if((ts.isCallExpression(n)||ts.isNewExpression(n))&&(n.expression.kind===ts.SyntaxKind.ImportKeyword||['eval','Function','createRequire','require','spawnSync'].includes(n.expression.getText(source))))calls.push(printer.printNode(ts.EmitHint.Unspecified,n,source));if(ts.isFunctionDeclaration(n)&&n.name?.text==='resolveGraphPackage')producers.push(printer.printNode(ts.EmitHint.Unspecified,n,source));ts.forEachChild(n,visit);}visit(source);return {fingerprint:createHash('sha256').update(printer.printFile(source)).digest('hex'),calls,producers};}
const before=scan(baseline),after=scan(candidate);assert.ok(before.calls.length>=5);assert.equal(before.producers.length,1);assert.deepEqual(after.calls,before.calls);assert.deepEqual(after.producers,before.producers);assert.equal(before.fingerprint,'5c518f1967f915dcf6ee270c5f7f4f58c5dfafac4beb76fd9801e7191938f303');assert.equal(after.fingerprint,'986652de3f98248d87c8c13e775029e7ba1177caf7e96030df9d2da460b6bab0');
console.log(JSON.stringify({file,before,after,note:'Dynamic loader/eval/createRequire/spawn sites and graph package producer are unchanged. New server.address() and invalid-port server.close() calls are separately reviewed as methods of the same returned GraphServer; this is not a claim that all method calls in the handler are unchanged.'},null,2));console.log('GRAPH_LOADER_SURFACE_PRESERVED');
