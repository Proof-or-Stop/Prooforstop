# Writer resource declarations — independent audit

Reviewer: Claude (verifier). Owner: Codex (developer).
Worktree audited: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`
HEAD `4830880ffc`; working tree clean except two untracked files (`AGENTS.override.md`,
`experiments/five-item-proof/real-suite-consumers.mjs`).
Scope: the five remaining undeclared routine writers (`validate.commands` indices 1, 80, 82, 83, 125)
and both `doneRequiredCommands`. Static source reading plus one read-only execution of an already
registered validate command (§3). No source/config/dist edits, no builds, no Story mutation, no subagents.
No timing or performance claim is made anywhere in this document.

---

## 0. Verdict

| Question | Verdict |
|---|---|
| Is the stated premise ("a workspace-local writer is not by itself grounds for globally exclusive git-common-dir capacity") true? | **Verified true.** §2 |
| Does leaving these seven undeclared actually force cross-worktree exclusivity? | **Verified true**, and the mechanism is exact. §1 |
| Does the proposed shape (retain exclusive per-worktree `validate-plan-barrier` + enumerate real shared resources + automatic exclusive workspace claim) hold? | **Sound, and the retained barrier is load-bearing** — path claims alone cannot serialize these writers. §1.3 |
| Can all seven be declared today with source-supported completeness? | **Six yes, one partly.** §4 gives concrete JSON for 1, 80, 82, 83, done[0], done[1]; #125 is declarable but with one residual unknown. §7 |
| Is there a blocker? | **Yes, and it is already firing today.** A registered validate command (`validate.commands[112]`) fails right now, and declaring four of the five adds four more failures to it. §3 |
| Does declaring the five deliver independent cross-worktree routine validate? | **Only partly, and not for the full plan.** #125 binds machine-global TCP ports; the capacity ticket always claims the whole command universe. §5.1, §6.3 |

---

## 1. Mechanism, verified from source

### 1.1 Two independent layers

**Plan layer** — intra-invocation, in-process. `resolveValidationCommandResourceClaims`
(`packages/main/src/core/validation-executor.ts:1768-1796`):

- declared, non-empty → `[barrier(shared), ...declared]`, `exclusiveByDefault: false`
- absent or `[]` → `[barrier(exclusive)]`, `exclusiveByDefault: true`

`VALIDATE_PLAN_BARRIER_CLAIM_KEY = '.proof-or-stop/runtime/validate-plan-barrier'`
(`validation-executor.ts:1722-1723`), canonicalized against `projectRoot`
(`executeValidationPlan`, `validation-executor.ts:1864`). In this worktree `.proof-or-stop/`
and `.proof-or-stop/runtime/` are real directories, not symlinks, so the barrier canonicalizes to
`fixed-path:<worktree>/.proof-or-stop/runtime/validate-plan-barrier` — **per-worktree**. Confirmed.

**Capacity layer** — cross-invocation, cross-process. `declaredValidationCapacity`
(`packages/main/src/core/validation-execution-lock.ts:831-845`) feeds
`withWorkspaceValidationCapacity` (`:640`), whose queue directory is
`validationCapacityLockPath` (`:265-281`) → `resolveGitCommonLockRoot` (`:233-244`) →
`VALIDATION_CAPACITY_LOCK_REL = '.proof-or-stop/locks/validation-capacity.lock'` (`:35`).

Measured in this worktree:

```
git rev-parse --git-common-dir → /Users/jek/Documents/GitHub/Prooforstop/.git
resolveGitCommonLockRoot        → /Users/jek/Documents/GitHub/Prooforstop
capacity queue                  → /Users/jek/Documents/GitHub/Prooforstop/.proof-or-stop/locks/validation-capacity.lock
```

That directory is shared by **every worktree of this repository**. This is the "global" in the brief,
and it is exactly per-git-common-dir, not per-machine.

### 1.2 Why one undeclared command makes the whole queue exclusive

`declaredValidationCapacity` line 834:

```ts
if (!commands.length || commands.some(command => !command.resources?.length)) return {};
```

`{}` → `options.resources === undefined` → `capacityDeclaration` returns `null`
(`validation-execution-lock.ts:584`) → the ticket is published without `resources.json`
(`:617-632`) → `readCapacityDeclaration` returns `null` (`:590-600`) → in
`capacityTicketAdmitted` (`:602-615`) a ticket at index > 0 with `own === null` is refused, **and**
any later ticket sitting behind a null-declaration ticket is refused because `earlier === null`.
Result: strictly one official validation at a time across all worktrees of this repo.

The routine-validate call site passes the **entire** configured command universe, not the planned
subset: `verifier.ts:1552-1553` calls
`declaredValidationCapacity(configuredValidationCommands(projectRoot), handlerGitCwd)`.
The DONE call site is `handlers/done-required-validation.ts:53`,
`declaredValidationCapacity(policy.commands, gitCwd)`.

So the fix is genuinely all-or-nothing: **all 134 routine commands and both DONE commands must carry
a non-empty `resources` array, or nothing changes.** Current state, computed from the config:
134 commands, 129 declared, 5 undeclared — exactly indices 1, 80, 82, 83, 125; both
`doneRequiredCommands` have no `resources` field.

### 1.3 Exact-key comparison, and why the retained barrier is load-bearing

`claimsConflict` (`packages/main/src/core/keyed-scheduler.ts:133-139`) compares
`a.canonicalKey === b.canonicalKey` and conflicts only if one side is `exclusive`. There is **no
ancestor or prefix containment**. `pathIsContained` (`:76-79`) exists solely for the ownership-root
guard in `canonicalFilesystemPath` (`:81-99`) and for `runner-cleanable` symlink checking (`:101-110`);
it is never used in admission.

Consequence, from the config's actual declared keys:

| declared key | count of routine commands declaring it |
|---|---|
| `git-common-dir` `.` shared | 111 |
| `fixed-path packages/main/dist` shared | 18 |
| `fixed-path proof-or-stop.config.json` shared | 10 |
| `fixed-path packages/main/src` shared | 7 |
| `fixed-path package.json` shared | 5 |
| `fixed-path scripts` shared | 4 |
| `fixed-path bin` shared | 3 |
| `fixed-path packages/main/dist/tasks` shared | 1 (index 79) |
| `fixed-path packages/main/tests/red` shared | 1 (index 79) |
| `fixed-path packages/utils/dist` shared | 1 |
| `fixed-path .proof-or-stop/story/actives` shared | 1 |

Every single declared claim in the config is `shared`. There is not one `exclusive` claim today.

Now the load-bearing part. #80 writes into `packages/main/dist/tasks/` and
`packages/main/tests/red/`. An exclusive claim on `packages/main/dist/tasks` conflicts with index 79
(which names that exact key) but **does not conflict with the 18 readers that name
`packages/main/dist`** — different canonical key, no containment. Symmetrically, #1 and #82 rewriting
`packages/main/dist` do not conflict with index 79's `packages/main/dist/tasks` claim.

**Therefore path claims alone cannot make these writers safe, and the proposal's decision to retain an
explicit `exclusive` claim on the barrier key is not belt-and-braces — it is the only thing that
serializes them.** I verified the retained-barrier encoding works: a command that declares
`{class:'fixed-path', key:'.proof-or-stop/runtime/validate-plan-barrier', access:'exclusive'}`
receives `[barrier(shared), barrier(exclusive), ...]` from the resolver; since every other plan entry
holds `barrier(shared)` and `claimsConflict` fires when *either* side is exclusive, the writer still
runs alone. The only thing that changes is `exclusiveByDefault`, which flips to `false` — see §3 and §7.1.

### 1.4 The automatic exclusive workspace claim

`declaredValidationCapacity` line 835 prepends
`{class:'fixed-path', key: resolve(workspaceRoot), access:'exclusive'}`. Two official validations in the
**same** workspace therefore always conflict and serialize. Two in **different** worktrees produce
different absolute paths and do not conflict on this claim. `VALIDATION_EXECUTION_RUNTIME_REQUIREMENTS
.declaredInvocationCapacity = 2` (`core/runtime-fact-registry.ts:169`), so the ceiling is two concurrent
official validations repo-wide even when everything is declared and disjoint.

This claim is what makes every *workspace-local* footprint automatically covered at the capacity layer.
It is also why the per-command workspace-local claims below are documentation rather than admission
control at that layer — I still recommend declaring them, because at the plan layer and under any future
change to the barrier convention they become load-bearing again.

---

## 2. The premise: verified true

> A workspace-local writer is not by itself grounds for globally exclusive git-common-dir capacity.

Correct, and I verified the one thing that could have falsified it — the build mutex.

`scripts/build-lock-target.mjs:26-30`:

```js
export function buildLockTarget(repoKey) {
  const digest = createHash('sha256').update(String(repoKey)).digest('hex');
  return join(tmpdir(), `proof-or-stop-build-lock-${digest}`);
}
```

`scripts/build-main-with-binding.mjs:18` sets `projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')`
— the **worktree** root, because `scripts/` is a checked-out file in the worktree — and `:32` calls
`withBuildLock(projectRoot, ...)`. The digest is therefore taken over the worktree's own absolute path.
**The build mutex is per-worktree, not per-repository.** A build in worktree A cannot block a build in
worktree B.

The prior audit called this an "undeclarable per-checkout build mutex" and used it as part of the case
for keeping #1/#82/#83 undeclared. That reasoning does not survive: "undeclarable" is true (it lives under
`os.tmpdir()`, and `canonicalFilesystemPath` refuses any key that escapes the ownership root —
`keyed-scheduler.ts:95-97`), but "per-checkout" means the resource it protects is exactly the workspace,
which the automatic exclusive workspace claim (§1.4) already expresses. Nothing about it justifies
blocking other worktrees.

Same conclusion for every other footprint of the five: `packages/main/dist`, `packages/utils/dist`,
`packages/graph/dist`, `packages/graph/assets`, `packages/main/tests/red`, the probe files, the
`dist.staging`/`dist.trash-*` siblings, and `.proof-or-stop/` state are all inside one worktree.

**One caveat that limits the practical payoff, and it is not about paths — see §5.1.**

---

## 3. Blocker: the CHK-005 barrier guard is already failing

`packages/main/tests/validate-resource-claims.test.mjs` §7 (lines 261-325) holds a
`PROVEN_UNSAFE_TO_SHARE` map of ten argv strings that "must keep the fail-closed barrier", and asserts
that none of them carries a non-empty `resources` array. It is registered as `validate.commands[112]`
and as the npm script `test:validate-resource-claims`. It is not a member of `test:serial-reference`,
so `npm test` does not cover it — routine validate does.

I ran it read-only (it writes only `mkdtemp` roots, `:198-205`; it imports from `packages/main/dist` and
refuses to build, `:30-35`). It **fails now, before any change proposed here**:

```
VI-OK B7DFF-CHK002-CONFIGURED-PLAN-CLASSIFIED configured plan: 134 commands, 129 declared, 5 exclusive by fail-closed default
AssertionError: CHK-005 audited these as repo-shared writers; they must keep the fail-closed barrier:
  node packages/main/dist/tasks/retired-authority-vocabulary-guard-smoke.js — runs the real dist/cli.js with cwd=repoRoot, so cli-engine writeLog appends to the repository .proof-or-stop/activity.jsonl
  node packages/main/dist/tasks/command-catalog-smoke.js — runs the real dist/cli.js with --root <repoRoot>, so cli-engine writeLog appends to the repository .proof-or-stop/activity.jsonl
  node packages/main/dist/tasks/quorum-submit-smoke.js — explicitly out of CHK-005 scope; splitting it is its own change
  node packages/main/tests/red/red-b49d4-registration-derivation.mjs — sweepLegacyProbeDebris rmSync-es marker-gated paths under repoRoot and BLOCK D asserts whole-tree git status
  node packages/main/tests/red/red-1734-lock-liveness.mjs — creates and removes the real repository build lock directory and build lock target
  node packages/main/dist/tasks/proofstory-acceptance-rollout-smoke.js --issuer-mutations — readOrCreatePrivateKey writes proof-or-stop-acceptance-rollout-verifier-v1.key into the git common dir with flag wx
```

(The process exits via `triggerUncaughtException`, so the shell's `$?` is not a reliable signal here; the
assertion text above is the evidence.)

Six of the ten already carry declarations: indices 3, 6, 40, 79, 81, 105. The remaining four listed
entries are precisely #1, #80, #82, #83 — so **declaring them takes this guard from six failures to
ten**. Index 125 is not in the map and is unaffected by this guard.

Three consequences the owner must decide on before landing anything:

1. This is not caused by the proposal; it is present at HEAD. It should be reported as a live regression
   in its own right.
2. CHK-005's recorded reasons are the only in-repo record of why those commands were refused
   declarations (the test says so at `:270-271`). Overwriting the map without replacing the evidence
   destroys that record. The map needs to be rewritten to express the *new* rule — "these writers must
   retain an exclusive barrier claim" — rather than "these writers must have no claims at all". Concretely:
   assert `resources` contains a `fixed-path` claim on `VALIDATE_PLAN_BARRIER_CLAIM_KEY` with
   `access: 'exclusive'`, instead of asserting `resources` is empty. That preserves the guard's bite and
   its negative control (`:311-324`) while admitting the new encoding.
3. Two of CHK-005's stated reasons contradict the shipped audit, and one of them names a genuine
   cross-worktree write. See §7.3.

`experiments/five-item-proof/resource-config.mjs:21-22` is a second, weaker guard that will also break:
it asserts `exclusiveByDefault === true` for indices 1, 80, 82, 83, 125 and for both
`doneRequiredCommands`. `exclusiveByDefault` is *by definition* false for any declared command
(`validation-executor.ts:1786-1795`), so these assertions must be restated in terms of effective
exclusivity — e.g. that the canonicalized entry conflicts with every other plan entry — not in terms of
the resolver's default flag. Its `assert.equal(safe.length, 21)` at `:14` and the
`assert.deepEqual(command.resources, entry.suggestedResources)` at `:19` are also already inconsistent
with a config that now declares 129 commands; that is Lab-experiment maintenance, not a correctness issue.

---

## 4. Per-command findings and safe declarations

Notation: `WL` = worktree-local (cannot affect another worktree), `XW` = cross-worktree.
All keys below are repo-root-relative, matching the existing config convention.

### 4.1 `validate.commands[1]` — `npm --prefix packages/main run build`

Also `doneRequiredCommands[0]` (identical argv, `providesBuildProof: "packages-main-build"`).

Evidence:
- `packages/main/package.json` `scripts.build` → `node ../../scripts/build-main-with-binding.mjs`.
- `scripts/build-main-with-binding.mjs:26` fast-path `verifyBuildBinding` skip; `:32` `withBuildLock(projectRoot, ...)`;
  `:38-40` builds into `packages/main/dist.staging`, trashes to `packages/main/dist.trash-<pid>`;
  `:53-55` in-lock sweep of `dist.staging` / `dist.trash-*` siblings **in `packages/main/` itself**;
  promotion by rename via `scripts/promote-dist.mjs`.
- `scripts/full-suite-build-binding.mjs:6` `BUILD_MANIFEST = 'packages/main/dist/full-suite-build-binding.json'`, written at `:49`.
- Lock target: `os.tmpdir()`, keyed by sha256(worktree root) — **WL, and inexpressible** (§2).
- No git invocation. No socket bind.

Safe declaration (WL only; the barrier is what serializes it):

```json
[
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/src", "access": "shared" },
  { "class": "fixed-path", "key": "proof-or-stop.config.json", "access": "shared" }
]
```

`packages/main` is listed separately from `packages/main/dist` because the staging/trash siblings live in
the package directory and nested keys do not conflict (§1.3). `packages/main/src` and
`proof-or-stop.config.json` are reads folded into the binding digest.

For `doneRequiredCommands[0]`: identical array. Note that at the DONE layer this array is consumed
**only** by `declaredValidationCapacity` — see §4.6 — so the barrier claim there is inert but harmless,
and I recommend keeping it identical to index 1 so the two copies of the same command cannot drift.

### 4.2 `validate.commands[80]` — `node packages/main/tests/red/red-b49d4-chk002-receipt.mjs`

Evidence (read in full, `:55-190`):
- `:62-64` probe constants; `:66` `sweep()` `rmSync`s both from `repoRoot`.
- `:150` `writeFileSync(join(repoRoot, 'packages/main/tests/red/chk002-receipt-probe-unprefixed.harness'))` — a real, **untracked** write into the tracked test corpus.
- `:156` `writeFileSync(join(repoRoot, 'packages/main/dist/tasks/red-evidence-chk002-receipt-probe.js'))`.
- `:88-93` `readdirSync` of `packages/main/tests/red` and `packages/main/dist/tasks`.
- `:120-124` `mkdtemp` sandbox whose entries are symlinks back into the real repo, **excluding** `proof-or-stop.config.json`, which is written as a real file inside the sandbox (`:127-128`). The real config is never written; `:69` / `:184` assert its digest is unchanged.
- `:132`, `:135` spawn the two guard files; `runReal` uses `cwd: repoRoot`, `runSandbox` uses `cwd: sandbox`.
- The two guards (`red-w2c-validate-registration.mjs`, `red-b49d4-harness-registration.mjs`) contain no `execFileSync`/`spawnSync`/`git`/write calls at all (grep returned nothing).
- No socket bind. **All writes WL.**

```json
[
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/dist/tasks", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/tests/red", "access": "exclusive" },
  { "class": "fixed-path", "key": "proof-or-stop.config.json", "access": "shared" }
]
```

The two exclusive keys are chosen to string-match index 79's declared keys exactly, so the pair conflicts
at the plan layer even independently of the barrier. They deliberately do **not** protect the 18
`packages/main/dist` readers — nothing short of the barrier does (§1.3).

### 4.3 `validate.commands[82]` — `node packages/main/tests/red/red-1734-content-binding.mjs`

Evidence (`:245-325` read in full):
- `:257-258` `runMainBuild` / `runUtilsBuild` = `execFileSync` of the real build scripts with `cwd: repoRoot`.
- `:266-267` unconditional rebuild of both dists as a precondition; `:318-320` `finally` rebuilds both again.
- `:273-274` writes an orphan `.js` into `packages/main/dist`; `:287` `rmSync` of a real dist `.js`; `:300` in-place tamper of a real dist `.js`; `:309` `rmSync(join(repoRoot, BUILD_MANIFEST))`.
- Everything at `:71-72,114,130,153,160,204,219` targets a `mkdtemp` fixture `root`, not `repoRoot`.
- No git invocation, no socket bind. Takes the per-worktree build mutex transitively. **All writes WL.**

```json
[
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/utils/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/utils", "access": "exclusive" },
  { "class": "fixed-path", "key": "scripts", "access": "shared" }
]
```

### 4.4 `validate.commands[83]` — `node packages/main/tests/red/red-1734-reader-race.mjs`

Evidence:
- `:76-85` `sweepSwapSiblings()` `rmSync`s `dist.staging` / `dist.trash-*` in **both** `packages/main` and `packages/utils`.
- `:97` `rmSync(join(repoRoot, BUILD_MANIFEST))`; `:100` spawns `scripts/build-main-with-binding.mjs` with `cwd: repoRoot` — a real rebuild.
- `:150-153`, `:169`, `:195-196`, `:201` `rmSync`/`mkdirSync`/`utimesSync` of `` `${buildLockTarget(repoRoot)}.lock` `` — the **real** per-worktree build lock under `os.tmpdir()`.
- `:106-119` keeps up to 24 concurrent `bin/proof-or-stop.js --help` children in flight with `cwd: repoRoot` for the whole build window.
- `:205-235` `readerrace:3` operates entirely inside a `mkdtemp` `base` (`rmSync(base)` in `finally`).
- No git invocation, no socket bind. **All writes WL.**

```json
[
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/utils", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/utils/dist", "access": "shared" },
  { "class": "fixed-path", "key": "bin", "access": "shared" }
]
```

`packages/utils/dist` is `shared` here (unlike #82): this command sweeps the *siblings* under
`packages/utils` and reads `packages/utils/dist` through the bootstrap gate
(`bin/bootstrap-runner.js:106` requires both dists present), but it rebuilds only main.
One residual unknown for this entry — see §7.2.

### 4.5 `validate.commands[125]` — `npm --prefix packages/graph run check`

`packages/graph/package.json` `scripts.check` chains twelve steps. Evidence gathered:

**Writes (all WL):**
- `npm run build` = `tsc && node scripts/build-web.mjs`; `build-web.mjs:13-14,44` writes `packages/graph/assets/app.html`; `tsc` writes `packages/graph/dist`.
- `verify-missing-assets-fail.mjs:31-33,42,192-195,230-235` renames `packages/graph/assets/app.html` to `assets/.app.html.verify-stash` and `assets/app.html.rebuilt-probe`, and restores.
- `verify-no-project-writes.mjs:117,123-124` writes/removes a driver and a probe dir under `os.tmpdir()` only.

**Cross-worktree resources — REAL:**
- `verify-serves.mjs:14,23-31` binds **TCP 8814**, and refuses with `PORT_BUSY` if the port is already held.
- `verify-json-no-listener.mjs:12,22-23` uses **TCP 8815**, same `PORT_BUSY` refusal.
- `verify-missing-assets-fail.mjs:34,44` uses **TCP 8819**.

All three read `process.env.GRAPH_VERIFY_PORT ?? <default>`; command 125 sets no `env`, so the defaults
apply. These ports are machine-global: `canonicalizeEntries` renders a `fixed-port` claim as
`fixed-port:<number>` with no host and no workspace prefix (`keyed-scheduler.ts:118-120,126`).

**Whole-tree quiescence assertions (inexpressible as claims):**
- `verify-clean-tree.mjs:20-21,47-49` runs `git status --porcelain` over the whole worktree before and
  after and fails if it differs. (`:20` omits `cwd`, so it resolves the toplevel from the npm-set cwd,
  `packages/graph` → this worktree's root.)
- `verify-no-project-writes.mjs:35,68-83` takes a whole-repo content digest over
  `git ls-files --cached --others --exclude-standard` (pruning `node_modules`, `dist`, `.git`,
  `.proof-or-stop/runtime/validation-traces/`) and fails on any change.

No finite claim set expresses "the whole working tree must be quiescent". The prior audit was right
about that. But it is a *plan-layer* property, and the exclusive barrier still expresses it exactly as
well as being undeclared did.

**Outside-workspace, per-worktree, inexpressible:** the graph index cache. `packages/graph/src/core/app.ts:37-41`
resolves `dbPath` to `~/.cache/proof-or-stop-graph/<basename(root)>-<sha256(root).slice(0,12)>/index.db`.
Keyed by the resolved root, so it is per-worktree despite living under `$HOME`. Not a cross-worktree hazard.
`canonicalFilesystemPath` would throw on any attempt to claim it (`keyed-scheduler.ts:95-97`).

**Reads:** `packages/main/dist/handlers/graph.js` and `packages/main/src/handlers/graph.ts`
(`verify-engines-floor.mjs:39,55`), `bin/`, `.proof-or-stop/story/actives`, `proof-or-stop.config.json`,
`docs/` (`verify-docs.mjs`). `verify-engines-floor.mjs:96,125` runs `handlers.graph({ json: true })` on an
older node — the `--json` path is proven not to listen by `verify-json-no-listener`, so no extra bind.

```json
[
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/validate-plan-barrier", "access": "exclusive" },
  { "class": "fixed-port", "key": "8814", "access": "exclusive" },
  { "class": "fixed-port", "key": "8815", "access": "exclusive" },
  { "class": "fixed-port", "key": "8819", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/graph", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/graph/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/graph/assets", "access": "exclusive" },
  { "class": "git-common-dir", "key": ".", "access": "shared" },
  { "class": "fixed-path", "key": "packages/main/dist", "access": "shared" },
  { "class": "fixed-path", "key": "packages/main/src", "access": "shared" },
  { "class": "fixed-path", "key": "bin", "access": "shared" },
  { "class": "fixed-path", "key": ".proof-or-stop/story/actives", "access": "shared" },
  { "class": "fixed-path", "key": "proof-or-stop.config.json", "access": "shared" }
]
```

**The three port claims are mandatory, not optional.** Without them, declaring #125 removes the only
thing currently preventing two worktrees from running the graph check concurrently, and the second one
fails with `PORT_BUSY`. Today that cannot happen because undeclared ⇒ globally exclusive. Declaring #125
without the ports converts a correctness guarantee into an intermittent cross-worktree failure. This is
the single most consequential finding in this audit.

`git-common-dir` is `shared` (not exclusive): the only git operations are `rev-parse`, `status --porcelain`
and `ls-files`. `git status` may refresh an index, but a worktree's index lives at
`.git/worktrees/<name>/index` and is private to that worktree; the coarse `git-common-dir` key would
serialize every worktree for a byte-range that is not actually shared. **I refuse an exclusive
`git-common-dir` claim here as unjustified.**

### 4.6 `doneRequiredCommands` — routing question resolved

The prior audit left open whether DONE commands are scheduled at all. **They are not.**
`core/done-required-validation.ts:894-907` runs them in a plain `for` loop calling `runValidationCommand`
directly. The file contains no `runScheduled`, no `canonicalizeEntries`, and no
`resolveValidationCommandResourceClaims` call. Therefore a DONE command's `resources` array is consumed
**only** by `declaredValidationCapacity` at `handlers/done-required-validation.ts:53`.

The field is schema-supported on DONE commands: `core/done-required-validation.ts:321-330` parses
`raw.resources`, runs `validateResourceClaims`, and on error records
`doneRequiredCommands[i].resources invalid: ...` in `configErrors` rather than silently dropping it.

### 4.7 `doneRequiredCommands[1]` — `npm test`

Two stages.

**pretest.** `package.json` `scripts.pretest = node scripts/ensure-dist.mjs`;
`ensure-dist.mjs:20-21` runs `build-main-with-binding.mjs` then `build-utils-with-binding.mjs` with
`cwd: root` — a conditional but real rebuild of both dists, under the shared per-worktree build mutex
(`:8-13`). Same footprint as §4.1 plus `packages/utils`.

**test.** `scripts.test = node packages/main/dist/tasks/full-suite-runner.js`. Its `RESOURCE_POLICY`
(`packages/main/src/tasks/full-suite-runner.ts:119-240`) is a third membership authority; the union of
every claim it declares is:

| claim | source |
|---|---|
| `git-common-dir` `.` shared | `repoRead` helper, `:110-111`, on ~25 members |
| `fixed-port` `43127` exclusive | `:122` (`test:full-suite-runner-smoke`), `:125` (`test:full-suite-resource-sentinel`) |
| `fixed-path` `.proof-or-stop/runtime/full-suite-fixed-sentinel` exclusive | `:121`, `:126` |
| `fixed-path` `.proof-or-stop/runtime/full-suite-heavy` exclusive | `:112` `heavySmokeClaim` |
| `runtime-lock` `.proof-or-stop/runtime/full-suite-runtime-sentinel.lock` exclusive | `:127` |
| `main-write-lock` `.proof-or-stop/locks/full-suite-main-write-sentinel.lock` exclusive | `:128` |
| `runtime-lock` `.proof-or-stop/runtime` shared | `:192` |
| `fixed-path` `package.json` shared | `:131` |

`stateDirKey` (`:23`) resolves against `PROOF_OR_STOP_STATE_DIR = '.proof-or-stop'`
(`core/brand-paths.ts:2`), so all of the above except the port are worktree-local.

I checked for other machine-global ports in the suite. `packages/main/src/tasks/browser-server.ts:12`
(`HTTP_PORT` 9877) and `browser-executor.ts:27,504` are not reachable from any `package.json` script and
are not `test:serial-reference` members, so **43127 is the only fixed port in `npm test`**.

```json
[
  { "class": "fixed-port", "key": "43127", "access": "exclusive" },
  { "class": "git-common-dir", "key": ".", "access": "shared" },
  { "class": "fixed-path", "key": "packages/main/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/main", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/utils/dist", "access": "exclusive" },
  { "class": "fixed-path", "key": "packages/utils", "access": "exclusive" },
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/full-suite-fixed-sentinel", "access": "exclusive" },
  { "class": "fixed-path", "key": ".proof-or-stop/runtime/full-suite-heavy", "access": "exclusive" },
  { "class": "runtime-lock", "key": ".proof-or-stop/runtime/full-suite-runtime-sentinel.lock", "access": "exclusive" },
  { "class": "main-write-lock", "key": ".proof-or-stop/locks/full-suite-main-write-sentinel.lock", "access": "exclusive" },
  { "class": "runtime-lock", "key": ".proof-or-stop/runtime", "access": "shared" },
  { "class": "fixed-path", "key": "package.json", "access": "shared" },
  { "class": "fixed-path", "key": "packages/main/src", "access": "shared" },
  { "class": "fixed-path", "key": "proof-or-stop.config.json", "access": "shared" },
  { "class": "fixed-path", "key": "bin", "access": "shared" },
  { "class": "fixed-path", "key": "scripts", "access": "shared" }
]
```

Two deliberate omissions, each for a stated reason:

- **`ownership: 'runner-cleanable'` is not propagated.** `declaredValidationCapacity:841` would carry it
  through, and `canonicalizeEntries:116` would then run `assertOwnedPathHasNoSymlink`. That flag is the
  full-suite runner's *cleanup* contract for paths it owns inside its own scheduler; at the capacity layer
  it grants no admission benefit and only adds a failure mode. Declare the same class/key/access without it.
- **No claim on the graph ports.** The graph check is not a `test:serial-reference` member.

**The full suite must never be marked reusable.** It already is not: `sharedValidationReuseAllowed`
(`core/shared-validation-execution.ts:26-34`) requires `executionReuse === 'exact-inputs'` **and**
`!requiresBuildProof`, and `doneRequiredCommands[1]` carries `requiresBuildProof: "packages-main-build"`,
so it returns `false` today on two independent grounds. `doneRequiredCommands[0]` is likewise excluded by
`providesBuildProof`. Adding `resources` does not touch this predicate — `resources` and `executionReuse`
are orthogonal fields. **Do not add `executionReuse` or `executionInputs` to either DONE command.**

---

## 5. Actual shared cross-worktree resources — complete inventory for these seven

The claim vocabulary can express exactly two cross-worktree things: `fixed-port` (canonicalized to the
bare number) and `git-common-dir` (canonicalized to the shared common dir with
`allowOutsideOwnershipRoot: true`, `keyed-scheduler.ts:121-124`). Every `fixed-path`, `runtime-lock` and
`main-write-lock` key must resolve **inside** the workspace root or `canonicalFilesystemPath` throws
(`:95-97`) — and from a worktree, the main checkout root is an ancestor, so it can never be named.

### 5.1 Ports (genuinely shared, genuinely justified)

| port | commands | source |
|---|---|---|
| 8814 | #125 | `packages/graph/scripts/verify-serves.mjs:14` |
| 8815 | #125 | `packages/graph/scripts/verify-json-no-listener.mjs:12` |
| 8819 | #125 | `packages/graph/scripts/verify-missing-assets-fail.mjs:34` |
| 43127 | `doneRequiredCommands[1]` | `full-suite-runner.ts:122,125` |

**Consequence the owner must weigh.** The capacity ticket for routine validate always claims the union of
the *entire* 134-command universe (`verifier.ts:1552-1553`), not the planned subset. Once #125 declares
8814/8815/8819, **every** routine validate ticket carries those ports exclusively, so two full routine
validates in different worktrees still serialize — correctly, but they serialize. What the change does buy:

- routine validate no longer serializes against DONE `npm test` (disjoint ports, disjoint workspace roots);
- the serialization that remains is named and justified, rather than a side effect of a null declaration;
- the same-workspace guarantee is unchanged and still exact (§1.4).

If the goal is genuinely independent cross-worktree routine validate, the remaining fix is a source change
in `packages/graph/scripts/` — bind an ephemeral port instead of a fixed default — which is Codex's call
and outside my remit. Do not paper over it by omitting the port claims.

### 5.2 The git common dir

Shared by construction across all worktrees. 111 routine commands already declare it `shared`. Of my
seven, only #125 touches it, read-only (`rev-parse`, `status --porcelain`, `ls-files`) — `shared` is correct.

There is one genuine cross-worktree **write** into that directory in the wider command set, and it is not
one of my seven: `core/acceptance-rollout.ts:97-108`, `readOrCreatePrivateKey` →
`join(gitCommonDir(gitCwd), 'proof-or-stop-acceptance-rollout-verifier-v1.key')` with `flag: 'wx'`.
Create-once; after the file exists it is read-only, but two worktrees racing the very first creation would
have one of them throw `EEXIST`. See §7.3 — I could not close this one and it is outside my scope.

### 5.3 Inexpressible globals (named, not claimed)

| resource | scope | why it cannot be a claim |
|---|---|---|
| build mutex `<tmpdir>/proof-or-stop-build-lock-<sha256(worktree root)>` | per-worktree | outside ownership root; `canonicalFilesystemPath` throws |
| graph index cache `~/.cache/proof-or-stop-graph/<basename>-<sha256(root)[:12]>/` | per-worktree | same |
| npm's own `~/.npm/_cacache` and `_logs` | machine-global | same; `npm run` performs no install, so this is read-mostly |

None of these is cross-worktree, so none of them justifies an exclusive `git-common-dir` claim.
**I refuse any such claim for all seven commands.**

---

## 6. Cross-cutting notes

**6.1 Key-resolution divergence between the two layers.** `ValidationCommand.resources`'s own
doc-comment (`core/validation-types.ts:56-58`) states keys are resolved "relative to the PROJECT ROOT,
not to `cwd`", and the plan layer does exactly that (`validation-executor.ts:1864` passes `projectRoot`).
`declaredValidationCapacity:837,840` instead resolves against `resolve(workspaceRoot, command.cwd ?? '.')`.
No configured command sets `cwd` today (verified: zero of 134), so the two agree — but the divergence is
latent, and `workspaceRoot` is `handlerGitCwd`, which can differ from `projectRoot` in a wrapper-root
layout. Worth a comment or an assertion; not a blocker here.

**6.2 Declaring resources changes the config bytes.** `ValidationCommand.id`'s doc-comment
(`validation-types.ts:26-27`) records that `source.inputDigest` binds the raw config file contents, so
editing `resources` invalidates existing routine reuse receipts. Expected, not a defect — but the change
should land expecting a cold reuse cache.

**6.3 The declared set is all-or-nothing.** One future command added without `resources` silently reverts
the whole repository to globally exclusive capacity, with no error and no warning — `declaredValidationCapacity`
just returns `{}`. This is worth a guard of its own: assert that every entry in
`configuredValidationCommands(root)` and every `doneRequiredCommands` entry has a non-empty `resources`
array, so the regression is loud. That guard does not exist today.

---

## 7. Unresolved items and the precise evidence still missing

**7.1 Does an explicitly-declared exclusive barrier claim survive every consumer of `exclusiveByDefault`?**
I verified the scheduler behaviour (§1.3) and read the three consumers I found —
`validation-executor.ts:1865,1979`, `tasks/validate-parallel-benchmark.ts:234-236`,
`tasks/validate-parallel-equivalence-smoke.ts:296`. All three only *count and report*. I did not
exhaustively prove that no other code path treats `exclusiveByDefault === false` as "safe to overlap"
independently of the claims. **Missing evidence:** a full call-graph sweep of `exclusiveByDefault`
readers, or a targeted red test asserting that a barrier-declaring writer still observes zero co-runners
under the real `runScheduled` (the existing test at `validate-resource-claims.test.mjs:120-150` does
exactly this for the *undeclared* case and is the natural template).

**7.2 `#83` and the activity log.** `red-1734-reader-race.mjs:106-119` spawns ≥40
`bin/proof-or-stop.js --help` children with `cwd: repoRoot`. `core/activity-log.ts:17-19` puts the
runtime log at `<projectRoot>/.proof-or-stop/activity.jsonl`, and `cli-engine.ts:1468,1540` call
`writeLog` on the command paths. I did **not** establish whether `--help` short-circuits before reaching
`writeLog`; note also that `.proof-or-stop/activity.jsonl` does not currently exist in this worktree,
which is suggestive but not proof. This does not change the cross-worktree verdict (the path is
worktree-local either way), but if `--help` does log, `#83`'s claim array should add
`{ "class": "fixed-path", "key": ".proof-or-stop/activity.jsonl", "access": "exclusive" }`.
**Missing evidence:** the `--help` dispatch path in `packages/main/src/cli-engine.ts` read end-to-end,
or one observed run of `bin/proof-or-stop.js --help` checked against the file's mtime.

**7.3 CHK-005 contradicts the shipped audit on two already-declared commands.** Outside my assigned five,
but it bears directly on whether the *existing* 129 declarations are sound, and therefore on whether
declaring my five is worth doing:

- CHK-005 (`validate-resource-claims.test.mjs:276-279`) says indices 3 and 6 run the real `dist/cli.js`
  with `cwd=repoRoot` and so append `.proof-or-stop/activity.jsonl`. `experiments/five-item-proof/resource-audit.json`
  entries for the same commands say "no repoRoot-anchored write anywhere". Both are in-repo records; they
  cannot both be right. Same unresolved question as §7.2.
- CHK-005 `:292-293` says index 105 writes the rollout verifier key into the git common dir with `wx`.
  At the one call site I read (`tasks/proofstory-acceptance-rollout-smoke.ts:267-272`) the key is only
  *copied out* under an `existsSync` guard, into the fixture's own common dir. `core/acceptance-rollout.ts:418,847`
  call `readOrCreatePrivateKey(args.gitCwd)`, so whether a real write lands in the shared common dir
  depends on what `gitCwd` is at those two call sites during this smoke. Index 105 currently declares
  `git-common-dir . shared`; if CHK-005 is right, `shared` is wrong.
  **Missing evidence:** trace `args.gitCwd` at `acceptance-rollout.ts:418` and `:847` for the code path
  the smoke drives, or observe whether `<main repo>/.git/proof-or-stop-acceptance-rollout-verifier-v1.key`
  is created by a run of index 105 in a repo where it is absent.

**7.4 `GRAPH_VERIFY_PORT`.** All three graph verifiers read the same env var, so an operator who exports it
collapses 8814/8815/8819 to one value and silently invalidates the declaration. Command 125 sets no `env`,
so the declared defaults are correct for the configured invocation. If the owner wants the declaration to be
robust rather than merely correct-as-configured, pin the value with the command's `env` field
(`ValidationCommand.env`, `validation-types.ts:35`) and declare that single port — the three scripts run
sequentially within the check chain, so one port suffices.

**7.5 Whether `packages/graph`'s remaining sub-scripts are fully enumerated.** I read `build-web`,
`verify-clean-tree`, `verify-no-project-writes`, `verify-serves`, `verify-json-no-listener`,
`verify-missing-assets-fail`, `verify-engines-floor` and grepped the rest for writes and binds. I did not
read `verify-assets-ignored.mjs`, `verify-docs.mjs`, `copy-assets.mjs`, `ok.mjs`, or
`src/tasks/{anchor-check.mjs,audit.js,bench.js}` line by line. The grep for `writeFileSync|rmSync|mkdirSync|
cpSync|renameSync|unlinkSync` and for `.listen(`/port literals across `packages/graph` returned nothing
outside what is listed in §4.5, so I believe the enumeration is complete, but it rests on that sweep rather
than on exhaustive reading.

---

## 8. Recommendation

1. **Fix the live failure first.** `validate.commands[112]` fails at HEAD (§3), independently of this work.
2. **Restate CHK-005 rather than delete it** — assert the exclusive-barrier claim is present, not that
   `resources` is empty — so the recorded evidence for why these ten are dangerous survives the change.
3. **Land the seven declarations** as given in §4, with #125's three port claims non-negotiable.
4. **Restate the Lab guard** in `experiments/five-item-proof/resource-config.mjs:21-22` in terms of
   effective exclusivity rather than `exclusiveByDefault`.
5. **Add the all-or-nothing guard** described in §6.3, or the next undeclared command silently reverts
   everything.
6. Close §7.1 and §7.2 before treating the declarations as complete; §7.3 is a separate finding that should
   be raised on its own.
