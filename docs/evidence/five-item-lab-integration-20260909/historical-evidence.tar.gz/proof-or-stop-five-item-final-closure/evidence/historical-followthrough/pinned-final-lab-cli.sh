#!/bin/sh
export PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN=1
export PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST=9f47a7be17e4a160055c48867c071a8e1e3651c09feede66c41bd879b4ad989f
exec /opt/homebrew/Cellar/node/26.8.1/bin/node /Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/bin/proof-or-stop.js "$@"
