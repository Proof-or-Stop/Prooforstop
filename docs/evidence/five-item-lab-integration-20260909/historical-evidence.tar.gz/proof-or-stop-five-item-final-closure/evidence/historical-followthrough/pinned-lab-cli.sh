#!/bin/sh
export PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN=1
export PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST=b2c35d959cc331fec5a301bfdb2dc3baceb5355d0c9094b18c3575133c36b1ed
exec /opt/homebrew/Cellar/node/26.8.1/bin/node /Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/bin/proof-or-stop.js "$@"
