import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
const lab='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const out=path.join(path.dirname(new URL(import.meta.url).pathname),'full-config-comparison');fs.mkdirSync(out,{recursive:true});
const {runScheduled,canonicalizeEntries}=await import(lab+'/packages/main/dist/core/keyed-scheduler.js');
const {resolveValidationPlanEntries,runValidationCommand}=await import(lab+'/packages/main/dist/core/validation-executor.js');
const {configuredValidationCommands}=await import(lab+'/packages/main/dist/handlers/verifier.js');
const git=args=>execFileSync('git',args,{cwd:lab,encoding:'utf8',maxBuffer:32*1024*1024}).trim();
const baselineCommit='cf21df09c273074d7aa3227a5f436c6f5badf47a';
const oldConfig=JSON.parse(git(['show',baselineCommit+':proof-or-stop.config.json']));
const commands=configuredValidationCommands(lab),config=fs.readFileSync(lab+'/proof-or-stop.config.json');
assert.equal(commands.length,oldConfig.validate.commands.length);
for(let i=0;i<commands.length;i++)assert.deepEqual([commands[i].command,...commands[i].args],[oldConfig.validate.commands[i].command,...oldConfig.validate.commands[i].args],'Both modes must execute the same real command inventory');
const manifest={baselineCommit,candidateCommit:git(['rev-parse','HEAD']),configSha256:createHash('sha256').update(config).digest('hex'),node:process.version,cpuCount:os.availableParallelism(),inventory:commands.map((c,i)=>({index:i,command:c.command,args:c.args,timeoutMs:c.timeoutMs,baselineResources:oldConfig.validate.commands[i].resources??null,candidateResources:c.resources})),contract:['Both arms run all 134 current real commands and assertions through the production keyed scheduler and command executor with jobs=4. Only resource declarations differ; RED uses baseline main declarations.','Graph CLI/verifier fixes and candidate configuration source are common to both arms; graph recovery has its own before/after comparison. This isolates resource scheduling, not whole-repair or whole-Story performance.','No formal Story is created or advanced, no canonical baseline or phase proof is published, and no external validation capacity ticket is held.','One pair is diagnostic, not a population estimate. Every timeout/failure is retained; no passing speedup is claimed for failing suites.']};
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2));
const rows=[];
for(const mode of ['RED','GREEN']){
 const selected=commands.map((c,i)=>({...c,resources:mode==='RED'?oldConfig.validate.commands[i].resources:c.resources}));
 const entries=canonicalizeEntries(resolveValidationPlanEntries({provider:'full-config-resource-comparison',commands:selected}),lab);
 const start=performance.now(),events=[];let active=0,peak=0;
 const results=await runScheduled(entries,4,async entry=>{
  active++;peak=Math.max(peak,active);const begin=performance.now();const index=entry.commandIndex-1;
  fs.appendFileSync(path.join(out,'events.jsonl'),JSON.stringify({mode,index,event:'start',atMs:begin-start,active})+'\n');
  let result;
  try{result=await runValidationCommand(entry.command,lab,300000);}
  catch(error){result={code:999,output:String(error.stack),timedOut:false};}
  finally{active--;}
  const row={mode,index,elapsedMs:performance.now()-begin,startMs:begin-start,endMs:performance.now()-start,code:result.code,timedOut:result.timedOut??false,pollution:result.worktreePollution??null};events.push(row);
  fs.writeFileSync(path.join(out,`${mode}-${String(index).padStart(3,'0')}.log`),result.output??'');fs.appendFileSync(path.join(out,'events.jsonl'),JSON.stringify({...row,event:'end'})+'\n');
  console.log(mode,index,result.code,row.elapsedMs.toFixed(1));return {name:entry.name,status:result.code===0?'PASS':'FAIL'};
 },{cancellation:'run-all'});
 assert.equal(results.length,134);assert.equal(events.length,134);
 const row={mode,elapsedMs:performance.now()-start,peak,passed:events.filter(x=>x.code===0).length,failed:events.filter(x=>x.code!==0),events};rows.push(row);
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({manifest,rows},null,2));
 console.log('ARM_COMPLETE',mode,row.elapsedMs,row.passed+'/134');
 assert.equal(git(['rev-parse','HEAD']),manifest.candidateCommit,'Source commit must stay frozen across measurement');
 assert.equal(createHash('sha256').update(fs.readFileSync(lab+'/proof-or-stop.config.json')).digest('hex'),manifest.configSha256,'Candidate configuration must stay frozen across measurement');
}
