#!/usr/bin/env node
// Private verifier fixture F: core/shared-validation-execution.ts calls
// executeCausalEvidence with selector:'' (the DONE-required / routine-validate path).
// selectorVerdict evaluates readCausalSelectorOutput(...) BEFORE the
// `selector.length === 0` clause, so an empty-selector reuse now depends on the
// sidecar bytes it never needs.
const DIST='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
const {DEFAULT_CAUSAL_SELECTOR_POLICY,createCausalEvidenceBatch,executeCausalEvidence,preflightCausalEvidence}=await import(DIST);
class NoSidecarStore{ #r=new Map();
  readCausalEvidenceReceipt(s,k){return this.#r.get(`${s}:${k}`)??null;}
  writeCausalEvidenceReceipt(s,rec){this.#r.set(`${s}:${rec.executionKey}`,structuredClone(rec));} }
const cwd=process.cwd();
const identity={storyId:'B-verifier-f',cwd,command:{executable:process.execPath,args:['-e','0']},
  bootstrap:{executable:'proof-or-stop',args:['verification-evidence']},
  inputs:{materialHash:'m',explicitInput:'f'},storyFilesHash:'s',
  effectiveEnvironment:{NODE_ENV:'test'},runtimeVersion:process.version,toolVersion:'verifier@1',
  selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
const preflight=preflightCausalEvidence({
  cli:{available:true,path:'proof-or-stop'},worktree:{expected:cwd,actual:cwd},
  gitIndex:{readable:true,path:`${cwd}/.git/index`,expected:'h',actual:'h',contentDigest:'sha256:x'},
  gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},
  writerLease:{available:true,valid:true},
  providerCapability:{required:['allowlisted-command','bounded-output'],available:['allowlisted-command','bounded-output']},
  resources:{required:{timeoutMs:1000},available:{timeoutMs:1000}},
  evidenceTarget:{writable:true,path:'B-verifier-f/causal-evidence/'},
  sideChannel:{available:true,maxOutputChars:12_000,maxProgressEvents:10},
},undefined,identity);
const store=new NoSidecarStore();
let executions=0;
const output='routine validate output\n'+'q'.repeat(20000);
const call=()=>executeCausalEvidence({identity,selector:'',receiptStore:store,batch:createCausalEvidenceBatch(),
  preflight,revalidateBeforeRun:()=>true,run:async()=>{executions++;return {code:0,output};}});
const first=await call();
console.log('first  verdict (empty selector) :',first.verdict.result);
try{ const second=await call(); console.log('reuse  verdict (empty selector) :',second.verdict.result); }
catch(e){ console.log('reuse  THREW                    :',e.message); }
console.log('command executions              :',executions);
