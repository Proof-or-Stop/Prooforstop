#!/usr/bin/env node
// Private verifier fixture D: run.output is the COMPLETE unbounded command output
// (core/validation-executor.ts runValidationCommandWithCompleteOutput). The candidate
// persists its redacted form verbatim, with no size cap in executeCausalEvidence,
// StoryStore.writeCausalSelectorOutput, or verifyCausalEvidenceReceipt. Measure the
// write cost and the PER-INTENT cross-process reuse cost (each reuse re-reads and
// re-SHA256s the whole object because the WeakMap only holds the producing object).
import {mkdtempSync,rmSync,statSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {performance} from 'node:perf_hooks';
const DIST='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
const {DEFAULT_CAUSAL_SELECTOR_POLICY,createCausalEvidenceBatch,executeCausalEvidence,preflightCausalEvidence}=await import(DIST);
const root=mkdtempSync(join('/Users/jek/.codex/artifacts/proof-or-stop-five-item-followthrough-20260909/claude-output/fixtures/','tmp-d-'));
// Mirror of StoryStore.readCausalSelectorOutput / writeCausalSelectorOutput (store.ts:873-894).
const store={ receipts:new Map(),
  readCausalEvidenceReceipt:(s,k)=>store.receipts.get(`${s}:${k}`)??null,
  writeCausalEvidenceReceipt:(s,r)=>{store.receipts.set(`${s}:${r.executionKey}`,structuredClone(r));},
  readCausalSelectorOutput:(s,d)=>JSON.parse(readFileSync(join(root,s,d+'.json'),'utf8')).output,
  writeCausalSelectorOutput:(s,d,o)=>{const p=join(root,s,d+'.json');mkdirSync(dirname(p),{recursive:true});
    const ser=JSON.stringify({output:o},null,2)+'\n';writeFileSync(p+'.tmp',ser,'utf8');JSON.parse(readFileSync(p+'.tmp','utf8'));writeFileSync(p,ser,'utf8');rmSync(p+'.tmp');},
};
const cwd=process.cwd();
const mk=(mb)=>{
  const identity={storyId:'B-verifier-d-'+mb,cwd,command:{executable:process.execPath,args:['-e',String(mb)]},
    bootstrap:{executable:'proof-or-stop',args:['verification-evidence']},
    inputs:{materialHash:'m',explicitInput:'d'+mb},storyFilesHash:'s',
    effectiveEnvironment:{NODE_ENV:'test'},runtimeVersion:process.version,toolVersion:'verifier@1',
    selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
  const preflight=preflightCausalEvidence({
    cli:{available:true,path:'proof-or-stop'},worktree:{expected:cwd,actual:cwd},
    gitIndex:{readable:true,path:`${cwd}/.git/index`,expected:'h',actual:'h',contentDigest:'sha256:x'},
    gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},
    writerLease:{available:true,valid:true},
    providerCapability:{required:['allowlisted-command','bounded-output'],available:['allowlisted-command','bounded-output']},
    resources:{required:{timeoutMs:1000},available:{timeoutMs:1000}},
    evidenceTarget:{writable:true,path:identity.storyId+'/causal-evidence/'},
    sideChannel:{available:true,maxOutputChars:12_000,maxProgressEvents:10},
  },undefined,identity);
  return {identity,preflight};
};
for(const mb of [1,16,64]){
  const {identity,preflight}=mk(mb);
  const output='MIDDLE_MARKER_'+mb+'\n'+'z'.repeat(mb*1024*1024);
  let t=performance.now();
  const first=await executeCausalEvidence({identity,selector:'MIDDLE_MARKER_'+mb,intentRef:'I-1',receiptStore:store,
    batch:createCausalEvidenceBatch(),preflight,revalidateBeforeRun:()=>true,run:async()=>({code:0,output})});
  const writeMs=performance.now()-t;
  const digest=first.receipt.selectorOutput.digest;
  const bytes=statSync(join(root,identity.storyId,digest+'.json')).size;
  // Cross-process style reuse: fresh batch each time => receipt re-read from the store,
  // so liveSelectorOutput WeakMap misses and the whole object is re-read + re-hashed.
  t=performance.now();
  for(let i=0;i<5;i++){
    await executeCausalEvidence({identity,selector:'MIDDLE_MARKER_'+mb,intentRef:'I-'+(i+2),receiptStore:store,
      batch:createCausalEvidenceBatch(),preflight,revalidateBeforeRun:()=>true,
      run:async()=>{throw new Error('must not re-run');}});
  }
  const reuseMs=performance.now()-t;
  console.log(`outputMB=${String(mb).padStart(3)}  verdict=${first.verdict.result}  persistedBytes=${bytes}  `
    +`firstWriteMs=${writeMs.toFixed(0)}  5 reuse intents=${reuseMs.toFixed(0)}ms (${(reuseMs/5).toFixed(0)}ms per intent)`);
}
rmSync(root,{recursive:true,force:true});
