#!/usr/bin/env node
// Private verifier fixture C: does the widening from `identity.effectiveEnvironment`
// to `{...process.env, ...identity.effectiveEnvironment}` add anything on the real
// handler path? The handler builds identity.effectiveEnvironment with
// effectiveCausalEnvironment(undefined, cwd), so measure what that already contains.
const DIST='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
const {effectiveCausalEnvironment}=await import(DIST);
process.env.LAB_SELECTOR_SECRET_TOKEN='private-selector-token-91369';   // same name the owner tool uses
const effective=effectiveCausalEnvironment(undefined,process.cwd());
console.log('effectiveEnvironment key count      :',Object.keys(effective).length);
console.log('process.env key count               :',Object.keys(process.env).length);
console.log('LAB_SELECTOR_SECRET_TOKEN present   :',Object.hasOwn(effective,'LAB_SELECTOR_SECRET_TOKEN'));
console.log('...and its value is RAW (unredacted):',effective.LAB_SELECTOR_SECRET_TOKEN===process.env.LAB_SELECTOR_SECRET_TOKEN);
const R=/(token|secret|password|passwd|api[_-]?key|private[_-]?key|credential|authorization|auth)/i;
const inEnvOnly=Object.keys(process.env).filter(k=>!Object.hasOwn(effective,k));
console.log('keys in process.env but NOT in effectiveEnvironment:',JSON.stringify(inEnvOnly));
console.log('  ...of those, secret-named            :',JSON.stringify(inEnvOnly.filter(k=>R.test(k))));
console.log('=> extra secret values the widening can newly redact on the handler path:',
            inEnvOnly.filter(k=>R.test(k)).length);
