# Independent verification — Lab candidate `4830880ffc` (predecessor `f3f69038ab`)

Reviewer: Claude CLI, invoked as an independent verifier by explicit user authorization.
Date: 2026-09-09. Worktree under review (read-only):
`/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`.
All artifacts written only under
`/Users/jek/.codex/artifacts/proof-or-stop-five-item-followthrough-20260909/claude-output/`.

Candidate commit message: *"fix: bind complete redacted selector output to reusable execution receipts"*.

---

## 1. Read-only discipline — what I touched

* No source, config, build output, `main`, version, or Story file was modified. `git diff --stat 4830880ffc`
  over `packages/main/src/core/causal-evidence.ts`, `store.ts`, `validation-executor.ts`,
  `validation-command-environment.ts` is empty; `packages/main/dist/**` mtimes are unchanged at
  `2026-09-09T01:53:31` (the owner's pre-existing build).
* I ran no build and dispatched no subagents.
* My private fixtures signed receipts through `signCausalAuthorityPayload`, which resolves the authority key
  to the *shared* repo root. That key file
  (`/Users/jek/Documents/GitHub/Prooforstop/.proof-or-stop/runtime/lattice-causal-evidence-authority-v1.key`)
  pre-existed with birth **and** mtime `2026-09-04T22:15:21`, so my runs only read it. No file was created
  inside the Lab worktree by me.
* **Concurrency caveat:** the owner advanced this worktree *during* my review. At the start of my session
  `HEAD` was `4830880ffc` with a clean tree; by the end `HEAD` was `8b1f8248f8` (the next RED) with
  `docs/validation-performance.md`, `packages/main/src/core/process-fact-registry.ts`,
  `packages/main/src/handlers/checklist.ts`, `scripts/verify-process-fact-contract.mjs` modified in the
  working tree. `4830880ffc` is an ancestor of the new `HEAD`. All of my source claims below are pinned to
  commit contents (`git show 4830880ffc:...`, `git diff f3f69038ab..4830880ffc`), not to the moving working
  tree, and the two files carrying the substantive logic are byte-identical to `4830880ffc`.

---

## 2. Commands executed, verbatim, with exits

Working directory for all runs: the Lab worktree.

| # | Command | Exit | Log |
|---|---------|------|-----|
| 1 | `FIVE_ITEM_PROOF_OUTPUT=<out>/complete-output node experiments/five-item-proof/complete-output.mjs` | **0** | `logs/complete-output.stdout.log` |
| 2 | `FIVE_ITEM_PROOF_OUTPUT=<out>/complete-output-adversarial node experiments/five-item-proof/complete-output-adversarial.mjs` | **0** | `logs/complete-output-adversarial.stdout.log` |
| 3 | `node packages/main/dist/tasks/causal-evidence-smoke.js` | **0** | `logs/causal-evidence-smoke.stdout.log` |
| 4 | `node <out>/fixtures/fixture-a-store-without-sidecar.mjs` | 0 | `logs/fixture-a.log` |
| 5 | `node <out>/fixtures/fixture-b-ambient-redaction.mjs` | 0 | `logs/fixture-b.log` |
| 6 | `node <out>/fixtures/fixture-c-redaction-nonop.mjs` | 0 | `logs/fixture-c.log` |
| 7 | `node --max-old-space-size=4096 <out>/fixtures/fixture-d-unbounded-output.mjs` | 0 | `logs/fixture-d.log` |
| 8 | `node <out>/fixtures/fixture-e-legacy-shape.mjs` | 0 | `logs/fixture-e.log` |
| 9 | `node <out>/fixtures/fixture-f-empty-selector.mjs` | 0 | `logs/fixture-f.log` |

`<out>` = `/Users/jek/.codex/artifacts/proof-or-stop-five-item-followthrough-20260909/claude-output`.
Fixtures 4–9 are newly written by me, live only under `<out>/fixtures/`, allocate their own temp
directories, and never write to the Lab worktree or `dist`.

Observed stdout for the three owner tools:

```
complete-output.mjs             -> COMPLETE_OUTPUT_SELECTOR_AND_FANOUT_GREEN
complete-output-adversarial.mjs -> OUTPUT_TAMPER_MISSING_ABSENT_REDACTION_GREEN
                                   COMPLETE_OUTPUT_SELECTOR_AND_FANOUT_GREEN
causal-evidence-smoke.js        -> causal-evidence-smoke: PASS — CausalEvidence: intentCount=2
                                   uniqueExecutionKeys=1 commandExecutions=1 cacheHitRate=50% ...
```

All three reproduce green on my machine, in my own output directories, from the owner's `dist`.

---

## 3. What the change does

`git diff f3f69038ab..4830880ffc` — 6 files, +147/−5:

* `causal-evidence.ts`: adds `CAUSAL_OUTPUT_DIRECTORY`, an optional signed
  `receipt.selectorOutput = {digest,length}` emitted only when `redactedOutput.length > 12_000`, an exported
  `readCausalSelectorOutput(receipt, store)` that resolves those bytes from a `WeakMap` (producing process)
  or the store (other processes) and *throws* unless length **and** SHA-256 match, and rewires
  `selectorVerdict` to match against the complete bytes. Redaction input widened from
  `identity.effectiveEnvironment` to `{...process.env, ...identity.effectiveEnvironment}`.
* `store.ts`: `readCausalSelectorOutput` / `writeCausalSelectorOutput` as content-addressed
  `causal-evidence/outputs/<sha256>.json`, with a digest-shape guard and an equal-content collision check.
* `process-fact-registry.ts`, `scripts/verify-process-fact-contract.mjs`, `docs/validation-performance.md`:
  registry entry, mechanical pattern enforcement, documentation.

Ordering is correct and fail-safe: bytes are published *before* the receipt is written, so a receipt can
never advertise an output object whose write failed; an orphan output object carries no authority because
nothing indexes it.

---

## 4. Claims I independently confirmed

1. **Middle-of-output selector now matches.** `complete-output.mjs` green; the adversarial tool additionally
   asserts `!stored.outputProbe.includes('PUBLISH_RESTART_OK')`, and the persisted checklist evidence I
   inspected (`complete-output-adversarial/results.json`) has a 4,000-char `outputTail` of `y` padding with
   `tail has marker: false`. So the match genuinely comes from the sidecar, not the probe or tail.
2. **Cross-process reuse without re-execution.** Both tools' `second.log` reports
   `commandExecutions=0 cacheHitRate=100%`, and the witness execution counter stays at 1.
3. **Fail-closed on tamper and on missing bytes, with no rerun and no evidence mutation.** Adversarial
   `tamper.log` → `causal_selector_output_invalid` from `readCausalSelectorOutput`; `missing.log` → the same
   code from `StoryStore.readCausalSelectorOutput`; `absent.log` → `receipt_selector_absent`. All exit 70,
   `.counts` stays 1, and the checklist JSON is byte-identical before/after.
4. **Digest tamper is rejected by receipt verification.** `verifyCausalEvidenceReceipt` returns `false` when
   `selectorOutput.digest` is edited, because `receiptHash` covers the whole payload.
5. **Legacy receipt shape is preserved (fixture E).** A ≤12,000-char output emits **no** `selectorOutput`;
   such a receipt still reuses through a store with no sidecar support at all
   (`disposition=reused`, `commandExecutions=1`), an absent selector still fans out to `fail` independently,
   `verifyCausalEvidenceReceipt` returns `true`, and `readCausalSelectorOutput({outputProbe})` falls back to
   the probe. The `!receipt.selectorOutput && receipt.outputTail.includes(...)` branch keeps the predecessor
   matcher exactly for legacy receipts.
6. **Path safety.** Both store methods validate `^[a-f0-9]{64}$` before any path join; `writeJsonFile` is
   tmp+rename atomic with post-write JSON validation.
7. **Registry coverage of the new directory.** `runtime-artifact-registry.ts:147`'s
   `ignorePatterns: ['**/causal-evidence/']`, `materialHash: 'exclude'` already covers
   `causal-evidence/outputs/`, so writing an output object does not dirty the tree or perturb `materialHash`.

---

## 5. Findings

### 5.1 A store that implements only the two required interface methods is permanently bricked for long outputs (latent, in-repo shape exists)

`CausalEvidenceReceiptStore` declares `readCausalSelectorOutput?` / `writeCausalSelectorOutput?` as
**optional**, but `executeCausalEvidence` sets `receipt.selectorOutput` unconditionally whenever the redacted
output exceeds 12,000 chars — including when the store cannot persist it
(`args.receiptStore?.writeCausalSelectorOutput?.(...)` silently no-ops). The receipt is then written and
indexed. The producing process still passes via the `liveSelectorOutput` WeakMap, but any later read of that
receipt is a fresh object, so the WeakMap misses and the sidecar lookup is `undefined`.

Fixture A reproduces this with a store shaped exactly like the repo's own `MemoryReceiptStore`
(`packages/main/src/tasks/causal-evidence-smoke.ts:27-39`), using a selector at char 0 — i.e. a selector the
**predecessor matched fine** from the display probe:

```
first.verdict = pass executions = 1
receipt.selectorOutput = {"digest":"565c6918...3286","length":20012}
outputProbe contains HEAD_MARKER = true
verifyCausalEvidenceReceipt = true
reuse in a NEW batch (store round-trip) => THREW: Complete selector output is missing or changed
                                                 [causal_selector_output_invalid]
executions after reuse attempt = 1
```

It is fail-*closed*, and there is no rerun or rewrite, so no false PASS is produced. But the receipt is now
permanently unusable at that address: nothing deletes receipts, and `executeCausalEvidence` throws before it
can re-execute. In practice recovery requires the execution key to change (any `materialHash` /
`storyFilesHash` movement does that), so an unchanged workspace stays stuck.

**Scope:** not currently reachable on a production path — every handler (`checklist.ts`, `verifier.ts`,
`done-required-validation.ts`, `shared-validation-execution.ts`) passes `StoryStore`, which implements both
sidecar methods. The exposure is the interface contract, the shipped smoke-test store (which passes today
only because its output is 45 chars), and any future implementer. Suggested minimal fix: emit
`selectorOutput` only when the store can actually persist it, i.e. gate on
`typeof args.receiptStore?.writeCausalSelectorOutput === 'function'`, or make the two methods required.

### 5.2 Unbounded persistence: no size cap anywhere on the new output object

`run.output` is the **complete, unbounded** command output
(`validation-executor.ts:1342 runValidationCommandWithCompleteOutput`, deliberately not governed by the
persistence window). Its redacted form is now written verbatim. There is no cap in
`executeCausalEvidence`, none in `StoryStore.writeCausalSelectorOutput`, and
`verifyCausalEvidenceReceipt` accepts any `Number.isSafeInteger(selectorOutput.length) >= 0`. The predecessor
persisted at most 12,000 + 4,000 chars per receipt. Fixture D, measured:

```
outputMB=  1  verdict=pass  persistedBytes=1048612   firstWriteMs=66   5 reuse intents=313ms (63ms/intent)
outputMB= 16  verdict=pass  persistedBytes=16777253  firstWriteMs=132  5 reuse intents=557ms (111ms/intent)
outputMB= 64  verdict=pass  persistedBytes=67108901  firstWriteMs=404  5 reuse intents=929ms (186ms/intent)
```

Two consequences. (a) A chatty validation suite now deposits an arbitrarily large JSON per receipt into the
Story directory, and `writeJsonFile` re-reads and `JSON.parse`s the whole file to validate the write, roughly
doubling peak memory. (b) Cross-process fanout is **O(bytes × intents)**: each reusing intent re-reads and
re-SHA-256s the whole object because the `WeakMap` only holds the producing object. At 186 ms/intent for
64 MB this is still far cheaper than re-running a suite, so it is a cost-and-growth concern rather than a
defect — but neither the code, the docs, nor the registry entry states any bound, and nothing garbage-collects
`causal-evidence/outputs/`.

### 5.3 The empty-selector caller pays for, and can hard-fail on, bytes it never needs

`selectorVerdict` evaluates `readCausalSelectorOutput(receipt, store).includes(selector)` **before** the
`selector.length === 0` clause. `core/shared-validation-execution.ts:93` — the DONE-required /
routine-validate path — calls with `selector: ''`. Fixture F reproduces the resulting refusal:

```
first  verdict (empty selector) : pass
reuse  THREW                    : Complete selector output is missing or changed [causal_selector_output_invalid]
command executions              : 1
```

**Scope:** also latent, and doubly guarded today. `shared-validation-execution.ts` marks any run with
`fresh.output.length > CAUSAL_MAX_OUTPUT_CHARS` as `partial`, so such receipts get `status: 'partial'`, are
never `reusable`, and are never stored; and `StoryStore` has the sidecar anyway. Still, an empty selector
should short-circuit before touching the sidecar — it is both a free win on the hot path and a narrowing of
the fail-closed surface.

### 5.4 The redaction widening is close to a no-op on the production path, and the registry rationale reads as if it were new

The registry entry added by this commit asserts *"Raw secret environment values are excluded from persisted
selector bytes."* That is true — but it was **already** true at `f3f69038ab`. The handler builds
`identity.effectiveEnvironment` with `effectiveCausalEnvironment(undefined, cwd)`
(`checklist.ts:1166`), which is `effectiveValidationCommandEnvironment` — the entire ambient environment with
**raw** values, minus a 30-entry frozen transport list and `PWD`. The predecessor already redacted every
secret-named value in that set. Fixture C, measured in this environment:

```
effectiveEnvironment key count      : 49
process.env key count               : 59
LAB_SELECTOR_SECRET_TOKEN present   : true
...and its value is RAW (unredacted): true
keys in process.env but NOT in effectiveEnvironment: ["CODEX_SESSION_ID","CODEX_THREAD_ID","OLDPWD","SHLVL",
  "CLAUDE_CODE_MESSAGING_SOCKET","CLAUDE_CODE_MESSAGING_TOKEN","CLAUDE_CODE_SESSION_ID",
  "CLAUDE_CODE_CHILD_SESSION","CLAUDE_PID","_"]
  ...of those, secret-named            : ["CLAUDE_CODE_MESSAGING_TOKEN"]
=> extra secret values the widening can newly redact on the handler path: 1
```

So on the real path the widening adds exactly one harness-injected variable here, and zero in an ordinary
owner session. Note also that the spread order `{...process.env, ...identity.effectiveEnvironment}` makes
`effectiveEnvironment` **win**, so for any key present in both it is the identity value that is searched for —
the ambient `process.env` value is only consulted for keys the identity omits, which is precisely the frozen
transport list. The adversarial tool's `SECRET_PERSISTED` assertion is therefore a valid regression guard but
is **not** evidence of a protection introduced by this commit; I expect it would pass at the predecessor too.
(I could not execute the predecessor `dist` to confirm that directly — see §7.)

The flip side is a real hazard, though a **pre-existing** one that this diff marginally widens:
`SECRET_ENV_KEY` matches on the variable *name* (`token|secret|password|passwd|api_key|private_key|
credential|authorization|auth`) and then blind-`split/join`s the *value* out of the output regardless of how
short or common it is. Fixture B, with an undeclared ambient `CI_AUTH_MODE=OK`:

```
raw output starts with : "ALL_CHECKS_OK\nxxxxxx"
persisted probe starts  : "ALL_CHECKS_<redacted>\nxxxxxxxxxxxxxxxxxx"
receipt.status          : pass exitCode=0
selector verdict        : fail   <-- command exited 0 and printed the marker
```

A two-character secret-named environment value silently converts a passing verification into a refusal, and
because the redaction happens at write time the poisoned bytes are what every later reusing process reads. To
be precise about attribution: on the production handler path such a variable would already have been inside
`effectiveEnvironment` at `f3f69038ab`, so this is **not newly introduced by this diff** — it is now simply
applied to a larger persisted body. Worth a minimum-length or word-boundary guard, but that is beyond this
repair's scope.

### 5.5 Minor: `producerSourceRefs` names a file with no relevant code

The new registry entry lists `packages/main/src/handlers/checklist.ts` among `producerSourceRefs`. At
`4830880ffc` that file contains **zero** occurrences of `selectorOutput`, `readCausalSelectorOutput`, or
`CAUSAL_OUTPUT_DIRECTORY` (`git show 4830880ffc:packages/main/src/handlers/checklist.ts | grep -c ...` → `0`).
It is a consumer (it wires `receiptStore` and surfaces `receipt_selector_absent`), not a producer. The
contract script does not check `producerSourceRefs` at all — `grep -n "producerSourceRefs"
scripts/verify-process-fact-contract.mjs` returns nothing — so this inaccuracy is unenforced.

### 5.6 Minor: observability of the stored evidence

For a long-output command the persisted checklist evidence receipt carries `selectorMatched: true` alongside
an `outputTail` that does **not** contain the selector (verified in
`complete-output-adversarial/results.json`: `tail has marker: false`). The justification now lives entirely in
the sidecar object. That is a defensible design, but a reader of `test-evidence.json` alone can no longer see
why the selector matched.

### 5.7 Minor: two `length` fields with different meanings

`receipt.outputLength` is `run.output.length` (**raw**), while `receipt.selectorOutput.length` is the
**redacted** length. Likewise, the doc says the sidecar triggers when output "exceeds the 12,000-character
display probe", but the actual condition is on the *redacted* length. Harmless, but the two numbers will not
agree and nothing explains why.

---

## 6. Does the RED failure actually follow from the baseline?

**Yes**, and the provenance is pinned rather than re-derived. From the HMAC-sealed Lab record
(`.git/lab-maintenance/five-item-proof-20260908.json`, extracted read-only to
`logs/lab-red-green-provenance.log`):

```
red   f3f69038ab...  at 2026-09-09T00:49:42Z  status 1  expected "LONG_OUTPUT_MIDDLE_SELECTOR_REFUSED"
      command ["node","experiments/five-item-proof/complete-output.mjs"]
green 4830880ffc...  at 2026-09-09T00:54:34Z  status 0  same command
      output tail: "COMPLETE_OUTPUT_SELECTOR_AND_FANOUT_GREEN\n"
```

The recorded RED output names the exact mechanism, on the **first** run, before any reuse:

```
LONG_OUTPUT_MIDDLE_SELECTOR_REFUSED: Error: verification evidence refused: pinned selector
"PUBLISH_RESTART_OK" not found in command output for I-1 [receipt_selector_absent]
    at enforceAndStampEvidence (.../dist/handlers/checklist.js:1007:15)
```

This is consistent with the predecessor source: the witness prints 15,000 `x`, the marker, then 15,000 `y`
(≈30,018 chars). `boundedOutputProbe` keeps a ~5,990-char head, a gap sentinel, and a ~5,990-char tail;
`boundedOutputTail` keeps the last 4,000 chars. The marker sits at ≈char 15,001, in none of them, so the
predecessor's `outputProbe.includes || outputTail.includes` necessarily returned `false`. The candidate's
adversarial tool independently confirms the arithmetic today by asserting
`!stored.outputProbe.includes('PUBLISH_RESTART_OK')`. The RED is a genuine target failure, not a missing
dependency or a harness artifact.

Two honest qualifications:

* **The RED proves only the selector-loss half.** The run failed on `mode=first`, so the assertions about
  cross-process fanout (`commandExecutions=0`, `LONG_OUTPUT_FANOUT_RERAN_COMMAND`, `.counts` stability) were
  never reached at baseline. They are meaningful regression guards added at GREEN, but there is no evidence
  that fanout was broken before, and none should be claimed.
* **`dist` is git-ignored, so the RED build cannot be verified from git.** The RED was recorded at 00:49:42Z
  against a `dist` built at 00:31Z — i.e. from `6d99d14d96`/`37e50cd185`, before the fix; `f3f69038ab` adds
  only the test file and no source, so that `dist` is the correct baseline. That reasoning rests on build-log
  timestamps in the owner's artifact directory, not on a reproducible artifact. I did not rebuild, as
  instructed.

---

## 7. Limitations — what this review does **not** establish

* **I did not run the predecessor.** No baseline build exists to execute and rebuilding was out of scope, so
  every predecessor-behavior statement above is derived from committed source plus the pinned RED record, not
  from an executed baseline.
* **`dist` is unverifiable from git.** All three owner tools and all six of my fixtures import
  `packages/main/dist/**`. I checked that `dist` was built at 01:53 local, after the candidate commit, and
  contains the new symbols, and that the two source files carrying the logic match `4830880ffc` byte for byte
  — but a compiled artifact is not a proof that it was compiled from that source.
* **The worktree moved under me** (§1). Findings are pinned to commit contents; anything the owner changes in
  `checklist.ts`, `process-fact-registry.ts`, `docs/validation-performance.md`, or
  `verify-process-fact-contract.mjs` after `4830880ffc` is outside this review.
* **I ran no build, no test suite, and not `scripts/verify-process-fact-contract.mjs`** (to avoid side
  effects); the mechanical enforcement of the new registry entry is reviewed by reading only.
* **Concurrency and crash-recovery are unexercised.** I did not test two processes racing on the same
  execution key through `withCausalEvidenceExecution`, nor a crash between the output write and the receipt
  write. The ordering argument in §3 is a code reading.
* **A genuine predecessor-written >12,000-char receipt was never exercised.** Fixture E covers the legacy
  *shape* only via a ≤12,000-char receipt (where the probe is the whole output), so the
  `outputTail`-only legacy branch is verified by reading, not by execution. Forging a signed legacy receipt
  would have meant minting evidence, which I declined to do.
* **No performance or Story-level claim.** The fixtures measure a synthetic two-process handler sequence over
  a temp fixture; the owner's own `results.json` carries the same limitation verbatim. Nothing here supports a
  Story delivery-time speedup, and nothing here speaks to the other four items of the five-item proof — this
  review covers exactly one candidate commit.
* Fixtures B, C and the ambient-environment scan reflect **this machine's** environment (a Claude Code
  harness session, 59 env vars, 2 secret-named). Numbers will differ in an owner session.

## 8. False or overstated claims found

* The registry rationale's *"Raw secret environment values are excluded from persisted selector bytes"* is
  true but was already true at the predecessor; presented inside this commit's rationale it reads as a
  property this repair delivers (§5.4). The adversarial tool's `SECRET_PERSISTED` assertion does not
  discriminate between the two commits.
* `producerSourceRefs` names `handlers/checklist.ts`, which contains no code for this fact (§5.5).
* `docs/validation-performance.md` says *"The output object is process evidence, not a disposable runtime
  cache"*, while `runtime-artifact-registry.ts:147` classifies the whole `causal-evidence/` subtree as
  git-ignored, `materialHash: 'exclude'`, `volatile: true`. Both statements are internally defensible, but
  together they mean load-bearing, fail-closed evidence now lives in a subtree the registry marks disposable;
  a routine clean of ignored paths produces exactly the `missing` refusal the adversarial tool asserts, with
  no rerun path until the execution key changes. Worth reconciling in one of the two places.
* No claim I checked was false in the sense of contradicting observed behavior. The candidate does what its
  commit message says.

## 9. Assessment

The repair is well-shaped for its stated target: content-addressed complete output, bound by the signed
receipt, verified by both length and digest before use, published before the receipt, refusing rather than
rerunning or rewriting on tamper or loss, with the predecessor matcher preserved verbatim for legacy
receipts. The three owner tools reproduce green under independent execution in my own output directories,
and the RED is a genuine baseline failure with pinned provenance.

The substantive gaps are: an optional store interface paired with unconditional emission (§5.1), no size
bound of any kind on newly persisted bytes (§5.2), an empty-selector path that reads bytes it does not need
(§5.3), and a redaction claim that overstates what this diff adds (§5.4). None of §5.1–§5.3 is reachable
through an in-repo production path today — all are contract-level latencies guarded by `StoryStore` and by
the `partial` marking of >12,000-char shared-validation runs. §5.4 is a documentation accuracy issue, not a
behavior defect.

**Verdict: the candidate does what it claims for the path it was built for, with four issues worth
addressing before this pattern is relied on more widely. I do not assert all five items, and I make no
Story-speedup claim.**
