#!/usr/bin/env node
// Private verifier fixture E: legacy compatibility. A receipt whose redacted output is
// <= CAUSAL_MAX_OUTPUT_CHARS carries NO selectorOutput -- byte-identical in shape to every
// receipt the predecessor wrote. It must still reuse and select through a store that has
// no sidecar support at all, and readCausalSelectorOutput must fall back to outputProbe.
import assert from 'node:assert/strict';
const DIST='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
const {DEFAULT_CAUSAL_SELECTOR_POLICY,createCausalEvidenceBatch,executeCausalEvidence,preflightCausalEvidence,readCausalSelectorOutput,verifyCausalEvidenceReceipt,createCausalExecutionKey}=await import(DIST);
class LegacyStore{ #r=new Map();   // predecessor-era store: required methods only
  readCausalEvidenceReceipt(s,k){return this.#r.get(`${s}:${k}`)??null;}
  writeCausalEvidenceReceipt(s,rec){this.#r.set(`${s}:${rec.executionKey}`,structuredClone(rec));} }
const cwd=process.cwd();
const identity={storyId:'B-verifier-e',cwd,command:{executable:process.execPath,args:['-e','0']},
  bootstrap:{executable:'proof-or-stop',args:['verification-evidence']},
  inputs:{materialHash:'m',explicitInput:'e'},storyFilesHash:'s',
  effectiveEnvironment:{NODE_ENV:'test'},runtimeVersion:process.version,toolVersion:'verifier@1',
  selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
const preflight=preflightCausalEvidence({
  cli:{available:true,path:'proof-or-stop'},worktree:{expected:cwd,actual:cwd},
  gitIndex:{readable:true,path:`${cwd}/.git/index`,expected:'h',actual:'h',contentDigest:'sha256:x'},
  gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},
  writerLease:{available:true,valid:true},
  providerCapability:{required:['allowlisted-command','bounded-output'],available:['allowlisted-command','bounded-output']},
  resources:{required:{timeoutMs:1000},available:{timeoutMs:1000}},
  evidenceTarget:{writable:true,path:'B-verifier-e/causal-evidence/'},
  sideChannel:{available:true,maxOutputChars:12_000,maxProgressEvents:10},
},undefined,identity);
const store=new LegacyStore();
let executions=0;
const output='a'.repeat(5000)+'\nMIDDLE_MARKER\n'+'b'.repeat(5000);   // 10,015 chars: under the 12,000 bound
const call=(selector)=>executeCausalEvidence({identity,selector,intentRef:'I',receiptStore:store,batch:createCausalEvidenceBatch(),
  preflight,revalidateBeforeRun:()=>true,run:async()=>{executions++;return {code:0,output};}});
const first=await call('MIDDLE_MARKER');
console.log('outputLength                    :',first.receipt.outputLength);
console.log('selectorOutput emitted          :',first.receipt.selectorOutput!==undefined,'(legacy shape when false)');
console.log('first verdict                   :',first.verdict.result);
const second=await call('MIDDLE_MARKER');     // fresh batch -> reuse comes back off the store
console.log('reuse verdict via store         :',second.verdict.result,'disposition='+second.disposition);
console.log('command executions              :',executions);
const third=await call('MARKER_NOT_IN_OUTPUT');
console.log('absent selector verdict         :',third.verdict.result,'(fanout stays independent)');
console.log('verifyCausalEvidenceReceipt     :',verifyCausalEvidenceReceipt(second.receipt,createCausalExecutionKey(identity).key));
console.log('readCausalSelectorOutput falls back to outputProbe:',
  readCausalSelectorOutput({outputProbe:'PROBE_ONLY'})==='PROBE_ONLY');
assert.equal(executions,1);assert.equal(second.verdict.result,'pass');assert.equal(third.verdict.result,'fail');
console.log('LEGACY_SHAPE_OK');
