#!/usr/bin/env node
// Private verifier fixture B: the candidate widened redaction from the DECLARED
// identity.effectiveEnvironment to the whole ambient process.env. Any ambient env
// var whose NAME matches SECRET_ENV_KEY (token|secret|password|passwd|api_key|
// private_key|credential|authorization|auth) has its VALUE string-replaced out of
// the persisted output, regardless of how short or how common that value is.
const DIST='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
const {DEFAULT_CAUSAL_SELECTOR_POLICY,createCausalEvidenceBatch,executeCausalEvidence,preflightCausalEvidence}=await import(DIST);
// Ambient var the Story identity never declares. Short, plausible CI-style value.
process.env.CI_AUTH_MODE='OK';
const cwd=process.cwd();
const identity={storyId:'B-verifier-b',cwd,command:{executable:process.execPath,args:['-e','0']},
  bootstrap:{executable:'proof-or-stop',args:['verification-evidence']},
  inputs:{materialHash:'m',explicitInput:'b'},storyFilesHash:'s',
  effectiveEnvironment:{NODE_ENV:'test'},runtimeVersion:process.version,toolVersion:'verifier@1',
  selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
const preflight=preflightCausalEvidence({
  cli:{available:true,path:'proof-or-stop'},worktree:{expected:cwd,actual:cwd},
  gitIndex:{readable:true,path:`${cwd}/.git/index`,expected:'h',actual:'h',contentDigest:'sha256:x'},
  gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},
  writerLease:{available:true,valid:true},
  providerCapability:{required:['allowlisted-command','bounded-output'],available:['allowlisted-command','bounded-output']},
  resources:{required:{timeoutMs:1000},available:{timeoutMs:1000}},
  evidenceTarget:{writable:true,path:'B-verifier-b/causal-evidence/'},
  sideChannel:{available:true,maxOutputChars:12_000,maxProgressEvents:10},
},undefined,identity);
const output='ALL_CHECKS_OK\n'+'x'.repeat(20000);   // selector marker ends with "OK"
const r=await executeCausalEvidence({identity,selector:'ALL_CHECKS_OK',intentRef:'CHK-001:happy:0',
  batch:createCausalEvidenceBatch(),preflight,revalidateBeforeRun:()=>true,
  run:async()=>({code:0,output})});
console.log('raw output starts with :',JSON.stringify(output.slice(0,20)));
console.log('persisted probe starts  :',JSON.stringify(r.receipt.outputProbe.slice(0,40)));
console.log('receipt.status          :',r.receipt.status,'exitCode='+r.receipt.exitCode);
console.log('selector verdict        :',r.verdict.result,'<-- command exited 0 and printed the marker');
