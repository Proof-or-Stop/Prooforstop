#!/usr/bin/env node
// Private verifier fixture A: a CausalEvidenceReceiptStore that implements only the
// required receipt methods (exactly like the shipped MemoryReceiptStore in
// packages/main/src/tasks/causal-evidence-smoke.ts) plus a >12,000 char output whose
// selector sits inside the head of the display probe (i.e. a selector that the
// PREDECESSOR probe-only matcher would have matched).
import assert from 'node:assert/strict';
const DIST='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/packages/main/dist/core/causal-evidence.js';
const {DEFAULT_CAUSAL_SELECTOR_POLICY,createCausalExecutionKey,createCausalEvidenceBatch,executeCausalEvidence,preflightCausalEvidence,verifyCausalEvidenceReceipt}=await import(DIST);

class MemoryReceiptStore {           // no readCausalSelectorOutput / writeCausalSelectorOutput
  #receipts=new Map();
  readCausalEvidenceReceipt(storyId,executionKey){return this.#receipts.get(`${storyId}:${executionKey}`)??null;}
  writeCausalEvidenceReceipt(storyId,receipt){this.#receipts.set(`${storyId}:${receipt.executionKey}`,structuredClone(receipt));}
}
const cwd=process.cwd();
const identity={storyId:'B-verifier-a',cwd,command:{executable:process.execPath,args:['-e','0']},
  bootstrap:{executable:'proof-or-stop',args:['verification-evidence']},
  inputs:{materialHash:'m',explicitInput:'a'},storyFilesHash:'s',
  effectiveEnvironment:{NODE_ENV:'test'},runtimeVersion:process.version,toolVersion:'verifier@1',
  selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
const preflight=preflightCausalEvidence({
  cli:{available:true,path:'proof-or-stop'},worktree:{expected:cwd,actual:cwd},
  gitIndex:{readable:true,path:`${cwd}/.git/index`,expected:'h',actual:'h',contentDigest:'sha256:x'},
  gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},
  writerLease:{available:true,valid:true},
  providerCapability:{required:['allowlisted-command','bounded-output'],available:['allowlisted-command','bounded-output']},
  resources:{required:{timeoutMs:1000},available:{timeoutMs:1000}},
  evidenceTarget:{writable:true,path:'B-verifier-a/causal-evidence/'},
  sideChannel:{available:true,maxOutputChars:12_000,maxProgressEvents:10},
},undefined,identity);
// HEAD_MARKER lands at char 20 -> inside boundedOutputProbe head slice (first ~5,990 chars).
const output='HEAD_MARKER\n'+'x'.repeat(20000);
const store=new MemoryReceiptStore();
let executions=0;
const run=async()=>{executions++;return {code:0,output};};
const call=(selector,batch)=>executeCausalEvidence({identity,selector,intentRef:'CHK-001:happy:0',receiptStore:store,batch,preflight,revalidateBeforeRun:()=>true,run});

const first=await call('HEAD_MARKER',createCausalEvidenceBatch());
console.log('first.verdict =',first.verdict.result,'executions =',executions);
console.log('receipt.selectorOutput =',JSON.stringify(first.receipt.selectorOutput));
console.log('outputProbe contains HEAD_MARKER =',first.receipt.outputProbe.includes('HEAD_MARKER'));
console.log('verifyCausalEvidenceReceipt =',verifyCausalEvidenceReceipt(first.receipt,createCausalExecutionKey(identity).key));

let secondResult;
try{ const second=await call('HEAD_MARKER',createCausalEvidenceBatch());
     secondResult=`verdict=${second.verdict.result} disposition=${second.disposition}`; }
catch(error){ secondResult='THREW: '+error.message; }
console.log('reuse in a NEW batch (store round-trip) =>',secondResult);
console.log('executions after reuse attempt =',executions);
assert.equal(executions,1,'no rerun happened');
