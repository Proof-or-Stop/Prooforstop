import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {performance} from 'node:perf_hooks';
const lab='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const script=fileURLToPath(import.meta.url),art=path.dirname(script),out=path.join(art,'real-capacity-config');fs.mkdirSync(out,{recursive:true});
const {declaredValidationCapacity,withWorkspaceValidationCapacity}=await import(lab+'/packages/main/dist/core/validation-execution-lock.js');
const {runValidationCommand}=await import(lab+'/packages/main/dist/core/validation-executor.js');
const candidate=JSON.parse(fs.readFileSync(lab+'/proof-or-stop.config.json'));
const baseline=JSON.parse(execFileSync('git',['show','cf21df09c273074d7aa3227a5f436c6f5badf47a:proof-or-stop.config.json'],{cwd:lab,encoding:'utf8'}));
const indices=[117,118,119,120];
if(process.argv[2]==='--worker'){
 const [root,mode]=process.argv.slice(3),config=mode==='RED'?baseline:candidate;
 const commands=config.validate.commands.map((c,i)=>({...c,label:String(i)}));
 await new Promise(r=>{process.once('message',r);process.send('ready');});
 const requested=Date.now();
 await withWorkspaceValidationCapacity({root,workspaceRoot:root,command:'full-declarations-four-real-suites',...declaredValidationCapacity(commands,root),pollMs:5},async()=>{
  const entered=Date.now();process.stdout.write(JSON.stringify({event:'enter',at:entered,queueMs:entered-requested,pid:process.pid})+'\n');
  for(const index of indices){const result=await runValidationCommand({...commands[index],label:String(index)},root,30000);assert.equal(result.code,0,result.output);process.stdout.write(JSON.stringify({event:'suite',index,code:result.code,output:result.output})+'\n');}
  process.stdout.write(JSON.stringify({event:'exit',at:Date.now(),pid:process.pid})+'\n');
 });
 process.exit(0);
}
const fixture=fs.mkdtempSync(path.join(os.tmpdir(),'capacity-real-invocations-')),base=path.join(fixture,'base');fs.mkdirSync(base);
const git=args=>execFileSync('git',args,{cwd:base,stdio:'pipe'}),roots=[path.join(fixture,'left'),path.join(fixture,'right')];
try {
 fs.writeFileSync(path.join(base,'.gitignore'),'packages/\nnode_modules/\n.proof-or-stop/\n');git(['init','-q']);git(['add','.']);git(['-c','user.name=Fixture','-c','user.email=fixture@example.test','commit','-qm','fixture']);
 for(const [i,root] of roots.entries()){
  git(['worktree','add','-q','-b','copy'+i,root]);
  fs.mkdirSync(path.join(root,'packages/main'),{recursive:true});fs.cpSync(lab+'/packages/main/dist',path.join(root,'packages/main/dist'),{recursive:true});fs.copyFileSync(lab+'/packages/main/package.json',path.join(root,'packages/main/package.json'));
  fs.symlinkSync(lab+'/node_modules',path.join(root,'node_modules')); // shared read-only dependencies; independent writable dist
  for(const index of indices){const rel=candidate.validate.commands[index].args[0];fs.mkdirSync(path.dirname(path.join(root,rel)),{recursive:true});fs.copyFileSync(path.join(lab,rel),path.join(root,rel));}
 }
 const rows=[];
 for(let pair=1;pair<=2;pair++)for(const mode of pair%2?['RED','GREEN']:['GREEN','RED']){
  let ready=0;const children=[],started=performance.now();
  const logs=await Promise.all(roots.map(root=>new Promise((resolve,reject)=>{
   const child=spawn(process.execPath,[script,'--worker',root,mode],{stdio:['ignore','pipe','pipe','ipc']});children.push(child);let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
   const timer=setTimeout(()=>child.kill('SIGTERM'),90000);child.on('message',()=>{if(++ready===roots.length)children.forEach(c=>c.send('start'));});child.on('error',reject);child.on('close',code=>{clearTimeout(timer);fs.writeFileSync(path.join(out,`${pair}-${mode}-${path.basename(root)}.log`),stdout+stderr);code===0?resolve(stdout.trim().split('\n').map(JSON.parse)):reject(new Error('capacity child '+code+': '+stderr));});
  })));
  const windows=logs.map(events=>({enter:events.find(e=>e.event==='enter').at,exit:events.find(e=>e.event==='exit').at,queueMs:events.find(e=>e.event==='enter').queueMs,completedSuites:events.filter(e=>e.event==='suite').length}));
  const overlapMs=Math.min(...windows.map(w=>w.exit))-Math.max(...windows.map(w=>w.enter));assert.equal(overlapMs>0,mode==='GREEN','Actual capacity admission must serialize RED and overlap GREEN');assert.ok(windows.every(w=>w.completedSuites===4));
  rows.push({pair,mode,elapsedMs:performance.now()-started,overlapMs,windows});fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({rows,sourceCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:lab,encoding:'utf8'}).trim(),declaredCommands:134,executedCommandsPerWorktree:4,limitations:['Real shared-capacity queue with two actual linked Git worktrees and all 134 real resource declarations.','Only four existing assertion suites execute inside each admitted ticket; this is not two complete 134-command runs or whole-Story elapsed time.','Dist copies are independent; immutable node_modules is shared read-only. No parent repository capacity ticket is used.']},null,2));console.log(mode,pair,rows.at(-1).elapsedMs,overlapMs);
 }
 console.log('ACTUAL_FULL_DECLARATION_CAPACITY_GREEN');
} finally {fs.rmSync(fixture,{recursive:true,force:true});}
