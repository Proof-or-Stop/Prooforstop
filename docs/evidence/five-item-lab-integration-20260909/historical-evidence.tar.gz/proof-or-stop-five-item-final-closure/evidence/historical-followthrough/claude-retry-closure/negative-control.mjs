// Independent negative controls for Lab 89cccb38c1 / e4301c5df9.
// Read-only against the Lab: the only writes are under this artifact directory
// and a throwaway $TMPDIR fixture. No build, no Lab mutation.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const LAB = '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const DIST = join(LAB, 'packages/main/dist/core/causal-evidence.js');
const OUT = dirname(fileURLToPath(import.meta.url));

const fixed = await import(pathToFileURL(DIST).href);

// A copy of the shipped dist module with only the new consumer-selector guard
// removed, so the guard's load-bearingness is measured rather than assumed.
const source = readFileSync(DIST, 'utf8');
const GUARD = `    if (receipt.selectorWitness
        && receipt.selectorWitness.selectorDigest !== createHash('sha256').update(args.selector).digest('hex')) {
        receipt = await executeFresh();
        disposition = 'executed';
    }
`;
assert.ok(source.includes(GUARD), 'guard text not found in dist; control would be vacuous');
const unfixedPath = join(OUT, 'causal-evidence.guard-removed.mjs');
writeFileSync(
  unfixedPath,
  source
    .replace(GUARD, '')
    .replace(/from '\.\/([a-z-]+\.js)'/g, (_m, f) => `from '${join(LAB, 'packages/main/dist/core', f)}'`),
);
const unfixed = await import(pathToFileURL(unfixedPath).href);
assert.equal(readFileSync(unfixedPath, 'utf8').includes('receipt = await executeFresh()'), false);

const root = mkdtempSync(join(tmpdir(), 'claude-retry-closure-'));
const digest = s => createHash('sha256').update(s).digest('hex');
const results = [];
const ok = (name, detail) => { results.push(`NC-OK ${name} ${detail}`); console.log(`NC-OK ${name} ${detail}`); };

try {
  const identity = {
    storyId: 'B-retry-closure-control', cwd: root,
    command: { executable: process.execPath, args: ['-e', 'opaque control witness'] },
    inputs: { materialHash: 'test-material' }, storyFilesHash: 'test-story',
    effectiveEnvironment: { TEST_SECRET_TOKEN: 'private-value-123' },
    runtimeVersion: process.version, toolVersion: 'test',
    selectorPolicy: fixed.DEFAULT_CAUSAL_SELECTOR_POLICY,
  };
  const facts = {
    cli: { available: true, path: process.execPath }, worktree: { expected: root, actual: root },
    gitIndex: { readable: true, path: join(root, 'index'), contentDigest: 'index' },
    gitMaterial: { available: true, headHash: 'head', materialHash: 'test-material', storyFilesHash: 'test-story' },
    writerLease: { available: true, valid: true },
    providerCapability: { required: ['bounded-output'], available: ['bounded-output'] },
    resources: { required: { slots: 1 }, available: { slots: 1 } },
    evidenceTarget: { writable: true, path: root },
    sideChannel: { available: true, maxOutputChars: 12000, maxProgressEvents: 1 },
  };
  const preflight = fixed.preflightCausalEvidence(facts, () => true, identity);
  const pause = ms => new Promise(r => setTimeout(r, ms));

  // ---- A. One selector genuinely absent: truthful refusal and correct attribution?
  const absentScenario = async mod => {
    const batch = mod.createCausalEvidenceBatch();
    let calls = 0;
    const selectors = ['PRESENT_ONE', 'PRESENT_TWO', 'ABSENT_MARK'];
    const invoke = selector => mod.executeCausalEvidence({
      identity, preflight, batch, revalidateBeforeRun: () => true, selector,
      run: async () => { calls++; await pause(5); return { code: 0, output: 'PRESENT_ONE PRESENT_TWO ' + 'x'.repeat(20000) }; },
    });
    const values = await Promise.all(selectors.map(invoke));
    return { calls, selectors, values };
  };

  const fixedRun = await absentScenario(fixed);
  for (let i = 0; i < 3; i++) {
    const { receipt, verdict } = fixedRun.values[i];
    assert.ok(receipt.selectorWitness, 'fallback witness expected (no durable store, >12k output)');
    assert.equal(receipt.selectorWitness.selectorDigest, digest(fixedRun.selectors[i]),
      'each consumer must hold a witness for its own selector');
    assert.ok(fixed.verifyCausalEvidenceReceipt(receipt, receipt.executionKey), 'receipt must verify');
    assert.equal(verdict.selector, fixedRun.selectors[i]);
    assert.equal(verdict.receiptHash, receipt.receiptHash, 'verdict must cite the receipt that tested it');
  }
  assert.equal(fixedRun.values[0].verdict.result, 'pass');
  assert.equal(fixedRun.values[1].verdict.result, 'pass');
  assert.equal(fixedRun.values[2].verdict.result, 'fail');
  assert.equal(fixedRun.values[2].verdict.reason, 'selectorMismatch');
  assert.equal(fixedRun.values[2].receipt.selectorWitness.matched, false);
  assert.equal(new Set(fixedRun.values.map(v => v.receipt.receiptHash)).size, 3, 'no receipt is shared across selectors');
  ok('WITNESS-BOUND-TO-OWN-SELECTOR',
    `3 selectors, ${fixedRun.calls} executions, 3 distinct receipts; the absent selector fails on its own witness (matched=false)`);

  const unfixedRun = await absentScenario(unfixed);
  const borrowed = unfixedRun.values.filter((v, i) => v.receipt.selectorWitness.selectorDigest !== digest(unfixedRun.selectors[i]));
  assert.ok(borrowed.length > 0, 'guard removal must reproduce the defect, otherwise the guard is not load-bearing');
  const falseRefusals = borrowed.filter(v => v.verdict.result === 'fail' && v.receipt.selectorWitness.matched === true);
  ok('GUARD-LOAD-BEARING',
    `guard removed: ${unfixedRun.calls} executions, ${borrowed.length}/3 consumers hold another selector's witness, ` +
    `${falseRefusals.length} of those refuse on a witness that reported matched=true for a different selector`);

  // ---- B. Storage-failure behaviour: bytes, receipt writes and child count.
  const storeFactory = (mode) => {
    const receipts = new Map(); const outputs = new Map();
    const s = {
      receiptWrites: 0, outputWrites: 0, outputs,
      readCausalEvidenceReceipt: (_s, k) => receipts.get(k) ?? null,
      writeCausalEvidenceReceipt: (_s, r) => { s.receiptWrites++; receipts.set(r.executionKey, structuredClone(r)); },
      readCausalSelectorOutput: (_s, k) => outputs.get(k),
      writeCausalSelectorOutput: (_s, k, out) => {
        s.outputWrites++;
        if (mode === 'permanent' || s.outputWrites === 1) throw new Error(`${mode.toUpperCase()}_OUTPUT_WRITE_FAILURE`);
        outputs.set(k, out);
      },
    };
    return s;
  };
  const transient = storeFactory('transient');
  let transientCalls = 0;
  const secret = 'private-value-123';
  const transientResult = await fixed.executeCausalEvidence({
    identity, preflight, receiptStore: transient, revalidateBeforeRun: () => true, selector: 'OK',
    run: async () => { transientCalls++; return { code: 0, output: 'OK ' + secret + ' ' + 'x'.repeat(20000) }; },
  });
  assert.equal(transientResult.verdict.result, 'pass');
  assert.equal(transientCalls, 1, 'no second child');
  assert.equal(transient.outputWrites, 2, 'exactly one republication attempt');
  assert.equal(transient.receiptWrites, 1);
  const published = transient.outputs.get(transientResult.receipt.selectorOutput.digest);
  assert.equal(createHash('sha256').update(published).digest('hex'), transientResult.receipt.selectorOutput.digest,
    'republished bytes must be the bytes the receipt advertises');
  assert.equal(published.includes(secret), false, 'republished bytes stay redacted');
  ok('TRANSIENT-REPUBLISH-SAME-BYTES',
    `1 child, 2 write attempts, receipt digest matches stored bytes (${published.length} chars), secret still redacted`);

  const permanent = storeFactory('permanent');
  let permanentCalls = 0;
  await assert.rejects(() => fixed.executeCausalEvidence({
    identity, preflight, receiptStore: permanent, revalidateBeforeRun: () => true, selector: 'OK',
    run: async () => { permanentCalls++; return { code: 0, output: 'OK ' + 'x'.repeat(20000) }; },
  }), /PERMANENT_OUTPUT_WRITE_FAILURE/);
  assert.equal(permanentCalls, 1, 'refusal must not launch a second child');
  assert.equal(permanent.outputWrites, 2, 'bounded at two attempts, no unbounded retry');
  assert.equal(permanent.receiptWrites, 0, 'no receipt may be published for unpublished bytes');
  assert.equal(permanent.outputs.size, 0);
  ok('PERMANENT-REFUSAL-PUBLISHES-NOTHING',
    '1 child, 2 bounded attempts, 0 receipts written, 0 output objects');

  // ---- C. Does the new audit guard police the supersession record itself?
  const { verifyResourceAudit } = await import(pathToFileURL(join(LAB, 'experiments/five-item-proof/resource-audit-policy.mjs')).href);
  const config = JSON.parse(readFileSync(join(LAB, 'proof-or-stop.config.json'), 'utf8'));
  const audit = JSON.parse(readFileSync(join(LAB, 'experiments/five-item-proof/resource-audit.json'), 'utf8'));
  assert.deepEqual(verifyResourceAudit(config, audit), { auditedReaders: 21, effectivelySharedReaders: 15, supersededReaders: 6 });

  const entry3 = audit.entries.find(e => e.commandIndex === 3);
  const droppable = entry3.suggestedResources.find(r => r.access === 'shared');
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const mutatedAudit = structuredClone(audit); const mutatedConfig = structuredClone(config);
  const mEntry = mutatedAudit.entries.find(e => e.commandIndex === 3);
  mEntry.supersededBy.effectiveResources = mEntry.supersededBy.effectiveResources.filter(r => !same(r, droppable));
  mutatedConfig.validate.commands[3].resources = mutatedConfig.validate.commands[3].resources.filter(r => !same(r, droppable));
  let dropCaught = null;
  try { verifyResourceAudit(mutatedConfig, mutatedAudit); } catch (error) { dropCaught = error.message; }
  ok('SUPERSESSION-NOT-SUPERSET-CHECKED',
    `dropping audited shared claim ${JSON.stringify(droppable)} from BOTH the supersession record and the config is ` +
    (dropCaught ? `rejected (${dropCaught})` : 'ACCEPTED by verifyResourceAudit; supersededBy need not retain suggestedResources'));

  const forged = structuredClone(audit);
  forged.entries.find(e => e.commandIndex === 3).supersededBy.classification = 'shared-local-reader';
  assert.throws(() => verifyResourceAudit(config, forged), /RESOURCE_AUDIT_SUPERSESSION_INVALID/);
  const noRef = structuredClone(audit);
  delete noRef.entries.find(e => e.commandIndex === 6).supersededBy.reference;
  assert.throws(() => verifyResourceAudit(config, noRef), /RESOURCE_AUDIT_SUPERSESSION_INVALID/);
  ok('SUPERSESSION-SHAPE-ENFORCED', 'classification and reference are both required; a reader-classified supersession is refused');

  const barrier = r => r.class === 'fixed-path' && r.key === '.proof-or-stop/runtime/validate-plan-barrier' && r.access === 'exclusive';
  const reviewed = audit.entries.filter(e => e.recommendation === 'safe-to-declare-shared');
  const withBarrier = reviewed.filter(e => config.validate.commands[e.commandIndex].resources.some(barrier));
  assert.equal(reviewed.length, 21);
  assert.equal(withBarrier.length, 6);
  assert.deepEqual(withBarrier.map(e => e.commandIndex).sort((a, b) => a - b), [3, 6, 40, 79, 81, 105]);
  assert.ok(reviewed.filter(e => e.supersededBy).every(e => e.suggestedResources.every(s => e.supersededBy.effectiveResources.some(x => same(x, s)))),
    'as shipped, every supersession retains its prior suggested claims');
  ok('AUDIT-PARTITION-INDEPENDENT',
    '21 reviewed = 6 barrier-serialized (3,6,40,79,81,105) + 15 overlappable, recomputed from config+audit without the policy module');

  writeFileSync(join(OUT, 'negative-control.result.txt'), results.join('\n') + '\n');
  console.log('CLAUDE_RETRY_CLOSURE_CONTROLS_GREEN');
} finally {
  rmSync(root, { recursive: true, force: true });
}
