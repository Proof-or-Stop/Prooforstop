// Control D: the new consumer-selector guard must not destroy legitimate
// single-execution fan-out when durable selector output IS available.
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const LAB = '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const m = await import(join(LAB, 'packages/main/dist/core/causal-evidence.js'));
const root = mkdtempSync(join(tmpdir(), 'claude-fanout-'));
try {
  const identity = { storyId: 'B-fanout-control', cwd: root, command: { executable: process.execPath, args: ['-e', 'opaque'] },
    inputs: { materialHash: 'm' }, storyFilesHash: 's', effectiveEnvironment: {}, runtimeVersion: process.version,
    toolVersion: 'test', selectorPolicy: m.DEFAULT_CAUSAL_SELECTOR_POLICY };
  const facts = { cli: { available: true, path: process.execPath }, worktree: { expected: root, actual: root },
    gitIndex: { readable: true, path: join(root, 'index'), contentDigest: 'i' },
    gitMaterial: { available: true, headHash: 'h', materialHash: 'm', storyFilesHash: 's' },
    writerLease: { available: true, valid: true }, providerCapability: { required: ['bounded-output'], available: ['bounded-output'] },
    resources: { required: { slots: 1 }, available: { slots: 1 } }, evidenceTarget: { writable: true, path: root },
    sideChannel: { available: true, maxOutputChars: 12000, maxProgressEvents: 1 } };
  const preflight = m.preflightCausalEvidence(facts, () => true, identity);
  const receipts = new Map(), outputs = new Map();
  const store = { readCausalEvidenceReceipt: (_s, k) => receipts.get(k) ?? null,
    writeCausalEvidenceReceipt: (_s, r) => receipts.set(r.executionKey, structuredClone(r)),
    readCausalSelectorOutput: (_s, k) => outputs.get(k), writeCausalSelectorOutput: (_s, k, o) => outputs.set(k, o) };
  const selectors = ['ALPHA_MARK', 'BETA_MARK', 'GAMMA_MARK', 'MISSING_MARK'];
  const batch = m.createCausalEvidenceBatch();
  let calls = 0;
  const values = await Promise.all(selectors.map(selector => m.executeCausalEvidence({
    identity, preflight, batch, receiptStore: store, revalidateBeforeRun: () => true, selector,
    run: async () => { calls++; await new Promise(r => setTimeout(r, 5)); return { code: 0, output: 'ALPHA_MARK BETA_MARK GAMMA_MARK ' + 'x'.repeat(20000) }; } })));
  assert.equal(calls, 1, 'durable output must still fan out to one execution');
  assert.ok(values.every(v => v.receipt.selectorOutput && !v.receipt.selectorWitness));
  assert.deepEqual(values.map(v => v.verdict.result), ['pass', 'pass', 'pass', 'fail']);
  assert.equal(new Set(values.map(v => v.receipt.receiptHash)).size, 1, 'one shared reusable receipt');
  console.log(`NC-OK DURABLE-FANOUT-PRESERVED 4 selectors -> ${calls} execution, 1 shared reusable receipt, absent selector still fails (no witness rerun)`);
  console.log('CLAUDE_FANOUT_CONTROL_GREEN');
} finally { rmSync(root, { recursive: true, force: true }); }
