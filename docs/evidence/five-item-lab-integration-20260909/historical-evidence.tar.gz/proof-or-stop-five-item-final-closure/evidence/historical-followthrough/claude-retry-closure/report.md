# Independent verification — e4301c5df9 (RED) + 89cccb38c1 (repair)

Reviewer: independent Claude CLI session, 2026-09-09. **Not a formal Story review; creates no Story credential.**
Lab: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`.
Read: the two named commits' diff, `causal-evidence.ts:690-931` (the enclosing function), `recordExecution`
(`:603-613`), `resource-audit-policy.mjs`, `resource-audit.json`, `proof-or-stop.config.json`.
Background only, not re-derived: `claude-final-repairs/report.md` (F1/F2) and
`llm-review-experiment/candidate-performance.result.txt` (batch witness, late retry).

**Provenance caveat.** The Lab advanced under me. My three mandated runs (03:15:47–03:16:00) executed at
HEAD `89cccb38c1`. At 03:17:19 the Lab committed `335c2bbe10 test: reproduce repeated real capacity claim
normalization`, which adds exactly one new file (`experiments/five-item-proof/capacity-claim-dedup.mjs`)
and touches nothing I imported; my controls (03:18–03:19) therefore ran against identical bytes for every
file under review. That new RED test has no fix commit yet — its defect is open, and nothing here speaks to it.

I modified nothing in the Lab. `git status --porcelain` before and after is the same single untracked
`AGENTS.override.md`. No build, no agents, no Story mutation, no full suite. All my writes are under
`.../claude-retry-closure/` plus a throwaway `$TMPDIR` fixture. **[EXEC]** = ran it; **[READ]** = source only.

## 1. Mandated commands, actual exits [EXEC]

Run from the Lab root, no environment overrides:

| # | Command | Exit | Final marker |
|---|---|---|---|
| 1 | `node experiments/five-item-proof/final-review-regressions.mjs` | **0** | `BATCH_RETRY_SELECTOR_GREEN`, `RESOURCE_AUDIT_SUPERSESSION_AND_MUTATION_GUARDS_GREEN`, `FINAL_REVIEW_REGRESSIONS_GREEN` (3 PASS lines; `{"fallbackCalls":3}`) |
| 2 | `node experiments/five-item-proof/publication-restart.mjs` | **0** | `CROSS_PROCESS_PUBLICATION_RECOVERY_GREEN` |
| 3 | `node scripts/verify-hash-accuracy.mjs` | **0** | `HASH_ACCURACY_GREEN` — `Exact independent oracle: 27/27` |

Verbatim stdout in `run-*.log`. The tests import `packages/main/dist`; that `dist` is newer than the
reviewed source (`causal-evidence.js` 03:10:46 vs `.ts` 03:09:40) and contains all three source edits
(`retryExecutions.get(key.key) ??`, the bounded `attempt === 1` publication loop, the witness-digest
guard), so what ran is what I read. I did not rebuild, so I cannot rule out staleness elsewhere in `dist`.

## 2. My own controls [EXEC]

`negative-control.mjs` (exit **0**, `negative-control.log`), `fanout-control.mjs` (exit **0**),
`ledger-control.mjs` (exit **0**). Results:

```
NC-OK WITNESS-BOUND-TO-OWN-SELECTOR 3 selectors, 3 executions, 3 distinct receipts; the absent selector fails on its own witness (matched=false)
NC-OK GUARD-LOAD-BEARING guard removed: 2 executions, 1/3 consumers hold another selector's witness, 1 of those refuse on a witness that reported matched=true for a different selector
NC-OK TRANSIENT-REPUBLISH-SAME-BYTES 1 child, 2 write attempts, receipt digest matches stored bytes (20005 chars), secret still redacted
NC-OK PERMANENT-REFUSAL-PUBLISHES-NOTHING 1 child, 2 bounded attempts, 0 receipts written, 0 output objects
NC-OK SUPERSESSION-NOT-SUPERSET-CHECKED dropping audited shared claim {"class":"fixed-path","key":"packages/main/dist","access":"shared"} from BOTH the supersession record and the config is ACCEPTED by verifyResourceAudit
NC-OK SUPERSESSION-SHAPE-ENFORCED classification and reference are both required; a reader-classified supersession is refused
NC-OK AUDIT-PARTITION-INDEPENDENT 21 reviewed = 6 barrier-serialized (3,6,40,79,81,105) + 15 overlappable, recomputed from config+audit without the policy module
NC-OK DURABLE-FANOUT-PRESERVED 4 selectors -> 1 execution, 1 shared reusable receipt, absent selector still fails (no witness rerun)
NC-OK LEDGER-HONEST intents=3 actualChildren=3 recordedAttempts=3 entries=1
```

`GUARD-LOAD-BEARING` is the one that matters: I copied the shipped `dist` module into my directory,
removed **only** the four-line guard (rewriting its three relative imports to absolute Lab paths, asserting
the removal took), and re-ran the identical scenario. The defect reappears on the shipped build — so the
repair is load-bearing, not a test that would pass either way. I did not treat the Lab's RED file as proof.

## 3. The five review questions

### 3.1 Is the signed fallback witness bound to the consumer's actual selector? — Yes [EXEC/READ]

`causal-evidence.ts:908-916`: after the shared execution resolves, a caller holding a receipt whose
`selectorWitness.selectorDigest !== sha256(args.selector)` discards it and runs its own `executeFresh()`.
Because the witness is built from `args.selector` inside that same closure (`:764-765`), the replacement is
bound to this caller **by construction** — a second mismatch is unreachable, so the single unconditional
rerun is a sufficient bound, not a heuristic. Measured with three concurrent distinct selectors on
>12,000-char output and no durable store: 3 executions, 3 distinct verifying receipts, each
`selectorWitness.selectorDigest` equal to its own selector's digest, each `verdict.receiptHash` equal to
its own receipt. The genuinely absent selector fails on its own `matched: false` with
`reason: 'selectorMismatch'` — a truthful refusal, correctly attributed. With the guard removed, one of
three consumers instead refused on a foreign witness that had recorded `matched: true` for a different
selector: precisely the "verdict minted for a selector never evaluated" defect.

Cost is bounded and correctly documented: one execution per distinct selector **only** on the non-durable
fallback path. The guard keys on witness presence alone, so the durable path is untouched — 4 selectors
against a store with `read/writeCausalSelectorOutput` still fan out to **1 execution and one shared
reusable receipt**, with the absent selector still failing (control D). No reuse regression.

### 3.2 Do late joiners launch a third identical retry? — No, with one narrow window [EXEC/READ]

`:826-828` now resolves `batchPromise` as `retryExecutions.get(key) ?? executions.get(key)`, so a caller
arriving while the converged retry is in flight subscribes to it. The Lab test gates a real retry open and
asserts `calls === 2`; it passed. Bound I found and could not close by reading alone: between the leader's
`executions.delete` (`:887-889`) and the first follower's `retryExecutions.set` (`:863`) neither map holds
the key, and a caller landing in that gap registers nothing and runs a third child. The gap is microtask-
only (no `await` separates the follower's map reads from `executeFresh()`'s synchronous prefix), so a timer-
or I/O-scheduled caller cannot land in it; I judge it very narrow but non-empty, and I did not manufacture it.

### 3.3 Is completed output retried at most twice with no second child? — Yes [EXEC/READ]

`:799-810` wraps **only** `writeCausalSelectorOutput` in `for (attempt = 0; attempt < 2; ...)`, rethrowing
on the second failure. `args.run()` is at `:754`, outside the loop, so no path re-launches a child.
Measured: transient store → 1 child, exactly 2 write attempts, exactly 1 receipt write, and the republished
bytes hash to the digest the signed receipt advertises (20,005 chars) with the fixture secret still
redacted — the retry publishes the same immutable bytes, not a re-observation. Bound: the second attempt is
immediate, with no delay or backoff, so it only covers a fault transient at microsecond scale (a full disk
will fail both attempts). "At most twice" is exact.

### 3.4 Does permanent storage failure remain refused? — Yes, with evidenceWrites=0 [EXEC/READ]

Permanent-failure store: the call rejects with the store's error, 1 child ran, exactly 2 attempts, **0
receipts written and 0 output objects stored**. The `writeCausalEvidenceReceipt` call (`:815-817`) is
downstream of the throw, so no receipt can advertise bytes that were never published. `docs/validation-
performance.md` states this ("A permanent storage error still refuses and provides no cross-process
recovery guarantee") and the claim matches behaviour. Residual: the prior F2 is **narrowed, not closed** —
`writeCausalEvidenceReceipt` at `:815-817` is still unwrapped, so a receipt-store write fault still converts
a completed PASS into a thrown validation error. Fail-closed, no corrupt evidence; the docs paragraph
covers only output publication.

### 3.5 Resource audit: exact claims and machine-readable 21/15/6 — accurate; one gap [EXEC/READ]

`resource-audit-policy.mjs` restores exactness: `assert.deepEqual(command.resources,
supersession?.effectiveResources ?? entry.suggestedResources)`. That is the correct repair of F1 — the
subset check that let six barrier reversions pass unseen is gone, and the audit file must now name each
supersession explicitly. A supersession must carry `classification: 'exclusive-local-writer'`, a
`reference`, and the barrier claim; `argv` drift is still checked. `resource-audit-contract.mjs` exercises
both mutation directions (adding an unapproved barrier to reader 117, removing a retained barrier from 3)
and both throw `RESOURCE_AUDIT_DRIFT`; it passed under command #1.

The numbers are right and are machine-readable. I recomputed the partition directly from
`proof-or-stop.config.json` + `resource-audit.json` without the policy module: 21 entries recommended
`safe-to-declare-shared`, exactly 6 carry the exclusive barrier in the live config (indices 3, 6, 40, 79,
81, 105 — the same six), leaving 15 overlappable. `resource-config.mjs` now spreads
`{auditedReaders, effectivelySharedReaders, supersededReaders}` into `results.json`, and the Lab's own
03:12 run wrote `{"auditedReaders":21,"effectivelySharedReaders":15,"supersededReaders":6,
"remainingRoutineWriterBarriers":11}`. F1's "overstates the result" complaint is resolved. All six
supersessions do in fact retain every prior suggested claim (0 dropped) and reference `b97fe91cb7`.

**G1 (new, low–medium) — the supersession record itself is not superset-checked.** `verifyResourceAudit`
compares the config against `effectiveResources` but never requires `effectiveResources ⊇
suggestedResources`. My control removed `fixed-path packages/main/dist shared` from **both** entry 3's
supersession record and the config command, and the guard **accepted** it — a future edit could quietly
withdraw a claim the audit recommended, so long as the audit file is edited to match. That is drift from
the reviewed recommendation, which is exactly what this guard exists to catch. The shipped data does not
exercise the hole. Narrow fix: assert every `suggestedResources` entry is present in `effectiveResources`
(the barrier is then the only permitted addition). I did not run `resource-config.mjs` (it executes real
assertion suites in RED/GREEN pairs); §3.5 is `[READ]` on that file's guards plus `[EXEC]` on the extracted
policy module and the contract test.

## 4. Other bounds observed, not claimed solved

- **Retry rejection now couples concurrent subscribers.** A late joiner that subscribes via
  `retryExecutions` inherits that retry's rejection (`:832`, `.then` onFulfilled never runs) and, having
  registered nothing at `:883`, gets an error where it would previously have run its own attempt. The
  rejection handler (`:856-860`) clears both maps, so *subsequent* callers still retry; the blast radius is
  concurrent subscribers only. Fail-closed.
- **Ledger accounting is honest; one derived metric name is not.** Summed `executionAttempts` equals actual
  child runs (3 = 3) and the ledger verifies, because `recordExecution` merges per key and adds attempts.
  But `deriveCausalMetrics` on that same ledger reports `commandExecutions: 1`, `cacheHitRate: 0.667`,
  `commandReruns: 2` — the two per-selector reruns surface only in `commandReruns`. A reader of
  `commandExecutions` alone would understate the work. Recorded as an observation for the experiment
  register, not audited further and not claimed solved.
- The mismatch rerun at `:914` is not offered back to `batch.executions`; if such a rerun ever produced a
  reusable receipt it would be stored durably but not batch-deduplicated. Missed dedup, not a correctness issue.

Per instruction, the dependency DAG, secrets heuristics, metrics and global session migration are **not**
audited here and remain open in the register.

## 5. Scope limits

- Not a Story review. No full suite, no build, no agents, no Lab writes.
- I ran the three mandated commands plus four controls of my own. I did **not** run `resource-config.mjs`,
  `capacity-config.mjs`, or the copied `real-capacity-config.mjs` — the real two-worktree capacity check was
  outside these five questions and is unchanged by these two commits, so I spent the budget on the retry and
  audit closure instead. Nothing here re-verifies the capacity claims.
- Everything in §3.1–3.4 is measured through the prebuilt `dist` with in-memory fixture stores; no
  cross-process, real-filesystem or hostile-host claim is made beyond command #2's own green result.
- The §3.2 window and the §4 coupling are `[READ]` conclusions about ordering; I did not force either.
- No speed claim: §3.1's "3 executions for 3 selectors" is correctness cost, and `results.json`'s
  RED/GREEN medians are the Lab's measurement, not mine.

## 6. Files here

| File | What it is |
|---|---|
| `report.md` | this report |
| `run-final-review-regressions.log`, `run-publication-restart.log`, `run-verify-hash-accuracy.log` | verbatim stdout of the three mandated commands (all exit 0) |
| `negative-control.mjs` / `.log` / `.result.txt` | witness binding, guard-removal control, storage-failure controls, audit-guard controls |
| `causal-evidence.guard-removed.mjs` | copy of the shipped `dist` module with only the four-line guard removed, used by the load-bearing control |
| `fanout-control.mjs` / `.log` | durable-store fan-out regression control |
| `ledger-control.mjs` / `.log` | batch ledger accounting for the per-selector rerun |
| `lab-status-before.txt` | Lab `git status --porcelain` before my run |
