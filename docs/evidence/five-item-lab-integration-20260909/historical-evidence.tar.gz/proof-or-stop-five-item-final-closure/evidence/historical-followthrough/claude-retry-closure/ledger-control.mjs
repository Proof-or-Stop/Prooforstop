// Control E: the per-selector rerun must be accounted for in the signed batch
// ledger -- no undercount (hidden child) and no double count.
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const LAB = '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const m = await import(join(LAB, 'packages/main/dist/core/causal-evidence.js'));
const root = mkdtempSync(join(tmpdir(), 'claude-ledger-'));
try {
  const identity = { storyId: 'B-ledger-control', cwd: root, command: { executable: process.execPath, args: ['-e', 'opaque'] },
    inputs: { materialHash: 'm' }, storyFilesHash: 's', effectiveEnvironment: {}, runtimeVersion: process.version,
    toolVersion: 'test', selectorPolicy: m.DEFAULT_CAUSAL_SELECTOR_POLICY };
  const facts = { cli: { available: true, path: process.execPath }, worktree: { expected: root, actual: root },
    gitIndex: { readable: true, path: join(root, 'index'), contentDigest: 'i' },
    gitMaterial: { available: true, headHash: 'h', materialHash: 'm', storyFilesHash: 's' },
    writerLease: { available: true, valid: true }, providerCapability: { required: ['bounded-output'], available: ['bounded-output'] },
    resources: { required: { slots: 1 }, available: { slots: 1 } }, evidenceTarget: { writable: true, path: root },
    sideChannel: { available: true, maxOutputChars: 12000, maxProgressEvents: 1 } };
  const preflight = m.preflightCausalEvidence(facts, () => true, identity);
  const batch = m.createCausalEvidenceBatch();
  let calls = 0;
  const selectors = ['FIRST_MARK', 'SECOND_MARK', 'THIRD_MARK'];
  await Promise.all(selectors.map(selector => m.executeCausalEvidence({
    identity, preflight, batch, revalidateBeforeRun: () => true, selector,
    run: async () => { calls++; await new Promise(r => setTimeout(r, 5)); return { code: 0, output: selectors.join(' ') + 'x'.repeat(20000) }; } })));
  const attempts = batch.ledger.executions.reduce((n, e) => n + e.executionAttempts, 0);
  assert.ok(m.verifyCausalEvidenceLedger(batch.ledger), 'ledger must verify');
  assert.equal(batch.ledger.intentCount, 3);
  assert.equal(attempts, calls, 'recorded executionAttempts must equal actual child runs');
  const metrics = m.deriveCausalMetrics(batch.ledger);
  console.log(`NC-OK LEDGER-HONEST intents=3 actualChildren=${calls} recordedAttempts=${attempts} entries=${batch.ledger.executions.length} metrics=${JSON.stringify(metrics)}`);
  console.log('CLAUDE_LEDGER_CONTROL_GREEN');
} finally { rmSync(root, { recursive: true, force: true }); }
