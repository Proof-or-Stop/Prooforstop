这是可复验的本地 Lab 候选包。最终结论见 report.md，完整数据在 evidence/。它没有合入用户项目的 main，也不是 Story DONE 或发布版本。

先在解包目录执行 `shasum -a 256 -c SHA256SUMS`，再查看 verification.json。外部同目录 package-verification.json 另外记录压缩包本身的摘要和解包结果。原始失败和较慢结果保留；Claude 早期报告中的错误归因以 claude-contract-addendum/report.md 更正为准。

candidate.bundle 是相对 cf21df09c273074d7aa3227a5f436c6f5badf47a 的增量包，需要已有基线对象。candidate.patch 是相同基线到最终候选的完整补丁；两者任选一种，不要重复叠加。

复验优先使用已保留的 Lab：/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908。先阅读 REPRODUCE.md；不要在正在运行验证时重新构建。验证命令将写入自己的临时实验目录，Graph 资源恢复用例会临时移动该 Lab 的构建物并恢复，因此不得与构建或其他 Graph 消费者并发。

如需从包重建，使用一个全新的独立克隆，绝不把补丁应用到原项目 main：

```sh
# 以下变量分别指向已解包的绝对路径、一个新建独立克隆目录。
# 示例目录必须尚不存在。所有 git 写操作都限于这个新克隆。
proof_package=/absolute/path/proof-or-stop-five-item-followthrough
proof_repro=/tmp/proof-or-stop-five-item-private-repro
 git clone --no-hardlinks /Users/jek/Documents/GitHub/Prooforstop "$proof_repro"
 git -C "$proof_repro" bundle verify "$proof_package/candidate.bundle"
 git -C "$proof_repro" fetch "$proof_package/candidate.bundle" HEAD
 git -C "$proof_repro" switch -C main FETCH_HEAD
```

这里 main 仅是新独立克隆的本地分支，用于满足仓库 CLI 的工作区布局判定；原项目的 refs、工作区及 main 不会被这些命令改动。随后仅在新克隆安装依赖，按 REPRODUCE.md 构建 main/utils、Lab 扩展和需要的 Graph 模块，运行定向命令。不要复用原 Lab 的绝对路径 pin 启动器到新克隆；运行时路径及依赖变化必须重新生成自己的实现身份记录。

包内 134 条资源对照有每组 6 条失败，不能按全套 PASS 解读。默认 retired-authority 保护入口仍受基线提示词指纹问题阻塞；Graph 限定证明的 14 个反例通过不替代它。不要执行 release、finish、push 或关闭检查来取得绿色结果。
