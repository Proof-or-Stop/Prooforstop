import assert from 'node:assert/strict';
import fs from 'node:fs';
import {spawn,execFileSync} from 'node:child_process';
import {createServer} from 'node:net';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
const lab='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const art=path.dirname(new URL(import.meta.url).pathname),out=path.join(art,'graph-readiness-timing');fs.mkdirSync(out,{recursive:true});
const {StoryStore}=await import(lab+'/packages/main/dist/core/store.js');
const before=fs.readFileSync(path.join(art,'graph-missing-assets-before.mjs'),'utf8');
// Baseline assertions/timer remain unchanged. Restrict its cleanup to this private
// verifier's process group so the historical global PID heuristic cannot kill others.
const safeBefore=before.replace('const leaked = listeners();',`const leaked = listeners().filter(pid => { try { return Number(execFileSync('ps',['-p',String(pid),'-o','pgid='],{encoding:'utf8'}).trim()) === process.pid; } catch { return false; } });`);
assert.notEqual(before,safeBefore);fs.writeFileSync(path.join(out,'baseline-ownership-only-adjustment.mjs'),safeBefore);
const rows=[];
for(let pair=1;pair<=2;pair++)for(const mode of pair%2?['RED','GREEN']:['GREEN','RED']){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'graph-ready-bench-'));
 try {
  fs.mkdirSync(path.join(root,'packages'),{recursive:true});fs.cpSync(lab+'/packages/graph',path.join(root,'packages/graph'),{recursive:true});
  fs.mkdirSync(path.join(root,'bin'));fs.symlinkSync(lab+'/bin/proof-or-stop.js',path.join(root,'bin/proof-or-stop.js'));
  fs.writeFileSync(path.join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  const store=new StoryStore(root);store.writeStory('B-timing',{storyId:'B-timing',name:'Graph readiness timing',title:'Equal client recovery coverage',description:'Private timing fixture',type:'chore',phase:'DEV',priority:'medium',createdAt:new Date().toISOString()});store.writeChecklist('B-timing',{items:[]});execFileSync('git',['init','-q'],{cwd:root});
  const verifier=path.join(root,'packages/graph/scripts/verify-missing-assets-fail.mjs');if(mode==='RED')fs.writeFileSync(verifier,safeBefore);
  const reserve=createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));const port=reserve.address().port;await new Promise(r=>reserve.close(r));
  const start=performance.now();const child=spawn(process.execPath,[verifier],{cwd:root,detached:true,env:{...process.env,GRAPH_VERIFY_PORT:String(mode==='RED'?port:0)},stdio:['ignore','pipe','pipe']});
  let log='';child.stdout.on('data',x=>log+=x);child.stderr.on('data',x=>log+=x);
  const timer=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch(e){if(e.code!=='ESRCH')throw e;}},150000);
  const result=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}));}).finally(()=>clearTimeout(timer));
  fs.writeFileSync(path.join(out,`${pair}-${mode}.log`),log);rows.push({pair,mode,elapsedMs:performance.now()-start,...result,coverage:'two missing-client recoveries, complete asset assertions and live HTTP; baseline first pass uses historical timeout',scriptSha256:createHash('sha256').update(fs.readFileSync(verifier)).digest('hex')});
  fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({rows,baselineSafetyAdjustment:'Only limit historical listener cleanup to the private verifier process group; no assertion or 60-second timeout removed.',limitations:['Two alternating pairs on one host, not all validation or Story delivery time.','Private fixture contains one Story; sources and browser assets are unchanged between modes.','Port reservation is released before historical bind; collision would fail and be retained, not count as improvement.']},null,2));
  assert.equal(result.code,0,log);assert.match(log,/MISSING_ASSETS_HANDLED_OK/);console.log(mode,pair,rows.at(-1).elapsedMs);
 } finally {fs.rmSync(root,{recursive:true,force:true});fs.rmSync(path.join(os.homedir(),'.cache/proof-or-stop-graph',path.basename(root)+'-'+createHash('sha256').update(root).digest('hex').slice(0,12)),{recursive:true,force:true});}
}
