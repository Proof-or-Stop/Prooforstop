from pathlib import Path
import subprocess,tempfile,shutil,os,json,time,hashlib
art=Path(__file__).resolve().parent
lab=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908')
main=Path('/Users/jek/Documents/GitHub/Prooforstop')
base='cf21df09c273074d7aa3227a5f436c6f5badf47a'
out=art/'baseline-failure-controls';out.mkdir(exist_ok=True)
root=Path(tempfile.mkdtemp(prefix='five-item-baseline-controls-'))/'repo'
subprocess.run(['git','clone','--shared','--no-checkout',str(main),str(root)],check=True,capture_output=True)
subprocess.run(['git','checkout','--detach',base],cwd=root,check=True,capture_output=True)
(root/'node_modules').symlink_to(lab/'node_modules',target_is_directory=True)
for package in ['utils','lab']:
 source=lab/'packages'/package/'dist';dest=root/'packages'/package/'dist'
 if source.exists():shutil.copytree(source,dest)
with (out/'build.log').open('w') as log:r=subprocess.run(['npm','--prefix','packages/main','run','build'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,'baseline build failure'
manifest={'baselineCommit':base,'root':str(root),'node':subprocess.check_output(['node','--version'],text=True).strip(),'note':'Separate clone, exact committed base source, separately compiled main dist, read-only dependency symlink and independent copies of unchanged utils/lab dist. No main or retained Lab source/dist write. All fixtures are private to the invoked suites.'}
rows=[]
for name in ['proofstory-acceptance-rollout-smoke','proofstory-acceptance-basis-smoke','cli-surface-smoke','validation-tier-planner-smoke','validation-protocol-smoke']:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(['node','packages/main/dist/tasks/'+name+'.js']+(['--issuer-mutations'] if name=='proofstory-acceptance-rollout-smoke' else []),cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=360)
 rows.append({'test':name,'code':r.returncode,'elapsedMs':(time.monotonic()-start)*1000})
 (out/'results.json').write_text(json.dumps({'manifest':manifest,'rows':rows},indent=2)+'\n');print(name,r.returncode,flush=True)
print('BASELINE_CONTROLS_COMPLETE',flush=True)
