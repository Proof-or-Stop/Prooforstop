# Independent verification — graph OS-assigned port repair

- Worktree: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`
- Fix commit under review: `cb6e0899b9` ("fix: verify graph readiness with owned OS-assigned ports")
- Target test: `d94e84c375` (`experiments/five-item-proof/graph-ephemeral.mjs`)
- Date: 2026-09-09, platform darwin 25.6.0, Node v26.8.1
- Logs in this directory: `graph-ephemeral.log`, `graph-missing-control.log`, `verify-json-no-listener.log`, `observer-positive-control.log`

## Verdict

No regression found in the reviewed commit. Every command I was asked to run exited 0,
and each of the five claimed properties is backed by code I read in the commit, not only
by the passing exit status. Two coverage observations and two low-severity robustness
notes are listed below; none is a proven bug.

## Commands actually run (exit codes as observed)

| Command | Exit | Output |
| --- | --- | --- |
| `node experiments/five-item-proof/graph-ephemeral.mjs` | **0** | `ACTUAL_CLI_EPHEMERAL_PORTS_GREEN` |
| `node experiments/five-item-proof/graph-missing-control.mjs` | **0** | `GRAPH_MISSING_ASSETS_REFUSED_BEFORE_LISTEN` |
| `node packages/graph/scripts/verify-json-no-listener.mjs` | **0** | `--json returned 414 stories and exited without serving` / `JSON_NO_LISTENER_OK` |

Extra check I ran (my own instrument positive control, see below): exit 0, one recorded
listen from an inherited grandchild process.

Not run, per instruction: `packages/graph/scripts/verify-missing-assets-fail.mjs`
(asset recovery) — inspected statically instead, with the pre-existing
`../graph-recovery-check.log` as the recorded run.

## Property-by-property findings

### 1. OS-bound reported ports — CONFIRMED

`packages/graph/src/io/http.ts:57` — `startServer` returns `Promise<http.Server>`, a real
`http.Server`, so `address()` in the handler is the kernel-assigned address, not an echo of
the request. `packages/main/src/handlers/graph.ts:583-586` reads `server.address()` and
overwrites `listeningPort`; if the result is not an integer in `1..65535` it closes the
server and throws `server did not report a usable bound port`, so the failure mode is a
refusal rather than an unusable URL. Both the announced URL and the heartbeat line use
`listeningPort` (`graph.ts:607-608`, `618`, `642`), so there is no second code path that
could still print the requested port.

The RED state is genuine rather than asserted: before this commit the URL was built from
`args.port ?? GRAPH_DEFAULT_PORT`, so `--port=0` announced `http://localhost:0/`. The
recorded red run (`../graph-ephemeral-red.log`) shows exactly that — `AssertionError
EPHEMERAL_PORT_NOT_REPORTED`, `actual: '0'`.

The target test does more than check a nonzero number: it fetches `api/status` on the
announced URL, asserts `status.root` equals the private fixture root and `stories === 1`
(so the port is not merely nonzero but reaches *this* server, not a stray one), asserts the
body is an HTML document, and asserts two concurrently launched servers receive *distinct*
ports.

### 2. Caller process-group ownership — CONFIRMED

`packages/graph/scripts/graph-process.mjs:5` spawns with `detached: process.platform !==
'win32'`, which makes the child a process-group leader; `graph-process.mjs:10` signals
`process.kill(-child.pid, …)` on POSIX and falls back to `child.kill` on win32. The negated
pid therefore reaches only the group the verifier itself created — which is what makes the
nested `npm run build` grandchild reachable — and cannot reach an unrelated holder of the
same port. `ESRCH` is swallowed, other errors rethrown. The same shape is used in the target
test (`graph-ephemeral.mjs:13`). Escalation is SIGTERM, then SIGKILL after 3s.

Empirically after my three runs: no `proof-or-stop.js graph` processes remained, no
`graph-port-fixture-*` / `graph-no-assets-*` temp roots remained, and the worktree was clean
apart from a pre-existing untracked `AGENTS.override.md`.

This also removes the old approach's real weakness, which the deleted comments in
`verify-missing-assets-fail.mjs` documented: `lsof -ti:<port>` plus a `ps` command-line
match to guess ownership, which had already produced a false hit on Google Chrome.

### 3. Complete-served-HTML assertions preserved — CONFIRMED, and strengthened

Comparing `git show cb6e0899b9^:packages/graph/scripts/verify-missing-assets-fail.mjs`
against the new file, every content assertion survives the rewrite:

| Old assertion | New location |
| --- | --- |
| doctype present | `verify-missing-assets-fail.mjs:20` |
| contains `openStoryDossier` | `:20` |
| `length >= 100_000` | `:21` |
| `assets/d3.min.js` exists | `:22` |
| asset was actually rebuilt before serving | `:18` |
| served body is a real client page (`>1000` bytes, has markup) | `:23`, strengthened |

The last row is a strict strengthening: the old check accepted any response over 1000 bytes
containing `<script|div|body`; the new one asserts `html === built`, byte equality between
what the live server returned and the rebuilt file, plus `status.root === repo` so the bytes
came from this repository's server.

### 4. Exact original-asset restoration — CONFIRMED, and strengthened

`verify-missing-assets-fail.mjs:11-13` snapshots the original bytes before the rename and
refuses to start if `.app.html.verify-stash` or `app.html.rebuilt-probe` already exists
(an interrupted earlier run). The old script had no such guard and would have overwritten a
surviving true original with a rebuilt copy. The `finally` at `:32-35` removes the probe
copy and restores by a single atomic `renameSync`, and `:36` asserts `deepEqual` against
the pre-run bytes. The two-pass loop parks the pass-1 rebuild under its own path
(`:30`), never onto `stash`, so the true original is never the thing that gets discarded.

### 5. No JSON listeners, and fail-before-listen negative control — CONFIRMED

`verify-json-no-listener.mjs` patches `net.Server.prototype.listen` via `NODE_OPTIONS
--import`, which reaches inherited children and unref'ed servers, delegates to the original
with `Reflect.apply`, asserts exit 0, asserts the listen log file was never created, and
asserts the log never contains `graph serving http:`. `graph-missing-control.mjs` uses the
same observer against a private fixture whose `app.html` is deleted and whose build script
is stubbed to a no-op success, then requires a nonzero status, `signal === null` (a real
refusal, not a timeout kill), the message naming `required output is missing`, `app.html`
and `npm --prefix …/packages/graph run build`, and zero listen calls.

I validated the instrument rather than trusting it. Reproducing the observer generation
verbatim and setting the same `NODE_OPTIONS`, a `net.createServer().listen(0)` in a
*grandchild* process was recorded (`observer-positive-control.log`: `{"pid":74070}`, the
grandchild's pid). Separately, two malformed observers I generated by mistake caused Node to
exit nonzero at startup — so a broken instrument makes these verifiers fail loudly rather
than silently pass their "no listener" assertion.

## Observations (not defects)

1. **Refusal coverage left the packaged check suite.** The old
   `verify-missing-assets-fail.mjs` carried both branches: recovery *and* refuse-before-listen
   when recovery is impossible. The new file covers recovery only; the refusal branch now
   lives solely in `experiments/five-item-proof/graph-missing-control.mjs`, which
   `packages/graph/package.json`'s `check` script does not invoke (it runs the four
   `scripts/verify-*.mjs` entries only). The refusal path is verified today because the
   experiment is run by hand; it is not verified by `npm run check`. Missing coverage, not a
   bug — and arguably the better home, since the control needs a fixture whose build is
   stubbed to fail.
2. **The byte-identity assertion sits outside the `finally`.**
   `packages/graph/scripts/verify-missing-assets-fail.mjs:36` runs only when the loop
   succeeded; if a probe throws, restoration still happens but identity is never asserted.
   The restore is a rename of a file nothing ever wrote to, so identity holds by
   construction. Cosmetic.
3. **`stop()` with an undefined pid.** `packages/graph/scripts/graph-process.mjs:10`
   computes `-child.pid`; on a spawn failure `child.pid` is `undefined`, so
   `process.kill(NaN, …)` throws a range error that is not `ESRCH` and would mask the
   original spawn error in `startGraph`'s catch. Unreachable in practice — the executable is
   `process.execPath`.
4. Doc text added in `docs/validation-performance.md:220-230` matches what the code does,
   including the explicit non-claim that these checks do not authorize shared access during a
   local rebuild.

## Limitations of this audit

- Single run per command, single platform (darwin). The win32 branches
  (`child.kill` instead of the negated-pid group signal) were read, never executed.
- I did not run graph asset recovery (`verify-missing-assets-fail.mjs`) as instructed, so my
  evidence for properties 3 and 4 is static reading of the committed script plus the
  pre-existing `../graph-recovery-check.log` (`Recovery 1 served 497517 bytes from
  http://localhost:56607/`, `Recovery 2 … :56611`, `MISSING_ASSETS_HANDLED_OK`) — two
  distinct OS-assigned ports, consistent with the fix. I did not reproduce those bytes.
- `verify-serves.mjs` was outside my run list; read statically only. Its recorded run is
  `../graph-serves-check.log` (`SERVES_OK`).
- I ran against the already-built `packages/main/dist`; I did not rebuild. The pre-fix RED
  behaviour is established by static reading of the pre-commit handler plus the recorded
  `../graph-ephemeral-red.log`, not by a rebuild-and-rerun on my part.
- Scope was commit `cb6e0899b9` and test `d94e84c375` only. Root resource declarations,
  other Stories, and the wider repository were not reviewed.
- No source, Stories, or main-branch artifacts were modified; all writes went to this
  directory.
