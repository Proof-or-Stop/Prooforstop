// Does a NUL-bearing selectorProbe survive the real on-disk store round-trip,
// stay verifiable, keep reuse, and still refuse the synthetic '<redacted>' selector?
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const LAB='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const {executeCausalEvidence,preflightCausalEvidence,verifyCausalEvidenceReceipt,DEFAULT_CAUSAL_SELECTOR_POLICY}
  = await import('file://'+join(LAB,'packages/main/dist/core/causal-evidence.js'));
const {StoryStore}=await import('file://'+join(LAB,'packages/main/dist/core/store.js'));
const root=mkdtempSync(join(tmpdir(),'nul-probe-'));
try{
 const store=new StoryStore(root),storyId='B-nulprobe';
 store.writeStory(storyId,{storyId,name:'nul-probe',title:'t',description:'d',type:'chore',phase:'DEV',priority:'medium',createdAt:new Date().toISOString(),startedAt:new Date().toISOString(),endedAt:null});
 const identity={storyId,cwd:root,command:{executable:process.execPath,args:['-e','x']},inputs:{materialHash:'m'},storyFilesHash:'s',effectiveEnvironment:{PROBE_SECRET_TOKEN:'sekret-42'},runtimeVersion:process.version,toolVersion:'test',selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
 const facts={cli:{available:true,path:process.execPath},worktree:{expected:root,actual:root},gitIndex:{readable:true,path:join(root,'index'),contentDigest:'i'},gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},writerLease:{available:true,valid:true},providerCapability:{required:['bounded-output'],available:['bounded-output']},resources:{required:{slots:1},available:{slots:1}},evidenceTarget:{writable:true,path:root},sideChannel:{available:true,maxOutputChars:12000,maxProgressEvents:1}};
 const preflight=preflightCausalEvidence(facts,()=>true,identity);
 const counter={n:0};
 const output='BEGIN sekret-42 REAL_MARKER END';
 const exec=sel=>executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector:sel,run:async()=>{counter.n++;return{code:0,output};}});
 const a=await exec('REAL_MARKER');
 const stored=store.readCausalEvidenceReceipt(storyId,a.receipt.executionKey);
 const b=await exec('REAL_MARKER');
 const synthetic=await executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector:'<redacted>',run:async()=>{counter.n++;return{code:0,output};}});
 console.log(JSON.stringify({
  firstVerdict:a.verdict.result, reuseVerdict:b.verdict.result, runInvocationsAfterReuse:counter.n,
  reusable:a.receipt.reusable, storedFound:!!stored,
  storedProbeHasNUL: typeof stored?.selectorProbe==='string' && stored.selectorProbe.includes('\0'),
  storedProbeEqualsLive: stored?.selectorProbe===a.receipt.selectorProbe,
  storedHashMatches: stored?.receiptHash===a.receipt.receiptHash,
  storedVerifies: stored?verifyCausalEvidenceReceipt(stored):null,
  secretInProbe: (stored?.selectorProbe??'').includes('sekret-42') || (stored?.outputProbe??'').includes('sekret-42'),
  syntheticRedactedSelectorVerdict: synthetic.verdict.result,
  totalRunInvocations: counter.n,
 },null,2));
}finally{rmSync(root,{recursive:true,force:true});}
