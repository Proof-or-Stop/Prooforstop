// Private negative control (not in Lab tree): does the fallback signed witness
// preserve cross-request zero-rerun reuse, and stay non-reusable/unforgeable?
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const LAB='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const {executeCausalEvidence,preflightCausalEvidence,verifyCausalEvidenceReceipt,DEFAULT_CAUSAL_SELECTOR_POLICY,CAUSAL_SELECTOR_OUTPUT_BOUND_BYTES}
  = await import('file://'+join(LAB,'packages/main/dist/core/causal-evidence.js'));
const root=mkdtempSync(join(tmpdir(),'witness-reuse-control-'));
const out=[];
try{
 const identity={storyId:'B-witness-control',cwd:root,command:{executable:process.execPath,args:['-e','control']},inputs:{materialHash:'m'},storyFilesHash:'s',effectiveEnvironment:{},runtimeVersion:process.version,toolVersion:'test',selectorPolicy:DEFAULT_CAUSAL_SELECTOR_POLICY};
 const facts={cli:{available:true,path:process.execPath},worktree:{expected:root,actual:root},gitIndex:{readable:true,path:join(root,'index'),contentDigest:'i'},gitMaterial:{available:true,headHash:'h',materialHash:'m',storyFilesHash:'s'},writerLease:{available:true,valid:true},providerCapability:{required:['bounded-output'],available:['bounded-output']},resources:{required:{slots:1},available:{slots:1}},evidenceTarget:{writable:true,path:root},sideChannel:{available:true,maxOutputChars:12000,maxProgressEvents:1}};
 const preflight=preflightCausalEvidence(facts,()=>true,identity);
 const capableStore=()=>{const d=new Map(),o=new Map();return{runs:0,readCausalEvidenceReceipt:(_s,k)=>d.get(k)??null,writeCausalEvidenceReceipt:(_s,r)=>d.set(r.executionKey,structuredClone(r)),writeCausalSelectorOutput:(_s,k,v)=>o.set(k,v),readCausalSelectorOutput:(_s,k)=>o.get(k),_objects:o};};
 const legacyStore=()=>{const d=new Map();return{readCausalEvidenceReceipt:(_s,k)=>d.get(k)??null,writeCausalEvidenceReceipt:(_s,r)=>d.set(r.executionKey,structuredClone(r))};};
 const exec=(store,output,selector,counter)=>executeCausalEvidence({identity,preflight,revalidateBeforeRun:()=>true,receiptStore:store,selector,run:async()=>{counter.n++;return{code:0,output};}});

 // Case A: exit-only (empty selector) with >12k output, capable store.
 {const st=capableStore(),c={n:0};
  const a=await exec(st,'z'.repeat(20000),'',c); const b=await exec(st,'z'.repeat(20000),'',c);
  out.push({case:'A_exit_only_long_output',verdicts:[a.verdict.result,b.verdict.result],runInvocations:c.n,
    reusable:a.receipt.reusable,hasWitness:!!a.receipt.selectorWitness,hasSelectorOutput:!!a.receipt.selectorOutput,
    objectsWritten:st._objects.size,receiptVerifies:verifyCausalEvidenceReceipt(a.receipt)});}

 // Case B: >1 MiB output with a fully capable store (ceiling fallback).
 {const st=capableStore(),c={n:0};const big='q'.repeat(2*1024*1024)+'REAL_END';
  const a=await exec(st,big,'REAL_END',c); const b=await exec(st,big,'REAL_END',c);
  out.push({case:'B_over_1MiB_capable_store',verdicts:[a.verdict.result,b.verdict.result],runInvocations:c.n,
    reusable:a.receipt.reusable,hasWitness:!!a.receipt.selectorWitness,hasSelectorOutput:!!a.receipt.selectorOutput,
    objectsWritten:st._objects.size,receiptVerifies:verifyCausalEvidenceReceipt(a.receipt),bound:CAUSAL_SELECTOR_OUTPUT_BOUND_BYTES});}

 // Case C: legacy store lacking both complete-output methods, >12k output.
 {const st=legacyStore(),c={n:0};const big='w'.repeat(20000)+'REAL_END';
  const a=await exec(st,big,'REAL_END',c); const b=await exec(st,big,'REAL_END',c);
  out.push({case:'C_legacy_store_long_output',verdicts:[a.verdict.result,b.verdict.result],runInvocations:c.n,
    reusable:a.receipt.reusable,hasWitness:!!a.receipt.selectorWitness,receiptVerifies:verifyCausalEvidenceReceipt(a.receipt)});}

 // Case D: forgery attempts against the witness receipt.
 {const st=legacyStore(),c={n:0};const big='w'.repeat(20000)+'REAL_END';
  const a=await exec(st,big,'REAL_END',c);
  const forgedReusable=structuredClone(a.receipt);forgedReusable.reusable=true;
  const forgedDual=structuredClone(a.receipt);forgedDual.selectorOutput={digest:'a'.repeat(64),length:5};
  const forgedDigest=structuredClone(a.receipt);forgedDigest.selectorWitness={...forgedDigest.selectorWitness,selectorDigest:'b'.repeat(64)};
  out.push({case:'D_witness_forgery',originalVerifies:verifyCausalEvidenceReceipt(a.receipt),
    reusableFlipVerifies:verifyCausalEvidenceReceipt(forgedReusable),
    witnessPlusOutputVerifies:verifyCausalEvidenceReceipt(forgedDual),
    wrongDigestVerifies:verifyCausalEvidenceReceipt(forgedDigest)});}

 // Case E: control - short output keeps reuse (baseline that A/B/C are not universal).
 {const st=capableStore(),c={n:0};
  const a=await exec(st,'SHORT_OK','SHORT_OK',c); const b=await exec(st,'SHORT_OK','SHORT_OK',c);
  out.push({case:'E_short_output_baseline',verdicts:[a.verdict.result,b.verdict.result],runInvocations:c.n,reusable:a.receipt.reusable,hasWitness:!!a.receipt.selectorWitness});}

 console.log(JSON.stringify(out,null,2));
 assert.equal(out.at(-1).runInvocations,1,'BASELINE_REUSE_BROKEN');
}finally{rmSync(root,{recursive:true,force:true});}
