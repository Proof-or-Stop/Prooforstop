# Independent audit — dabf7cf494 and af82427f78

Reviewer: independent Claude run, 2026-09-09. Read-only against the Lab worktree
`/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`.
Nothing in the Lab was modified; all writes are under
`/Users/jek/.codex/artifacts/proof-or-stop-five-item-followthrough-20260909/claude-retention-identity/`.
No builds, no agents, no Story mutation. The prebuilt `packages/main/dist` was used as-is.

Two evidence classes are kept separate throughout:
**[EXEC]** = a command I ran, with its exit code; **[READ]** = source/diff analysis only.

---

## 1. Executed tools and exits

Each tool ran with its own absolute `FIVE_ITEM_PROOF_OUTPUT` under `verify/`.

| Tool | `FIVE_ITEM_PROOF_OUTPUT` | Exit | stdout marker | stderr |
|---|---|---|---|---|
| `experiments/five-item-proof/evidence-implementation.mjs` | `verify/evidence-implementation` | **0** | `EVIDENCE_HANDLER_IMPLEMENTATION_GREEN` | empty |
| `experiments/five-item-proof/output-retention-contract.mjs` | `verify/output-retention-contract` | **0** | `OUTPUT_RETENTION_COMPATIBILITY_BOUND_AND_SYNTHETIC_MARKER_GREEN` | empty |
| `experiments/five-item-proof/output-artifact-policy.mjs` | `verify/output-artifact-policy` | **0** | `SELECTOR_EVIDENCE_RETENTION_POLICY_GREEN` | empty |
| `experiments/five-item-proof/complete-output-adversarial.mjs` | `verify/complete-output-adversarial` | **0** | `OUTPUT_TAMPER_MISSING_ABSENT_REDACTION_GREEN` + `COMPLETE_OUTPUT_SELECTOR_AND_FANOUT_GREEN` | empty |

Added negative controls (private fixtures under `extra-negative-control/`, importing the
Lab `dist` read-only; nothing written into the Lab tree):

| Control | Exit | Log |
|---|---|---|
| `witness-reuse-control.mjs` — fallback-witness reuse, ceiling, legacy store, forgery | **0** | `extra-negative-control/control.log` |
| `nul-probe-roundtrip.mjs` — NUL `selectorProbe` through the real on-disk `StoryStore` | **0** | `extra-negative-control/nul-probe.log` |

Measured counters from my own run (not the prior run's):

- `evidence-implementation` run modes `first/same/changed/restored` → command executions
  `1/1/2/2`; handler-reported `commandExecutions` = `1/0/1/0`.
- `complete-output-adversarial` `first/second` → executions `1/1`; `commandExecutions` = `1/0`;
  `recoveryCommandExecutions` = 0. Fault injections returned exit 70 with
  `causal_selector_output_invalid` (tamper, missing) and `receipt_selector_absent` (absent),
  with no rerun and no evidence mutation.

The prior run's four folders contain the same green markers, so I did not re-derive its
findings. One apparent discrepancy in its artifacts resolves benignly: `results.json`
`evidence.timestamp` reads `01:26` while the folder mtimes read `02:26` — those are the same
instant (evidence stamps UTC, filesystem shows local BST +01:00), not a stale or canned blob.

---

## 2. Review questions

### 2.1 Does a same-version bootstrap change invalidate checklist reuse? — Yes [EXEC]

`enforceAndStampEvidence` records `executionImplementationIdentity().digest` into the receipt
identity inputs and checks it at three points (pre-launch via `revalidateBeforeRun`, after the
child returns, and in the stale-refresh raw-process fanout); canonical import compares
`recordedInputs.implementationDigest` against the current digest before reusing
(`packages/main/src/handlers/checklist.ts:1149,1163,1191,1195,1997,3149,3195`). [READ]

Executed: appending a comment to `runtime/scripts/build-lock-target.mjs` — same package
version, different bytes — moved the `changed` mode to a fresh execution (executions 1→2,
`commandExecutions=1`); restoring the original bytes returned to reuse (`commandExecutions=0`,
execution count unchanged at 2). Version equality did not carry a receipt across differing
implementation bytes.

### 2.2 Does optional storage still poison reuse? — No [EXEC]

Before af82427f78, a store lacking the complete-output methods could still mint a
`reusable: true` receipt advertising a `selectorOutput` whose bytes were never persisted; a
later process then refused with `causal_selector_output_invalid`. Now `durableOutput` requires
both store methods, and any long output without a durable object is marked with a
`selectorWitness`, which forces `reusable: false` in both the producer and
`verifyCausalEvidenceReceipt` (`causal-evidence.ts:562,750,755,777`). [READ]

Control C [EXEC]: legacy store, 20 000-char output — verdicts `pass`/`pass`, receipt verifies,
`reusable: false`, no refusal. The poisoned-address failure mode is gone. Its replacement is a
re-execution (see §3.2), not a refusal.

### 2.3 Does >1 MiB output still prove its own selector? — Yes, via a non-reusable witness [EXEC]

Control B: 2 MiB output with a fully capable store → verdict `pass` for the real selector,
`selectorWitness` present, `selectorOutput` absent, **0** output objects written,
`verifyCausalEvidenceReceipt` = true, ceiling `CAUSAL_SELECTOR_OUTPUT_BOUND_BYTES` = 1 048 576.
`output-retention-contract` independently asserts `writtenBytes <= 1 MiB` on the same shape.

Control D [EXEC] — forgery of the witness receipt is rejected by `verifyCausalEvidenceReceipt`:
flipping `reusable` to true → false; adding a `selectorOutput` beside the witness → false;
substituting a different `selectorDigest` → false. A witness proves exactly one selector: a
different selector's digest will not match, so the witness cannot be repurposed.

### 2.4 Does the empty-selector proof avoid output reads? — Yes [EXEC]

`selectorVerdict` short-circuits `selector.length === 0` to `receipt.status === 'pass'` before
any read path (`causal-evidence.ts:662`). [READ] `output-retention-contract` runs two
exit-only executions against a store whose `readCausalSelectorOutput` throws, and asserts
`outputReads === 0`. Passed. [EXEC]

### 2.5 Can synthetic redaction text prove an absent raw selector? — No, for new receipts [EXEC]

`REDACTED` is literally `'<redacted>'` (`causal-evidence.ts:393`), so the placeholder is a
plausible selector string. Matching text is now built with `'\0'` as the replacement and
selectors containing NUL are rejected outright; the display copy substitutes `<redacted>` only
after the matching copy is fixed. [READ]

Executed twice, in two ways: `output-retention-contract`'s in-memory case (selector
`<redacted>` against output containing only the secret → `fail`), and my
`nul-probe-roundtrip` control against the **real on-disk `StoryStore`**, where the
`<redacted>` request reused the stored receipt and returned `fail` with
`totalRunInvocations = 1` — i.e. refused cross-request, from disk, without a rerun.

That control also closed a gap none of the four tools covered: a NUL-bearing `selectorProbe`
round-trips through real JSON storage intact (`storedProbeEqualsLive: true`,
`storedHashMatches: true`, `storedVerifies: true`), the raw secret appears in neither
`selectorProbe` nor `outputProbe`, and reuse is preserved.

### 2.6 Are output artifacts treated as disposable? — No [EXEC]

`output-artifact-policy.mjs` passes for all three story-directory prefixes
(`.proof-or-stop`, `.lattice`, `docs`): `isVolatileRuntimeArtifactPath` false,
`isRepairableTrackedRuntimeArtifactPath` false, `isMaterialExcludedRuntimeArtifactPath` true.
This matches the new `causal-complete-selector-output` registry entry
(`volatile: false`, `repairableTrackedArtifact: false`, `materialHash: 'exclude'`). [READ]
The tool only checks the three prefixes it enumerates; other layouts are untested.

---

## 3. Defects and costs

### 3.1 [Defect] Exit-only checks with >12 000 chars of output lost reuse entirely

`durableOutput` requires `args.selector.length > 0` (`causal-evidence.ts:750`). An exit-only
check (empty selector) whose output exceeds `CAUSAL_MAX_OUTPUT_CHARS` therefore falls to
`selectorWitness`, which forces `reusable: false`.

Control A [EXEC]: capable store, empty selector, 20 000-char output → verdicts `pass`/`pass`,
`reusable: false`, 0 objects written, **`runInvocations: 2`**. Every repeat re-executes the
command. Control E confirms this is not universal: short output keeps `reusable: true` and
`runInvocations: 1`.

Before af82427f78 this same case produced a `selectorOutput` and a reusable receipt, so this
is a behavioural narrowing introduced by the repair, not a pre-existing limit. The stated
safety goal — "Exit-only checks never read selector objects" — is already fully achieved by
the `selector.length === 0` short-circuit in `selectorVerdict` (§2.4), independently of
whether the bytes were stored. Gating durable storage on selector length is therefore broader
than the property it protects: it trades reuse of exit-only long-output checks for avoided
storage. That may be a deliberate trade, but `docs/validation-performance.md` discloses only
that "another selector or a publication recovery request may need a fresh execution"; it does
not say that exit-only checks over the char limit are never reusable at all. Either narrow the
condition or state this case in the doc.

### 3.2 [Candour, as requested] Fallback witnesses give no cross-request zero-rerun publication recovery

This is the point most at risk of being read as a win. It is not one. In all three fallback
shapes — exit-only long output (A), over-ceiling output (B), legacy store (C) — the receipt is
`reusable: false`, and `executeCausalEvidence` deliberately does not store non-reusable
receipts, so `createChecklistHandlers`' reuse gate (`checklist.ts:2037`) never finds one.
Measured consequence: **2 command invocations for 2 requests** in every fallback case, versus 1
for the durable path. A publishing process that exits after producing a witness receipt cannot
have its work recovered by a later process; the later process runs the command again.

What the fallback buys is correctness — no poisoned address, no unbounded Story file, no
forgeable reuse — not recovery and not speed. None of the guards audited here should be
recorded as a time saving; two of them (3.1, 3.2) cost re-executions.

### 3.3 [Scope, as requested] Implementation binding does not unify running owner/reviewer sessions

dabf7cf494 binds each receipt to the implementation bytes of the process that produced it, and
refuses reuse across differing bytes. It contains no mechanism by which separately running
owner or reviewer sessions adopt a common CLI installation. Sessions on differing installations
simply do not reuse each other's receipts — they each re-execute. The doc's disclaimer is
accurate and should not be softened. The `evidence-implementation` fixture demonstrates binding
only within one fixture's copied runtime; it does not exercise two independently installed
sessions.

### 3.4 [Residual limitation, READ-only — not executed] Legacy receipts keep the synthetic-text weakness

`verifyCausalEvidenceReceipt` accepts a receipt with no `selectorOutput`, no `selectorProbe`
and no `selectorWitness` at `reusable: true`. For such a receipt, `selectorVerdict` falls
through to `readCausalSelectorOutput()` → `receipt.outputProbe`, and to the
`receipt.outputTail.includes(selector)` branch (`causal-evidence.ts:647,665-666`). Both of
those strings are built from the **display** copy, in which redactions are the literal text
`<redacted>`. So a pre-repair receipt can still be matched by the selector `<redacted>` even
though the command never printed it. This is the deliberate legacy-compatibility path and the
repair does not claim to fix it retroactively, but the §2.5 property holds only for receipts
minted after af82427f78. I did not execute this: constructing a valid legacy receipt requires
the signing authority, and forging one is out of scope. **Unresolved by execution.**

### 3.5 [Minor, READ-only] NUL in genuine command output causes safe false negatives

A selector containing NUL is rejected unconditionally, and NULs occurring naturally in raw
output are indistinguishable from redaction boundaries in the matching copy. Both push toward
`fail`/refusal rather than a false `pass`, so the direction is safe, but a command that
legitimately emits NUL bytes cannot have selectors matched across them.

---

## 4. Scope limits of this audit

- Only the two named commits and their directly necessary callers were inspected. I did not
  survey causal dependency APIs or graph code; `cb6e0899b9`/`d94e84c375` (graph port readiness)
  are out of scope and untouched.
- No build was run. All executed evidence is against the existing `packages/main/dist`. That
  dist does contain both repairs — `CAUSAL_SELECTOR_OUTPUT_BOUND_BYTES` imported at 1 048 576
  and `selectorWitness` behaviour was observed — but I did not verify dist is byte-current with
  every line of `src`.
- Timings in `results.json` are incidental; I made no performance claim and measured none.
- The fixtures use synthetic Stories in temp directories. No real Story, main, source, config
  or dist file was modified. Both added controls live outside the Lab tree.
- §3.4 is analysis only. Everything in §2 and §3.1–3.2 is backed by an executed exit code.

## 5. Bottom line

Both repairs do what their commit messages claim, and every adversarial and forgery case I ran
refused correctly. The one substantive defect is §3.1: the selector-length condition on durable
storage is broader than the property it protects and silently removed reuse for exit-only
checks with long output — undisclosed in the doc. §3.2 and §3.3 are honest limits rather than
defects, but both are easy to misread as capabilities and should be stated as written.
