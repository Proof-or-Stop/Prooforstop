# Review observation disposition and measurement boundary

This register is owner analysis, not signed Story findings or a final certification.
All 120 prose observations from the first, extra and candidate waves remain in
`observations.json` with their source report and index. They overlap heavily and
are not 120 independently reproduced defects. The original role reports remain
available, including request-changes verdicts; no verdict is relabelled PASS.

| Observation family | Executed evidence / disposition | Limit |
|---|---|---|
| Successful middle-output selector lost by display truncation | RED at f3f69038ab; complete-output and tamper/missing/absent controls pass after4830880ffc and retention hardening | Complete output is bounded; fallback witnesses are non-reusable |
| Checklist same-version implementation changes reused old execution | RED at8b1f8248f8; actual four-process handler test passes afterdabf7cf494 | Existing unrelated sessions are not migrated; this is not hostile-host isolation |
| Exit-only verbose output lost reuse | Claude reproduced; RED8655495aa8 / GREENef11c14a10 plus independent Claude final-repairs controls | Above1MiB or legacy Store stillnon-reusable |
| Legacy display markers could prove output never emitted | Valid private signed legacy credential reproduces both redaction and gap cases; ef11c14a10 refuses both, keeps plain complete legacy | Conservative refusal can also reject genuinely printed marker text in a legacy receipt |
| Different selectors consume another follower's bounded witness | Reproduced in batch-retry-selector-precheck.log; RED e4301c5df9 / candidate89cccb38c1 passes all three actual printed selectors | Fallback may need a separate command per selector; no fabricated speed claim |
| A late subscriber starts a third command while a retry is active | Explicit promise-gated reproduction; RED e4301c5df9, candidate89cccb38c1 requires2calls | This proves the named late-subscriber path, not every distributed failure schedule |
| Complete-output publication fails after execution | Transient first-write fault now retries the same bytes,1child/2writes; permanent2write failure refuses | No guarantee of cross-process recovery after permanent storage failure or loss of unpersisted output |
| Empty-selector API semantics | Deliberate exit-only contract for shared validation; checklist first pin requires command+selector. Existing-pin corruption requires an actual authorized ingress before calling it a production bypass | No hostile on-disk Story mutation was admitted or claimed safe |
| Dependency rerun verifier does not bind an expected command | Preserved API concern; repository production consumer at handlers/certification-window.ts:269 supplies no rerunEvidence. Thus the supplied arbitrary-rerun admission example has no demonstrated production call path here | This is not a proof that the general exported API is complete or safe for every future caller |
| Artifact-selected trust root / partial current-identity helper | Preserved API concern; checklist canonical publication supplies live currentIdentity, expected material/story hashes and automatic implementation digest, and the target tests refuse mismatches | Basic signature verification alone is not a full admission decision; no blanket safety claim |
| Execution-ledger counters / stale receipt attribution | Preserved reporting concern. Performance experiments count actual child processes and external entry/exit times instead of trusting those counters | Rendered falseFresh=0 etc. are not used as evidence of complete defect recall or correctness |
| Secret heuristics, generic shell normalization, optional metadata, DAG identity details | Preserved broader observations, not experimentally adjudicated as part of these scoped repairs | Their absence from the repair diff must not be described as resolution |

The measured waves took275.895s(first),436.009s(extra on unchanged baseline),
296.997s(candidate), four independent Claude calls per wave. A common-input
workflow replay can attribute436.009s and four calls to the extra wave. It cannot
prove that skipping every such wave preserves defect discovery: the extra and
candidate reports produced real follow-up defects, including those fixed above.
Targeted repair verification continues without repeating every unrelated role.
No whole-Story lead-time or general defect-recall percentage follows from these
measurements. The candidate packet predates the final ef11/89cc corrections; the
independent scoped follow-up reports, not that old packet's verdict, verify them.
