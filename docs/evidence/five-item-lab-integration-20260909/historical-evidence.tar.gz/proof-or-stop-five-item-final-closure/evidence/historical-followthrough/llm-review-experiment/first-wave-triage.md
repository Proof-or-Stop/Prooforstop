# First-wave disposition (owner, pending independent check)

This is an experiment observation register, not Story findings or gate credentials.

Verified target defects: middle-output selector loss (`complete-output.mjs` RED at f3f69038ab); checklist same-version implementation reuse (`evidence-implementation.mjs` RED at 8b1f8248f8). All four independent Claude roles observed these two root causes in the real frozen source packet. Their reports remain verbatim.

Additional observations are not automatically repairs or new scope. Empty-selector acceptance is deliberate for exit-only shared validation; checklist pins reject empty selectors upstream. The packet omitted that upstream code, so the report is not a verified checklist bypass. Caller-selected trust roots and optional current-identity arguments require an actual gate exploit before claiming applicability; production checklist publication supplies live expected bindings, and host-owned signing keys are trusted. Orphan recovery verifies the exact requested key before promoting a signed receipt; after one orphan, the next request recovers before executing, so repeated normal index-write failure does not by itself establish two independently executed orphan PASS receipts. Tests must distinguish that from direct filesystem injection.

Potential bounded follow-ups requiring reproduction: batch retry crossing another process's successful single flight; failure ledger attribution; volatile preflight fields reducing reuse; receipt scan cost; overly broad redaction matching. These are preserved as observations, not erased, signed formal findings, or evidence that the two verified target repairs are complete. The extra RED wave will inspect unchanged code. Any additional applicable reproduced defect must enter the experiment result and cannot be silently dropped to improve the GREEN timing.

No claim of complete defect recall or whole-Story speedup follows from this review experiment.
