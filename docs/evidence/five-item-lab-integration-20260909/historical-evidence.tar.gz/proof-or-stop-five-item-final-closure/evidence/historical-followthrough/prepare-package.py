from pathlib import Path
import os,json,hashlib,shutil,subprocess,tempfile,tarfile
art=Path(__file__).resolve().parent
lab=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908')
base='cf21df09c273074d7aa3227a5f436c6f5badf47a'
stage=Path(tempfile.mkdtemp(prefix='five-item-followthrough-package-'))
payload=stage/'proof-or-stop-five-item-followthrough';payload.mkdir()
evidence=payload/'evidence';evidence.mkdir()
skipped=[];sanitized=[]
DROP=object()
def clean(x):
 if isinstance(x,dict):
  if x.get('type') in ['thinking','redacted_thinking','thinking_delta','signature_delta']:return DROP
  return {k:v2 for k,v in x.items() if k not in ['thinking','redacted_thinking'] and (v2:=clean(v)) is not DROP}
 if isinstance(x,list):return [v2 for v in x if (v2:=clean(v)) is not DROP]
 return x
for f in sorted(art.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(art)
 if f.name in ['continuation-notes.md','README-current-draft.md','package-verification.json'] or f.suffix in ['.tar','.gz','.bundle','.patch']:skipped.append(str(rel));continue
 dest=evidence/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if f.suffix=='.jsonl':
  lines=[]
  for n,line in enumerate(f.read_text().splitlines(),1):
   if not line.strip():continue
   try:value=clean(json.loads(line))
   except json.JSONDecodeError:raise RuntimeError('Cannot safely package non-JSON transcript line '+str(rel)+':'+str(n))
   if value is not DROP:lines.append(json.dumps(value,ensure_ascii=False))
  dest.write_text('\n'.join(lines)+'\n');sanitized.append(str(rel))
 elif f.suffix=='.json':
  try:value=clean(json.loads(f.read_text()))
  except (json.JSONDecodeError,UnicodeError):shutil.copy2(f,dest);continue
  if value is not DROP:dest.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
 else:shutil.copy2(f,dest)
assert (art/'claude-contract-addendum/report.md').is_file(), 'Final independent addendum missing'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab,text=True).strip()
with (payload/'candidate.patch').open('wb') as f:subprocess.run(['git','diff','--binary',base,head],cwd=lab,stdout=f,check=True)
subprocess.run(['git','bundle','create',str(payload/'candidate.bundle'),'HEAD','^'+base],cwd=lab,check=True)
bv=subprocess.run(['git','bundle','verify',str(payload/'candidate.bundle')],cwd=lab,text=True,capture_output=True);(payload/'bundle-verify.log').write_text(bv.stdout+bv.stderr);assert bv.returncode==0
reconstruction=stage/'reconstruction';reconstruction.mkdir()
archive=stage/'base.tar';subprocess.run(['git','archive','--format=tar','-o',str(archive),base],cwd=lab,check=True)
with tarfile.open(archive) as t:t.extractall(reconstruction)
subprocess.run(['git','apply','--check',str(payload/'candidate.patch')],cwd=reconstruction,check=True)
subprocess.run(['git','apply',str(payload/'candidate.patch')],cwd=reconstruction,check=True)
files=subprocess.check_output(['git','ls-tree','-r','--name-only','-z',head],cwd=lab).decode().split('\0');files=[x for x in files if x]
def digest(p):return hashlib.sha256((os.readlink(p).encode() if p.is_symlink() else p.read_bytes())).hexdigest()
mismatch=[name for name in files if not os.path.lexists(reconstruction/name) or digest(reconstruction/name)!=digest(lab/name)]
assert not mismatch,mismatch
verification={'base':base,'candidateCommit':head,'trackedFilesCompared':len(files),'patchReconstructionMismatches':mismatch,'bundleVerified':True,'sanitizedJsonl':sanitized,'excludedFiles':skipped,'note':'Claude hidden reasoning blocks are omitted. Kept reports, tool calls/results, measured data and independently reproducible controls. The native Lab HMAC record is retained without exporting its local signing key; package checksums prove transport integrity, not independent Story certification.'}
(payload/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(payload/'report.md').write_text((art/'report.md').read_text().replace('](./','](evidence/'));shutil.copy2(lab/'experiments/five-item-proof/README.md',payload/'REPRODUCE.md');shutil.copy2(art/'PACKAGE-README.md',payload/'README.md')
manifest=[]
for f in sorted(payload.rglob('*')):
 if f.is_file():manifest.append(digest(f)+'  '+str(f.relative_to(payload)))
(payload/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
target=art.parent/(art.name+'.tar.gz')
with tarfile.open(target,'w:gz') as t:t.add(payload,arcname=payload.name)
extracted=stage/'extracted';extracted.mkdir()
with tarfile.open(target) as t:t.extractall(extracted)
root=extracted/payload.name
for line in (root/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1);assert digest(root/name)==expected,name
verification.update({'archive':str(target),'archiveSha256':digest(target),'filesChecksumVerified':len(manifest),'archiveBytes':target.stat().st_size,'stagingDirectory':str(stage)})
(art/'package-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({k:v for k,v in verification.items() if k not in ['sanitizedJsonl','excludedFiles']},indent=2))
