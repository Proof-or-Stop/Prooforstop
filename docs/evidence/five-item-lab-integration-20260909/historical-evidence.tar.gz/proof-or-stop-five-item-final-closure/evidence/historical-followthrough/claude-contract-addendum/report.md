# Addendum — independent verification at `296d1ca401`

Verifier: Claude CLI, independent of the developing session. Date 2026-09-09.
Worktree `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`,
HEAD `296d1ca4014aeee839927393c9a3ba09e2f9a665`, working tree clean except untracked
`AGENTS.override.md`. Nothing was edited, built, committed, or advanced; no Story, main,
other worktree, or subagent was touched. All outputs are under `claude-contract-addendum/`.

`claude-final-state/report.md` is historical at `0d3c962a65` and is left intact. This addendum
covers `0d3c962a65..296d1ca401` and corrects one attribution error in that report's §5.

## 1. Commands executed — exact exits

| # | Command (cwd = Lab worktree) | Exit | Observed | Log |
|---|---|---|---|---|
| 1 | `node scripts/verify-process-fact-contract.mjs` | **0** | ends `Process fact contract verified` / `Process-fact contract verification passed` | `verify-process-fact-contract.log` |
| 2 | `pinned-final-lab-cli.sh --version` | **0** | `Proof-or-Stop 0.3.284` | `pinned-final-version.log` |
| 3 | `pinned-final-lab-cli.sh --implementation-identity` | **0** | stderr 0 bytes; digest `9f47a7be…` | `pinned-final-identity.json` |

The pinned entry still resolves and still accepts the runtime, so the contract fix did not move
the implementation pin.

## 2. Implementation identity vs `final-implementation-identity.json`

```
digest    9f47a7be17e4a160055c48867c071a8e1e3651c09feede66c41bd879b4ad989f   (both)
fileCount 1656                                                              (both)
sha256 of the whole artifact file: d1369413313577b77d13…  → BYTE-IDENTICAL
```

Unchanged from the `0d3` measurement, as expected for a whitespace + mirror-string change with
no rebuild. `packages/main/dist/cli.js` mtime is Sep 9 04:36 — earlier than the graph-contract
runs (04:45–04:49) and than commits `817857204a` / `296d1ca401`. No dist rebuild occurred.
Raw comparison: `identity-comparison.txt`.

### `labFiles` 23 vs 19 — two scopes over one identical file set

Both counts are derived from the **same** 1,656-entry list with the same digest; they are not
two identities.

| Predicate | Count |
|---|---|
| path **contains** `lab` (the old report's `labFiles 23`) | **23** |
| path **starts with** `lab/` (`final-runtime-binding.json` `"labFiles": 19`) | **19** |
| path starts with `packages/lab/` | 0 |

The four extra entries under the looser predicate are `core/cli/lab-entrypoint.js`,
`unresolved-dependency/@proof-or-stop/lab`, and two substring coincidences —
`dependency/zod@4.5.4/src/v3/tests/nullable.test.ts` and its v4 counterpart (`nul-lab-le`).
`19 + 4 = 23`. Full list in `identity-comparison.txt`.

## 3. `0d3c962a65..296d1ca401` — what actually changed

Two commits, 5 files, +4 −5 (`diff-0d3c962a65-to-HEAD.patch`):

* `817857204a` — one line in `scripts/verify-process-fact-contract.mjs`
  (`assertCloseoutTrustBoundary` required-literal list): `5c518f1967…f303` → `986652de…bab0`.
  This is the **mirror** of the guard's approved graph pin, not a second decision point. It
  changes only the literal the contract requires to be present in the guard source.
* `296d1ca401` — whitespace only: a trailing space on one line in each of
  `complete-output-adversarial.mjs`, `complete-output.mjs`, `evidence-implementation.mjs`, and a
  terminal blank line in `packages/main/src/core/process-fact-registry.ts`.

Semantics of `296d1ca401` confirmed two ways:

* `git diff -w --ignore-blank-lines 817857204a 296d1ca401` → **0 bytes**
  (`diff-817-to-HEAD-w-ignore-blank-lines.patch`).
  Note `--ignore-all-space` alone still prints 545 bytes, because a whitespace-only line becoming
  empty and a removed blank line need `--ignore-blank-lines` as well.
* Per-file content hash after stripping trailing whitespace and blank lines: **SAME** for all
  four files (`normalized-content-equality.txt`).

The historical RED for the contract fix is preserved and is genuine:
`graph-contract-red.log` fails with
`retired vocabulary guard must enforce narrow compatibility usage: 5c518f1967…`;
`graph-contract-green.log` / `graph-contract-final-green.log` end
`Process-fact contract verification passed`. My run 1 above reproduces that GREEN natively at
`296d1ca401`.

## 4. Correction to `claude-final-state/report.md` §5 — index 3

That report's §5 said index 3 of the full 134-command comparison was the
`prompt-full-context-envelope` source pin and concluded **"None of the six is attributable to
the candidate."** The raw logs do not support that sentence, and I am withdrawing it.

`full-config-comparison/RED-003.log` and `GREEN-003.log` are 1,216 bytes each and byte-for-byte
carry the same failure (copies: `full-config-RED-003.copy.log`, `full-config-GREEN-003.copy.log`):

```
AssertionError [ERR_ASSERTION]: dynamic-code exemption fingerprint must be exact:
packages/main/src/handlers/graph.ts
  actual:   '986652de3f98248d87c8c13e775029e7ba1177caf7e96030df9d2da460b6bab0'
  expected: '5c518f1967f915dcf6ee270c5f7f4f58c5dfafac4beb76fd9801e7191938f303'
```

Neither log mentions `prompt-full-context-envelope`, line 2159, or the
`895187c6…` token.

**Measured failure (benchmark, candidate `09596536ad`, before the re-pins):** the candidate's own
Graph port repair changed `handlers/graph.ts`, so its canonical AST fingerprint moved to
`986652de…` while the approved pin still read `5c518f19…`. The guard refused it. This failure
**is attributable to the candidate** — it is exactly the guard detecting the candidate's
unreconciled source change. It is present identically in both arms, so it says nothing about the
resource-declaration variable under test.

**Later failure (after the re-pins `416fddb`/`7d81c9`/`0d3c962`):** with the pin renewed to
`986652de…`, the default guard gets past `graph.ts` and aborts further on at
`assertLoaderArgumentProvenance`, on the pre-existing
`prompt-full-context-envelope-smoke.ts` source pin — which reproduces on prepared main
(`baseline-failure-controls/retired-guard-on-main.log`) and is unrelated to this work. That is
what my `0d3` run 3 observed. It is a **different, subsequent** failure, not the one the
benchmark measured.

Corrected statement: of the six benchmark failures, **index 3 as measured was candidate-induced
(self-invalidated approved fingerprint) and has since been repaired by the re-pin plus the
`817857204a` mirror alignment.** Indices 105, 106, 126, 130, 133 remain not attributable to the
candidate, per the prepared-main controls already cited; that part of §5 stands. The candidate's
omission — a changed source whose two pins and one contract mirror were not updated in the same
change — is preserved here, not erased.

This also means the failure was found in three stages, and all three are on record: the benchmark
caught the guard pin, the scoped RED/GREEN caught the second pin, and `graph-contract-red.log`
caught the contract mirror.

## 5. Scope limits observed

* No full 134-command rerun; the benchmark numbers are not re-measured or re-labelled to
  `296d1ca401`. They remain measurements of `09596536ad`.
* No widening into the unrelated base failures (`prompt-full-context-envelope`, 105/106/130/133).
* No edit, build, dist regeneration, Story command, main or other-worktree access, or subagent.
* The `--implementation-identity` artifact is a local file digest; it is not host isolation.
* The default guard entry still fails at `296d1ca401` for the pre-existing reason; there is no
  passing full guard and no passing 134-command inventory to claim.
