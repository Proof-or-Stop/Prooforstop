# Independent source-approval audit — guarded-source repin of `prompt-full-context-envelope-smoke.ts`

Auditor: Claude CLI, independent of the developing session. Date 2026-09-09.
Worktree (read-only): `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`
HEAD at audit time: `e0598510627e836242a95b85a8e3edc9c10fd530` (branch `codex/lab-five-item-proof-20260908`).

Nothing was modified: no source edit, no build, no dist write, no git mutation, no Story
state change, no subagents. Both audited files were verified clean in `git status` before
reading. All output is written only under this artifact directory. No bootstrap or other
pinned digest was touched or proposed for change.

---

## 1. Exact compared boundary

| Side | Object |
|---|---|
| OLD | `git show 1a222c4795:packages/main/src/tasks/prompt-full-context-envelope-smoke.ts` — 2314 lines, raw sha256 `850edc1ffa02336addeeca4bbe45903ebd81f79748f0d722e2324802612e5d08` |
| CURRENT | worktree `packages/main/src/tasks/prompt-full-context-envelope-smoke.ts` @ `e059851062` — 2340 lines, raw sha256 `01547675ff20753c9de5d99606cafc5adb292f433a00a40be0ca903c5097413b` |
| GUARD | `packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts` (5978 lines), same HEAD, unmodified |

The approval under review is exactly ONE map entry, guard line 1698, inside
`BENIGN_NON_LITERAL_LOADER_SOURCE_FINGERPRINTS`:

```
['packages/main/src/tasks/prompt-full-context-envelope-smoke.ts', '<digest>']
```

Scope confirmation: this path appears **0 times** in `PINNED_EXECUTABLE_SOURCE_FINGERPRINTS`
(checked by extracting that map and grepping it), so the repin moves exactly one digest.
The four sibling entries in the BENIGN map are unchanged and out of scope:
`bin/bootstrap-runner.js` `d1542f52…`, `bin/proof-or-stop-codex.js` `02301729…`,
`packages/main/src/cli.ts` `af73220a…`, `packages/main/src/handlers/graph.ts` `986652de…`.

## 2. The guard algorithm, as actually implemented

`retired-authority-vocabulary-guard-smoke.ts:821-827`,
`CANONICAL_AST_FINGERPRINT_ALGORITHM = 'typescript-printer-remove-comments-sha256-v1'`:

```ts
canonicalAstFingerprint(file, text) =
  sha256hex( ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed })
               .printFile( ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ScriptKind.TS) ) )
```

Consumed at `isKnownBenignNonLiteralLoaderCall` (2049-2068): approval requires
(a) a call-shape entry in `knownBenignNonLiteralLoaderCalls`, AND (b) the whole-file
canonical fingerprint equal to the pin, AND (c) `loaderArgumentProvenanceFailure() === undefined`.
Fingerprint alone never approves; provenance is evaluated first in
`scanConcealedCompatibilityLoads` (2096-2103) and is not gated by any fingerprint override.

## 3. Executed proof — independent recomputation

Run from the worktree, using the repo's own `typescript` (version printed by the run: **5.9.3**),
re-implementing the algorithm above rather than importing the guard:

```
node -e '...ts.createPrinter({removeComments:true,newLine:LineFeed}).printFile(createSourceFile(...)) -> sha256...'
```

Output:

```
typescript 5.9.3
old_ast    3c932df7aa37d3f489dacf3bb8696e2c895dfeee625033d595a5aa9275d26633
cur_ast    895187c6121e3be076bc1528950ad147452dd89da922ca43cd02be2923d5cb50
old_sha256_raw 850edc1ffa02336addeeca4bbe45903ebd81f79748f0d722e2324802612e5d08
cur_sha256_raw 01547675ff20753c9de5d99606cafc5adb292f433a00a40be0ca903c5097413b
```

- The claimed OLD approval `3c932df7aa37d3f489dacf3bb8696e2c895dfeee625033d595a5aa9275d26633`
  **reproduces exactly** from `1a222c4795`'s content and matches the digest currently pinned
  at guard line 1698.
- The proposed CURRENT digest `895187c6121e3be076bc1528950ad147452dd89da942…` —
  full value `895187c6121e3be076bc1528950ad147452dd89da922ca43cd02be2923d5cb50` —
  **reproduces exactly** from the current file. The proposal is arithmetically honest.

Note: this digest is toolchain-sensitive (it prints through `ts.createPrinter`); the value
above is bound to typescript 5.9.3 as resolved in this worktree.

## 4. Delta actually being approved

`git diff 1a222c4795 -- <fixture>` is **strictly additive**: 26 added lines, **zero deleted or
modified lines**. Two hunks:

1. Imports: `fullTaskSemanticDigest` added to the existing static import from
   `../core/prompt-envelope.js`, plus a new **static** import
   `import { SCOPE_INVENTORY_LIMITS } from '../core/scope-inventory-budget.js';`.
   Both targets verified to exist and be exported
   (`scope-inventory-budget.ts:5`, `prompt-envelope.ts:1307`). Neither is a dynamic load.
2. At line 1601, a B-adc3 scope-inventory test block: bounded-capacity assertions over
   `allowedCreate`, digest/envelopeId distinctness assertions, and `assert.throws` limit
   checks (4096 / 512 / 512 / serialized-byte boundary).

New bindings introduced by the added block: `count, paths, large, assembled, modified,
remaining, byteBoundary` (all `const`) and one loop `let i`. None collides with, shadows,
or rebinds any pinned identifier.

## 5. Provenance surface — byte-identity check

The approval for this file consists of three pinned facts besides the digest:

- call shape (guard 1626-1628): anchor `importEnvelopeMutant`, argument `pathToFileURL(mutantPath).href`
- provenance pin (guard 1829-1837): `rootIdentifier: 'mutantPath'`, `producer: 'writeEnvelopeMutant'`,
  `producerParameters: ['label']`, `producerParameterTypes: ["'no-safe-narrowing' | 'broad-deletion'"]`,
  `urlHelper: 'pathToFileURL'`
- negative controls (guard 5382-5419) that must keep failing: external-input rebinding,
  indirect producer alias, `let` (mutable) path binding, widened producer type, override parameter.

I extracted every line in both versions matching
`import(|require(|createRequire|eval(|new Function|spawnSync|execSync|pathToFileURL|mutantPath|writeEnvelopeMutant|importEnvelopeMutant|no-safe-narrowing|broad-deletion|process.env|child_process|node:vm`
and diffed them with line numbers stripped:

```
old_matches=14 cur_matches=14
diff → IDENTICAL
```

Current locations of that surface:

```
   2: import { execFileSync } from 'node:child_process';
   6: import { fileURLToPath, pathToFileURL } from 'node:url';
2145: function writeEnvelopeMutant(label: 'no-safe-narrowing' | 'broad-deletion'): string {
2146:   assert.ok(label === 'no-safe-narrowing' || label === 'broad-deletion', 'only the two fixed mutants are admitted');
2152:   const mutantPath = join(mutantCoreRoot, `prompt-envelope.b8a40-${label}.js`);
2154:   return mutantPath;
2157: async function importEnvelopeMutant(label: 'no-safe-narrowing' | 'broad-deletion') {
2158:   const mutantPath = writeEnvelopeMutant(label);
2159:   return import(pathToFileURL(mutantPath).href);
2164/2186: importEnvelopeMutant('no-safe-narrowing') / ('broad-deletion')
```

Therefore, verified byte-identical across the boundary:

- **Dynamic-import producer/loader**: exactly one `import(...)` in the file, unchanged, still
  `import(pathToFileURL(mutantPath).href)` inside `importEnvelopeMutant`. No `import()`,
  `require()`, `createRequire`, `eval(`, `new Function`, `spawnSync` was added, moved, or rewritten.
- **Allowed labels**: still the closed union `'no-safe-narrowing' | 'broad-deletion'`, on both
  the producer signature and the loader signature, with the runtime `assert.ok` narrowing
  intact — matching `producerParameterTypes` verbatim.
- **Isolated mutable path / initialization binding**: `mutantPath` remains a same-scope
  `const` initialized directly by the pinned producer call `writeEnvelopeMutant(label)`
  (not `let`, not an alias, not `process.env`), and the producer keeps its single required,
  non-optional, non-rest, non-defaulted `label` parameter. The mutant path is still built
  inside the producer from `join(mutantCoreRoot, …)`, not from caller or environment input.

## 6. Security-relevant changed provenance

**None found.** The delta admits no new module load, no new process spawn, no new
environment/caller-influenced input, no widening of the label domain, no relaxation of an
assertion, and no change to any allowlist or guard file. The two new static imports move
first-party constants and a digest function into the fixture; a static import is outside the
class this pin governs.

Two honest limitations, stated rather than papered over:

1. The pin is a **whole-file, comment-stripped** fingerprint. Accepting the new digest
   therefore also blanket-approves the 26 added test lines. I read the entire added block;
   it is assertion-only. That is the full extent of what the new digest additionally covers.
2. I did **not** execute the guard smoke itself (that would require a build, which is
   outside the authorized read-only scope). The executed proof here is an independent
   re-derivation of the guard's algorithm against the same shipped typescript, plus a
   source-level reading of the approval predicate — not an observed guard exit code.

## 7. Verdict

**APPROVED** — for this one entry only.

Reasons: (1) both digests independently reproduce under the guard's actual algorithm, so the
proposal is not a fabricated hash; (2) the delta is strictly additive with zero deletions or
modifications; (3) the entire security-relevant surface the pin exists to protect —
the single dynamic `import()`, its `pathToFileURL` helper, the `mutantPath` const binding,
the `writeEnvelopeMutant` producer and its closed two-label parameter type — is byte-identical
across the boundary; (4) the change is confined to added scope-inventory tests and two static
imports of verified first-party exports; (5) exactly one digest moves, and the bootstrap,
codex, cli.ts and graph.ts pins are untouched.

This approval covers the source repin only. It is not authority to weaken any assertion,
widen `knownBenignNonLiteralLoaderCalls`, `APPROVED_LOADER_ARGUMENT_PROVENANCE`, or any
global allowlist, or to refresh any other pinned digest. If the fixture changes again, this
approval is void by design.
