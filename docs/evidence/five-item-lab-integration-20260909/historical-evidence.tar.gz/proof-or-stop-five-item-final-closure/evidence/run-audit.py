import subprocess, pathlib, sys, time, json
out=pathlib.Path(sys.argv[1]); prompt=(out/'prompt.txt').read_text()
start=time.time()
args=['claude','-p','--verbose','--output-format','stream-json','--no-session-persistence','--permission-mode','dontAsk','--allowedTools','Bash,Read,Write,Edit,Glob,Grep','--tools','Bash,Read,Write,Edit,Glob,Grep','--add-dir',sys.argv[2]]
with (out/'stream.jsonl').open('w') as log,(out/'stderr.log').open('w') as err:
 p=subprocess.run(args,cwd=out,input=prompt,text=True,stdout=log,stderr=err)
(out/'execution.json').write_text(json.dumps({'startEpoch':start,'endEpoch':time.time(),'exitCode':p.returncode,'cwd':str(out),'readRepository':sys.argv[2]},indent=2)+'\n')
sys.exit(p.returncode)
