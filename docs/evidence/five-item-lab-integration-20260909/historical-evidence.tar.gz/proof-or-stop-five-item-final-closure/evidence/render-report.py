from pathlib import Path
import json,statistics
art=Path(__file__).resolve().parent
root=json.loads((art/'root-command-repeat-complete/results.json').read_text())
full=json.loads((art/'full-ordered-comparison/results.json').read_text())
order=json.loads((art/'full-ordered-comparison/order-proof.json').read_text())
cold=json.loads((art/'full-ordered-comparison/cold-prefix.json').read_text())
assert all(order.values()) and cold['distAbsentAtStart'] and cold['cliPresentAtEnd'] and cold['result']['allPass']
assert len(root['trials'])==4 and all(t['allPass'] and t['successfulConsumers']==2 for t in root['trials'])
assert len(full['rows'])==2 and {t['mode'] for t in full['rows']}=={'RED','GREEN'}
assert all(t['allPass'] and t['passed']==134 and len(t['result']['commands'])==134 and not t['failed'] for t in full['rows'])
rows={r['mode']:r for r in full['rows']}
for a,b in zip(rows['RED']['result']['commands'],rows['GREEN']['result']['commands']):
 assert a['code']==b['code']==0 and not a.get('timedOut') and not b.get('timedOut')
 assert [a['command'],a['args']]==[b['command'],[x for x in b['args'] if x not in ['--jobs=4','--probe-jobs=4']]]
med={mode:statistics.median(t['elapsedMs']/1000 for t in root['trials'] if t['mode']==mode) for mode in ['RED','GREEN']}
rp=100*(1-med['GREEN']/med['RED']);ft={mode:rows[mode]['elapsedMs']/1000 for mode in ['RED','GREEN']};fp=100*(1-ft['GREEN']/ft['RED'])
summary={'rootRoutineRepeat':{'medianSeconds':med,'observedTimeDecreasePercent':rp,'trials':4,'consumerInvocations':8,'actualSuiteProcesses':6},'fullValidation':{'seconds':ft,'observedTimeDecreasePercent':fp,'commandsPerArm':134,'bothAllPass':True,'sameCommandIdentityExceptTwoPoolFlags':True,'scope':'Same executed production/test scripts; old/new scheduling activation plus corrected precheck barrier. Different pinned commits/configs. Both full timings begin prepared. One paired observation, no Story lead-time inference.'},'coldPrefix':{'seconds':cold['elapsedMs']/1000,'commands':3,'distAbsentAtStart':True,'allPass':True,'scope':'Separate actual first three root commands, not a cold 134-command benchmark.'}}
(art/'final-metrics.json').write_text(json.dumps(summary,indent=2)+'\n')
source=json.loads((art/'final-source-delta.json').read_text())
v={
'FINAL_VERDICT':f"完整的134条对照两边均通过；五项在下表列出的Lab机制与场景已取得可核验的正确性证据，其中重复重型命令和并发验证测到了收益。最终保留候选为{source['candidateCommit'][:12]}，包含本轮最后发现的构建顺序修正，见[最终源码差异](./final-source-delta.json)。本结论不把明确保留的范围外部署条件和未复现OS风险称为已消失。",
'ROOT_TABLE':f"| 实际根注册重型命令、两个routine消费者；2组交错对照中位数 | {med['RED']:.3f}秒，2次执行 | {med['GREEN']:.3f}秒，1次执行 | 4组均成功，8次消费者调用全部通过；该场景观察耗时下降{rp:.1f}% |",
'FULL_TABLE':f"| 完整134条验证；相同生产/测试脚本，原始超时，1组对照 | {ft['RED']:.3f}秒，134/134通过 | {ft['GREEN']:.3f}秒，134/134通过 | 完整工作负载本次观察耗时变化：减少{fp:.1f}%；不是所有代码修复的因果收益或Story速度 |",
'FULL_EXPLANATION':f"完整对照见[全部结果/每条输出](./full-ordered-comparison/results.json)、[GREEN实际调度事件](./full-ordered-comparison/events.jsonl)、[RED原始事件](./full-complete-comparison/events.jsonl)及[命令、源码与范围](./full-ordered-comparison/manifest.json)。RED在{source['baselineMeasurementCommit'][:12]}的执行器输入中恢复CF资源声明、去掉两项内部并发参数；GREEN使用{source['candidateCommit'][:12]}的已审核声明、两个有界池和预检查独占屏障。两边实际生产/测试脚本相同，但Git提交和配置不同；jobs都为4，原始超时未增加，134条命令无遗漏；顶层峰值分别为{rows['RED']['peak']}和{rows['GREEN']['peak']}。两个全量计时都从已准备构建物开始；另行删除新私有副本main/dist后，实际前三条命令{cold['elapsedMs']/1000:.3f}秒全部通过，见[冷启动原始结果](./full-ordered-comparison/cold-prefix.json)。[顺序断言](./full-ordered-comparison/order-proof.json)核对冷启动以及完整RED/GREEN中构建均先于所有后续消费者。未声称134条全部从无dist开始。完整对照只有一组，不能排除宿主负载/缓存/顺序对绝对差值的贡献；内部完整73条和58条另有交错重复对照支持对应机制。",
'ROOT_EXPLANATION':"真实根命令复用见[4组原始结果](./root-command-repeat-complete/results.json)、[重新计算的摘要](./root-command-repeat-complete/summary.json)及[Claude独立审计](./claude-root-repeat-audit/report.md)。计数记录实际套件进程启动，日志在fixture之外，实际实现来自只读冻结副本；两个消费者在不同Node进程运行。NODE_OPTIONS只读计数探针在两边都使用。每组使用新的私有测试准入夹具，不授予真实Story权威。根DONE没有该命令的精确重合，不宣称清除了根配置所有routine/DONE叶子测试的重复。",
'AUDIT_FINAL':"Claude CLI对核心机制、身份/审查/51分钟证据、证据修正与第二次rename故障、真实根命令及资源声明分别独立核验；最后的[完成审计](./claude-completion-audit/report.md)核对本报告与完整134条原始数据。原始审核者文本中的两处非结论性措辞更正见[审计阅读更正](./audit-reading-errata.md)，不覆盖其原报告。",
'MAIN_FINAL':"主分支只读核验记录见[main核对](./main-final-audit.json)和[并行任务变更记录](./parallel-main-movement.json)。本任务没有main集成、版本升级或push；但不能写成main一直没变化：期间main通过另一项Lab b-e40f-convergence-20260909的提交推进到04e66fdbaeae、版本0.3.285。本Lab候选不是main的祖先；原始22个文件哈希及开工Git状态仍相同。本实验固定使用CF基线0.3.284，未追随浮动main。提交列表见[Lab本地提交](./repair-commits.txt)。",
'PACKAGE_FINAL':"包外package-verification.json记录最终归档SHA-256、补丁重建和解包逐文件校验；包内verification.json、SHA256SUMS及transcript-verification.json分别记录源码、文件和审核日志的校验。未用于任何结论的大型探索性CPU profile不随包重复分发，其哈希/大小/排除理由被记录，原机文件仍保留。"
}
s=(art/'report-template.md').read_text()
for k,value in v.items():s=s.replace('{{'+k+'}}',value)
assert '{{' not in s
if (art/'final-audit-note.md').exists():
 s+='\n'+(art/'final-audit-note.md').read_text()
(art/'report.md').write_text(s)
print(json.dumps(summary,indent=2))
