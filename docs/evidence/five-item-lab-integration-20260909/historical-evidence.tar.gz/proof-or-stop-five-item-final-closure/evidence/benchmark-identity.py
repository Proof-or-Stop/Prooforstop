from pathlib import Path
import json,shutil,tempfile,subprocess,time,os,hashlib,difflib,statistics
art=Path(__file__).resolve().parent;src=Path(json.loads((art/'quorum-paired-runtime.json').read_text())['path']);old=Path(json.loads((art/'long-runtime-bindings.json').read_text())[1]['runtime']);dest=Path(tempfile.mkdtemp(prefix='pos-identity-benchmark-'));out=art/'identity-timing';out.mkdir(exist_ok=True)
for name in ['package.json','node_modules','bin','scripts','packages/main/dist','packages/main/package.json','packages/main/templates','packages/utils/dist','packages/utils/package.json','packages/lab/dist','packages/lab/package.json']:
 a=src/name;b=dest/name;b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_dir():shutil.copytree(a,b,symlinks=True)
 else:shutil.copy2(a,b)
file=dest/'packages/main/dist/cli-engine.js';before=(old/'packages/main/dist/cli-engine.js').read_bytes();after=file.read_bytes();diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='before',tofile='after'));(out/'only-cli-difference.patch').write_text(diff)
assert diff.count('@@')==2,'Only the runCli synchronous identity-output hunk may differ'
entry=dest/'packages/main/dist/cli.js';env={**os.environ};env.pop('PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST',None);env.pop('PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN',None)
identities={};rows=[]
for mode,data in [('RED',before),('GREEN',after)]:
 file.write_bytes(data);p=subprocess.run(['node',str(entry),'--implementation-identity'],cwd=dest,env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr;identities[mode]=json.loads(p.stdout)
assert identities['RED']['fileCount']==identities['GREEN']['fileCount'];diffFiles=[(a,b) for a,b in zip(identities['RED']['files'],identities['GREEN']['files']) if a!=b];assert len(diffFiles)==1 and diffFiles[0][0]['path']=='core/cli-engine.js',diffFiles
for pair in range(1,8):
 for mode in (['RED','GREEN'] if pair%2 else ['GREEN','RED']):
  file.write_bytes(before if mode=='RED' else after);pinned={**env,'PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN':'1','PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST':identities[mode]['digest']};start=time.monotonic();p=subprocess.run(['node',str(entry),'--implementation-identity'],cwd=dest,env=pinned,text=True,capture_output=True);elapsed=time.monotonic()-start;assert p.returncode==0,p.stderr;assert json.loads(p.stdout)==identities[mode];rows.append({'pair':pair,'mode':mode,'elapsedSeconds':elapsed,'exitCode':p.returncode,'fileCount':identities[mode]['fileCount']})
file.write_bytes(after)
summary={mode:statistics.median(x['elapsedSeconds'] for x in rows if x['mode']==mode) for mode in ['RED','GREEN']};(out/'results.json').write_text(json.dumps({'runtime':str(dest),'rows':rows,'medianSeconds':summary,'fileCount':identities['GREEN']['fileCount'],'changedIdentityFiles':diffFiles,'scope':'Strict --implementation-identity output only; same freshly read file inventory. Other execution boundaries retain full fresh scans; not a speedup for all CLI commands.'},indent=2)+'\n');print(summary,flush=True)
