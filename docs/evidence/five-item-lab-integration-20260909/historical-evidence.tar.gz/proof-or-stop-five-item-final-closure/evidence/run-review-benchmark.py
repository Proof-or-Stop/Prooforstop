from pathlib import Path
import json,subprocess,time,concurrent.futures,hashlib
art=Path(__file__).resolve().parent;base=art/'review-benchmark';contract=json.loads((base/'preregistered.json').read_text());rows=[]
def review(arm,wave,role):
 state='after' if wave=='final' else 'before';packet=base/state;out=base/'runs'/arm/wave/role;out.mkdir(parents=True,exist_ok=True)
 source=(packet/'protocol.mjs').read_bytes();sha=hashlib.sha256(source).hexdigest()
 prompt=f'''Independent Claude CLI audit requested by user. This is a bounded Lab calibration, not a Story or production code. Your lane is {role}. Read ONLY {packet}/CONTRACT.md, protocol.mjs and inspect.mjs; do not read sibling directories, other review reports, oracle files or any repository. Do not edit packet/code, build, create Story, use subagents, or touch main. Outputs only {out}. At most10 tool calls; use batched reads and keep prose concise.
First actually execute {base}/pinned-cli.sh --implementation-identity and save stdout to {out}/identity.json; do not echo its file list. This pins the same Lab framework runtime as the owner; refusal means stop and record the error, not unset/bypass the pin.
Review all ten exported helpers for violations of their EXACT stated contract and valid input domains. Do not assume any defect count or force findings. Focus lane {role}, but report any verified applicable violation you find. Any finding MUST have a concrete JSON argument array and expected JSON result according to the contract. Actually run counterexamples with node {packet}/inspect.mjs and save outputs in {out}/counterexamples.log. Behavior outside the stated input domain is not a defect. Do not speculate about I/O/security features not in these pure-helper contracts.
Write {out}/review.json as JSON object {{"role":"{role}","sourceSha256":"{sha}","findings":[{{"function":"exportedName","args":[],"expected":false,"reason":"which exact contract is violated"}}]}}. Include ONLY executable witnessed violations; an empty list is correct if none. Do not silently omit the file; a missing file means failed review. This is stage {wave}; fixed final code still needs independent scrutiny, not automatic approval. End with a short completion statement. Do not read review-benchmark/preregistered.json or another state of protocol.mjs.'''
 (out/'prompt.txt').write_text(prompt);args=['claude','--print','--verbose','--output-format','stream-json','--permission-mode','dontAsk','--allowedTools','Read','Bash','Write','--add-dir',str(out)];start=time.monotonic()
 with (out/'stream.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:p=subprocess.run(args,input=prompt,text=True,cwd=packet,stdout=stdout,stderr=stderr,timeout=600)
 row={'arm':arm,'wave':wave,'role':role,'elapsedSeconds':time.monotonic()-start,'exitCode':p.returncode,'sourceSha256':sha,'sourceUnchanged':source==(packet/'protocol.mjs').read_bytes(),'output':str(out)}
 if (out/'identity.json').exists():
  try:row['identityDigest']=json.loads((out/'identity.json').read_text())['digest']
  except Exception as e:row['identityError']=str(e)
 row['reportPresent']=(out/'review.json').exists();(out/'execution.json').write_text(json.dumps(row,indent=2)+'\n');return row
for arm,waves in contract['arms'].items():
 for wave in waves:
  start=time.monotonic();print('START',arm,wave,flush=True)
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:waveRows=list(pool.map(lambda role:review(arm,wave,role),contract['roles']))
  row={'arm':arm,'wave':wave,'elapsedSeconds':time.monotonic()-start,'reviews':waveRows};rows.append(row);(base/'wave-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',arm,wave,row['elapsedSeconds'],[(x['role'],x['exitCode'],x['reportPresent']) for x in waveRows],flush=True)
  assert all(x['exitCode']==0 and x['reportPresent'] and x.get('identityDigest')==contract['runtimeDigest'] and x['sourceUnchanged'] for x in waveRows),'Review collection or identity failed; preserve failure rather than claim coverage'
