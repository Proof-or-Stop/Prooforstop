from pathlib import Path
import json
p=Path(__file__).resolve().parent/'full-complete-comparison/events.jsonl'
if not p.exists(): print('Full comparison not started');raise SystemExit
states={}
lines=p.read_text().splitlines()
ordered=p.parent.parent/'full-ordered-comparison/events.jsonl'
if (p.parent.parent/'ordered-runtime.json').exists():
 lines=[l for l in lines if json.loads(l)['mode']=='RED']
 if ordered.exists():lines+=ordered.read_text().splitlines()
for line in lines:
 e=json.loads(line);s=states.setdefault(e['mode'],{'passed':0,'failed':[],'active':{},'atMs':0});s['atMs']=e['atMs'];i=e.get('commandIndex')
 if e['type']=='command_start':s['active'][i]={'name':e.get('label'),'startMs':e['atMs'],'timeoutMs':e.get('timeoutMs')}
 elif e['type']=='command_end':
  s['active'].pop(i,None)
  if e.get('code')==0 and not e.get('timedOut'):s['passed']+=1
  else:s['failed'].append({'oneBasedIndex':i,'code':e.get('code'),'timedOut':e.get('timedOut')})
for mode,s in states.items():
 print(mode,'completed',s['passed']+len(s['failed']),'passed',s['passed'],'failed',s['failed'],'observedElapsedSeconds',round(s['atMs']/1000))
 print(' active',[(i,round((s['atMs']-v['startMs'])/1000),(v['name'] or '')[:85]) for i,v in s['active'].items()])
