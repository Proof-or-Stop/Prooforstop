from pathlib import Path
import json, re, subprocess, hashlib

art = Path(__file__).resolve().parent
lab = Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908')
data = json.loads((art/'full-ordered-comparison/results.json').read_text())
base = json.loads(subprocess.check_output(['git', 'show', 'cf21df09c273074d7aa3227a5f436c6f5badf47a:proof-or-stop.config.json'], cwd=lab, text=True))
baseline_executor = subprocess.check_output(['git', 'show', 'cf21df09c273074d7aa3227a5f436c6f5badf47a:packages/main/src/core/validation-executor.ts'], cwd=lab, text=True)
timeout_match = re.search(r'export const DEFAULT_VALIDATE_COMMAND_TIMEOUT_MS = ([0-9_]+);', baseline_executor)
assert timeout_match
default_timeout = int(timeout_match.group(1).replace('_', ''))
arms = {row['mode']: row for row in data['rows']}
assert set(arms) == {'RED', 'GREEN'} and len(data['rows']) == 2
registry_path = Path(data['manifest']['runtime']['path'])/'packages/main/dist/tasks/quorum-case-registry.js'
registry = json.loads(subprocess.check_output(['node', '--input-type=module', '-e', 'const m=await import(process.argv[1]);console.log(JSON.stringify(m.QUORUM_CASES));', registry_path.as_uri()], text=True))
registry_names = sorted(c['name'] for c in registry)
assert len(registry_names) == len(set(registry_names)) == 73
coverage = {}
for mode, row in arms.items():
    commands = row['result']['commands']
    assert row['allPass'] and row['passed'] == 134 and not row['failed'] and len(commands) == 134
    for i, (command, original) in enumerate(zip(commands, base['validate']['commands'])):
        assert command['code'] == 0 and not command.get('timedOut'), (mode, i)
        assert command['timeoutMs'] == original.get('timeoutMs', default_timeout), (mode, i, 'timeout changed')
        assert command['command'] == original['command']
        assert [a for a in command['args'] if a not in ['--jobs=4', '--probe-jobs=4']] == original.get('args', [])
    quorum = commands[40]['output']
    assert 'quorum_submit smoke passed (73 checks)' in quorum
    names = sorted(line.strip()[1:].strip() for line in quorum.splitlines() if line.strip().startswith('\u2713') and 'smoke passed' not in line)
    if mode == 'RED':
        assert names == registry_names
    else:
        marker = re.search(r'^QUORUM_EXACT_COVERAGE (.+)$', quorum, re.M)
        assert marker
        covered = json.loads(marker.group(1))
        assert covered['cases'] == 73 and covered['jobs'] == 4
        # The real parallel parent verifies all child IDs/body digests before this
        # marker. Successful per-worker temp reports were removed by that parent;
        # do not pretend their individual names were printed in the final log.
    marker = re.search(r'^ACCEPTANCE_FORBIDDEN_FIELD_COVERAGE (.+)$', commands[106]['output'], re.M)
    assert marker
    probes = json.loads(marker.group(1))
    assert probes['count'] == 58 and len(probes['ids']) == 58 and len(set(probes['ids'])) == 58
    assert 'ProofStory acceptance coverage basis Wave 1A smoke passed' in commands[106]['output']
    coverage[mode] = {'quorumNames': names, 'basisProbeIds': sorted(probes['ids']), 'basisJobs': probes['jobs'], 'basisPeak': probes['peak']}
assert coverage['RED']['basisProbeIds'] == coverage['GREEN']['basisProbeIds']
assert coverage['RED']['basisJobs'] == 1 and coverage['GREEN']['basisJobs'] == 4
order = json.loads((art/'full-ordered-comparison/order-proof.json').read_text())
assert all(order.values())
source = json.loads((art/'final-source-delta.json').read_text())
assert source['candidateCommit'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=lab, text=True).strip()
result = {'all268CommandResultsPassed': True, 'all268TimeoutsEqualOriginalPolicy': True,
          'red73NamesMatchCurrentRegistry': True, 'greenStrictCoverageMarker73': True,
          'greenIndividualWorkerReportsRetained': False, 'same58UniqueBasisProbeIds': True,
          'buildOrder': order, 'candidateCommit': source['candidateCommit'], 'coverage': coverage,
          'scope': 'Raw evidence verification only; no additional test suite execution or claim of population performance.'}
(art/'final-evidence-selfcheck.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'coverage'}, indent=2))
