# Independent Claude audit — internal quorum partitioning (`eeb02c2697`)

**Subject**: `b514122aa1..eeb02c2697` — "perf: partition independent quorum cases behind exact coverage checks".
**Frozen source/runtime**: `/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-quorum-paired-zqqmt720/repo` (read/execute only).
**Constraints honored**: no builds, no source edits, no commits, no subagents, no full-73 run (paired benchmark in progress). Outputs written only under this directory.
**Companion files**: `addendum-to-scheduling-design.md` (amends the earlier audit, which is preserved), `independent-callback-verify.mjs` + `independent-callback-verification.json`, `shared-state-independence-check.mjs` + `shared-state-independence.json`, `live-manifest.txt`.

## Verdict

No new correctness hole found in the partitioning mechanism. The coverage,
ordering, atomicity, drift and child-failure guards are real and were executed.
Four defects are reported below (one medium, three low); none blocks acceptance
and none makes existing evidence false. The prior audit's claim about the outer
exclusive barrier is corrected in the addendum; its two substantive findings are
confirmed, one of them now mechanically.

## What the diff actually is

Eight files. Four quorum task modules (`quorum-case-registry.ts` — 73 explicit
`{id,name,group}` records; `quorum-case-plan.ts` — plan algebra and verification;
`quorum-case-parallel.ts` — the parent; `quorum-submit-smoke.ts` — argument
contract, registration, and the `--jobs>1` branch), plus
`process-fact-registry.ts`, `scripts/verify-process-fact-contract.mjs`,
`docs/validation-performance.md`, `experiments/five-item-proof/quorum-plan-controls.mjs`.

**No scheduler / lock / resource / capacity file is touched.** That is the
evidence for the central claim: children are spawned *inside* the one scheduled
command process tree (`quorum-case-parallel.ts:16`), the outer resource
declaration is unchanged, and siblings stay blocked. An exclusive plan ticket is
a mutex around the callback; it never serialized processes created inside it. See
addendum A1 for the full correction and the one caveat that survives (capacity-model
fidelity, i.e. up to four git-heavy children under a ticket sized for one).

## Callback equivalence — independently verified, not taken from the report

Method: TypeScript 5.9.3 AST (`repo/node_modules/typescript`) over the HEAD
source and over `git show b514122aa1:…/quorum-submit-smoke.ts`, plus the LIVE
`--list-cases` manifest. `quorum-callback-equivalence.json` was read only at the
end, for comparison.

| Check | Result |
|---|---|
| `check(...)` call sites, HEAD / base | 73 / 73 |
| Arity | base all 2 args, HEAD all 3 (the id is the only addition) |
| Callback bodies byte-identical (matched by name *and* by position) | 73/73, zero differences |
| Registration order / names changed | none |
| IDs are `Q001..Q073` in registration order, unique | yes |
| `QUORUM_CASES` registry == AST (id, name, order) | exact |
| Live `--list-cases` manifest == registry | exact |
| Developer's `quorum-original-callbacks.json` bodies == my base extraction | 73/73 match |

**Digest-domain finding.** All 73 digests in `quorum-callback-equivalence.json`
differ from the live runtime digests (Q001: live `6b86637b…`, reported
`10c02944…`). This is a domain difference, not drift: the reported digests are
`sha256` of the **TypeScript source** body (they equal both the `digest` field of
`quorum-original-callbacks.json` and `sha256` of the current HEAD source bodies),
while the gate compares `sha256(fn.toString())` of the **compiled** function
across processes. Both chains are internally consistent and both independently
confirm retention. Worth labelling the domain in the report so the digests are
not mistaken for the gate's values.

## Shared-state grouping — the hand-authored `group` field checked mechanically

The whole design rests on one hand-written claim: that only 13 cases share the
single top-level fixture. I tested it instead of trusting it, by walking each
callback's AST for *free* references to `root` / `store` / `registry` / `result`
(excluding property names, object keys, and — after correcting a false positive
on Q040 — type qualifiers in `typeof a.b.c`).

Result: the set of cases with free shared-fixture references is **exactly** the
13 members of `ordered-quorum-state`; every atomic member has at least one such
reference and **no** singleton-group case has any. The grouping is correct as of
this commit. What is missing is the *guard* — see finding 4.

## Executed commands

All run from the frozen repo root; `S = packages/main/dist/tasks/quorum-submit-smoke.js`.

| Command | Exit | Observed |
|---|---|---|
| `node $S --list-cases` | 0 | 14 340-byte `QUORUM_CASE_MANIFEST:` line, 73 entries → `live-manifest.txt` |
| `node experiments/five-item-proof/quorum-selection-contract.mjs` | 0 | `QUORUM_EMPTY_SELECTION_REFUSED` |
| `node experiments/five-item-proof/quorum-plan-controls.mjs` | 0 | `QUORUM_PLAN_CONTROLS_GREEN` (also emits `Quorum failure artifacts retained: …` from its intentional child-failure control) |
| `node $S --case-ids=Q999 --result-file=…` | 1 | `UNKNOWN_QUORUM_CASE Q999` |
| `node $S --case-ids= --result-file=…` | 1 | `UNKNOWN_QUORUM_CASE` |
| `node $S --case-ids=Q001,Q001 --result-file=…` | 1 | `DUPLICATE_QUORUM_SELECTION` |
| `node $S --case-ids=Q024 --result-file=…` | 1 | `QUORUM_DEPENDENCY_SPLIT ordered-quorum-state` |
| `node $S --case-ids=Q001` | 1 | `QUORUM_SHARD_REQUIRES_RESULT_FILE` |
| `node $S --grep=x --case-ids=Q001 --result-file=…` | 1 | `AMBIGUOUS_QUORUM_SELECTION` |
| `node $S --list-cases --jobs=2` | 1 | `AMBIGUOUS_QUORUM_LIST` |
| `node $S --jobs=5` | 1 | `QUORUM_JOBS_OUT_OF_RANGE` |
| `node $S --bogus` | 1 | `UNKNOWN_QUORUM_OPTION` |
| `node $S --jobs=2 --jobs=3` | 1 | `DUPLICATE_QUORUM_OPTION --jobs` |
| `PROOF_OR_STOP_QUORUM_JOBS= node $S --list-cases` | 1 | `QUORUM_JOBS_OUT_OF_RANGE` (finding 3) |
| `node $S --case-ids=Q009,Q010,Q011,Q012 --result-file=/tmp/…/pure.json` | 0 | 4 pure derivation cases ran; `QUORUM_DIAGNOSTIC_SELECTION_PASSED (4 checks)`; result file has schema, ids and per-case digests |
| `node $S --case-ids=Q009..Q012 --result-file=relative-out.json` | 0 | **no file produced** (finding 2) |
| `node …/independent-callback-verify.mjs` | 0 | table above |
| `node …/shared-state-independence-check.mjs` | 0 | grouping result above |

Required negatives from the brief — unknown / empty / duplicate / missing ID,
name drift, body drift, atomic-group split, non-first-child exit failure,
callback-inventory-same — are all covered: the first four and the split directly
above; name drift, body drift, missing/duplicate plan case and
`QUORUM_SHARD_FAILED 1` (index 1, i.e. non-first) by `quorum-plan-controls.mjs`;
inventory-same by the AST verification.

## Register / execute consistency (reviewed, no defect)

`check()` registers *before* the selection early-return, so even a one-case
diagnostic run validates the whole inventory: `QUORUM_REGISTRATION_ORDER_OR_COUNT_DRIFT`
and `QUORUM_CASE_NAME_DRIFT` per case, `MISSING_QUORUM_REGISTRATION` at the end,
`QUORUM_EXECUTION_COVERAGE_MISMATCH` between executed and selected. The parent
adds `verifyQuorumResults`: schema, manifest deep-equality against a live
listing child, exact per-shard coverage, and per-case body digest. `validateQuorumPlan`
proves every id appears exactly once across shards. Children are pinned to
`PROOF_OR_STOP_QUORUM_JOBS=1` and an emptied `PROOF_OR_STOP_QUORUM_REPORT`, so
neither recursion nor report clobbering is possible. Exceptions fail closed: an
early throw aborts before any success marker, and the parallel branch runs before
the parent's own fixture exists, so the parent creates none.

Concurrency safety of the private-fixture claim was checked directly: every
mutable fixture derives from `mkdtempSync`, and all `IMPLEMENTATION_REPO_ROOT`
uses in the suite are reads (`readFileSync`, `git cat-file -e` with `cwd`). No
case body writes to the frozen repo.

## Findings

**1 — medium — no cancellation: a failed shard neither stops nor reaps its siblings.**
`quorum-case-parallel.ts:26` awaits `Promise.all` and only then checks exit codes
(`:27`); the sole `proc.kill` is the 16 MiB output guard (`:17`), and there is no
SIGINT/SIGTERM handling. Failure scenario: `--jobs=4`, shard 1 fails at t=5s —
shards 0, 2 and 3 run the remainder of their assigned suite to completion before
the parent can report, so a fast failure still costs a near-full run. Worse on
the `proc.on('error', reject)` path (`:18`): the rejection propagates while up to
three spawned children keep running unreaped, holding private git fixtures. No
wrong verdict results; the cost is wall-clock and stray processes. Retention of
`quorum-internal-shards-*` on failure is deliberate (`:34`) but unbounded — two
such directories already exist from the intentional control run.

**2 — low — a relative `--result-file` silently yields no file and exit 0.**
Proof: `node $S --case-ids=Q009,Q010,Q011,Q012 --result-file=relative-out.json` →
exit 0, `relative-out.json` does not exist. The write happens after `process.chdir(root)`,
so it lands in the fixture root that the `finally` immediately `rmSync`s. The
product path is unaffected (the parent always passes absolute paths), so this is
a diagnostic footgun, not a gate defect. Fix: require `isAbsolute(resultFile)`.

**3 — low — an exported-but-empty `PROOF_OR_STOP_QUORUM_JOBS` breaks the default serial path.**
`jobsRaw = uniqueArg('--jobs=') ?? process.env.PROOF_OR_STOP_QUORUM_JOBS ?? '1'`
— `??` falls back only on null/undefined, so `''` reaches `assert.match(/^[1-4]$/)`.
Proof: `PROOF_OR_STOP_QUORUM_JOBS= node $S --list-cases` → exit 1,
`QUORUM_JOBS_OUT_OF_RANGE`. Fail-closed, so harmless in effect, but `export VAR=`
is an ordinary shell idiom and it takes down the *default* path, not just the
opt-in one. Fix: treat `''` as absent.

**4 — low / advisory — nothing mechanically enforces the `group` field against real fixture usage.**
The correspondence is exact today (verified above), but it is hand-authored. A
future case registered as its own singleton that touches `root`/`store`/`registry`
would pass every guard in this change — coverage, digests, plan algebra all still
hold — and would go wrong only under `--jobs>=2`, while staying green in the
default serial mode. That is a defect class that hides until someone enables
partitioning. Recommendation: promote `shared-state-independence-check.mjs` (or
an equivalent free-reference assertion) into the suite. Not a present defect; the
missing guard is the point.

**Advisory, no change required — the pin cannot distinguish serial from partitioned.**
`PROOF_OR_STOP_QUORUM_JOBS` is environment, not argv, and the receipted command
is `node packages/main/dist/tasks/quorum-submit-smoke.js`, so two runs with
different partitioning share one pinned command string. Mitigated in practice:
the parallel path prints `QUORUM_EXACT_COVERAGE {"cases":73,"jobs":N,…}`, which
the serial path never prints, so a retained output tail does record it.

## Documentation and process-fact review

`docs/validation-performance.md` states the mechanism (73 cases, 13-case ordered
group, unchanged outer ticket, distinct diagnostic marker, retained callback
bodies) and closes with an explicit anti-generalization: use partitioning only
where the measured reduction exceeds setup and aggregation cost, and this is not
proof that splitting arbitrary product Stories helps. **It contains no forecasted
speedup number** — consistent with the brief. The
`runtime:quorum_assertion_inventory` process fact and the four
`verify-process-fact-contract.mjs` pattern anchors match the shipped identifiers
(`MISSING_QUORUM_PLAN_CASE`, `QUORUM_DEPENDENCY_SPLIT`, `QUORUM_SOURCE_OR_MANIFEST_DRIFT`,
`QUORUM_SHARD_COVERAGE_MISMATCH`, `MISSING_QUORUM_REGISTRATION`,
`QUORUM_DIAGNOSTIC_SELECTION_PASSED`, `QUORUM_EXECUTION_COVERAGE_MISMATCH`,
`QUORUM_SHARD_FAILED`, `PROOF_OR_STOP_QUORUM_JOBS`), all of which I observed in
the source and, where reachable, in executed output.

## Scope limits

No blocker was hit. Two limits are inherent to the brief, and neither is
compensated for elsewhere in this report:

- The full 73-case suite was **not** run in any mode (prohibited while the paired
  benchmark is in flight). So the empirical claim "a real 4-way parallel full run
  passes" rests on the in-progress paired runs, not on this audit. What I verified
  is the machinery that would detect its failure, plus a real 4-case execution.
- No performance claim of any kind is made or implied here. Timing belongs to the
  paired complete runs, which include setup and aggregation.
