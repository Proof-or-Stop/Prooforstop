# Addendum to `claude-scheduling-design/report.md`

Scope: this file **amends** the earlier Claude source audit
(`../claude-scheduling-design/report.md`, 2026-09-09). That report is preserved
unchanged; nothing in it is rewritten. Read the two together — where they
disagree, this addendum is the later and better-evidenced statement.

Frozen source/runtime: `/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-quorum-paired-zqqmt720/repo`, HEAD `eeb02c269784b85e6b18f3641fb761bbce22f54e`, base `b514122aa1`.

---

## A1 — CORRECTION: "relaxing the outer exclusive barrier is the only way to benefit" is wrong

The earlier report reasoned that because the quorum smoke runs under one
exclusive plan ticket, no parallel speedup is reachable without relaxing that
outer barrier. That conflates two different levels.

**What the implementation actually does.** `packages/main/src/tasks/quorum-case-parallel.ts`
is called from inside the single already-scheduled command process
(`quorum-submit-smoke.ts:791`, after the DYN-5 branch and *before* the top-level
fixture is created). It uses `node:child_process.spawn` to create private child
processes of that one process (`quorum-case-parallel.ts:16`). A plan-level
exclusive ticket is a scheduler mutex held *around the callback*; it does not and
cannot serialize processes the callback itself creates.

**The outer declaration is unchanged — proved by the diff, not by assertion.**
`git diff --name-only b514122aa1..HEAD` touches exactly eight files: the four
quorum task modules, `process-fact-registry.ts`,
`scripts/verify-process-fact-contract.mjs`, `docs/validation-performance.md`, and
`experiments/five-item-proof/quorum-plan-controls.mjs`. No scheduler, lock,
resource, capacity, `validation-execution-lock` or `story-aware-validation` file
appears. Sibling validation commands remain blocked exactly as before.

**The caveat that survives.** The ticket's *capacity model* loses fidelity: a
ticket sized for one command now covers up to four concurrent git-heavy child
workloads. That is a measurement-interpretation issue (paired wall-clock numbers
are only comparable under comparable machine load), not a serialization
violation. It is the accurate residue of the earlier report's concern.

## A2 — CONFIRMED and strengthened: 13 noncontiguous stateful cases

Confirmed, and now corroborated mechanically rather than by reading. Using the
TypeScript AST (`shared-state-independence-check.mjs`), the set of cases making a
*free* reference to the one top-level fixture (`root` / `store` / `registry` /
`result`) is **exactly** the 13 registered as `group: 'ordered-quorum-state'` —
Q017, Q018, Q019, Q020, Q022, Q023, Q024, Q025, Q026, Q027, Q029, Q030, Q050 —
and **no** singleton-group case makes such a reference
(`shared-state-independence.json`). Noncontiguity is real: Q021 and Q028
interleave the run, and both use isolated fixtures.

One false positive had to be cleared first: Q040 initially appeared to reference
the shared `store`. It does not. The only non-property occurrence is the type
qualifier in `as typeof fixture.store.appendProcessEvent`, which the TypeScript
AST models as a `QualifiedName` inside a TypeQuery, not a value reference. The
analyzer was corrected and re-run.

## A3 — CONFIRMED as fixed: the empty `--grep` fail-open

The earlier finding was correct and is now closed. A `--grep` matching nothing
refuses instead of reporting a passing suite over zero checks:

```
$ node packages/main/dist/tasks/quorum-submit-smoke.js --grep=LAB_INTENTIONALLY_UNKNOWN_CASE_734920
AssertionError: EMPTY_QUORUM_SELECTION            exit=1
```

Separately, the two markers are now distinguishable: a selected run prints
`QUORUM_DIAGNOSTIC_SELECTION_PASSED (N checks)` and never the full-suite line
`✓ quorum_submit smoke passed (N checks)`.

## A4 — NEW: the equivalence report's digests are source-text digests, not the gate's runtime digests

Not an error in the report (its `method` line does say "TypeScript callback
text"), but it must not be misread. `quorum-callback-equivalence.json` digests
are `sha256` of the **TypeScript source** callback text. The digests the
implementation actually compares across shards are `sha256(fn.toString())` of the
**compiled** function. All 73 differ between the two domains — e.g. Q001 live
`6b86637b…` vs reported `10c02944…`. Both were verified self-consistent; see the
main report, section "Callback equivalence".
