// Independent verification of the quorum callback-equivalence claim.
// Does NOT read quorum-callback-equivalence.json as evidence; it only compares
// against it at the end. Sources of truth: the current TypeScript AST at HEAD,
// the TypeScript AST at base commit b514122aa1 (via `git show`), and the LIVE
// runtime manifest emitted by `--list-cases`.
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFileSync, writeFileSync, existsSync} from 'node:fs';
import {createRequire} from 'node:module';
import {join} from 'node:path';

const REPO = '/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-quorum-paired-zqqmt720/repo';
const OUT = '/Users/jek/.codex/artifacts/proof-or-stop-five-item-final-closure-20260909/claude-quorum-implementation';
const ART = '/Users/jek/.codex/artifacts/proof-or-stop-five-item-final-closure-20260909';
const BASE = 'b514122aa1';
const REL = 'packages/main/src/tasks/quorum-submit-smoke.ts';

const require_ = createRequire(import.meta.url);
let ts = null, tsFrom = null;
for (const p of [join(REPO, 'node_modules/typescript'), join(REPO, 'packages/main/node_modules/typescript')]) {
  if (existsSync(p)) { ts = require_(p); tsFrom = p; break; }
}
if (!ts) throw new Error('typescript not resolvable; AST verification impossible');

const sha = (s) => createHash('sha256').update(s).digest('hex');

function extract(text, label) {
  const sf = ts.createSourceFile(label, text, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS);
  const out = [];
  const visit = (node) => {
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'check') {
      const args = node.arguments;
      const fn = args[args.length - 1];
      const lits = args.slice(0, -1).filter(ts.isStringLiteralLike).map((a) => a.text);
      out.push({
        arity: args.length,
        id: args.length === 3 ? lits[0] : null,
        name: args.length === 3 ? lits[1] : lits[0],
        body: fn.getText(sf),
      });
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return out;
}

const headText = readFileSync(join(REPO, REL), 'utf8');
const baseText = execFileSync('git', ['-C', REPO, 'show', `${BASE}:${REL}`], {encoding: 'utf8', maxBuffer: 64 * 1024 * 1024});
const head = extract(headText, 'head.ts');
const base = extract(baseText, 'base.ts');

const problems = [];
const eq = (label, a, b) => { if (a !== b) problems.push(`${label}: ${JSON.stringify(a)} !== ${JSON.stringify(b)}`); };
eq('head case count', head.length, 73);
eq('base case count', base.length, 73);
eq('head arity all 3', head.every((c) => c.arity === 3), true);
eq('base arity all 2', base.every((c) => c.arity === 2), true);

// 1. Callback bodies byte-for-byte identical, matched by POSITION and by NAME.
const byName = new Map(base.map((c) => [c.name, c]));
const bodyChanged = [], nameOrderChanged = [], missingInBase = [];
head.forEach((c, i) => {
  if (c.name !== base[i]?.name) nameOrderChanged.push({index: i, head: c.name, base: base[i]?.name ?? null});
  const b = byName.get(c.name);
  if (!b) { missingInBase.push(c.name); return; }
  if (b.body !== c.body) bodyChanged.push({name: c.name, headSha: sha(c.body), baseSha: sha(b.body)});
});

// 2. IDs are Q001..Q073 in registration order, unique.
const ids = head.map((c) => c.id);
const idsExpected = ids.every((id, i) => id === 'Q' + String(i + 1).padStart(3, '0'));
eq('ids are Q001..Q073 in order', idsExpected, true);
eq('ids unique', new Set(ids).size, ids.length);

// 3. Registry names/ids match the AST exactly.
const reg = JSON.parse(execFileSync('node', ['-e',
  "import('" + join(REPO, 'packages/main/dist/tasks/quorum-case-registry.js') + "').then(m=>console.log(JSON.stringify(m.QUORUM_CASES)))",
], {encoding: 'utf8'}));
eq('registry length', reg.length, 73);
const regMismatch = reg.filter((r, i) => r.id !== head[i].id || r.name !== head[i].name);
eq('registry == AST (id,name,order)', regMismatch.length, 0);
const atomic = reg.filter((r) => r.group === 'ordered-quorum-state').map((r) => r.id);
const expectedAtomic = ['Q017','Q018','Q019','Q020','Q022','Q023','Q024','Q025','Q026','Q027','Q029','Q030','Q050'];
eq('atomic group membership', JSON.stringify(atomic), JSON.stringify(expectedAtomic));
const singletons = reg.filter((r) => r.group !== 'ordered-quorum-state' && r.group !== r.id);
eq('all non-atomic groups are singleton==id', singletons.length, 0);

// 4. LIVE runtime manifest (--list-cases, executed separately) vs the report's digests.
const liveLine = readFileSync(join(OUT, 'live-manifest.txt'), 'utf8').split('\n').find((l) => l.startsWith('QUORUM_CASE_MANIFEST:'));
const live = JSON.parse(liveLine.slice('QUORUM_CASE_MANIFEST:'.length));
eq('live manifest length', live.length, 73);
const liveVsReg = live.filter((c, i) => c.id !== reg[i].id || c.name !== reg[i].name || c.group !== reg[i].group);
eq('live manifest == registry', liveVsReg.length, 0);

const report = JSON.parse(readFileSync(join(ART, 'quorum-callback-equivalence.json'), 'utf8'));
const reportDigests = new Map(report.bodyDigests.map((d) => [d.id, d.digest]));
const digestMismatch = live.filter((c) => reportDigests.get(c.id) !== c.bodyDigest)
  .map((c) => ({id: c.id, live: c.bodyDigest, report: reportDigests.get(c.id) ?? null}));

// 5. The developer's original-callback artifact, compared against MY base extraction.
let originalArtifact = {status: 'absent'};
const origPath = join(ART, 'quorum-original-callbacks.json');
if (existsSync(origPath)) {
  const raw = JSON.parse(readFileSync(origPath, 'utf8'));
  const arr = Array.isArray(raw) ? raw : (raw.cases ?? raw.callbacks ?? raw.entries ?? null);
  if (!arr) originalArtifact = {status: 'unrecognized-shape', topLevelKeys: Object.keys(raw)};
  else {
    const mine = new Map(base.map((c) => [c.name, c.body]));
    const bad = arr.filter((e) => {
      const name = e.name ?? e.case ?? e.title;
      const body = e.body ?? e.callback ?? e.text ?? e.source;
      if (body === undefined) return false;
      return mine.get(name) !== body;
    }).map((e) => e.name ?? e.case ?? e.title);
    originalArtifact = {status: 'compared', entries: arr.length, sampleKeys: Object.keys(arr[0] ?? {}), mismatchedAgainstMyBaseExtraction: bad};
  }
}

const summary = {
  verifier: 'independent-callback-verify.mjs (Claude audit)',
  typescriptFrom: tsFrom, tsVersion: ts.version, baseCommit: BASE,
  headCommit: execFileSync('git', ['-C', REPO, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
  astCases: {head: head.length, base: base.length},
  callbackBodiesChanged: bodyChanged,
  callbackOrderOrNameChanged: nameOrderChanged,
  casesMissingInBase: missingInBase,
  registryVsAstMismatch: regMismatch,
  liveManifestVsRegistryMismatch: liveVsReg,
  liveDigestVsReportedDigestMismatch: digestMismatch,
  atomicGroup: atomic,
  developerOriginalCallbackArtifact: originalArtifact,
  structuralProblems: problems,
  verdict: (problems.length === 0 && bodyChanged.length === 0 && nameOrderChanged.length === 0
    && missingInBase.length === 0 && digestMismatch.length === 0
    && (originalArtifact.mismatchedAgainstMyBaseExtraction ?? []).length === 0)
    ? 'INDEPENDENTLY_CONFIRMED: 73/73 callback bodies byte-identical to base; live digests equal reported digests'
    : 'DISCREPANCY',
};
writeFileSync(join(OUT, 'independent-callback-verification.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({...summary, atomicGroup: atomic.length + ' members'}, null, 2));
