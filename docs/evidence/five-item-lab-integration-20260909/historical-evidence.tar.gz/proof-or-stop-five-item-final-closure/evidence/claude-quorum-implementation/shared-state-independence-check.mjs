// (a) Determine which digest domain quorum-callback-equivalence.json uses.
// (b) Mechanically test the hand-authored `group` field: does any case registered
//     as its own singleton group make a FREE reference to the shared top-level
//     fixture bindings (root / store / registry / result)? Those are exactly the
//     bindings that make a case order-dependent, and the only thing that keeps a
//     shard's starting state equal to the serial starting state.
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFileSync, writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {join} from 'node:path';

const REPO = '/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-quorum-paired-zqqmt720/repo';
const OUT = '/Users/jek/.codex/artifacts/proof-or-stop-five-item-final-closure-20260909/claude-quorum-implementation';
const ART = '/Users/jek/.codex/artifacts/proof-or-stop-five-item-final-closure-20260909';
const REL = 'packages/main/src/tasks/quorum-submit-smoke.ts';
const ts = createRequire(import.meta.url)(join(REPO, 'node_modules/typescript'));
const sha = (s) => createHash('sha256').update(s).digest('hex');

const headText = readFileSync(join(REPO, REL), 'utf8');
const sf = ts.createSourceFile('head.ts', headText, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS);
const cases = [];
(function visit(node) {
  if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'check') {
    const a = node.arguments;
    cases.push({id: a[0].text, name: a[1].text, fn: a[a.length - 1]});
  }
  ts.forEachChild(node, visit);
})(sf);

// --- (a) digest domain -------------------------------------------------------
const report = JSON.parse(readFileSync(join(ART, 'quorum-callback-equivalence.json'), 'utf8'));
const reportDigest = new Map(report.bodyDigests.map((d) => [d.id, d.digest]));
const orig = JSON.parse(readFileSync(join(ART, 'quorum-original-callbacks.json'), 'utf8'));
const origArr = Array.isArray(orig) ? orig : (orig.cases ?? orig.callbacks ?? orig.entries);
const origBody = new Map(origArr.map((e) => [e.id ?? e.name, e.body]));
const origDigest = new Map(origArr.map((e) => [e.id ?? e.name, e.digest]));
const headBody = new Map(cases.map((c) => [c.id, c.fn.getText(sf)]));

const domain = {
  reportDigest_equals_sha256_of_originalArtifactBody: cases.every((c) => reportDigest.get(c.id) === sha(origBody.get(c.id))),
  reportDigest_equals_originalArtifactDigestField: cases.every((c) => reportDigest.get(c.id) === origDigest.get(c.id)),
  reportDigest_equals_sha256_of_currentHeadSourceBody: cases.every((c) => reportDigest.get(c.id) === sha(headBody.get(c.id))),
  originalArtifactBody_equals_currentHeadSourceBody: cases.every((c) => origBody.get(c.id) === headBody.get(c.id)),
  sample: {id: 'Q001', sha256OfHeadSourceBody: sha(headBody.get('Q001')), reported: reportDigest.get('Q001')},
};

// --- (b) free references to shared fixture bindings ---------------------------
const SHARED = new Set(['root', 'store', 'registry', 'result']);
const reg = JSON.parse(execFileSync('node', ['-e',
  "import('" + join(REPO, 'packages/main/dist/tasks/quorum-case-registry.js') + "').then(m=>console.log(JSON.stringify(m.QUORUM_CASES)))",
], {encoding: 'utf8'}));
const groupOf = new Map(reg.map((r) => [r.id, r.group]));

function freeSharedRefs(fnNode) {
  const bound = new Set();
  const hits = new Set();
  (function collectBindings(n) {
    if (ts.isParameter(n) && ts.isIdentifier(n.name)) bound.add(n.name.text);
    if (ts.isVariableDeclaration(n) && ts.isIdentifier(n.name)) bound.add(n.name.text);
    if (ts.isBindingElement(n) && ts.isIdentifier(n.name)) bound.add(n.name.text);
    ts.forEachChild(n, collectBindings);
  })(fnNode);
  (function walk(n, parent) {
    if (ts.isIdentifier(n) && SHARED.has(n.text) && !bound.has(n.text)) {
      const isPropName = parent && ts.isPropertyAccessExpression(parent) && parent.name === n;
      // `typeof fixture.store.appendProcessEvent` is a TypeQuery whose entity name is a
      // QualifiedName, NOT a PropertyAccessExpression: `store` there is a type qualifier, not a
      // free value reference. Without this the analyzer reports a false positive on Q040.
      const isQualified = parent && ts.isQualifiedName(parent);
      const isKey = parent && (ts.isPropertyAssignment(parent) || ts.isShorthandPropertyAssignment(parent)) && parent.name === n;
      if (!isPropName && !isKey && !isQualified) hits.add(n.text);
    }
    ts.forEachChild(n, (child) => walk(child, n));
  })(fnNode, undefined);
  return [...hits].sort();
}

const rows = cases.map((c) => ({id: c.id, group: groupOf.get(c.id), sharedRefs: freeSharedRefs(c.fn)}));
const atomic = rows.filter((r) => r.group === 'ordered-quorum-state');
const singletonsTouchingShared = rows.filter((r) => r.group !== 'ordered-quorum-state' && r.sharedRefs.length > 0);
const atomicWithoutShared = atomic.filter((r) => r.sharedRefs.length === 0);

const summary = {
  digestDomain: domain,
  atomicGroupSize: atomic.length,
  atomicMembersWithNoSharedRef: atomicWithoutShared.map((r) => ({id: r.id})),
  singletonGroupsWithFreeSharedFixtureRefs: singletonsTouchingShared,
  interpretation:
    'A singleton-group case that freely references root/store/registry/result reads or mutates the ONE top-level fixture. '
    + 'Serial execution gives it the accumulated state of every earlier case; under --jobs>=2 it gets whatever its own shard accumulated. '
    + 'The registry group field is hand-authored and nothing mechanically enforces this correspondence.',
};
writeFileSync(join(OUT, 'shared-state-independence.json'), JSON.stringify({...summary, allRows: rows}, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
