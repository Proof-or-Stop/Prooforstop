# Independent audit — bounded probe pool for `proofstory-acceptance-basis-smoke.ts`

**Verdict: APPROVED** (conditional on one required hardening the caller has already planned, plus two should-fix evidence assertions listed below). Read-only audit; nothing was edited, built, or committed.

Inputs compared:
- Lab source: `.worktrees/Lab-five-item-proof-20260908/packages/main/src/tasks/proofstory-acceptance-basis-smoke.ts` (1672 lines)
- Candidate: `~/.codex/artifacts/.../acceptance-basis-parallel-candidate.ts` (1695 lines)

## 1. Change is bounded

`diff -u` yields exactly three hunks, 65 diff lines:

1. imports: `+ execFile`, `+ promisify` (`execFileSync` retained and still used by `run()`, `git()`, and the contract-mutation block).
2. header: `--probe-jobs=[1-4]` argv parse + `execFileAsync`.
3. the forbidden-field double loop (source lines 1462–1473) replaced by the worker pool.

No other line in the file differs. Every other assertion in the smoke — including the `output replay rejection is atomic` check immediately after the block and the trailing `console.log('ProofStory acceptance coverage basis Wave 1A smoke passed')` — is byte-identical. **Allowed scope confirmed: the change is confined to the 58-probe block and its two enabling declarations.**

## 2. The four retained obligations — verified present

| Obligation | Evidence in candidate |
|---|---|
| Actual CLI rejection, per row | `execFileAsync(process.execPath, [cliPath, '--root', root, command, JSON.stringify(...)])` + `assert.match(forged, /Forbidden\|never\|invalid\|expected\|unsupported caller fields/i, ...)` — same binary, same regex, same message |
| Direct handler rejection, per row | `assert.throws(() => directHandlers[command]({...}), /unsupported caller fields/, ...)` — unchanged |
| `fullSnapshot()` atomicity, per row | both post-CLI and post-direct-handler `assert.deepEqual(fullSnapshot(), snapshot, ...)` retained, same frozen `snapshot` baseline |
| Exact 58 inventory | `forbiddenFields` has **29 keys**, × 2 commands = **58**; `completedProbes` is compared (sorted) against the full probe list, so every row must complete exactly once |

Env/exec parity with `run(..., allowFailure=true)`: same `cwd`, same `env` (`PROOF_OR_STOP_SESSION_ID`, `PROOF_OR_STOP_AGENT`), same `encoding`, same failure composition `stdout+stderr+message`. `stdio:['pipe','pipe','pipe']` is dropped but that is `execFile`'s default, so it is equivalent. Two real deltas: **`timeout: 30000` and `maxBuffer: 8MB` are new** (`execFileSync` here had neither; `maxBuffer` default is 1 MB for both, so 8 MB is a loosening — harmless here, the probes emit short rejections).

## 3. Direct-handler behaviour and schema-guard order — safe under concurrency

`src/handlers/proofstory.ts`:
- `acceptance_basis_generate(args): string` declared at line 614, first statement line 615: `rejectBasisWriteShape(args, ['storyId','json'])`.
- `acceptance_basis(args): string` declared at line 660, first statement line 661: same guard.
- `rejectBasisWriteShape` (481–486) is pure: it filters `Object.keys(args)` and throws `acceptance basis requests are verifier-derived; unsupported caller fields: ...`. No store read, no git, no FS.

Both handlers are **synchronous** and the guard is the **first** statement, so a forbidden-field call throws before any I/O. Consequently: (a) the direct-handler probe cannot interleave with anything (Node is single-threaded and the call never yields), (b) it cannot observe a partially-written fixture, (c) it cannot itself produce a side effect. `assert.throws` remains deterministic at any `probeJobs`. The rejection path also never reaches `autoCommitStoryMetadata` (line 646), so no probe can move HEAD.

No CLI-level lock or startup FS write exists on the entry path (`src/cli.ts`, `src/cli-engine.ts`, `src/cli/runtime-root.ts`, `src/cli/activity-policy.ts` show no `writeFileSync`/`appendFileSync`/`mkdirSync`, and no lockfile acquisition outside the unrelated build mutex in `command-catalog.ts`). So concurrent invocations introduce no new lock-contention error class at the CLI layer.

Top-level `await` compiles: `packages/main/package.json` is `"type":"module"`, tsconfig is `module: Node16`, `target: ES2022`. A rejection during module evaluation still exits non-zero, so RED remains RED.

## 4. Can concurrency hide side effects, silently accept errors, change authority evidence, or produce false GREEN?

**Hidden side effects — no.** All 116 in-loop `deepEqual` calls compare against the same pre-loop frozen `snapshot`, and the untouched `output replay rejection is atomic` assertion after the pool compares against it again. Any *persistent* mutation by any probe is therefore still caught. Parallelism is strictly *more* sensitive to transient artifacts (a checkpoint can now fire while another probe's child is mid-flight), so it biases toward false RED, not false GREEN.

**Silently accepted errors — one real vector, and it is the one the caller already plans to close.** The `catch` composes `forged` from `stdout+stderr+message` for *every* failure class, including `ETIMEDOUT`/`killed`/spawn error, and only then applies a loose regex. A bare timeout is safe by luck (`error.message` is `Command failed: <node> <cli.js> --root /tmp/proofstory-basis-cli-XXXX <command> {...}`; I checked all 29 field names and their values — `complete`, `forged`, `sha256:0…`, `receipt:forged`, `{}`, `[]`, `pass` — none contains `Forbidden|never|invalid|expected`). But **partial stdout on a killed child is not safe**: this same CLI legitimately emits `"status": "invalid"` on the read path (the smoke asserts exactly that string at the late-C2 check ~line 1447). A probe whose child is killed after emitting diagnostic JSON but before completing would match `/invalid/i` and pass without ever proving the forbidden-field guard fired. The new 30 s timeout makes this class newly reachable. **The caller's planned explicit `killed`/`ETIMEDOUT`/spawn-error rejection *before* evaluating the expected forbidden-field output is required, not optional.** With it in place, this vector closes.

**Authority evidence — preserved, with one semantic caveat.** Every row still produces one real CLI-process rejection and one in-process handler rejection; nothing is substituted or memoized. The caveat is attribution: at `probeJobs>1` the message `"${command} ${field} rejection is atomic"` no longer means "row *i* wrote nothing" — it means "aggregate fixture state was unchanged at the moment row *i* finished, while up to 3 other children were in flight." Detection is preserved, per-row attribution is not. State this in the acceptance record rather than letting the message text stand as a per-row claim.

**Failures are not swallowed.** `probeFailures` is asserted empty (`assert.equal(probeFailures.length, 0, joined)`) *before* the inventory assertion, and a thrown `git()`/`bytes()` inside `fullSnapshot()` is caught by the same outer `catch` and surfaces there. The behavioural delta is fail-fast → aggregate: after a first failure the remaining probes still run against a possibly-mutated fixture, so downstream messages may be noise. Acceptable; the first joined message is still the signal.

**Residual flakiness (false RED, not false GREEN):** `fullSnapshot()` runs `git status --porcelain` in the shared root. The smoke's own `git` calls are `execFileSync` and thus self-serialized, but a CLI child that touches git concurrently can contend on `index.lock`. `git()` has no `allowFailure`, so this throws loudly. This is the main reason a `jobs=4` run needs a repeated full-run proof before the value is changed in real config.

## 5. `fullSnapshot` scope (pre-existing; unchanged by this change)

It covers six byte digests (`index.json`, `checklist.json`, `proofstory.json`, `scope-contract.json`, `acceptance-basis.json`, `process-events.jsonl`) plus `git status --porcelain`. It does **not** cover `evidence/acceptance-basis.json`, decisions/receipts stored elsewhere, or gitignored paths; and `git status --porcelain` does not reveal HEAD movement, so a commit would leave it clean. "Atomic" here means "those six files and worktree/index cleanliness are unchanged", not "nothing happened". Untracked new files *are* caught. This is identical in both versions and the guard-first ordering means the probes cannot reach the commit path anyway. **Strengthening `fullSnapshot` (e.g. adding `head: git(root,['rev-parse','HEAD'])`) is outside the allowed scope** — it is shared by other assertions, which must remain unchanged. Track separately.

## 6. Minimal fixes recommended (not implemented)

1. **Required** — reject `killed`/`ETIMEDOUT`/`signal`/spawn errors explicitly before the `assert.match`, so a partially-emitted diagnostic can never satisfy the loose regex. (Caller already plans this.)
2. **Should fix** — the inventory assertion is self-derived: `completedProbes` is compared to `probes.map(...)`, both built from the same array, so a silently shrunken `forbiddenFields` still passes while the new `ACCEPTANCE_FORBIDDEN_FIELD_COVERAGE` line reads like an inventory proof. Add `assert.equal(probes.length, 58, ...)`.
3. **Should fix** — `peakProbes` is logged but never asserted, so a run that degenerates to serial is indistinguishable from a genuine 4-way run. If that log line is to serve as the equivalence evidence for enabling 4, add `assert.ok(probeJobs === 1 || peakProbes > 1, ...)`.
4. **Verify (low risk)** — the new `assert.ok(...,'INVALID_ACCEPTANCE_PROBE_JOBS')` hard-fails on any unexpected argv. The registered invocations (`package.json:51`, `proof-or-stop.config.json:2284`) pass no arguments, but any wrapper forwarding `--` args would now break.

## 7. Scope and claims discipline

- Default is `probeJobs=1`; at that setting behaviour is equivalent to the current loop except for the new timeout/maxBuffer and aggregate-vs-fail-fast reporting. **Approval covers landing the candidate with the serial default.**
- Setting `4` in real config is **not** approved by this audit: it requires an equivalent full-run GREEN proof (repeated, to expose the `index.lock` contention window) plus fix 3 so the run can be shown to have actually been concurrent.
- No whole-Story speedup may be inferred from this change. What is saved is 58 sequential Node process startups within one block of one task; that says nothing about total Story runtime, which is dominated by other work. Any timing claim must come from a measured full run, paired, not from startup arithmetic.
