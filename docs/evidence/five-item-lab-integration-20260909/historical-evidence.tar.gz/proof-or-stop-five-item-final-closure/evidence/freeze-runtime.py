from pathlib import Path
import sys, tempfile, subprocess, json
source=Path(sys.argv[1]); out=Path(sys.argv[2]); tag=sys.argv[3]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
repo=Path(tempfile.mkdtemp(prefix='pos-frozen-'+tag+'-'))/'repo'
subprocess.run(['git','clone','--shared','--no-checkout',str(source),str(repo)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
subprocess.run(['git','checkout','--detach',head],cwd=repo,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
baseline=sys.argv[4] if len(sys.argv)>4 else 'cf21df09c273074d7aa3227a5f436c6f5badf47a'
main=subprocess.check_output(['git','rev-parse',baseline],cwd=source,text=True).strip()
if subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/main'],cwd=repo).returncode!=0:
 subprocess.run(['git','branch','main',main],cwd=repo,check=True,stdout=subprocess.DEVNULL)
assert subprocess.check_output(['git','rev-parse','main'],cwd=repo,text=True).strip()==main
subprocess.run(['git','worktree','add',str(repo.parent/'baseline-authority'),'main'],cwd=repo,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
for rel in ['node_modules','packages/main/node_modules','packages/utils/node_modules','packages/graph/node_modules','packages/main/dist','packages/utils/dist','packages/graph/dist','packages/lab/dist','packages/lab/node_modules']:
 p=source/rel
 if p.exists():
  (repo/rel).parent.mkdir(parents=True,exist_ok=True)
  subprocess.run(['/bin/cp','-cR',str(p),str(repo/rel)],check=True)
out.write_text(json.dumps({'path':str(repo),'head':head,'main':main,'independentWritableDist':True,'copyMethod':'APFS clone-on-write; no mutable runtime symlinks'},indent=2)+'\n')
print(str(repo),flush=True)
