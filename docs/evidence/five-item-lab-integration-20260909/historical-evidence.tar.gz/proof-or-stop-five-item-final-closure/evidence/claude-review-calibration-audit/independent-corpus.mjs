// Independent exhaustive small-domain corpus.
// Oracles below were written by the auditor directly from before/CONTRACT.md,
// without consulting score-reviews.mjs's `spec` block or after/protocol.mjs.
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {writeFileSync} from 'node:fs';

const PK = '/Users/jek/.codex/artifacts/proof-or-stop-five-item-final-closure-20260909/review-benchmark';
const before = await import(pathToFileURL(join(PK, 'before/protocol.mjs')));
const after = await import(pathToFileURL(join(PK, 'after/protocol.mjs')));

const eq = (a, b) => { try { assert.deepEqual(a, b); return true; } catch { return false; } };
const lists = (alpha, maxLen) => { let out = [[]]; let cur = [[]];
  for (let n = 0; n < maxLen; n++) { cur = cur.flatMap(p => alpha.map(a => [...p, a])); out = out.concat(cur); }
  return out; };

// ---- auditor oracles, transcribed from CONTRACT.md prose ----
const O = {
  isReusable: (r, c) => r.version === c.version && r.implementationDigest === c.implementationDigest,
  hasWitness: (o, s) => o.split(s).length > 1,               // "selector occurs anywhere in the complete output"
  renewLease: (l, o, g, n) => (l.owner === o && l.generation === g) ? {...l, heartbeat: n} : null,
  mayPublish: (r, x) => r.status === 'pass' && x === 0,
  uniqueClaims: cs => { const out = []; for (const c of cs)
      if (!out.some(d => d.key === c.key && d.access === c.access && d.ownership === c.ownership)) out.push(c);
    return out; },
  historyExtends: (b, a) => b.length <= a.length && b.every((x, i) => x === a[i]),
  finalAdmission: c => c.fresh === true && c.kind === 'final',
  coversExactly: (req, sh) => { const flat = sh.flat();
    for (const id of flat) if (!req.includes(id)) return false;
    return req.every(id => flat.filter(y => y === id).length === 1); },
  mayShare: c => c.optIn && c.inputsKnown && !c.build,
  mayOverlap: (a, b) => { if (!a.known || !b.known) return false;
    if (a.key !== b.key) return true;
    return !(a.access === 'exclusive' || b.access === 'exclusive'); },
};

// ---- exhaustive in-domain case generation ----
const cases = {};
const V = ['v1', 'v2'], D = ['d1', 'd2'];
cases.isReusable = V.flatMap(a => D.flatMap(b => V.flatMap(c => D.map(d =>
  [{version: a, implementationDigest: b}, {version: c, implementationDigest: d}]))));

const S3 = lists(['a', 'b'], 3).map(x => x.join(''));
cases.hasWitness = S3.flatMap(o => S3.filter(s => s.length > 0).map(s => [o, s]));

cases.renewLease = ['o1', 'o2'].flatMap(lo => [1, 2].flatMap(lg => [0, 5].flatMap(hb =>
  ['o1', 'o2'].flatMap(co => [1, 2].flatMap(cg => [hb, hb + 7].map(now =>
    [{owner: lo, generation: lg, heartbeat: hb, tag: 'keep-me', nested: {k: 1}}, co, cg, now]))))));

cases.mayPublish = ['pass', 'fail'].flatMap(s => [0, 1, 2, 255].map(x => [{status: s, note: 'n'}, x]));

const CLAIMS = [
  {key: 'k1', access: 'shared', ownership: 'external'},
  {key: 'k1', access: 'shared', ownership: 'runner-cleanable'},
  {key: 'k1', access: 'exclusive', ownership: 'external'},
  {key: 'k2', access: 'shared', ownership: 'external'},
];
cases.uniqueClaims = lists(CLAIMS, 3).map(x => [x]);

const H = lists(['a', 'b'], 3);
cases.historyExtends = H.flatMap(b => H.map(a => [b, a]));

cases.finalAdmission = [true, false].flatMap(f => ['final', 'remediation'].map(k => [{fresh: f, kind: k}]));

const REQ = [['a'], ['b'], ['a', 'b'], ['a', 'b', 'c']];
const SHARDS = lists(lists(['a', 'b', 'x'], 2), 2);
cases.coversExactly = REQ.flatMap(r => SHARDS.map(s => [r, s]));

cases.mayShare = [true, false].flatMap(o => [true, false].flatMap(i => [true, false].map(b =>
  [{optIn: o, inputsKnown: i, build: b}])));

const RES = [true, false].flatMap(k => ['k1', 'k2'].flatMap(key => ['shared', 'exclusive'].map(acc =>
  ({known: k, key, access: acc}))));
cases.mayOverlap = RES.flatMap(a => RES.map(b => [a, b]));

// ---- evaluate ----
const report = {};
for (const fn of Object.keys(O)) {
  const cs = cases[fn];
  const row = {cases: cs.length, beforeMismatches: 0, afterMismatches: 0,
               firstBeforeCounterexample: null, firstAfterCounterexample: null};
  for (const args of cs) {
    const want = O[fn](...structuredClone(args));
    const gotB = before[fn](...structuredClone(args));
    const gotA = after[fn](...structuredClone(args));
    if (!eq(gotB, want)) { row.beforeMismatches++;
      row.firstBeforeCounterexample ??= {args, expected: want, actual: gotB}; }
    if (!eq(gotA, want)) { row.afterMismatches++;
      row.firstAfterCounterexample ??= {args, expected: want, actual: gotA}; }
  }
  report[fn] = row;
}
const summary = {
  totalCases: Object.values(report).reduce((s, r) => s + r.cases, 0),
  beforeDefectiveFunctions: Object.keys(report).filter(f => report[f].beforeMismatches > 0).sort(),
  afterDefectiveFunctions: Object.keys(report).filter(f => report[f].afterMismatches > 0).sort(),
  perFunction: report,
};
writeFileSync(join(import.meta.dirname, 'independent-corpus-results.json'),
  JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({
  totalCases: summary.totalCases,
  beforeDefectiveFunctions: summary.beforeDefectiveFunctions,
  afterDefectiveFunctions: summary.afterDefectiveFunctions,
  perFunction: Object.fromEntries(Object.entries(report).map(([k, v]) =>
    [k, {cases: v.cases, before: v.beforeMismatches, after: v.afterMismatches}])),
  sampleBeforeCounterexamples: Object.fromEntries(Object.entries(report)
    .filter(([, v]) => v.firstBeforeCounterexample)
    .map(([k, v]) => [k, v.firstBeforeCounterexample])),
}, null, 2));
