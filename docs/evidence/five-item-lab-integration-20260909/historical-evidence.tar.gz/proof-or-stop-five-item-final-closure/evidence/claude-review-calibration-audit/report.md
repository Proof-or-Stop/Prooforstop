# Independent audit — Claude CLI review-policy calibration & execution identity

Auditor: independent Claude Opus 5 session, 2026-09-09. Read-only over the campaign artifacts;
all writes confined to `claude-review-calibration-audit/`. No source, runtime, Story or Git mutation.
No subagents, no builds, no re-run of the long review benchmark.

Artifacts produced here: `report.md`, `independent-corpus.mjs`,
`independent-corpus-results.json`, `replay/` (sandboxed scorer replay).

---

## 1. Verdict

**GREEN — execution integrity.** All 20 reviewer executions really ran and really finished; the
identity handshake is genuine, strict, and enforced; source packets were not mutated; the scorer is
bit-for-bit reproducible; and the substantive correctness result (8/8 known defects found by
executable witness, 0 false positives, 0 findings against fixed code) survives independent
re-derivation from a corpus I wrote myself.

**RED — the RED-vs-GREEN wallclock framing.** `442.139s` vs `267.097s` is **not** a treatment
contrast. The two arms are procedurally identical; RED simply runs one extra wave. The number is a
reviewer-budget difference, not a calibration or capability gain, and its residual is inside
same-configuration noise.

**RED — pre-registration of the scoring oracle.** The defect list, arms, roles, runtime digest and
criteria were fixed before the first run. `score-reviews.mjs` was not: its oracles and domain gates
were authored after 19 of the 20 reviewer outputs were on disk.

**AMBER — identity optimization magnitude.** Direction is supported (7/7 counterbalanced pairs,
sign-test p≈0.008); the `1.00949s → 0.86265s` magnitude is a single-machine point estimate whose
delta (0.147s) is ~7× smaller than the run-to-run spread I measured today on the same binary.

---

## 2. What I verified, and how

### 2.1 All 20 executions finished (GREEN)

`review-benchmark/runs/` contains exactly the pre-registered matrix — RED `first`/`extra`/`final`
and GREEN `first`/`final`, 4 roles each = **12 RED + 8 GREEN = 20** reviewer processes. Every row in
`wave-results.json` has `exitCode: 0`, `reportPresent: true`, `sourceUnchanged: true` and the
pre-registered `identityDigest`. Per-wave wallclock ≈ half the summed reviewer time, consistent with
the declared `max_workers=2`:

| arm | wave | wall (s) | Σ reviewer (s) | validated defect ids |
|---|---|---|---|---|
| RED | first | 126.7 | 242.9 | all 8 |
| RED | extra | 123.1 | 234.3 | all 8 |
| RED | final | 192.3 | 316.1 | — (none) |
| GREEN | first | 115.8 | 227.5 | all 8 |
| GREEN | final | 151.3 | 280.5 | — (none) |

Source pinning is real per wave: `first`/`extra` reviewers all saw sha `d08551c9cf43…` (the defective
`before/protocol.mjs`), `final` reviewers all saw `1f987efe4b91…` (`after/protocol.mjs`), and the
harness re-read the bytes after each review to set `sourceUnchanged`.

### 2.2 Failures would have stopped the campaign (GREEN, with one caveat)

The harness gate runs **inside** the wave loop, so a bad wave aborts the remaining waves. I
simulated the gate predicate against each failure mode:

```
all-good         -> CONTINUE
nonzero-exit     -> STOP
missing-report   -> STOP
no-identity      -> STOP     (identity.json absent/unparseable => key missing => != digest)
wrong-identity   -> STOP
source-mutated   -> STOP
```

Caveat (`run-review-benchmark.py:23`): the gate is a bare Python `assert`, so it is compiled out
under `python -O`. Same for the scorer's terminal `assert.ok(result.passed, …)`. Not a live defect —
the runs executed under a normal interpreter — but the stop guarantee is an interpreter-flag away
from silent, and an explicit `raise` would be strictly better.

### 2.3 Identity handshake — 21 participants, one byte-identical output (GREEN)

- All 20 reviewer `identity.json` files **plus** `owner-identity.json` hash to the *same* value:
  `b376c73bc032f1033d6c6fdf87a6b51fcde7b476b53806ef902a90a0d2dbcf4a` (213,931 bytes each). Not just
  the same `digest` field — the entire 1,659-entry file inventory is byte-identical across all 21.
- Content: `schema execution-implementation.v1`, `digest 6eb84016…` (matches
  `preregistered.runtimeDigest` and `pinned-cli.sh`), `packageVersion 0.3.284`, node `v26.8.1`,
  **`fileCount: 1659`**. *(Note: the working assumption of "1656-ish" is slightly off — the actual
  count is 1659, consistent across all 21 outputs, `identity-timing/results.json`, and my live
  re-run.)*
- Every one of the 20 stream logs contains an actual `pinned-cli.sh --implementation-identity` Bash
  invocation. All `identity.err` files are zero bytes.
- **Live negative test** (frozen runtime still present): with `REQUIRE_IMPLEMENTATION_PIN=1` and a
  deliberately wrong expected digest, the CLI exits **1** with
  `IMPLEMENTATION_PIN_MISMATCH: expected=0000… actual=6eb84016…` and writes **0 bytes** to stdout.
  The pin is a real gate, not a decorative env var.
- **Live positive test**: re-running `pinned-cli.sh --implementation-identity` today reproduces the
  identity output **byte-identically** (sha `b376c73b…`) — a 22nd independent confirmation.

**Defect (low severity, `run-review-benchmark.py:16-18`).** The harness's own gate only parses
`json.loads(identity.json)['digest']` and string-compares it. A reviewer that wrote
`{"digest":"6eb84016…"}` by hand — without executing the pinned CLI — would pass the gate. The
byte-identity above is far stronger evidence, but it is *my* check, not the harness's. Likewise
`score-reviews.mjs:39` computes `identityParticipants: 1 + reviews.length` — the owner's "+1" is
hardcoded; the scorer never opens `owner-identity.json`. The claim "21 participants share one
identity" is true (I checked it), but the campaign's own tooling only checks 20 of the 21.

### 2.4 Scorer replay and contract validation (GREEN)

I copied `score-reviews.mjs` and the two `protocol.mjs` files plus `wave-results.json` into
`replay/` and ran the scorer there (so it wrote its `scored-results.json` inside my audit
directory, leaving the original untouched — confirmed unchanged at 76,820 bytes / 05:56).
The replayed output is **identical** to the stored `scored-results.json`, including all 97 detail
records. `review-score.log` faithfully reflects it.

Reading the scorer against `CONTRACT.md` line by line, its `spec` oracles are correct and genuinely
re-phrased rather than copied from the candidate (`isReusable` via NUL-joined comparison,
`historyExtends` via `deepEqual(a, b.slice(0,a.length))`, `coversExactly` via an occurrence-count
Map, etc.), and the `domain` predicates faithfully encode the contract's stated input domains
(`hasWitness` output ≤1000 chars and nonempty selector; `renewLease` positive-integer generation and
`now >= heartbeat`; `mayPublish` exit integer 0..255; `coversExactly` nonempty distinct required).
It imports `node:assert/strict`, so `deepEqual` is strict. I found no way to smuggle a false positive
past it.

### 2.5 Independent counterexample replay and my own exhaustive corpus (GREEN)

- **Replay.** I extracted all 49 unique `(wave, function, args)` triples from the 97 findings and
  re-executed each through the packet's own `inspect.mjs` against the state that reviewer actually
  saw. **0 disagreements** with the scorer's recorded `actual` values, and no case where the observed
  behaviour matched the reviewer's `expected` (i.e. no finding was a mis-transcription).
- **My corpus** (`independent-corpus.mjs`). I transcribed all ten contracts into my own oracles
  directly from `CONTRACT.md` — deliberately phrased differently again (`hasWitness` via
  `split(s).length > 1`, `coversExactly` via unknown-ID rejection then per-ID occurrence count) —
  and enumerated **1,416 exhaustive in-domain cases** across all ten helpers.

  Result: `before/protocol.mjs` fails on exactly **8** functions (218 failing cases), and
  `after/protocol.mjs` fails on **0 of 1,416**. The defective set I derive independently is exactly
  the pre-registered `knownDefectFunctions`, and `mayShare`/`mayOverlap` are clean in **both**
  states — so the two clean controls are genuinely clean, not merely unflagged.

  | function | cases | before fails | after fails |
  |---|---|---|---|
  | isReusable | 16 | 4 | 0 |
  | hasWitness | 210 | 28 | 0 |
  | renewLease | 64 | 16 | 0 |
  | mayPublish | 8 | 3 | 0 |
  | uniqueClaims | 85 | 20 | 0 |
  | historyExtends | 225 | 106 | 0 |
  | finalAdmission | 4 | 1 | 0 |
  | coversExactly | 732 | 40 | 0 |
  | **mayShare** (control) | 8 | **0** | **0** |
  | **mayOverlap** (control) | 64 | **0** | **0** |

  This matters because of a real structural gap in the scorer: `score-reviews.mjs:34` only checks
  the fixed code (`assert.deepEqual(after[f](…), expected)`) **at argument vectors reviewers
  happened to submit**. `finalValidatedDefects: []` therefore means "no reviewer produced a witness
  against the fixed code," not "the fixed code is correct." My corpus supplies that missing check
  over the enumerated small domain — it is still not a proof over the unbounded domain (arbitrary
  strings, long arrays, non-integer numerics).

### 2.6 False positives and missed defects (GREEN)

- 97 findings total, **all 97 classified `validated_defect`**. Zero `outside_contract_domain`, zero
  `not_a_defect`, zero `incorrect_expected`.
- **Zero clean-control flags.** `mayShare` and `mayOverlap` were never reported by any of the 12
  reviewers who saw defective code — 24 opportunities to hallucinate, none taken.
- **Zero findings on fixed code.** All 8 final-wave reviewers returned `"findings": []` despite
  being told explicitly that "fixed final code still needs independent scrutiny, not automatic
  approval," and despite each actually running counterexamples against it (their
  `counterexamples.log` files are the *largest* in the campaign, 3.4–8.8 KB, showing genuine probing
  that simply found nothing).
- **Recall was saturated:** every individual reviewer found all 8 (one found 9 findings — a second
  argument vector for one function). There is no reviewer-level variance to analyse.
- I found no defect class in the defective packet that reviewers missed: my exhaustive corpus finds
  no ninth defective function, and no in-domain failure of the two controls.
- Isolation held: grep over all `first`/`extra` stream logs found no read of `after/`, no read of
  `preregistered.json`, and no other oracle access.

---

## 3. Concrete defects and methodological findings

### D1 — RED and GREEN are the same experiment; 442.139s vs 267.097s is a budget difference (RED)

`run-review-benchmark.py:5` sets `state = 'after' if wave=='final' else 'before'`. **`arm` is used
only as an output-path component.** I diffed a RED and a GREEN prompt for the same role: they differ
in exactly the output directory string. Same packet, same sha, same roles, same runtime, same
concurrency, same model, same instructions.

So the wallclock difference decomposes as:

```
RED   = 126.7 (first) + 123.1 (extra) + 192.3 (final) = 442.1s
GREEN = 115.8 (first)                 + 151.3 (final) = 267.1s
delta = 175.0s, of which 123.1s IS the extra wave itself
                and 51.9s is variance between identically-configured waves
```

That residual is not small: RED/first 126.7s vs GREEN/first 115.8s (+9%) and RED/final 192.3s vs
GREEN/final 151.3s (+27%) are the *same* configuration run twice. With n=1 wave per cell, the 51.9s
is noise, not signal.

The campaign's own data also shows the extra wave bought nothing: RED/first, RED/extra and
GREEN/first each independently validated the identical set of all 8 defects. **The honest claim is
"the third wave was redundant on this fixture," not "the after configuration is 40% faster."**

### D2 — Arm ordering is uncounterbalanced and fully confounded with time (RED)

The harness iterates `contract['arms']` in dict order, so all three RED waves (05:43–05:49) ran
strictly before both GREEN waves (05:49–05:54). Any drift — service latency, machine load, thermal
state, cache warmth — is perfectly confounded with arm. Notably, `benchmark-identity.py:16`
*does* counterbalance (`['RED','GREEN'] if pair%2 else ['GREEN','RED']`), so the technique was known
and simply not applied to the review arms.

### D3 — The scoring oracle is not pre-registered (RED)

Timeline by mtime:

```
05:40:47  preregistered.json, owner-identity.json     <- fixed before any run
05:42:09  run-review-benchmark.py
05:43:11  first reviewer execution.json
05:53:48  score-reviews.mjs                            <- authored after 19/20 runs
05:53:58  last reviewer execution.json, wave-results.json
05:56:00  scored-results.json, review-score.log
```

The *substance* of pre-registration held: the 8 defect ids, 2 controls, arm/wave layout, roles,
`maxConcurrentReviewers`, `runtimeDigest` and the 4 pass criteria were all committed before the
first reviewer ran. But the `spec` oracles and `domain` gates — the code that decides whether a
finding counts — were written with reviewer outputs already visible on disk. A domain gate authored
after seeing which arguments reviewers chose is exactly the knob that could launder a false positive
into a `validated_defect`.

Mitigation, and why I still call the correctness result GREEN: my §2.5 corpus was written from the
contract alone and reproduces the identical 8-defective / 2-clean partition, so the post-hoc scorer
is demonstrably not doing the work. Secondary weakness: pre-registration rests on mutable filesystem
mtimes — there is no VCS commit, content hash, or signed timestamp binding `preregistered.json` to a
point in time.

### D4 — Identity gate checks a string, not an execution (RED, low severity)

See §2.3. The harness accepts any `identity.json` whose `digest` field matches; the scorer never
inspects `owner-identity.json` at all and hardcodes the owner as participant #21. The claim survives
because I verified byte-identity across all 21 files and reproduced it live — but the campaign's
tooling does not verify what its summary asserts.

### D5 — Fixture difficulty is far below the claim surface (scope, not a defect)

Ten single-expression pure helpers, each with an exact written contract, an executable harness, and
planted defects that are single-clause omissions (`r.version===c.version` missing the digest
conjunct; `historyExtends` checking only length). Twelve of twelve reviewers scored 100%. This is a
ceiling measurement on a differential-testing task with a complete specification — it is much closer
to "does the reviewer run the oracle" than to code review. It supports no inference about multi-file
changes, I/O-bearing code, under-specified behaviour, or foreign-owner code.

---

## 4. Identity optimization — `1.00949s → 0.86265s` (AMBER)

**Scope is correctly stated and I confirm it.** `identity-timing/only-cli-difference.patch` is
exactly 2 hunks (the script asserts this), entirely inside `runCli`'s synchronous
`--implementation-identity` branch:

```diff
-    enforceExecutionImplementationPin();
+    const enforcedImplementationIdentity = enforceExecutionImplementationPin();
     if (process.argv.slice(2).includes('--implementation-identity')) {
-        console.log(JSON.stringify(executionImplementationIdentity()));
+        console.log(JSON.stringify(enforcedImplementationIdentity ?? executionImplementationIdentity()));
```

**Coverage is provably unchanged, not merely asserted.** `benchmark-identity.py` compares the two
modes' full identity outputs element-by-element and asserts `fileCount` equality plus exactly one
differing file entry. `results.json` confirms: `fileCount 1659` in both modes, and
`changedIdentityFiles` contains exactly one pair — `core/cli-engine.js`, i.e. the edited file's own
digest (`d660de3b…` → `ecbeee62…`). Since the RED output came from `executionImplementationIdentity()`
and the GREEN output came from the pin-enforcement result, that element-wise match is a direct
equivalence proof that the reused scan has the same inventory and the same per-file digests. This is
reuse of a scan already performed in the same process, not a cache and not a reduced inventory.

**The `??` fallback preserves the unpinned path.** When the pin is not required,
`enforceExecutionImplementationPin()` yields nothing and the code still calls
`executionImplementationIdentity()` for a fresh scan. I confirmed empirically on the frozen runtime
that pinned and unpinned invocations produce byte-identical output (both sha `b376c73b…`). The
optimization therefore applies **only** to the strict pinned handshake — exactly as
`results.json.scope` states, and it is not a speedup for any other CLI command or execution boundary.

**Where I am less comfortable — magnitude.** Measuring today on the frozen (GREEN) runtime, 7 pinned
`--implementation-identity` runs of the *same binary under the same config* spanned
**0.908s – 1.928s** (median 1.024s, spread 1.020s). The claimed RED→GREEN median delta is **0.147s** —
roughly 7× smaller than that single-condition spread. My GREEN-code median today (1.024s) is *above*
the campaign's recorded RED median (1.009s), so the absolute figures do not transfer across
machine/temp-copy/load; only the within-session paired comparison is meaningful.

What rescues the direction is the design, not the medians: the campaign counterbalanced arm order
across 7 pairs. Recomputing from the raw rows, the paired differences (RED − GREEN) are
`+0.0851, +0.1137, +0.5735, +0.1421, +0.1328, +0.0825, +0.2028` — **7 of 7 positive**, median paired
difference **0.133s**, one-sided sign test **p ≈ 0.008**. That is real evidence of a consistent
direction. It is *not* evidence for a stable absolute magnitude: n=1 measurement per cell, one
machine, one temp copy, no warmup discard, and the pair-3 RED sample (1.357s) is a visible outlier.

---

## 5. Claims this evidence supports — and does not

**Supported (each tied to evidence above):**

1. All 20 preregistered reviewer executions completed with exit 0, a present report, and an
   unmutated source packet (§2.1).
2. All 21 owner/reviewer identity outputs are byte-identical (sha `b376c73b…`, 1,659 file entries,
   digest `6eb84016…`), every reviewer actually invoked the pinned CLI, and the pin is enforcing —
   a wrong expected digest exits 1 with `IMPLEMENTATION_PIN_MISMATCH` and no stdout (§2.3).
3. Exit-code, missing-report, identity-mismatch and source-mutation failures each trip the harness
   gate mid-campaign (§2.2).
4. On this fixture, every pre-fix wave independently found **all 8** planted defects via executable
   in-domain counterexamples, with **0 false positives in 97 findings**, **0 clean-control flags**,
   and **0 findings against the fixed code** (§2.4–2.6).
5. The scorer is deterministic and reproducible, and its verdict is independently corroborated by a
   1,416-case exhaustive corpus written from the contract alone (§2.4–2.5).
6. The identity change is confined to the strict `--implementation-identity` pinned handshake, and
   reuses a scan of provably identical coverage (1,659 files, one differing entry = the edited file
   itself). Its direction is supported at 7/7 counterbalanced pairs, p≈0.008 (§4).

**Not supported — do not claim:**

1. ~~"The GREEN configuration reviews 40% faster."~~ The arms are procedurally identical; the
   difference is one extra wave plus uncounterbalanced ordering noise (D1, D2).
2. Any universal or production defect-recall figure. Eight single-clause defects in ten one-line
   pure helpers with a complete written spec and an executable oracle. Not a Story, not multi-file,
   no I/O, no ambiguity (D5).
3. "The fixed code is correct." Verified over 1,416 enumerated in-domain cases and every
   reviewer-submitted vector — not over the unbounded input domain.
4. Any lead-time, quality or gate-effectiveness claim about real Stories or current foreign owners.
   Nothing here touched a Story or foreign-owned code.
5. A stable absolute identity-handshake speedup. `0.147s` is a one-machine, one-temp-copy point
   estimate below my measured noise spread; and it applies to the pinned handshake only, not to any
   other CLI command (§4).
6. That the campaign's *own tooling* verified the 21-participant identity claim. It verified 20
   digest strings; the byte-level and owner comparison is this audit's contribution (D4).

**Standing context confirmed:** the campaign benchmarks a permitted review pattern against a
synthetic fixture. It is not, and does not present itself as, a new production gate — the main
remediation mechanism already exists. The absence of universal recall proof is a scope boundary the
artifacts state explicitly (`preregistered.json.scope`, `scored-results.json.scope`,
`identity-timing/results.json.scope`), and all three scope strings are accurate as written.

---

## 6. Recommendations (smallest first)

1. Restate the wallclock line as *"the third RED wave added zero incremental recall (123.1s of pure
   cost); two waves sufficed"* — drop the 442→267 framing entirely (D1).
2. Interleave arms and repeat each wave configuration at least twice if any review-timing claim is
   to be retained (D2).
3. Move `score-reviews.mjs`'s `spec` and `domain` blocks into the pre-registered artifact, hashed
   alongside `preregistered.json`, before the first run (D3).
4. Have the harness compare each `identity.json` **byte-for-byte** against `owner-identity.json`
   rather than string-comparing one field, and have the scorer include the owner file in the
   digest-set assertion instead of hardcoding `1 +` (D4).
5. Replace the campaign-halting `assert`s with explicit raises so the stop gate is not
   `python -O`-removable (§2.2).
6. Fold an exhaustive small-domain sweep (like `independent-corpus.mjs`) into the scorer so
   `finalValidatedDefects: []` is backed by more than reviewer-chosen vectors (§2.5).
