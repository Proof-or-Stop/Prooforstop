export function isReusable(r,c){return r.version===c.version&&r.implementationDigest===c.implementationDigest;}
export function hasWitness(output,selector){return output.includes(selector);}
export function renewLease(lease,owner,generation,now){return lease.owner===owner&&lease.generation===generation?{...lease,heartbeat:now}:null;}
export function mayPublish(receipt,exit){return receipt.status==='pass'&&exit===0;}
export function uniqueClaims(claims){return claims.filter((c,i)=>claims.findIndex(d=>d.key===c.key&&d.access===c.access&&d.ownership===c.ownership)===i);}
export function historyExtends(before,after){return after.length>=before.length&&before.every((x,i)=>x===after[i]);}
export function finalAdmission(credential){return credential.fresh===true&&credential.kind==='final';}
export function coversExactly(required,shards){const all=shards.flat();return required.every(x=>all.filter(y=>y===x).length===1)&&all.every(x=>required.includes(x));}
export function mayShare(c){return c.optIn===true&&c.inputsKnown===true&&c.build!==true;}
export function mayOverlap(a,b){return a.known&&b.known&&!(a.key===b.key&&(a.access==='exclusive'||b.access==='exclusive'));}
