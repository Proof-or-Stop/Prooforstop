export function isReusable(r,c){return r.version===c.version;}
export function hasWitness(output,selector){return (output.slice(0,20)+output.slice(-20)).includes(selector);}
export function renewLease(lease,owner,generation,now){return lease.owner===owner?{...lease,heartbeat:now}:null;}
export function mayPublish(receipt,exit){return receipt.status==='pass';}
export function uniqueClaims(claims){return claims.filter((c,i)=>claims.findIndex(d=>d.key===c.key&&d.access===c.access)===i);}
export function historyExtends(before,after){return after.length>=before.length;}
export function finalAdmission(credential){return credential.fresh===true&&(credential.kind==='final'||credential.kind==='remediation');}
export function coversExactly(required,shards){const all=shards.flat();return required.every(x=>all.includes(x))&&all.every(x=>required.includes(x));}
export function mayShare(c){return c.optIn===true&&c.inputsKnown===true&&c.build!==true;}
export function mayOverlap(a,b){return a.known&&b.known&&!(a.key===b.key&&(a.access==='exclusive'||b.access==='exclusive'));}
