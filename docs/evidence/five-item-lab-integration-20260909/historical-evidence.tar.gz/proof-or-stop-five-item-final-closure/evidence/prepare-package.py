from pathlib import Path
import os,json,hashlib,shutil,subprocess,tempfile,tarfile
art=Path(__file__).resolve().parent
lab=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908')
base='cf21df09c273074d7aa3227a5f436c6f5badf47a'
stage=Path(tempfile.mkdtemp(prefix='five-item-final-package-'))
payload=stage/'proof-or-stop-five-item-final-closure';payload.mkdir()
evidence=payload/'evidence';evidence.mkdir()
skipped=[];sanitized=[];transforms=[];excluded_debug=[]
DROP=object()
def clean(x):
 if isinstance(x,dict):
  if x.get('type') in ['thinking','redacted_thinking','redacted-thinking','thinking_delta','signature_delta']:return DROP
  if x.get('type')=='system' and x.get('subtype')=='thinking_tokens':return DROP
  return {k:v2 for k,v in x.items() if (v2:=clean(v)) is not DROP}
 if isinstance(x,list):return [v2 for v in x if (v2:=clean(v)) is not DROP]
 return x
for f in sorted(art.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(art)
 if f.suffix=='.cpuprofile':
  excluded_debug.append({'path':str(rel),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'reason':'Large exploratory CPU profile from an invalid-layout diagnostic; not used for any correctness or timing claim. Original local file retained. Its command/output/provenance logs remain distributed.'});continue
 if '__pycache__' in rel.parts or f.name in ['continuation-notes.md','README-current-draft.md','package-verification.json','WORK-IN-PROGRESS.md','report-template.md'] or f.suffix in ['.tar','.gz','.bundle','.patch']:skipped.append(str(rel));continue
 dest=evidence/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if f.suffix=='.jsonl':
  lines=[]
  for n,line in enumerate(f.read_text().splitlines(),1):
   if not line.strip():continue
   try:value=clean(json.loads(line))
   except json.JSONDecodeError:raise RuntimeError('Cannot safely package non-JSON transcript line '+str(rel)+':'+str(n))
   if value is not DROP:lines.append(json.dumps(value,ensure_ascii=False))
  dest.write_text('\n'.join(lines)+'\n');sanitized.append(str(rel));transforms.append({'path':str(rel),'sourceSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'distributedSha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'reason':'Remove private reasoning blocks/system thinking-token events; preserve tool calls/results and explicit reports'})
 elif f.suffix=='.json':
  try:original=json.loads(f.read_text());value=clean(original)
  except (json.JSONDecodeError,UnicodeError):shutil.copy2(f,dest);continue
  if value is not DROP and value==original:
   shutil.copy2(f,dest)
  else:
   dest.write_text(json.dumps(None if value is DROP else value,ensure_ascii=False,indent=2)+'\n')
   transforms.append({'path':str(rel),'format':'json','sourceSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'distributedSha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'reason':'Remove private reasoning blocks; preserve tool calls/results and explicit reports. Unchanged JSON is copied byte-for-byte.'})
 else:shutil.copy2(f,dest)
assert (art/'claude-completion-audit/report.md').is_file(), 'Final independent audit missing'
assert (art/'claude-completion-addendum/report.md').is_file(), 'Independent closure addendum missing'
for audit in ['claude-completion-audit', 'claude-completion-addendum']:
 assert json.loads((art/audit/'execution.json').read_text())['exitCode']==0, audit
assert '{{' not in (art/'report.md').read_text(), 'Unresolved report template marker'
(payload/'sanitization-manifest.json').write_text(json.dumps(transforms,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab,text=True).strip()
assert json.loads((art/'final-evidence-selfcheck.json').read_text())['candidateCommit']==head
with (payload/'candidate.patch').open('wb') as f:subprocess.run(['git','diff','--binary',base,head],cwd=lab,stdout=f,check=True)
subprocess.run(['git','bundle','create',str(payload/'candidate.bundle'),'HEAD','^'+base],cwd=lab,check=True)
bv=subprocess.run(['git','bundle','verify',str(payload/'candidate.bundle')],cwd=lab,text=True,capture_output=True);(payload/'bundle-verify.log').write_text(bv.stdout+bv.stderr);assert bv.returncode==0
reconstruction=stage/'reconstruction';reconstruction.mkdir()
archive=stage/'base.tar';subprocess.run(['git','archive','--format=tar','-o',str(archive),base],cwd=lab,check=True)
with tarfile.open(archive) as t:t.extractall(reconstruction)
subprocess.run(['git','apply','--check',str(payload/'candidate.patch')],cwd=reconstruction,check=True)
subprocess.run(['git','apply',str(payload/'candidate.patch')],cwd=reconstruction,check=True)
files=subprocess.check_output(['git','ls-tree','-r','--name-only','-z',head],cwd=lab).decode().split('\0');files=[x for x in files if x]
def digest(p):return hashlib.sha256((os.readlink(p).encode() if p.is_symlink() else p.read_bytes())).hexdigest()
mismatch=[name for name in files if not os.path.lexists(reconstruction/name) or digest(reconstruction/name)!=digest(lab/name)]
assert not mismatch,mismatch
verification={'base':base,'candidateCommit':head,'trackedFilesCompared':len(files),'patchReconstructionMismatches':mismatch,'bundleVerified':True,'sanitizedJsonl':sanitized,'sanitizationManifest':'sanitization-manifest.json','excludedFiles':skipped,'excludedExploratoryProfiles':excluded_debug,'note':'Claude hidden reasoning blocks are omitted. Kept reports, tool calls/results, measured data and independently reproducible controls. The native Lab HMAC record is retained without exporting its local signing key; package checksums prove transport integrity, not independent Story certification.'}
(payload/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(payload/'report.md').write_text((art/'report.md').read_text().replace('](./','](evidence/'));shutil.copy2(lab/'experiments/five-item-proof/README.md',payload/'REPRODUCE.md');shutil.copy2(art/'PACKAGE-README.md',payload/'README.md')
manifest=[]
for f in sorted(payload.rglob('*')):
 if f.is_file():manifest.append(digest(f)+'  '+str(f.relative_to(payload)))
# Verify every distributed transcript retains the tool records and no private blocks.
def event_counts(value, counts):
 if isinstance(value,dict):
  kind=value.get('type')
  if kind in ['thinking','redacted_thinking','redacted-thinking','thinking_delta','signature_delta']:counts['private']+=1
  if kind=='system' and value.get('subtype')=='thinking_tokens':counts['private']+=1
  if kind in ['tool_use','tool_result']:counts[kind]+=1
  for child in value.values():event_counts(child,counts)
 elif isinstance(value,list):
  for child in value:event_counts(child,counts)
transcript_checks=[]
for entry in transforms:
 before_counts={'private':0,'tool_use':0,'tool_result':0};after_counts=dict(before_counts)
 if entry.get('format')=='json':
  event_counts(json.loads((art/entry['path']).read_text()),before_counts)
  event_counts(json.loads((evidence/entry['path']).read_text()),after_counts)
 else:
  for line in (art/entry['path']).read_text().splitlines():
   if line.strip():event_counts(json.loads(line),before_counts)
  for line in (evidence/entry['path']).read_text().splitlines():
   if line.strip():event_counts(json.loads(line),after_counts)
 assert after_counts['private']==0,entry['path']
 assert all(before_counts[k]==after_counts[k] for k in ['tool_use','tool_result']),entry['path']
 transcript_checks.append({'path':entry['path'],'removedPrivateBlocks':before_counts['private'],'toolCallsPreserved':after_counts['tool_use'],'toolResultsPreserved':after_counts['tool_result']})
# Independent audit artifacts bind exact bytes. Do not invalidate those hashes by
# reformatting JSON that contains no private reasoning.
audit_digests=json.loads((evidence/'claude-completion-addendum/addendum-findings.json').read_text())['artifactDigests']
for name,expected in audit_digests.items():
 assert digest(evidence/'claude-completion-addendum'/name)==expected, 'Independent audit byte hash changed: '+name
(payload/'transcript-verification.json').write_text(json.dumps(transcript_checks,indent=2)+'\n')
manifest.append(digest(payload/'transcript-verification.json')+'  transcript-verification.json')
(payload/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
target=art.parent/(art.name+'.tar.gz')
with tarfile.open(target,'w:gz') as t:t.add(payload,arcname=payload.name)
extracted=stage/'extracted';extracted.mkdir()
with tarfile.open(target) as t:t.extractall(extracted)
root=extracted/payload.name
for line in (root/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1);assert digest(root/name)==expected,name
verification.update({'archive':str(target),'archiveSha256':digest(target),'filesChecksumVerified':len(manifest),'archiveBytes':target.stat().st_size,'stagingDirectory':str(stage)})
(art/'package-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({k:v for k,v in verification.items() if k not in ['sanitizedJsonl','excludedFiles']},indent=2))
