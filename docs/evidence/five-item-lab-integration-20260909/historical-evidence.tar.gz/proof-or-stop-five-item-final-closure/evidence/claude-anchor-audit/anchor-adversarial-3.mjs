// Final probes: cross-store disagreement, and Git process cost on the write path.
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,rmSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';

const FROZEN='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-anchor-audit-ccp3yz1s';
const D=FROZEN+'/packages/main/dist';
const {StoryStore}=await import(D+'/core/store.js');
const {createChecklistHandlers}=await import(D+'/handlers/checklist.js');
const {acquireOwnerLease}=await import(D+'/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(D+'/core/digest.js');
const {resetConfigCache}=await import(D+'/core/config.js');
const {readIntentCheckpoint}=await import(D+'/core/verification-intent-checkpoint.js');

process.env.PROOF_OR_STOP_SESSION_ID='claude-anchor-audit-3';
const REALGIT='/usr/bin/git';
const storyId='B-audit-lab';
const errcode=e=>String(e&&(e.code||e.message)).split('\n')[0];
const record=(id,v,d)=>console.log(`[${v}] ${id} :: ${d}`);

function fixture(prefix){
  const root=mkdtempSync(join(tmpdir(),prefix));
  const git=a=>execFileSync(REALGIT,a,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
  mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(['init','-q','-b','work']);git(['config','user.name','Audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);
  resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'audit',title:'Preserve acceptance',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const old={id:'CHK-001',title:'Coverage',context:'Preserve signed history',status:'in_progress',startTime:null,endTime:null,
    files:{modify:['src/subject.js'],create:[],test:[]},
    verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}};
  store.writeChecklist(storyId,{items:[old]});
  acquireOwnerLease(store.storyDirPath(storyId),{command:'audit',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  const append=(add,reason)=>handler.verification_intent_append({storyId,itemId:'CHK-001',
    expectedIntentHash:digestCanonicalJson(store.readChecklist(storyId).items[0].verificationIntent),reason,addition:add});
  append({edge:[{id:'NEW',desc:'A newly required boundary must remain required',type:'cli',priority:'must'}]},
    'Add a required regression inside the existing acceptance scope for this private audit fixture.');
  const digest=digestCanonicalJson(storyId);
  return {root,git,store,handler,append,old,refName:'refs/proof-or-stop/intent-checkpoints/'+digest,
    mirrorDir:join(root,'.git/proof-or-stop-intent-checkpoints',digest)};
}
const cleanup=f=>{try{rmSync(f.root,{recursive:true,force:true});}catch{}resetConfigCache();};

// T9: the anchor is rolled back to an older generation while the mirror still holds the newer one.
{const f=fixture('audit-t9-');
 try{
  const gen1=f.git(['rev-parse',f.refName]);
  f.append({adversarial:[{id:'G2',desc:'A second required boundary that must survive',type:'cli',priority:'must'}]},
    'A second authorized amendment so the mirror and the anchor can be made to disagree.');
  const gen2=f.git(['rev-parse',f.refName]);
  const mirror=readdirSync(f.mirrorDir).filter(n=>/^\d{12}\.json$/.test(n)).sort();
  f.git(['update-ref',f.refName,gen1,gen2]);      // rollback inside the declared trust root
  const seen=readIntentCheckpoint(storyId,f.root);
  const mirrorLatest=JSON.parse(readFileSync(join(f.mirrorDir,mirror.at(-1)),'utf8'));
  record('T9-anchor-rollback-vs-mirror', seen.generation<mirrorLatest.generation?'UNDETECTED':'DETECTED',
    'anchor now reports generation '+seen.generation+' while the intact local mirror still holds generation '+
    mirrorLatest.generation+' ('+JSON.stringify(mirror)+'); the two stores are never compared');
  let t=null;try{f.store.readChecklist(storyId);}catch(e){t=e;}
  record('T9b-read-after-rollback',t?'FAIL-CLOSED':'SILENT',t?errcode(t):'canonical read silently accepted the rolled-back obligation');
 }catch(e){record('T9','ERROR',errcode(e));}finally{cleanup(f);}}

// T10: Git process cost of one amendment write.
{const f=fixture('audit-t10-');
 try{
  const shimDir=mkdtempSync(join(tmpdir(),'audit-shim3-')),log=join(shimDir,'git.log');
  writeFileSync(join(shimDir,'git'),'#!/bin/sh\nprintf "%s\\n" "$*" >> "$POS_GIT_LOG"\nexec '+REALGIT+' "$@"\n',{mode:0o755});
  const oldPath=process.env.PATH;process.env.PATH=shimDir+':'+oldPath;process.env.POS_GIT_LOG=log;writeFileSync(log,'');
  const t=process.hrtime.bigint();
  f.append({adversarial:[{id:'WRITE-COST',desc:'A required boundary used to measure the write path',type:'cli',priority:'must'}]},
    'One authorized amendment used only to count the Git subprocesses on the canonical write path.');
  const ms=Number(process.hrtime.bigint()-t)/1e6;
  const lines=readFileSync(log,'utf8').trim().split('\n').filter(Boolean);
  process.env.PATH=oldPath;delete process.env.POS_GIT_LOG;rmSync(shimDir,{recursive:true,force:true});
  const counts={};for(const l of lines){const k=l.split(' ').find(w=>!w.startsWith('-'))||l;counts[k]=(counts[k]||0)+1;}
  record('T10-write-path-cost','MEASURED',lines.length+' git processes in '+ms.toFixed(0)+' ms for one amendment; by subcommand '+JSON.stringify(counts));
 }catch(e){record('T10','ERROR',errcode(e));}finally{cleanup(f);}}
