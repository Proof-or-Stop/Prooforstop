# Independent audit — intent-checkpoint Git anchoring (`c1a8d38cd2`)

Auditor: Claude (independent of the developing agent). Date: 2026-09-09.

Scope as instructed: read the source change, confirm the frozen runtime is that change,
execute the three frozen acceptance experiments, then run independent bounded adversarial
tests. No Story command, no build, no commit, no subagent, no write to `main`, Lab source,
`dist`, or any real `.git`. Every injection below happened inside a `mkdtemp` fixture that is
deleted in a `finally` block.

- Frozen runtime executed: `/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-anchor-audit-ccp3yz1s` (HEAD `c1a8d38cd2`)
- Probe scripts (written by me, in this output directory): `anchor-adversarial.mjs`, `anchor-adversarial-2.mjs`, `anchor-adversarial-3.mjs`
- `git version 2.50.1 (Apple Git-155)`, Node 26.8.1

---

## 1. Verdict

**Not accepted as a complete closure of the stated gap.** One confirmed critical defect makes
the entire mechanism inert — with no error and no degraded-mode signal — on a supported Git
ref-storage backend, reopening the exact original erasure. Two further correctness defects and
a measurable cost regression are recorded below.

The parts that do work, work well: the fail-closed behaviours are genuinely fail-closed, the
compare-and-swap genuinely rejects a stale writer without corrupting prior truth, an interrupted
publication never claims success, and no branch moves.

---

## 2. Provenance checks

**Source change read** (`git show c1a8d38cd2`): `packages/main/src/core/verification-intent-checkpoint.ts`
(+50/−2), `process-fact-registry.ts` (rationale text), `docs/validation-performance.md`,
`scripts/verify-process-fact-contract.mjs` (pattern list).

**Frozen compiled function matches that change.** I read
`packages/main/dist/core/verification-intent-checkpoint.js` in the frozen copy in full: it is a
faithful TypeScript emit of the post-`c1a8d38` source — same `commonDirectory` split, same
`anchorRef` = `refs/proof-or-stop/intent-checkpoints/<digestCanonicalJson(storyId)>`, same
`validateCheckpoint`, `readAnchor`, `writeAnchor` (`hash-object` → `mktree` → `commit-tree` →
`update-ref <new> <old|zeros>`), same anchor-first ordering in `writeIntentCheckpoint`, same
anchor-preferred `readIntentCheckpoint`. The three experiment files in the frozen copy are
byte-identical (`diff -q`) to the Lab worktree copies.

**Frozen experiments, actual exits:**

| experiment | exit | stdout tail |
|---|---|---|
| `experiments/five-item-proof/acceptance-erasure.mjs` | **0** | `ANCHORED_ACCEPTANCE_ERASURE_GREEN: dual loss refused; actual owner CLI recovered; packed refs and GC retain evidence; main unchanged` |
| `experiments/five-item-proof/acceptance-checkpoint.mjs` | **0** | `CHECKPOINT_HISTORY_DELETION_REFUSED; CANONICAL_PROJECTION_FAILS_CLOSED; ACTUAL_CLI_RECOVERY_GREEN; INTERRUPTED_PUBLICATION_RECOVERED` |
| `experiments/five-item-proof/acceptance-revision.mjs` | **0** | `ACCEPTANCE_CHANNEL_GREEN …` |

My independent probe scripts exited 0 (they report per-probe verdicts rather than asserting).

---

## 3. Confirmed defects

### F1 — CRITICAL. The anchor is written but never read on a reftable repository; the original erasure succeeds silently

`readAnchor` decides whether an anchor exists with a **filesystem** probe before it ever asks Git:

```js
const ref=anchorRef(storyId), packed=join(common,'packed-refs');
if(!existsSync(join(common,ref)) && (!existsSync(packed) || !readFileSync(packed,'utf8')
   .split('\n').some(line=>line.endsWith(' '+ref)))) return null;
```

Git 2.45+ supports the `reftable` ref backend, in which refs live in `.git/reftable/` — there is
no loose ref file and no `packed-refs`. Both `existsSync` calls are false, so `readAnchor`
returns `null` and `readIntentCheckpoint` **silently falls through to the legacy mirror path**.

Probe `T8` (`anchor-adversarial-2.mjs`), fixture created with
`git init -q -b work --ref-format=reftable`, otherwise identical to the developer's own
`acceptance-erasure.mjs` fixture:

```
[OBSERVED] T8a-anchor-written-under-reftable :: git rev-parse resolves the anchor to
  1efa29173f7efa19a5d9abd6444af4d1b0dde9d8; loose ref file present=false;
  packed-refs present=false; mirror files=["000000000001.json"]
[ACCEPTED-ERASURE] T8b-reftable-dual-loss :: the retained anchor was never consulted;
  edge=[] amendments=undefined
```

The anchor **is** written and **is** retained — `git rev-parse` resolves it. Then the exact
original injection (delete `.git/proof-or-stop-intent-checkpoints`, rewrite `checklist.json`
back to the pre-amendment item) is performed, and the canonical read returns an
obligation-free checklist: the required `edge` intent is gone, `verificationIntentAmendments`
is `undefined`, and **no error is raised**.

This is not the declared trust-root boundary. The ref survived intact; only the read path
failed to consult it. It directly contradicts two shipped claims:

- `docs/validation-performance.md`: "Canonical reads use the verified anchor."
- `process-fact-registry.ts` rationale: "anchored to a retained single-parent Git ref … It detects combined projection-history and checkpoint-mirror deletion."

Aggravating detail: the pre-check is **redundant**. The very next line runs
`git rev-parse --verify <ref>`, which is the authoritative existence test and is
backend-independent. The filesystem probe buys one avoided subprocess in the no-anchor case and
costs the entire security property on a backend where the files simply live elsewhere.

Exposure: `reftable` is opt-in today (`git init --ref-format=reftable`), but an existing
repository can be converted in place with `git refs migrate --ref-format=reftable`, which would
silently disarm this protection for every already-anchored story. I verified the Prooforstop
repository itself is currently unaffected — read-only inventory:
`git rev-parse --show-ref-format` → `files`, `git for-each-ref 'refs/proof-or-stop/**'` → 0 refs,
`.git/proof-or-stop-intent-checkpoints` → 0 entries.

### F2 — MEDIUM. An interrupted mirror write permanently poisons the fallback path

Probe `T4` injects failure strictly inside the new anchor-before-mirror window by making the
checkpoint directory unwritable (`chmod 0500`), so `writeAnchor` succeeds and the mirror
`writeFileSync` fails with `EACCES`:

```
[OK]           T4a-interrupt-no-false-publication :: append threw EACCES; anchor generation=2;
                 mirror files=["000000000001.json"] (was ["000000000001.json"])
[FAIL-CLOSED]  T4b-projection-after-interrupt :: AMENDMENT_CHECKPOINT_PROJECTION_MISMATCH
[GAP]          T4c-mirror-generation-sequence :: mirror files=["000000000001.json","000000000003.json"]
[FALLBACK-BROKEN] T4d-fallback-after-anchor-loss :: AMENDMENT_CHECKPOINT_HISTORY_GAP
```

T4a and T4b are correct and are what the change promises: no false publication, and the
canonical read fails closed afterwards. The defect is T4c/T4d. After the owner recovers
(`verification_intent_recover --apply`, which succeeds) and makes one further **entirely
legitimate** amendment, the mirror sequence is `[1, 3]` — generation 2 is missing forever,
because `writeIntentCheckpoint` derives the next generation from the anchor and the recovery
projection is digest-identical so it writes nothing. The mirror's own contiguity invariant
(`AMENDMENT_CHECKPOINT_HISTORY_GAP`) is now violated by the product's normal path. From that
point the mirror is not a fallback at all: if the ref is ever lost, every canonical read of that
story throws `AMENDMENT_CHECKPOINT_HISTORY_GAP` permanently, including the read that
`verification_intent_recover` needs — the story becomes unreadable and unrecoverable rather
than degrading to the pre-fix behaviour.

Direction of failure is safe (refusal, not silent acceptance), which is why this is medium and
not critical. But the change converts a self-consistent append-only file sequence into one the
product itself can corrupt, and the two stores are never reconciled.

### F3 — MEDIUM (documented behaviour, undocumented consequence). Pre-existing stories stay exposed indefinitely

Probe `T6` simulates a story that predates the fix (valid mirror, no anchor) and then performs a
canonical write with unchanged content:

```
[NOT-MIGRATED]     T6a-legacy-unchanged-write :: after an unchanged canonical write the anchor is still absent
[ACCEPTED-ERASURE] T6b-legacy-window-erasure :: the pre-fix erasure still succeeds while unmigrated
```

`writeIntentCheckpoint` returns early on `previous?.dataDigest===dataDigest` **before**
`writeAnchor`, so no anchor is ever created for a story whose checklist does not change again.
Until that story is amended a second time, deleting the mirror plus the history field erases the
obligation exactly as before the fix.

The documentation does state the mechanism ("Old unanchored records retain the contiguous-file
verification path and acquire an anchor on their next changed canonical write") — credit where
due, this is disclosed, which is why it is not rated higher. What is not stated is the security
consequence: during that window the fixed defect is fully live. A one-line eager migration on
the unchanged-write path would close it. Current exposure in this repository is zero (no
existing mirrors, see F1's inventory), so this is a forward-looking correctness note.

### F4 — LOW. The anchor chain root asserts nothing about the generations before it

Probe `T6c`: a story amended twice, then de-anchored (simulating a pre-fix story at generation 2),
then amended once more.

```
[OBSERVED] T6c-migrated-anchor-root :: anchor root parents=0; generation=3; previousDigest=non-null
```

`readAnchor` accepts a parentless anchor commit at generation 3 carrying a non-null
`previousDigest`. The file path enforces the corresponding invariant
(`AMENDMENT_CHECKPOINT_FIRST_PREDECESSOR` rejects generation 1 with a non-null `previousDigest`);
the anchor path has no equivalent. A truncated chain and a legitimately migrated chain are
therefore indistinguishable. Truncation requires ref write access — inside the declared trust
root — so this is low, but the asymmetry between the two verification paths is real and cheap
to close.

### F5 — LOW. Anchor and mirror are never compared, so a rollback is undetected

Probe `T9` rewinds the ref from generation 2 to generation 1 while the mirror still holds both:

```
[UNDETECTED]  T9-anchor-rollback-vs-mirror :: anchor now reports generation 1 while the intact
                local mirror still holds generation 2 (["000000000001.json","000000000002.json"]);
                the two stores are never compared
[FAIL-CLOSED] T9b-read-after-rollback :: AMENDMENT_CHECKPOINT_PROJECTION_MISMATCH
```

The canonical read does fail closed, which is the important property. The residual concern is
that the record `readIntentCheckpoint` now returns — and therefore the snapshot
`verification_intent_recover` would restore the owner to — is the older generation 1, while
first-class local evidence contradicting the rollback (the generation 2 mirror file) sits
unread. I did not separately execute the recovery, so treat the recovery consequence as an
inference from the returned checkpoint plus the code path, not as an executed result. Within the
declared trust root; recorded because a monotonicity check against the mirror is nearly free.

### F6 — LOW. The compare-and-swap loser surfaces an untyped error

Probe `T5` replays exactly what a losing concurrent writer executes (a commit built from the
stale predecessor `c1`, then `update-ref <new> <c1>` after another writer moved the ref to `c2`):

```
[REJECTED] T5-stale-writer-cas :: update-ref exit=128; stderr="fatal: update_ref failed for ref
  'refs/proof-or-stop/intent-checkpoints/e7ee6c15…': cannot lock ref '…': is at 9d04dc26… but
  expected c5007341…"; ref unchanged; checkpoint generation still 2 (winner 2);
  mirror ["000000000001.json","000000000002.json"]
[UNTYPED]  T5b-cas-error-typing :: the losing writer surfaces a raw git failure, not an
  IntentAmendmentIntegrityError
```

The safety property holds: the CAS rejects the stale writer, the ref is unchanged, the winner's
checkpoint is still valid, and because `update-ref` runs strictly before the mirror write, the
loser writes no mirror file and leaves only unreferenced Git objects — no corruption of previous
truth, and no false claim of publication. The defect is presentational and narrow: this error
escapes as a raw `execFileSync` failure with git's `fatal:` text, not as the typed
`IntentAmendmentIntegrityError` the module's stated policy ("typed integrity errors propagate")
leads callers to expect.

---

## 4. Performance

Measured on the frozen runtime with a `PATH` shim that logs every `git` invocation. **Process
counts are exact; the millisecond figures are inflated by the shim's extra `/bin/sh` exec per
call and by machine load, so read them as loose upper bounds, not as the cost of the change.**

Canonical checklist read, one-item checklist with one amendment, anchor present vs. the same
build with the ref deleted (probe `T7`, N=20 each):

```
anchored     6.0 git processes/read   (189.2 ms/read, shim-inflated)
mirror-only  3.0 git processes/read   ( 90.1 ms/read, shim-inflated)
```

**The anchor doubles the number of Git subprocesses on every canonical checklist read** — a hot
path that gate evaluation, roster queries and ordinary CLI commands all traverse. `readAnchor`
alone issues `rev-parse --verify`, `show <commit>:checkpoint.json`, `show -s --format=%P`, plus a
fourth `show` when the anchor has a parent, and `validateCheckpoint` re-runs signature and
per-item amendment verification for both the record and its predecessor — so the cost also grows
with checklist item count.

One full amendment write costs **45 git processes** (probe `T10`, 1411 ms shim-inflated;
`rev-parse`×28, `show`×10, `hash-object`, `mktree`, `commit-tree`, `update-ref`, `worktree`).
A structural contributor visible in the source: `writeIntentCheckpoint` calls `readAnchor`, then
calls `readIntentCheckpoint`, whose first statement is another `readAnchor` — the anchor is
fetched, parsed, signature-verified and amendment-verified **twice per write**, with no caching
between the two.

There is no per-read caching of anchor validation at all; only the `--git-common-dir` lookup is
memoised (`commonDirs`).

---

## 5. Behaviour that is correct

Confirmed by my own probes, not taken from the developer's assertions:

- **T2 — foreign signing root refused, no downgrade.** An anchor commit carrying a checkpoint
  signed under a different repository's trust root is rejected with
  `AMENDMENT_CHECKPOINT_INVALID`, and — importantly — the read does **not** silently fall back to
  the valid local mirror that is still present. Invalid anchor ⇒ hard failure, not degradation.
- **T3 — anchor without payload refused.** Repointing the ref at an ordinary commit with no
  `checkpoint.json` yields `AMENDMENT_CHECKPOINT_ANCHOR_INVALID` (typed).
- **T4a/T4b** — interrupted publication never reports success and leaves the canonical read
  failing closed with a recoverable, correctly-typed error.
- **T5** — compare-and-swap semantics as described above.
- Branch refs are untouched: the developer's `acceptance-erasure.mjs` asserts
  `git rev-parse main` is unchanged, and it passes (exit 0). `writeAnchor` only ever writes
  `refs/proof-or-stop/intent-checkpoints/*`.
- Packed refs and `git gc --prune=now` retain the anchor (covered by the developer's experiment,
  exit 0, on the `files` backend).

---

## 6. Declared boundary — reported, not demanded

As instructed, I did not treat destruction of the trust root itself as a defect. For the record,
probe `T1` measures exactly where the boundary now sits:

```
[ACCEPTED-ERASURE] T1-ref+mirror+history-deleted :: edge=[] amendments=undefined
```

Deleting `refs/proof-or-stop/intent-checkpoints/<digest>` **in addition to** the mirror and the
history field erases the obligation with no error. This is consistent with the change's own
declaration ("The retained Git ref, object store and signing key are the local trust root.
Deleting that trust root too cannot be recovered from the remaining erased files") and I raise
no recovery demand against it.

The honest framing of what changed: the evidence moved from an ad-hoc directory under `.git` to
Git-managed metadata under the same `.git`. An actor able to `rm -rf` inside `.git` is not
newly stopped. What genuinely improved is robustness against *ordinary* loss — a ref is
preserved by packing, GC and standard tooling in a way an unknown directory is not, and the
anchor now survives the specific combined deletion that was reproduced. That is a real
improvement; it is a narrower one than "cannot erase the anchored obligation" reads.

---

## 7. Summary table

| # | Severity | Status | Finding |
|---|---|---|---|
| F1 | **Critical** | Confirmed, reproduced | reftable backend ⇒ anchor written but never read ⇒ original erasure accepted silently (`T8`) |
| F2 | Medium | Confirmed, reproduced | interrupted mirror write leaves a permanent generation gap; fallback path becomes unreadable if the ref is lost (`T4c/T4d`) |
| F3 | Medium | Confirmed, disclosed in docs | unchanged writes never migrate a pre-fix story; pre-fix erasure stays live in that window (`T6a/T6b`) |
| F4 | Low | Confirmed | anchor root accepts generation > 1 with non-null `previousDigest`; no `FIRST_PREDECESSOR` equivalent (`T6c`) |
| F5 | Low | Confirmed (recovery consequence inferred) | anchor rollback undetected; mirror never cross-checked (`T9`) |
| F6 | Low | Confirmed | CAS loser raises a raw git error, not a typed integrity error (`T5b`) |
| P1 | Performance | Measured | 2× Git subprocesses per canonical read; anchor validated twice per write (`T7`, `T10`) |

No patches were written. All fixtures were disposable and are deleted; no real `.git`, Story,
branch, source, or build artifact was modified.
