// Follow-up probes: T1 restated, and the ref-storage-backend assumption in readAnchor.
import {mkdtempSync,mkdirSync,writeFileSync,rmSync,existsSync,readdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';

const FROZEN='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-anchor-audit-ccp3yz1s';
const D=FROZEN+'/packages/main/dist';
const {StoryStore}=await import(D+'/core/store.js');
const {createChecklistHandlers}=await import(D+'/handlers/checklist.js');
const {acquireOwnerLease}=await import(D+'/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(D+'/core/digest.js');
const {resetConfigCache}=await import(D+'/core/config.js');

process.env.PROOF_OR_STOP_SESSION_ID='claude-anchor-audit-2';
const REALGIT='/usr/bin/git';
const storyId='B-audit-lab';
const errcode=e=>String(e&&(e.code||e.message)).split('\n')[0];
const record=(id,v,d)=>console.log(`[${v}] ${id} :: ${d}`);

function fixture(prefix,initArgs){
  const root=mkdtempSync(join(tmpdir(),prefix));
  const git=a=>execFileSync(REALGIT,a,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
  mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(initArgs);git(['config','user.name','Audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);
  resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'audit',title:'Preserve acceptance',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const old={id:'CHK-001',title:'Coverage',context:'Preserve signed history',status:'in_progress',startTime:null,endTime:null,
    files:{modify:['src/subject.js'],create:[],test:[]},
    verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}};
  store.writeChecklist(storyId,{items:[old]});
  acquireOwnerLease(store.storyDirPath(storyId),{command:'audit',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  handler.verification_intent_append({storyId,itemId:'CHK-001',expectedIntentHash:digestCanonicalJson(old.verificationIntent),
    reason:'Add a required regression inside the existing acceptance scope for this private audit fixture.',
    addition:{edge:[{id:'NEW',desc:'A newly required boundary must remain required',type:'cli',priority:'must'}]}});
  const digest=digestCanonicalJson(storyId);
  return {root,git,store,handler,old,digest,refName:'refs/proof-or-stop/intent-checkpoints/'+digest,
    mirrorDir:join(root,'.git/proof-or-stop-intent-checkpoints',digest)};
}
const cleanup=f=>{try{rmSync(f.root,{recursive:true,force:true});}catch{}resetConfigCache();};

// T1 restated: the exact original injection plus deletion of the ref the fix depends on.
{const f=fixture('audit-t1b-',['init','-q','-b','work']);
 try{
  f.git(['update-ref','-d',f.refName]);
  rmSync(f.mirrorDir,{recursive:true,force:true});
  f.store.writeJson(storyId,'checklist.json',{items:[f.old]});
  let t=null,v=null;try{v=f.store.readChecklist(storyId);}catch(e){t=e;}
  record('T1-ref+mirror+history-deleted',t?'REFUSED':'ACCEPTED-ERASURE',
    t?errcode(t):'edge='+JSON.stringify(v.items[0].verificationIntent.edge)+' amendments='+JSON.stringify(v.items[0].verificationIntentAmendments));
 }catch(e){record('T1','ERROR',errcode(e));}finally{cleanup(f);}}

// T8: same product, a repository using Git's reftable ref backend.
{let f=null;
 try{
  f=fixture('audit-t8-',['init','-q','-b','work','--ref-format=reftable']);
  const refExists=f.git(['rev-parse','--verify','--quiet',f.refName])||'(absent)';
  const looseFile=existsSync(join(f.root,'.git',f.refName)), packed=existsSync(join(f.root,'.git/packed-refs'));
  record('T8a-anchor-written-under-reftable','OBSERVED','git rev-parse resolves the anchor to '+refExists+
    '; loose ref file present='+looseFile+'; packed-refs present='+packed+'; mirror files='+JSON.stringify(readdirSync(f.mirrorDir)));
  rmSync(f.mirrorDir,{recursive:true,force:true});
  f.store.writeJson(storyId,'checklist.json',{items:[f.old]});
  let t=null,v=null;try{v=f.store.readChecklist(storyId);}catch(e){t=e;}
  record('T8b-reftable-dual-loss',t?'REFUSED':'ACCEPTED-ERASURE',
    t?errcode(t):'the retained anchor was never consulted; edge='+JSON.stringify(v.items[0].verificationIntent.edge)+
      ' amendments='+JSON.stringify(v.items[0].verificationIntentAmendments));
 }catch(e){record('T8','ERROR',errcode(e));}finally{if(f)cleanup(f);}}
