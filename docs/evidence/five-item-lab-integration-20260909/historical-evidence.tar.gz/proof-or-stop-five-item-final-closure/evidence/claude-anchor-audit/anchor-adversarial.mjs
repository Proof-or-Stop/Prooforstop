// Independent audit probes for the intent-checkpoint Git anchor (commit c1a8d38cd2).
// Runs ONLY against the frozen runtime and disposable mkdtemp fixtures.
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,rmSync,existsSync,chmodSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';

const FROZEN='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-anchor-audit-ccp3yz1s';
const D=FROZEN+'/packages/main/dist';
const {StoryStore}=await import(D+'/core/store.js');
const {createChecklistHandlers}=await import(D+'/handlers/checklist.js');
const {acquireOwnerLease}=await import(D+'/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(D+'/core/digest.js');
const {resetConfigCache}=await import(D+'/core/config.js');
const {readIntentCheckpoint,writeIntentCheckpoint}=await import(D+'/core/verification-intent-checkpoint.js');

process.env.PROOF_OR_STOP_SESSION_ID='claude-anchor-audit';
const REALGIT='/usr/bin/git';
const results=[];
const record=(id,verdict,detail)=>{results.push({id,verdict,detail});console.log(`[${verdict}] ${id} :: ${detail}`);};
const errcode=e=>(e&&(e.code||e.message))?String(e.code||e.message).split('\n')[0]:String(e);

const storyId='B-audit-lab';
const itemBase=()=>({id:'CHK-001',title:'Coverage',context:'Preserve signed history',status:'in_progress',startTime:null,endTime:null,
  files:{modify:['src/subject.js'],create:[],test:[]},
  verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}});

function fixture(prefix,{append=true}={}){
  const root=mkdtempSync(join(tmpdir(),prefix));
  const git=a=>execFileSync(REALGIT,a,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
  mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(['init','-q','-b','work']);git(['config','user.name','Audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);
  resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'audit',title:'Preserve acceptance',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const old=itemBase();
  store.writeChecklist(storyId,{items:[old]});
  acquireOwnerLease(store.storyDirPath(storyId),{command:'audit',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  if(append)handler.verification_intent_append({storyId,itemId:'CHK-001',expectedIntentHash:digestCanonicalJson(old.verificationIntent),
    reason:'Add a required regression inside the existing acceptance scope for this private audit fixture.',
    addition:{edge:[{id:'NEW',desc:'A newly required boundary must remain required',type:'cli',priority:'must'}]}});
  const digest=digestCanonicalJson(storyId);
  return {root,git,store,handler,old,digest,
    refName:'refs/proof-or-stop/intent-checkpoints/'+digest,
    mirrorDir:join(root,'.git/proof-or-stop-intent-checkpoints',digest),
    pristine:append?store.readChecklist(storyId):null};
}
const cleanup=f=>{try{rmSync(f.root,{recursive:true,force:true});}catch{}resetConfigCache();};

// ---------------------------------------------------------------- T1
// Original gap plus one extra deletion of the ref that the fix relies on.
{const f=fixture('audit-t1-');
 try{
  assert.ok(existsSync(join(f.root,'.git',f.refName)),'anchor ref must exist after append');
  f.git(['update-ref','-d',f.refName]);
  rmSync(f.mirrorDir,{recursive:true,force:true});
  f.store.writeJson(storyId,'checklist.json',{items:[f.old]});
  let threw=null,value=null;
  try{value=f.store.readChecklist(storyId);}catch(e){threw=e;}
  if(threw)record('T1-ref+mirror+history-deleted','REFUSED','read failed closed: '+errcode(threw));
  else record('T1-ref+mirror+history-deleted','ACCEPTED-ERASURE',
    'canonical read returned an obligation-free checklist; edge intents='+JSON.stringify(value.items[0].verificationIntent.edge)+
    '; amendments='+JSON.stringify(value.items[0].verificationIntentAmendments));
 }catch(e){record('T1','ERROR',errcode(e));}finally{cleanup(f);}}

// ---------------------------------------------------------------- T2
// Anchor holding a record signed under a different local trust root.
{const a=fixture('audit-t2a-'),b=fixture('audit-t2b-');
 try{
  const foreign=execFileSync(REALGIT,['show',b.refName+':checkpoint.json'],{cwd:b.root,encoding:'utf8'});
  const blob=execFileSync(REALGIT,['hash-object','-w','--stdin'],{cwd:a.root,input:foreign,encoding:'utf8'}).trim();
  const tree=execFileSync(REALGIT,['mktree'],{cwd:a.root,input:'100644 blob '+blob+'\tcheckpoint.json\n',encoding:'utf8'}).trim();
  const commit=execFileSync(REALGIT,['-c','user.name=x','-c','user.email=x@y.z','commit-tree',tree],{cwd:a.root,input:'foreign\n',encoding:'utf8'}).trim();
  execFileSync(REALGIT,['update-ref',a.refName,commit],{cwd:a.root});
  assert.ok(readdirSync(a.mirrorDir).length>0,'valid local mirror still present');
  let threw=null,value=null;
  try{value=readIntentCheckpoint(storyId,a.root);}catch(e){threw=e;}
  if(threw)record('T2-foreign-signing-root','REFUSED','no silent downgrade to the valid local mirror: '+errcode(threw));
  else record('T2-foreign-signing-root','ACCEPTED','returned generation '+value.generation);
 }catch(e){record('T2','ERROR',errcode(e));}finally{cleanup(a);cleanup(b);}}

// ---------------------------------------------------------------- T3
// Anchor ref repointed at an ordinary commit with no checkpoint.json.
{const f=fixture('audit-t3-');
 try{
  f.git(['update-ref',f.refName,f.git(['rev-parse','work'])]);
  let threw=null;try{readIntentCheckpoint(storyId,f.root);}catch(e){threw=e;}
  record('T3-anchor-without-payload',threw?'REFUSED':'ACCEPTED',threw?errcode(threw):'silently returned a checkpoint');
 }catch(e){record('T3','ERROR',errcode(e));}finally{cleanup(f);}}

// ---------------------------------------------------------------- T4
// Interruption strictly between writeAnchor and the mirror write.
{const f=fixture('audit-t4-');
 try{
  const gen1=readdirSync(f.mirrorDir).sort();
  chmodSync(f.mirrorDir,0o500);
  let threw=null;
  try{f.handler.verification_intent_append({storyId,itemId:'CHK-001',
    expectedIntentHash:digestCanonicalJson(f.pristine.items[0].verificationIntent),
    reason:'Interrupted publication probe for the anchor-before-mirror ordering window in a disposable fixture.',
    addition:{adversarial:[{id:'INT',desc:'Interrupted publication must not claim success',type:'cli',priority:'must'}]}});}catch(e){threw=e;}
  chmodSync(f.mirrorDir,0o700);
  assert.ok(threw,'interrupted mirror write must not report success');
  const anchored=readIntentCheckpoint(storyId,f.root);
  const mirrorAfter=readdirSync(f.mirrorDir).filter(n=>/^\d{12}\.json$/.test(n)).sort();
  record('T4a-interrupt-no-false-publication','OK','append threw '+errcode(threw)+
    '; anchor generation='+anchored.generation+'; mirror files='+JSON.stringify(mirrorAfter)+' (was '+JSON.stringify(gen1)+')');
  let readThrew=null;try{f.store.readChecklist(storyId);}catch(e){readThrew=e;}
  record('T4b-projection-after-interrupt',readThrew?'FAIL-CLOSED':'SILENT',readThrew?errcode(readThrew):'canonical read succeeded with the stale projection');
  // Owner recovery, then one more legitimate amendment.
  f.handler.verification_intent_recover({storyId,apply:true,expectedCheckpointDigest:anchored.dataDigest,
    reason:'Restore the anchored signed snapshot after the interrupted mirror write in this audit fixture.'});
  const cur=f.store.readChecklist(storyId);
  f.handler.verification_intent_append({storyId,itemId:'CHK-001',
    expectedIntentHash:digestCanonicalJson(cur.items[0].verificationIntent),
    reason:'A second authorized amendment after recovery, to observe the resulting mirror generation sequence.',
    addition:{adversarial:[{id:'AFTER',desc:'A later required boundary after recovery',type:'cli',priority:'must'}]}});
  const seq=readdirSync(f.mirrorDir).filter(n=>/^\d{12}\.json$/.test(n)).sort();
  const contiguous=seq.every((n,i)=>Number(n.slice(0,12))===i+1);
  record('T4c-mirror-generation-sequence',contiguous?'CONTIGUOUS':'GAP','mirror files='+JSON.stringify(seq));
  f.git(['update-ref','-d',f.refName]);
  let fbThrew=null,fb=null;try{fb=readIntentCheckpoint(storyId,f.root);}catch(e){fbThrew=e;}
  record('T4d-fallback-after-anchor-loss',fbThrew?'FALLBACK-BROKEN':'FALLBACK-OK',
    fbThrew?errcode(fbThrew):'legacy path returned generation '+fb.generation);
 }catch(e){record('T4','ERROR',errcode(e));}finally{try{chmodSync(f.mirrorDir,0o700);}catch{}cleanup(f);}}

// ---------------------------------------------------------------- T5
// Compare-and-swap against a writer holding a stale predecessor.
{const f=fixture('audit-t5-');
 try{
  const c1=f.git(['rev-parse',f.refName]);
  f.handler.verification_intent_append({storyId,itemId:'CHK-001',
    expectedIntentHash:digestCanonicalJson(f.pristine.items[0].verificationIntent),
    reason:'Advance the anchor so a stale concurrent writer can be replayed against the compare-and-swap.',
    addition:{adversarial:[{id:'RACE',desc:'A required boundary added by the winning writer',type:'cli',priority:'must'}]}});
  const c2=f.git(['rev-parse',f.refName]);
  const winner=readIntentCheckpoint(storyId,f.root);
  const mirrorBefore=readdirSync(f.mirrorDir).sort();
  // Replay exactly what a losing concurrent writer executes: it built its commit from c1.
  const stale=execFileSync(REALGIT,['-c','user.name=x','-c','user.email=x@y.z','commit-tree',f.git(['rev-parse',c1+'^{tree}']),'-p',c1],
    {cwd:f.root,input:'stale writer\n',encoding:'utf8'}).trim();
  let cas;
  try{execFileSync(REALGIT,['update-ref',f.refName,stale,c1],{cwd:f.root,encoding:'utf8',stdio:['pipe','pipe','pipe']});cas={status:0,stderr:''};}
  catch(e){cas={status:e.status,stderr:String(e.stderr||'').trim()};}
  const after=f.git(['rev-parse',f.refName]);
  const stillValid=readIntentCheckpoint(storyId,f.root);
  record('T5-stale-writer-cas',cas.status!==0&&after===c2?'REJECTED':'OVERWROTE',
    'update-ref exit='+cas.status+'; stderr='+JSON.stringify(cas.stderr)+'; ref '+(after===c2?'unchanged':'MOVED')+
    '; checkpoint generation still '+stillValid.generation+' (winner '+winner.generation+'); mirror '+JSON.stringify(mirrorBefore));
  record('T5b-cas-error-typing', cas.stderr.includes('AMENDMENT')?'TYPED':'UNTYPED',
    'the losing writer surfaces a raw git failure, not an IntentAmendmentIntegrityError');
 }catch(e){record('T5','ERROR',errcode(e));}finally{cleanup(f);}}

// ---------------------------------------------------------------- T6
// Legacy story: a valid mirror with no anchor, then an unchanged write.
{const f=fixture('audit-t6-');
 try{
  f.git(['update-ref','-d',f.refName]);          // simulate a pre-fix story
  const data=f.store.readChecklist(storyId);
  writeIntentCheckpoint(storyId,data,f.root);    // unchanged content
  const migrated=existsSync(join(f.root,'.git',f.refName));
  record('T6a-legacy-unchanged-write',migrated?'MIGRATED':'NOT-MIGRATED',
    'after an unchanged canonical write the anchor is '+(migrated?'present':'still absent'));
  if(!migrated){
    rmSync(f.mirrorDir,{recursive:true,force:true});
    f.store.writeJson(storyId,'checklist.json',{items:[f.old]});
    let t=null;try{f.store.readChecklist(storyId);}catch(e){t=e;}
    record('T6b-legacy-window-erasure',t?'REFUSED':'ACCEPTED-ERASURE',t?errcode(t):'the pre-fix erasure still succeeds while unmigrated');
  }
 }catch(e){record('T6','ERROR',errcode(e));}finally{cleanup(f);}}

// ---------------------------------------------------------------- T6c
// Legacy story that is then genuinely amended: what does the new anchor root attest?
{const f=fixture('audit-t6c-');
 try{
  f.handler.verification_intent_append({storyId,itemId:'CHK-001',
    expectedIntentHash:digestCanonicalJson(f.pristine.items[0].verificationIntent),
    reason:'Create a second checkpoint generation before simulating a story that predates the anchor mechanism.',
    addition:{adversarial:[{id:'G2',desc:'A second required boundary',type:'cli',priority:'must'}]}});
  f.git(['update-ref','-d',f.refName]);          // pre-fix story sitting at generation 2
  const cur=f.store.readChecklist(storyId);
  f.handler.verification_intent_append({storyId,itemId:'CHK-001',
    expectedIntentHash:digestCanonicalJson(cur.items[0].verificationIntent),
    reason:'The first amendment after migration, which creates the very first anchored commit for this story.',
    addition:{adversarial:[{id:'G3',desc:'A third required boundary',type:'cli',priority:'must'}]}});
  const commit=f.git(['rev-parse',f.refName]);
  const parents=f.git(['show','-s','--format=%P',commit]).split(' ').filter(Boolean);
  const rec=JSON.parse(f.git(['show',commit+':checkpoint.json']));
  record('T6c-migrated-anchor-root','OBSERVED','anchor root parents='+parents.length+
    '; generation='+rec.generation+'; previousDigest='+(rec.previousDigest===null?'null':'non-null')+
    ' (the file path rejects generation 1 with a non-null previousDigest; the anchor root has no equivalent check)');
 }catch(e){record('T6c','ERROR',errcode(e));}finally{cleanup(f);}}

// ---------------------------------------------------------------- T7
// Cost of the anchor on canonical checklist reads, measured on one build.
{const f=fixture('audit-t7-');
 try{
  const shimDir=mkdtempSync(join(tmpdir(),'audit-shim-')),log=join(shimDir,'git.log');
  writeFileSync(join(shimDir,'git'),'#!/bin/sh\nprintf "%s\\n" "$*" >> "$POS_GIT_LOG"\nexec '+REALGIT+' "$@"\n',{mode:0o755});
  const N=20,time=fn=>{const t=process.hrtime.bigint();fn();return Number(process.hrtime.bigint()-t)/1e6;};
  const oldPath=process.env.PATH;
  process.env.PATH=shimDir+':'+oldPath;process.env.POS_GIT_LOG=log;
  writeFileSync(log,'');
  const anchoredMs=time(()=>{for(let i=0;i<N;i++)f.store.readChecklist(storyId);});
  const anchoredGit=readFileSync(log,'utf8').trim().split('\n').filter(Boolean).length;
  execFileSync(REALGIT,['update-ref','-d',f.refName],{cwd:f.root});
  writeFileSync(log,'');
  const legacyMs=time(()=>{for(let i=0;i<N;i++)f.store.readChecklist(storyId);});
  const legacyGit=readFileSync(log,'utf8').trim().split('\n').filter(Boolean).length;
  process.env.PATH=oldPath;delete process.env.POS_GIT_LOG;
  rmSync(shimDir,{recursive:true,force:true});
  record('T7-read-cost','MEASURED',
    `anchored ${(anchoredMs/N).toFixed(1)} ms/read and ${(anchoredGit/N).toFixed(1)} git processes/read; `+
    `mirror-only ${(legacyMs/N).toFixed(1)} ms/read and ${(legacyGit/N).toFixed(1)} git processes/read; `+
    `overhead ${((anchoredMs-legacyMs)/N).toFixed(1)} ms/read`);
 }catch(e){record('T7','ERROR',errcode(e));}finally{cleanup(f);}}

console.log('\nSUMMARY '+JSON.stringify(results,null,1));
