import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,appendFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
const art=import.meta.dirname,info=JSON.parse(readFileSync(join(art,'full-final-runtime.json'),'utf8')),root=info.path;
const {executeValidationPlan}=await import(root+'/packages/main/dist/core/validation-executor.js');
const {configuredValidationCommands}=await import(root+'/packages/main/dist/handlers/verifier.js');
const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:16*1024*1024}).trim();
const baseline=JSON.parse(git(['show',info.main+':proof-or-stop.config.json']));
const commands=configuredValidationCommands(root),configHash=createHash('sha256').update(readFileSync(join(root,'proof-or-stop.config.json'))).digest('hex');
assert.equal(commands.length,134);assert.equal(baseline.validate.commands.length,134);
for(let i=0;i<134;i++)assert.deepEqual([commands[i].command,...commands[i].args.filter(a=>!['--jobs=4','--probe-jobs=4'].includes(a))],[baseline.validate.commands[i].command,...baseline.validate.commands[i].args]);
const out=join(art,'full-final-comparison');mkdirSync(out,{recursive:true});
const manifest={runtime:info,configHash,order:['GREEN','RED'],count:134,scope:'Same final repaired source and all134 command/assertion workloads. GREEN enables audited resource declarations and two bounded internal pools. RED restores baseline resource declarations and serial internal pools. This isolates scheduling activation, not every code repair, Story lead time, or deployment.',productionTimeoutsUnmodified:true,formalStoryEvidence:false};
writeFileSync(join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');const rows=[];
for(const mode of manifest.order){
 const selected=commands.map((c,i)=>mode==='GREEN'?c:{...c,args:c.args.filter(a=>!['--jobs=4','--probe-jobs=4'].includes(a)),resources:baseline.validate.commands[i].resources});
 const start=performance.now();let active=0,peak=0,ended=0;
 const result=await executeValidationPlan({provider:'lab-full-scheduling-comparison',commands:selected},root,git(['rev-parse','HEAD']),undefined,{jobs:4,progress:event=>{
   if(event.type==='command_start'){active++;peak=Math.max(peak,active);}if(event.type==='command_end'){active--;ended++;}
   appendFileSync(join(out,'events.jsonl'),JSON.stringify({mode,atMs:performance.now()-start,active,...event})+'\n');
   if(event.type==='command_end')console.log(mode,ended+'/134',event.commandIndex,event.code,event.elapsedMs);
 }});
 assert.equal(result.commands.length,134,'No missing command can be accepted');
 result.commands.forEach((r,i)=>writeFileSync(join(out,mode+'-'+String(i).padStart(3,'0')+'.log'),r.output));
 const row={mode,elapsedMs:performance.now()-start,peak,allPass:result.allPass,passed:result.commands.filter(r=>r.code===0&&!r.timedOut).length,failed:result.commands.flatMap((r,i)=>r.code===0&&!r.timedOut?[]:[{index:i,label:r.label,code:r.code,timedOut:r.timedOut}]),result};
 rows.push(row);writeFileSync(join(out,'results.json'),JSON.stringify({manifest,rows},null,2)+'\n');
 console.log('ARM_COMPLETE',mode,row.elapsedMs,row.passed+'/134',row.allPass);
 assert.equal(git(['rev-parse','HEAD']),info.head);assert.equal(createHash('sha256').update(readFileSync(join(root,'proof-or-stop.config.json'))).digest('hex'),configHash);
}
assert.ok(rows.every(r=>r.allPass&&r.passed===134),'FULL_WORKLOAD_NOT_CLOSED: retain every failed command; do not claim a successful speedup');
console.log('FULL_134_COMPARISON_GREEN');
