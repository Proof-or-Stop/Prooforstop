import ts from '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/node_modules/typescript/lib/typescript.js';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
const file = process.argv[2];           // logical repo-relative path
const path = process.argv[3];           // actual file to read
const text = readFileSync(path, 'utf8');
const scriptKind = file.endsWith('.tsx') ? ts.ScriptKind.TSX
  : file.endsWith('.jsx') ? ts.ScriptKind.JSX
  : /\.(?:js|mjs|cjs)$/.test(file) ? ts.ScriptKind.JS : ts.ScriptKind.TS;
const src = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, scriptKind);
const canonical = ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed }).printFile(src);
console.log(createHash('sha256').update(canonical).digest('hex'));
