# Independent Lab Audit — `delivery-context-pack.ts` pin repin + Q026 label fix

**Auditor:** Claude CLI (independent Lab auditor, read-only)
**Date:** 2026-09-09
**Repository:** `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908` (read-only; no source/dist/git/main mutation performed)
**Artifacts written:** this `report.md` and `recompute-fingerprint.mjs`, both in the audit cwd only.

---

## Verdict

| Item | Verdict |
| --- | --- |
| 1. Repin `delivery-context-pack.ts` → `7c345270…c6fd9` | **APPROVED** (with a mandatory two-site condition, §1.7) |
| 2. Q026 label-only rename (registry + matching `check` call) | **APPROVED** |

Neither change introduces a new authority sink, and neither widens the exemption surface. No blanket allowlist is proposed or required; all other negative controls remain in force.

---

## 0. Provenance discrepancies observed (do not change the verdict, but are on the record)

1. **HEAD mismatch.** The task states the tree is at `a03d1c2165`. Actual `HEAD` is `baeaa4fa58` (`test: reproduce blocked owner recovery with retained signed history`). Both commits exist and are reachable.
   *Immaterial to this audit:* `packages/main/src/handlers/delivery-context-pack.ts` is **blob-identical** (`eccb923ad3b59e49e8118ea11553196b4af1c33a`) at `HEAD`, at `a03d1c2165`, and at `6d99d14d96`. The fingerprint is therefore the same at all three, so the conclusion is invariant to which of them is the review point.
2. **Dirty working tree.** Modified but uncommitted: `docs/validation-performance.md`, `packages/main/src/core/process-fact-registry.ts`, `packages/main/src/core/store.ts`, `packages/main/src/core/verification-intent-checkpoint.ts`, `packages/main/src/handlers/checklist.ts`, and — relevant here — **`scripts/verify-process-fact-contract.mjs`**, one of the two files carrying the pin. The pinned file itself (`delivery-context-pack.ts`) is clean, and its worktree fingerprint equals its `HEAD` fingerprint, so the recomputation below is unaffected.
3. **Untracked `AGENTS.override.md`** is present at the repo root. I did not read or act on it. An untracked file that purports to override agent instructions is an injection-shaped artifact; flagging it for the humans, not treating it as authority.

---

## 1. Item 1 — Pinned executable source fingerprint

### 1.1 Algorithm, recomputed independently

The guard's algorithm is `typescript-printer-remove-comments-sha256-v1`
(`packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts:824-830`, with `parseSource` at `:809-822`):

```
ts.createSourceFile(file, text, ts.ScriptTarget.Latest, /*setParentNodes*/ true, scriptKind)
  → ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed }).printFile(...)
  → sha256(hex)
```

`scriptKind` for a `.ts` path resolves to `ts.ScriptKind.TS`. TypeScript in the lockfile: **5.9.3**.

I reimplemented this from the source above in a standalone script (`recompute-fingerprint.mjs`, written to the audit cwd) rather than calling the guard, so the check is genuinely independent of the code under audit.

### 1.2 Executed hashes

Path hashed: `packages/main/src/handlers/delivery-context-pack.ts`

| Revision | git blob | canonical AST SHA256 |
| --- | --- | --- |
| worktree (uncommitted) | `eccb923ad3b59e49e8118ea11553196b4af1c33a` | `7c345270f67ccc96bde83280cc2cf2fee2d7b7652b15cfc3e1e4b5b7f97c6fd9` |
| `HEAD` (`baeaa4fa58`) | `eccb923ad3b59e49e8118ea11553196b4af1c33a` | `7c345270f67ccc96bde83280cc2cf2fee2d7b7652b15cfc3e1e4b5b7f97c6fd9` |
| `a03d1c2165` | `eccb923ad3b59e49e8118ea11553196b4af1c33a` | `7c345270f67ccc96bde83280cc2cf2fee2d7b7652b15cfc3e1e4b5b7f97c6fd9` |
| `6d99d14d96` | `eccb923ad3b59e49e8118ea11553196b4af1c33a` | `7c345270f67ccc96bde83280cc2cf2fee2d7b7652b15cfc3e1e4b5b7f97c6fd9` |
| `main` / `origin/main` | `22e130d39881403ffbd6a82ab107c345e51aaf32` | `51af0fd5730add5aeff160f50c83b7dd70d2e5cdcfa0430e58acf4058acfb844` |

**Findings.** The candidate `7c345270…c6fd9` is confirmed by independent recomputation. The currently pinned `51af0fd5…acfb844` is confirmed to be exactly **main's** version of the file — i.e. the pin is stale relative to this branch, not wrong in itself. The guard is failing closed correctly, for the correct reason.

### 1.3 Exact old approved source, located via history

`git log --oneline main..HEAD -- <path>` returns exactly one commit:

```
6d99d14d96 fix: preserve signed acceptance history through replan and recoverable publication
```

The last approved source is therefore `main:packages/main/src/handlers/delivery-context-pack.ts` (blob `22e130d398`), and `6d99d14d96` is the sole commit that moved this file on the branch. The file has not been touched since; that is why `6d99d14d96`, `a03d1c2165` and `HEAD` are blob-identical.

### 1.4 Exact delta (complete, 2 insertions / 1 deletion, 1 file)

```diff
@@ -1,3 +1,4 @@
+import { rethrowIntentAmendmentIntegrityError } from '../core/verification-intent-amendment.js';
 import { execFileSync } from 'node:child_process';
 import { existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
 import { dirname } from 'node:path';
@@ -204,7 +205,7 @@ function assertSafeStoryId(storyId: unknown): asserts storyId is string {
 function readChecklist(ctx: HandlerContext, storyId: string): ChecklistData {
   try {
     return ctx.store.readChecklist(storyId);
-  } catch {
+  } catch (intentIntegrityError) { rethrowIntentAmendmentIntegrityError(intentIntegrityError);
     return { items: [] };
   }
 }
```

That is the whole delta. Nothing else in the file changed.

### 1.5 Compatibility producer / import / loader semantics — unchanged

The file's approved compatibility manifest
(`retired-authority-vocabulary-guard-smoke.ts:~352-357`) is:

```
symbols:     createLegacyLocalOnlyDeliveryClaims, LegacyLocalOnlyDeliveryClaims
calls:       createLegacyLocalOnlyDeliveryClaims → ['persistable-delivery-claims',
                                                    'delivery-context-report-claims']
occurrences: createLegacyLocalOnlyDeliveryClaims 3, LegacyLocalOnlyDeliveryClaims 3
```

Checked branch vs `main`:

| Symbol | branch | main |
| --- | --- | --- |
| `createLegacyLocalOnlyDeliveryClaims` | 3 | 3 |
| `LegacyLocalOnlyDeliveryClaims` (raw line count) | 6 | 6 |
| `isExactLegacyLocalOnlyDeliveryClaims` | 0 | 0 |

The raw count of 6 for `LegacyLocalOnlyDeliveryClaims` is the substring of the 3 `create…` lines plus its own 3 standalone uses; it reconciles with the manifest's 3 and, decisively, is **identical on both branches**. The compatibility producer surface, its two approved call shapes, and its occurrence counts are byte-for-byte untouched by the delta — the diff does not intersect any of those lines.

**Loader / dynamic-code semantics:** a scan for `import(`, `require(`, `eval(`, `new Function`, `createRequire` returns **NONE** on both the branch file and main's file. The file has no dynamic-load surface at all, before or after. The one added import is a **static, string-literal ESM import** of a first-party sibling module — the shape the guard treats as benign by construction, not by exemption. No non-literal loader call site is created, relocated, or re-anchored.

### 1.6 The changed checkpoint call — is this a new authority sink?

The changed call is the `catch` in `readChecklist`, now invoking:

```ts
// packages/main/src/core/verification-intent-amendment.ts:24-26
export function rethrowIntentAmendmentIntegrityError(error: unknown): void {
  if (error && typeof error === 'object' && 'code' in error
      && typeof error.code === 'string' && error.code.startsWith('AMENDMENT_')) throw error;
}
```

This is a **pure predicate-and-rethrow**. It performs no I/O, no store write, no verdict or phase mutation, no lease or receipt acquisition, and returns `void` on the non-matching path. It cannot grant, advance, or assert authority.

Its directional effect is the opposite of a sink: the previous bare `catch {}` swallowed **every** error from `ctx.store.readChecklist` and substituted `{ items: [] }`, which would silently mask an `AMENDMENT_*` intent-integrity failure as "this story has an empty checklist" — a fail-**open** path in a delivery-context producer. The change narrows that catch so integrity errors surface, while all other read failures still degrade to the empty checklist exactly as before. The fallback behaviour for non-integrity errors is unchanged.

**Conclusion: repinning retains a bounded exemption. It does not mask a new authority sink.** The pin moved because the whole-file structural fingerprint moves with *any* source edit — that is the pin's designed behaviour — and the two things this pin actually gates (the approved compatibility call shapes, and the absence of unapproved dynamic loads) are provably unchanged.

### 1.7 Scope of the approved repin — and a mandatory condition

Approved scope is **exactly one value in exactly two places**, `51af0fd5…acfb844` → `7c345270…c6fd9`:

1. `packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts:369` — the `PINNED_EXECUTABLE_SOURCE_FINGERPRINTS` entry.
2. `scripts/verify-process-fact-contract.mjs:2090` — the cross-checking expected-literal list.

**Both must move in the same commit.** These two are coupled by design, and the file's own comments record a prior incident of this exact class (`B-cdf6:F-057`) where only the guard was updated and the verifier then failed closed on the stale copy. Note that `verify-process-fact-contract.mjs` is currently dirty in the worktree (§0.2); the repin must be applied on top of a reviewed state of that file, not blind.

Also in scope: a re-approval comment at the guard entry recording the basis (new static import + narrowed catch in `readChecklist`; compat surface and dynamic-code surface unchanged). The AST algorithm strips comments, so the comment is the only durable record of the human re-approval and does not itself perturb the digest.

**Out of scope / must not happen:** no entry may be added to any allowlist or exemption map; `DYNAMIC_CODE_GENERATION_FINGERPRINT_EXEMPTIONS`, `legacyQuarantineFiles`, the approved-loader call-site registry, and every other pinned fingerprint must remain untouched. No blanket allowlist. All other negative controls stay.

---

## 2. Item 2 — Q026 case-registry metadata label (narrow label-only fix)

### 2.1 Confirmed finding

The three retired tokens are `authorityDone`, `fullAuthorityDone`, `productionDone`, appearing in the label string:

```
'never sets authorityDone, fullAuthorityDone, or productionDone'
```

at two sites:

- `packages/main/src/tasks/quorum-case-registry.ts:131` — the `"name"` field of the `Q026` entry (group `ordered-quorum-state`).
- `packages/main/src/tasks/quorum-submit-smoke.ts:1769` — the second argument of `check("Q026", …)`.

`quorum-submit-smoke.ts` **is** in the guard's allowed-test-file set (`retired-authority-vocabulary-guard-smoke.ts:291`). `quorum-case-registry.ts` is **not** in that set, nor in any other allowlist. So the new registry row copies vocabulary that was only ever approved inside the allowlisted assertion file into an un-exempted metadata file — which is precisely what the guard exists to catch. The guard is right to fail.

### 2.2 Assessment of the proposed fix: **APPROVED**

The proposed fix renames the label in the registry row and in the matching `check(...)` call, preserving all callback bodies and the `Q026` id.

- **It removes the violation at its source rather than exempting it.** No allowlist entry is added for `quorum-case-registry.ts`. This is strictly preferable to widening the exemption surface for what is only a human-readable display string.
- **It loses no test coverage.** The retired tokens that carry actual meaning are the *assertions*, and those all live in the preserved callback body inside the already-allowlisted smoke file: `result.authorityDone`, `result.fullAuthorityDone`, `result.productionDone`, the three `reviewEscalationStatus.*` counterparts, and the per-`runId` `summary.authorityDone` / `summary.fullAuthorityDone` / `summary.multiHostVerified` checks. Nine negative assertions, all retained. The label is metadata; the negative control is the body.
- **Both sites must move together, and the fix correctly says so.** The registry `name` and the `check()` label are a matched pair; renaming only one would trade a vocabulary failure for a registry-conformance failure.
- **Preserving the `Q026` id is correct** — the id is the stable cross-reference between the registry, the smoke, and any downstream case accounting. Renaming it would be a scope expansion with real breakage risk, for no benefit.

**Constraints on the rename:** the replacement label must describe the invariant without reusing the retired tokens (e.g. wording in terms of the current canonical vocabulary for those completion flags), must stay unique within the registry, and must be applied byte-identically at both sites. Nothing else in `quorum-case-registry.ts` or `quorum-submit-smoke.ts` should change — in particular, no assertion may be deleted or weakened under cover of the rename. Verified as a genuinely label-only change under those constraints.

---

## 3. Summary of executed checks

| # | Check | Result |
| --- | --- | --- |
| 1 | Recompute `7c345270…` from TS 5.9.3 printer, independently reimplemented | Confirmed on worktree, `HEAD`, `a03d1c2165`, `6d99d14d96` |
| 2 | Identify the currently-pinned `51af0fd5…` | Confirmed = `main`'s version of the file (stale pin) |
| 3 | Locate last approved source via history | `main` blob `22e130d398`; sole branch commit `6d99d14d96` |
| 4 | Exact delta | 1 file, +2 −1: one static import, one narrowed `catch` |
| 5 | Compat producer symbols / call shapes / occurrence counts, branch vs main | Identical (3/3/0 vs 3/3/0; raw 6 vs 6) |
| 6 | Dynamic-code surface (`import(`, `require(`, `eval(`, `new Function`, `createRequire`) | NONE on both branch and main |
| 7 | Semantics of the changed checkpoint call | Pure rethrow predicate; no writes, no authority mutation; closes a fail-open swallow |
| 8 | Q026 token provenance and allowlist status | Registry file not allowlisted; smoke file allowlisted at guard line 291 |
| 9 | Coverage retained under the label-only fix | All nine assertions preserved in the allowlisted body |

**Item 1: APPROVED**, conditional on both pin sites moving in one commit with a re-approval comment.
**Item 2: APPROVED** as a narrow label-only rename.
