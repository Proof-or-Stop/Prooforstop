#!/bin/sh
export PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN=1
export PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST=046d27c423734bfafcfe6457603222664738afe1993b8dd9358ba61a77af40d4
exec /opt/homebrew/bin/node /var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/cli.js "$@"
