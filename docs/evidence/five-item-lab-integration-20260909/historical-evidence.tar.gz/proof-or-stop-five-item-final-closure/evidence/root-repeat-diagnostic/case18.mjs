#!/usr/bin/env node
/**
 * B-ec67 CHK-006 — RED-first smoke for tool-executed, selector-bearing evidence
 * receipts. Drives the REAL handlers (verification_evidence_add AND
 * verification_evidence_batch_add) so both write paths are proven to reach the same
 * enforcement boundary, plus the coverage-gate demotion (buildVerificationCoverage).
 *
 * Prints `tool-executed-evidence-receipt-smoke: PASS` on success; throws (non-zero
 * exit) on any failed assertion.
 */
import { strict as assert } from 'node:assert';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { StoryStore } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/store.js';
import { acquireOwnerLease } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/story-owner-lease.js';
import { createChecklistHandlers } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/handlers/checklist.js';
import { buildVerificationCoverage } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/verification.js';
import { checkEvidenceFreshnessForGit, currentGitHead, currentMaterialHash, currentStoryFilesHash } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/evidence-freshness.js';
import { EVIDENCE_COMMAND_TIMEOUT_CAP_MS } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/validation-executor.js';
import { resetConfigCache } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/config.js';
import { runValidationCommand } from '/private/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-reuse-o31fjlkk/repo/packages/main/dist/core/validation-executor.js';
// Mirror of the private sha256Hex / VERIFICATION_OUTPUT_TAIL_CHARS in
// handlers/checklist.ts (checklist.ts:308-313). Recomputed independently in-test so a
// broken digest computation or truncation bound is actually mutation-killed (F-002).
function sha256Hex(value) {
    return createHash('sha256').update(value).digest('hex');
}
const VERIFICATION_OUTPUT_TAIL_CHARS = 4000;
function git(cwd, args) {
    return execFileSync('git', args, { cwd, encoding: 'utf-8', stdio: ['pipe', 'pipe', 'pipe'] }).trim();
}
function write(root, path, content) {
    mkdirSync(dirname(join(root, path)), { recursive: true });
    writeFileSync(join(root, path), content);
}
async function expectRejection(promise, marker, label) {
    let threw = false;
    try {
        await promise;
    }
    catch (e) {
        threw = true;
        const msg = e instanceof Error ? e.message : String(e);
        assert.match(msg, marker, `${label}: expected rejection matching ${marker}, got: ${msg}`);
    }
    assert.ok(threw, `${label}: expected the write to be REFUSED but it succeeded`);
}
/** Build an isolated temp git repo + story + checklist whose single item carries `intents`. */
function makeEnv(intents) {
    const root = mkdtempSync(join(tmpdir(), 'proof-or-stop-ec67-'));
    write(root, 'proof-or-stop.config.json', JSON.stringify({
        scanRoot: 'packages/main', rootDir: 'src', storyDir: '.proof-or-stop/story/actives', requirementsDir: 'docs/requirements',
    }, null, 2));
    // Causal execution keys require a resolved tool version. npm runs this smoke
    // with packages/main as process.cwd(), so seed the minimal manifest that the
    // resolver expects in an isolated fixture repo.
    write(root, 'packages/main/package.json', JSON.stringify({ name: '@proof-or-stop/core', version: '0.0.0-smoke' }, null, 2));
    write(root, 'packages/main/src/base.ts', 'export const base = true;\n');
    git(root, ['init', '-b', 'work']);
    git(root, ['config', 'user.email', 'smoke@example.test']);
    git(root, ['config', 'user.name', 'EC67 Smoke']);
    git(root, ['add', '.']);
    git(root, ['commit', '-m', 'seed']);
    git(root, ['branch', 'main']);
    resetConfigCache();
    const store = new StoryStore(root);
    const storyId = 'B-ec67s';
    const at = '2026-07-25T00:00:00.000Z';
    const story = {
        storyId, name: 'ec67-smoke', title: 'tool-executed evidence receipt smoke',
        description: 'smoke', type: 'chore', phase: 'DEV', priority: 'medium',
        createdAt: at, startedAt: at, endedAt: null,
    };
    const checklist = {
        items: [{
                id: 'CHK-001', title: 'exercise receipts', context: 'ctx', status: 'in_progress',
                startTime: null, endTime: null,
                verificationIntent: {
                    happy: intents.map((it, i) => ({ id: it.ref, desc: `intent ${i}`, type: it.type, priority: 'must' })),
                    edge: [], adversarial: [],
                },
            }],
    };
    store.writeStory(storyId, story);
    acquireOwnerLease(store.storyDirPath(storyId), { command: 'smoke_fixture_setup', cwd: root });
    store.writeChecklist(storyId, checklist);
    const handlers = createChecklistHandlers({ store, root, scanRoot: join(root, 'packages/main') });
    return { root, store, handlers, storyId };
}
function cleanup(env) {
    rmSync(env.root, { recursive: true, force: true });
}
// A trivial pinned command we fully control. The selector must appear in stdout.
const PASS_CMD = `node -e "console.log('MARKER_OK')"`;
const NO_SELECTOR_CMD = `node -e "console.log('SOMETHING_ELSE')"`;
const NONZERO_CMD = `node -e "console.log('MARKER_OK'); process.exit(3)"`;
const SELECTOR = 'MARKER_OK';
// ── 18. F-012: the audited override is CARRIED FORWARD by
//        verification_evidence_refresh_stale, so a receipt legitimately earned under a
//        raised ceiling is re-earned (not silently demoted) on refresh. Without the
//        carry-forward the stale row would be re-run at the 270s default, get KILLED, and
//        decay to a non-mechanical attestation on the very next refresh — turning the
//        override into a one-shot. Uses a fast pinned command with a raised budget: the
//        assertion is that the RE-EARNED receipt still carries the override block. ───────
{
    const env = makeEnv([{ ref: 'INT-REFRESH', type: 'cli' }]);
    try {
        await env.handlers.verification_evidence_add({
            storyId: env.storyId, itemId: 'CHK-001', intentRef: 'INT-REFRESH', kind: 'integration_test',
            command: PASS_CMD, selector: SELECTOR, result: 'pass', note: 'seed a raised-budget receipt to be refreshed',
            commandTimeoutMs: 45_000,
            commandTimeoutReason: 'seeded raised budget that must survive a stale-evidence refresh without decaying',
        });
        // Make the seeded row STALE by moving HEAD (a new commit changes headHash/materialHash).
        write(env.root, 'packages/main/src/drift.ts', 'export const drift = 1;\n');
        git(env.root, ['add', '.']);
        git(env.root, ['commit', '-m', 'drift so the seeded evidence goes stale']);
        const refreshOut = await env.handlers.verification_evidence_refresh_stale({ storyId: env.storyId });
        const ev = env.store.readChecklist(env.storyId).items[0].verificationEvidence?.find(e => e.intentRef === 'INT-REFRESH');
        assert.ok(ev, `refresh kept the evidence row (output: ${refreshOut})`);
        // The row was re-executed and re-earned: still a mechanical receipt, NOT demoted.
        assert.equal(ev.mechanical, true, 'F-012: the refreshed row is still a mechanical receipt (not demoted)');
        assert.ok(ev.receipt, 'F-012: the refreshed row still carries a receipt');
        assert.ok(ev.receipt.timeoutOverride, 'F-012: the refreshed receipt CARRIES FORWARD the audited override (else the raise decays to a one-shot)');
        assert.equal(ev.receipt.timeoutOverride.timeoutMs, 45_000, 'F-012: the carried-forward ceiling is the original raised one');
        assert.match(ev.receipt.timeoutOverride.reason, /must survive a stale-evidence refresh/, 'F-012: the carried-forward reason comes from the prior TOOL-OWNED receipt, staying attributable');
    }
    finally {
        cleanup(env);
    }
}
console.log('tool-executed-evidence-receipt-smoke: PASS');
console.log('tool-executed evidence receipt smoke passed');
//# sourceMappingURL=tool-executed-evidence-receipt-smoke.js.map