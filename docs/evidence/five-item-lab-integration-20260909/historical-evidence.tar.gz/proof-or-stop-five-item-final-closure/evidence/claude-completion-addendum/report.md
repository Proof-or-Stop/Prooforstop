# Independent Claude CLI addendum — closing the named gaps of `claude-completion-audit/report.md`

Auditor: Claude CLI (Opus 5), 2026-09-09. **Supplement, not a replacement**: the prior audit at
`../claude-completion-audit/report.md` is preserved untouched and its verdicts stand. This pass closes only the
five points that report explicitly marked *unverified*. It is a bounded source/control/count audit, not a
second broad review.

Targets: Lab `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908` @
`50ca0454dc8d6e2f44aa34918493da7415ee2c78`, and the main checkout read-only. No subagents, no builds, no
heavy/root/full-suite reruns, no source/config/Story/dist/Git mutation. Writes confined to this directory and
private temp. Post-check: Lab HEAD still `50ca0454`, working tree still only `?? AGENTS.override.md`; main HEAD
unchanged by me.

---

## 0. Identity gate — executed first, **PASS**

`../complete-identity/pinned-cli.sh --implementation-identity` → **exit 0**, output preserved as `identity.json`
(213,959 bytes, stderr empty).

| Check | Result |
|---|---|
| `a == b` against `../complete-identity/owner-strict.json` (full parsed structure) | **True** |
| Canonical SHA-256 of both documents | `68a4b15f751c9577a57ad57848ca8062072b4b0858d0d28fcd7198e7cdccd019` (equal) |
| Raw file SHA-256 of both | `b35c3ca450a5db9d86bf164ee5438ef9ad75c5f4659a40ef70f74d7c8570e0dc` (byte-identical) |
| Leaf-by-leaf diffs | 0 |
| `digest` | `48454fc7155b4822da9c947209b1a49c13d583bfb8a261180a4e196b6fb4cd95` ✓ expected |
| `fileCount` / `len(files)` | 1659 / 1659 ✓ expected |
| `schema` / `packageVersion` | `execution-implementation.v1` / `0.3.284` |

File inventory not echoed. As instructed, this pins the **read-only controller runtime** under
`…/pos-frozen-root-repeat-complete-fmb27fyi/repo`; it is not the `50ca` target's metadata.

---

## 1. Resource-audit classification and build-order controls — **VERIFIED**

Direct reads of `resource-audit-policy.mjs`, `resource-audit.json`, `resource-audit-contract.mjs`,
`build-order.mjs`, `resource-config.mjs` and the root `proof-or-stop.config.json`.

**Counts, recomputed from the raw JSON, not from any summary line:**

| Quantity | Computed | Where the code pins it |
|---|---|---|
| `validate.commands` | 134 | config |
| Audit entries total | 28 (21 `safe-to-declare-shared` + 7 `leave-undeclared`) | `resource-audit.json` |
| Audited readers | **21** | `resource-audit-contract.mjs:11`, `resource-config.mjs:15` |
| Effectively shared readers | **14** (indices 14, 18, 36, 87, 115, 116, 117–124) | same |
| `exclusive-local-writer` supersessions | **6** (indices 3, 6, 40, 79, 81, 105) | `resource-audit-contract.mjs:9` pins this exact list |
| `exclusive-build-precheck` supersessions | **1** (index 0 only) | `resource-audit-contract.mjs:12` |
| 14 + 6 + 1 | **= 21** ✓ | — |
| Routine writer barriers retained | **11** (1, 3, 6, 40, 79, 80, 81, 82, 83, 105, 125) | `resource-config.mjs:17` |
| `doneRequiredCommands` protected | **2 of 2** (`npm --prefix packages/main run build`, `npm test`) — both carry the exclusive plan barrier | `resource-config.mjs:18` |
| Commands declaring `resources` | 134 of 134, none empty; all 14 shared readers declare shared-only claims | recomputed here |

**Exclusivity of the precheck exception.** `resource-audit-policy.mjs:9` admits
`exclusive-build-precheck` only under the full conjunction `commandIndex===0` ∧
`argv==='node scripts/verify-lab-worktree.mjs'` ∧ `commands[1]` argv is exactly
`npm --prefix packages/main run build` ∧ `commands[1].resources` still contains the exclusive plan barrier, plus
(line 9, second assert) a non-empty `reference` and the barrier in its own `effectiveResources`, plus (line 10)
retention of every original `suggestedResources` claim. **`effectiveArgv` supersession** (line 7) is admitted only
at `commandIndex===40` with argv exactly `node packages/main/dist/tasks/quorum-submit-smoke.js` and
`effectiveArgv === argv + ' --jobs=4'`.

**I did not take that on reading alone.** `classification-probes.mjs` runs 13 mutated inputs
(`structuredClone` copies only — the Lab source is never written) through the real
`verifyResourceAudit`. Results in `classification-probes.json`:

| Probe | Outcome |
|---|---|
| baseline, unmutated | accepted, `{21, 14, 7}` |
| precheck class moved to index 3 / to index 40 | rejected `RESOURCE_AUDIT_SUPERSESSION_INVALID` |
| precheck entry argv altered (`--quiet` added, config kept consistent) | rejected `…SUPERSESSION_INVALID` |
| `commands[1]` changed to `run build:fast` | rejected `…SUPERSESSION_INVALID` |
| `commands[1]` barrier removed | rejected `…SUPERSESSION_INVALID` |
| precheck supersession drops its own barrier | rejected `…SUPERSESSION_INVALID` |
| precheck supersession missing `reference` | rejected `…SUPERSESSION_INVALID` |
| precheck drops one original suggested claim (config + audit changed together) | rejected `RESOURCE_AUDIT_WITHDRAWN_CLAIM: 0` |
| `effectiveArgv` applied at index 3 | rejected `AUDITED_ARGV_SUPERSESSION_INVALID` |
| index 40 with `--jobs=8` / with an extra `--verbose` | rejected `AUDITED_ARGV_SUPERSESSION_INVALID` |
| index 40 `effectiveArgv` deleted while config keeps the flag | rejected `AUDITED_COMMAND_DRIFT` |

**13 of 13 behave exactly as the narrow claim requires.** So: allowed *only* for the exact index-0 precheck; the
next command must be exactly the build and must keep its barrier; original suggested resources must all be
retained; `effectiveArgv` supersession is confined to index 40 quorum + exactly `--jobs=4`.

**Fresh short controls** (new private output in this directory, no 134-run, no performance series):

- `resource-config.mjs --audit-only` → exit 0,
  `RESOURCE_AUDIT_AND_BUILD_ORDER_GREEN {"auditedReaders":21,"effectivelySharedReaders":14,"supersededReaders":7}`
  (`addendum-resource-config-audit-only.log`). This is the short static mode and also re-asserts the two
  scheduler-level invariants at `resource-config.mjs:20-21` — index 0 conflicts with **every** other entry, and
  index 1 conflicts with every entry but itself.
- `resource-audit-contract.mjs` → exit 0, `RESOURCE_AUDIT_SUPERSESSION_AND_MUTATION_GUARDS_GREEN`
  (`addendum-resource-contract.log`).
- `build-order.mjs` → exit 0, `BUILD_ORDER_GREEN 8`, results in `addendum-build-order/build-order.json`.
  All 8 RED/GREEN cases reproduce `../build-order-green-v2/build-order.json` exactly:
  `stale` and `missing` pass only in GREEN; `failed-build` fails in both (codes `[0,3,1]`);
  **`removed-build-barrier` fails in GREEN too** — the sharpest control here, since it shows the index-0 precheck
  barrier alone does not order consumers after the build; the build's own barrier is load-bearing.

`../build-order-static134.log` and `../build-order-resource-contract-v2.log` carry exactly the two GREEN strings my
fresh runs reproduce.

**One reading corrected, no defect:** `build-order.mjs:25` checks `commandIndex===2` for the build end and `===3`
for the reader start against a 3-command plan. That is **not** an off-by-one: executor progress events are
1-based, confirmed from the recorded event streams (index set `{1,2,3}` in all 8 rows), and the guarding
`assert.ok(buildEnd>=0)` would fail loudly if it were wrong.

**Precision note (not a defect).** `verifyResourceAudit()` *on its own* does not pin *which* readers may become
`exclusive-local-writer` — that classification carries no index/argv restriction, unlike the precheck one. Probe
`new-exclusive-local-writer-on-shared-117` is accepted by the policy function in isolation, returning
`{21, 13, 8}`. It is then rejected by the count assertions `{21,14,7}` at `resource-audit-contract.mjs:11` and
`resource-config.mjs:15`, and the reverted set is separately pinned to `[3,6,40,79,81,105]` at
`resource-audit-contract.mjs:9`. The composite guard is sound and closed; the invariant simply lives in the
contract rather than in the policy function. I state it because a future refactor that keeps the policy but drops
the count assertions would silently widen the exception. **No applicable bug found; the classification is neither
flawed nor too broad, and I could not construct a negative input that passes the full contract.**

## 2. Root command repeat sub-counts — **VERIFIED**

Read `../root-command-repeat-complete.mjs` for schema/provenance, `../root-command-repeat-complete/results.json`,
its per-trial artifacts, `../claude-root-repeat-audit/report.md` and `../audit-reading-errata.md`. No heavy command
was rerun.

| Trial | Suite process starts | Successful consumers | allPass |
|---|---|---|---|
| pair 1 RED | 2 | 2 | true |
| pair 1 GREEN | 1 | 2 | true |
| pair 2 GREEN | 1 | 2 | true |
| pair 2 RED | 2 | 2 | true |
| **Total** | **6** | **8** | 4/4 |

**2/1/1/2 and 8 consumers (6 suite processes) confirmed**, and confirmed three independent ways rather than from
the summary: (a) `results.json` trial records; (b) the per-trial `*-processes.jsonl` files, whose raw line counts
are 2/1/1/2 with six distinct pids; (c) the eight per-run handler outputs, all `status: pass`, whose top-level
`commandExecutions` are `1,0,1,1,1,0,1,1` — **summing to exactly 6**, matching the OS-level pid count. The gate is
real, not descriptive: `root-command-repeat-complete.mjs:37` asserts `processes.length === (GREEN ? 1 : 2)`.

*Nuance worth recording:* in both RED run-2s the `reuse` record is `reusable: true` yet `commandExecutions: 1`.
That is not a contradiction — RED's fixture config sets `sharedExecution: false` (line 27), so lineage is computed
but reuse is not applied. The reuse records corroborate the mechanism; the process counts prove the effect.

**Eligibility, recomputed with the real helper** (`sharedValidationReuseAllowed` loaded from the frozen dist),
against both the frozen root-repeat runtime (`b25996f7`) and the current Lab worktree (`50ca0454`) —
identical on both (`addendum-root-eligibility.json`):

- `validate.commands` = 134, **reuse-eligible = 1** → index 8,
  `node packages/main/dist/tasks/tool-executed-evidence-receipt-smoke.js`. **1/134 confirmed.**
- `doneRequiredCommands` = 2, **reuse-eligible = 0**, **exact argv overlap with the eligible command = 0**.
  **DONE 0/2 with no exact argv overlap confirmed**, matching `rootDoneExactOverlap: 0` /
  `rootDoneReuseEligible: 0` — and `root-command-repeat-complete.mjs:17` asserts the overlap before writing it.

**Errata corrections confirmed against source, and adopted here:**

- The prior report's "Git silently fell back to `HEAD~1..HEAD`" is **wrong**. Git did not fall back; the auditor's
  own shell `||` chain did, after the 3-character `9d4` ref failed. Nothing about Git's ref resolution is
  demonstrated by that. Their re-check over the explicit full range is the result that stands.
- The recorded `argv[1]` is **inside** the temp fixture
  (`…/pos-root-repeat-YKFbRC/packages/main/dist/tasks/…`, true for all six events). What lies outside the fixture
  is the count log — `root-command-repeat-complete.mjs:22` writes it into the artifact directory — and the
  implementation actually executed, reached through the fixture's `packages/main/dist` symlink into the frozen
  root (line 29). The earlier phrasing "these paths resolve outside the private fixture" is imprecise.
- Fixtures are deleted on success (`keepFixture = !allPass`, lines 38–39). All four are absent today, and no
  `pos-root-repeat-*` directory remains. **Today's realpath therefore proves nothing about their former state**,
  and I make no such claim. The 2/1/1/2 counts do not depend on either wording.

**No current counter-evidence contradicts the prior report.** Every figure it published for this item
re-derives from the raw artifacts.

## 3. Main repository, recomputed read-only — **VERIFIED**

Independent recomputation in `addendum-main-recheck.json` (git read-only commands and my own SHA-256 only):

- **All 22 baseline files from `../before.json` `main.files`: 22 SAME, 0 changed, 0 missing** — hash-by-hash, not
  via the artifact's own flag.
- `git status --porcelain=v1 -z --untracked-files=all` is **byte-identical** to `before.main.status`
  (22 NUL-separated entries; empty symmetric difference).
- main HEAD moved `cf21df09…` → **`04e66fdbaeae…`**, root and `packages/main` version **0.3.285**, four commits:
  `e1d34d3dab`, `e96b6284bd`, `25b3a6a5ca "chore: record Lab b-e40f-convergence-20260909 maintenance at 0.3.285"`,
  `04e66fdbae`. This is the **separate named Lab movement**, not this experiment, and it must not be reverted.
- Lab HEAD `50ca0454…`, **`labHeadIsAncestorOfMain: false`** ✓. The merge base of Lab and main is exactly
  `cf21df09…` — the experiment's pinned baseline — with 65 Lab commits not on main. That is positive structural
  evidence that main advanced on a *different* line rather than absorbing this work.
- The experiment stays pinned at CF `cf21df09` / **0.3.284** (Lab `package.json` = 0.3.284; the pinned identity
  reports `packageVersion 0.3.284`).

I neither claim main never moved nor took any action toward it.

## 4. RED 74-vs-73 quorum count — **VERIFIED, fully resolved**

The prior audit's item 6 flagged a crude count of 74 `✓` lines against a reported 73. Parsing
`../full-ordered-comparison/results.json` `rows[mode=='RED'].result.commands[40].output` myself:

- Lines beginning with `✓`: **74**.
- Of these, exactly **one** is the trailing summary `✓ quorum_submit smoke passed (73 checks)`.
- Remaining: **73 case names, 73 unique, zero duplicates.**

**The discrepancy was the summary line, nothing else.** `final-evidence-selfcheck.py` excludes it with
`'smoke passed' not in line`, which is exactly the right exclusion, and the 74th line is not a wrapped or nested
artifact.

Verified independently against the **actual frozen registry**, not against the self-check's own output: loading
`QUORUM_CASES` from `packages/main/dist/tasks/quorum-case-registry.js` in both the frozen ordered runtime and the
Lab worktree gives 73 cases, 73 unique names, and the sorted name list is identical to RED's 73 — same SHA-256
`c7a23589c5a3a289ae62fba64b52d6c66da3fc8ddc918957df0fc94594af6a25` for all three lists, empty in both directions
(`addendum-quorum-registry-comparison.json`, names in `addendum-red-quorum-names.json`). `quorum-case-plan.ts:7-9`
independently pins the registry at 73 with unique IDs and names.

**GREEN's marker, correctly bounded.** GREEN's idx40 output has exactly **one** `✓` line (the summary) plus
`QUORUM_EXACT_COVERAGE {"cases":73,"jobs":4,"elapsedMs":228187.96825}` and **no individual names**. I make no claim
that GREEN archived individual worker logs — source confirms it cannot: `quorum-case-parallel.ts:78` removes the
shard temp directory (`index.json` / `index.log`) on success, retaining it only on failure.

**What the marker actually rests on.** `quorum-case-parallel.ts:71` calls `verifyQuorumResults` *before* printing
the marker at line 74, and `quorum-case-plan.ts:36-44` shows the parent checks, per shard: schema, `deepEqual` of
**every child manifest** against the parent's live manifest (`QUORUM_SOURCE_OR_MANIFEST_DRIFT`), the shard's exact
case-**ID** list against its plan slice (`QUORUM_SHARD_COVERAGE_MISMATCH`), and every case's **bodyDigest** against
the manifest (`QUORUM_CASE_BODY_DRIFT`) — over a plan that `validateQuorumPlan` already proved covers all 73 IDs
exactly once. The separately preserved paired worker evidence stands; no fresh heavy suite was needed, and none
was run.

## 5. Report claim accuracy — **VERIFIED**, with one correction to the *prior audit*

Read `../report.md` and `../claude-completion-audit/report.md`, and confirmed both drivers.

**Correction to the prior audit (item 1's "nuance"), which I substantiate with numbers.** That report states that
because both arms ran at peak concurrency 4, "the delta is intra-command pooling (`--jobs=4`, `--probe-jobs=4`)
plus the precheck barrier." **That inference does not hold**, for two independent reasons:

1. **The RED input also restored the CF baseline resource claims.** `full-complete-comparison.mjs:19` builds the
   RED arm as `{...c, args: <flags stripped>, resources: baseline.validate.commands[i].resources}`, with
   `baseline` read from `git show cf21df09…:proof-or-stop.config.json` (line 11). GREEN uses the current audited
   config unchanged (`run-ordered-green.mjs:11`, whose manifest at line 25 says so explicitly). Comparing the two
   configs directly: **26 of 134 commands differ in their resource declarations** (indices 0, 1, 3, 6, 14, 18, 36,
   40, 79–83, 87, 105, 115–125). Under the CF baseline **zero** commands carried the plan barrier and all 14
   audited readers were undeclared — i.e. fail-closed exclusive — whereas the current config has 12 barrier
   commands and declares those readers shared. So inter-command scheduling differs across the arms, not only the
   two internal pool flags and the precheck barrier.
2. **Equal peaks are maxima, not parallelism.** Mean concurrency (Σ per-command duration ÷ wall elapsed) is
   **1.559 for RED versus 2.325 for GREEN** — a ~49 % difference in average overlap despite both peaking at 4.

Evidence in `addendum-red-green-input-delta.json`. This is a correction to an auditor's inference; it does not
change the measured 268/268 result or the published elapsed figures, and it argues for *less* causal attribution,
not more.

**`../report.md` itself does not make that flawed claim, and I do not flag it for statements it never makes.**
Checked directly: line 32 already says RED restored the CF resource declarations while GREEN used the audited
declarations of `50ca0454` with two bounded pools and the precheck barrier; it reports the peaks as 4 and 4 as a
fact without the inference; and it states the full comparison is a **single pair** that cannot exclude host load,
cache or ordering contributions — no causal attribution to any one component. Line 5 explicitly denies an overall
48 % figure and denies summing the items into a Story-delivery claim. Line 40 already carries the GREEN
worker-log limitation in the correct form. Line 59 already states the main movement correctly. Line 36 already
carries the 21 → 14 + 6 + 1 split, the 11 retained routine writer barriers, and the statement that the
classification exception is limited to the exact index-0 command — all of which I verified above.

---

## Gap ledger

| Gap named by `claude-completion-audit/report.md` | Status |
|---|---|
| `resource-audit-policy.mjs` / `resource-audit.json` 21 = 14 + 6 + 1 split | **VERIFIED** (§1) |
| Narrowness of the precheck / `effectiveArgv` exception | **VERIFIED** (§1, 13/13 negative probes) |
| 11 routine writer barriers, DONE 2 protected | **VERIFIED** (§1) |
| The 8 bounded build-order controls + static-134 + contract-v2 logs | **VERIFIED**, reproduced fresh (§1) |
| Root repeat 2/1/1/2 split, 8 consumers / 6 processes | **VERIFIED** (§2) |
| `routine 1/134`, `DONE 0/2`, no exact argv overlap | **VERIFIED** via the live eligibility helper (§2) |
| `audit-reading-errata.md` not read | **READ**; both corrections confirmed against source (§2) |
| 22 original main file hashes not recomputed | **VERIFIED**, 22/22 same, status byte-identical (§3) |
| RED 73-vs-74 name count unresolved | **VERIFIED/RESOLVED**: 74 = 73 names + 1 summary line (§4) |

**Applicable bugs found: none.** One correction to the prior audit's causal inference (§5) and one
precision note about where the writer-set invariant lives (§1); neither is a defect in the Lab implementation.

## Unchanged and still not claimed

Nothing here alters the standing limitations. N8 and N9 remain unreproduced OS-level risks. The review
calibration remains exploratory and supports no universal recall claim. The 51-minute batch supports no speed
percentage. The full comparison remains one observed pair on a shared host — an observation, not a causal or
population result — and no 48 % Story figure is supported. **The final archive has not been created; approval
must stay conditional on the packager's own patch / bundle / unpack / hash verification actually running.**

## Artifacts in this directory

`identity.json` (preserved CLI output) · `addendum-findings.json` (machine-readable form of every figure above) ·
`classification-probes.mjs` / `.json` (13 negative inputs) · `addendum-resource-config-audit-only.log` ·
`addendum-resource-contract.log` · `addendum-build-order.log` + `addendum-build-order/build-order.json` ·
`addendum-root-eligibility.json` · `addendum-main-recheck.json` (22 hashes + status + ancestry) ·
`addendum-red-quorum-names.json` · `addendum-quorum-registry-comparison.json` ·
`addendum-red-green-input-delta.json`.
