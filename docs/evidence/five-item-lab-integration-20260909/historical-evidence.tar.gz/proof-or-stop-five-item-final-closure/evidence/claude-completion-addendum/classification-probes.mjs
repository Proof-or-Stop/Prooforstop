// Read-only negative-input probes for resource-audit-policy.mjs supersession classification.
// Mutates only structuredClone copies in memory; never writes Lab source.
import {readFileSync} from 'node:fs';
const root='/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const config=JSON.parse(readFileSync(root+'/proof-or-stop.config.json','utf8'));
const audit=JSON.parse(readFileSync(root+'/experiments/five-item-proof/resource-audit.json','utf8'));
const {verifyResourceAudit}=await import(root+'/experiments/five-item-proof/resource-audit-policy.mjs');
const barrier={class:'fixed-path',key:'.proof-or-stop/runtime/validate-plan-barrier',access:'exclusive'};
const results=[];
const probe=(name,expectThrow,fn)=>{
 const c=structuredClone(config),a=structuredClone(audit);
 let outcome,error=null;
 try{fn(c,a);const s=verifyResourceAudit(c,a);outcome='accepted';results.push({name,expectThrow,outcome,summary:s,error});}
 catch(e){outcome='rejected';error=String(e.message).split('\n')[0].slice(0,120);results.push({name,expectThrow,outcome,error});}
};
const ent=(a,i)=>a.entries.find(e=>e.commandIndex===i);

// Baseline (unmutated) must be accepted with the pinned counts.
probe('baseline-unmutated',false,()=>{});

// exclusive-build-precheck must be confined to index 0 with its exact argv.
probe('precheck-class-moved-to-index-3',true,(c,a)=>{ent(a,3).supersededBy.classification='exclusive-build-precheck';});
probe('precheck-class-moved-to-index-40',true,(c,a)=>{ent(a,40).supersededBy.classification='exclusive-build-precheck';});
probe('precheck-entry-argv-altered',true,(c,a)=>{
 ent(a,0).argv='node scripts/verify-lab-worktree.mjs --quiet';
 c.validate.commands[0].args=['scripts/verify-lab-worktree.mjs','--quiet'];});

// The command that follows the precheck must still be exactly the build, still holding its barrier.
probe('next-command-not-the-build',true,(c,a)=>{c.validate.commands[1].args=['--prefix','packages/main','run','build:fast'];});
probe('next-command-build-barrier-removed',true,(c,a)=>{
 c.validate.commands[1].resources=c.validate.commands[1].resources.filter(r=>r.key!==barrier.key);});
probe('precheck-supersession-drops-own-barrier',true,(c,a)=>{
 const keep=r=>r.key!==barrier.key;
 ent(a,0).supersededBy.effectiveResources=ent(a,0).supersededBy.effectiveResources.filter(keep);
 c.validate.commands[0].resources=c.validate.commands[0].resources.filter(keep);});
probe('precheck-drops-an-original-suggested-claim',true,(c,a)=>{
 const removed=ent(a,0).suggestedResources[0],keep=r=>JSON.stringify(r)!==JSON.stringify(removed);
 ent(a,0).supersededBy.effectiveResources=ent(a,0).supersededBy.effectiveResources.filter(keep);
 c.validate.commands[0].resources=c.validate.commands[0].resources.filter(keep);});
probe('precheck-supersession-reference-removed',true,(c,a)=>{delete ent(a,0).supersededBy.reference;});

// effectiveArgv supersession must be confined to index 40 quorum + exactly --jobs=4.
probe('effectiveArgv-on-index-3',true,(c,a)=>{
 ent(a,3).supersededBy.effectiveArgv=ent(a,3).argv+' --jobs=4';
 c.validate.commands[3].args=[...c.validate.commands[3].args,'--jobs=4'];});
probe('effectiveArgv-index40-jobs8',true,(c,a)=>{
 ent(a,40).supersededBy.effectiveArgv=ent(a,40).argv+' --jobs=8';
 c.validate.commands[40].args=c.validate.commands[40].args.map(x=>x==='--jobs=4'?'--jobs=8':x);});
probe('effectiveArgv-index40-extra-flag',true,(c,a)=>{
 ent(a,40).supersededBy.effectiveArgv=ent(a,40).argv+' --jobs=4 --verbose';
 c.validate.commands[40].args=[...c.validate.commands[40].args,'--verbose'];});
probe('effectiveArgv-index40-removed-but-config-keeps-flag',true,(c,a)=>{delete ent(a,40).supersededBy.effectiveArgv;});

// Breadth probe: does the policy alone stop an ARBITRARY extra reader being reclassified as a writer?
probe('new-exclusive-local-writer-on-shared-117',false,(c,a)=>{
 const e=ent(a,117);
 e.supersededBy={classification:'exclusive-local-writer',reference:'probe',
  effectiveResources:[...e.suggestedResources,barrier]};
 c.validate.commands[117].resources=[...c.validate.commands[117].resources,barrier];});

console.log(JSON.stringify(results,null,2));
