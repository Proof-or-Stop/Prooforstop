Bounded Lab calibration of pure evidence/lease/scheduling decision helpers. This is an intentionally small fixture, not production implementation or an actual Story. All inputs are restricted to the domains below; behavior outside those domains is not promised. The specification is authoritative. Do not infer a required number of defects.

isReusable: For objects with string version and implementationDigest, true exactly when both fields match. Version equality alone is insufficient.

hasWitness: For string output and a nonempty selector, true exactly when selector occurs anywhere in the complete output; output is at most1000chars.

renewLease: Lease has owner:string,generation:positive integer,heartbeat:nonnegative number. Caller owner:string,generation:positive integer,now>=heartbeat. Renew only when owner AND generation equal, preserving every other field; otherwise null.

mayPublish: Receipt status is pass or fail, exit is integer0..255. Reusable publication is allowed only for pass AND exit0.

uniqueClaims: Each claim has key:string,access:shared|exclusive,ownership:external|runner-cleanable. Deduplicate exactlyequal triples, preserving first occurrence order. Ownership differences are significant.

historyExtends: Inputs are arrays of signature strings. True exactly when before is a prefix of after, in the same order. Additional trailing signatures are allowed.

finalAdmission: Credential fresh:boolean,kind:final|remediation. Only fresh final credentials authorize final admission; remediation only allows repair.

coversExactly: Required is a nonempty array of distinct IDs; shards is array of ID arrays. Every required ID must occur exactlyonce across shards; no unknown IDs. Duplicates fail even when all required IDs exist.

mayShare: Input optIn,inputsKnown,build are booleans. Reuse only if optIn and inputsKnown and not build.

mayOverlap: Each resource has known:boolean,key:string,access:shared|exclusive. Unknown input refuses overlap. Equal keys conflict if either access isexclusive; different keys permit overlap when both known.