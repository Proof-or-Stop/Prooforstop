#!/bin/sh
export PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN=1
export PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST=6eb84016cd8c184fa7c13ceb2d83554d640ffb03d6e870689a0b5dbdceec999a
exec /opt/homebrew/bin/node /var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-quorum-paired-zqqmt720/repo/packages/main/dist/cli.js "$@"
