// Walk cli-engine.ts history and find which revision (if any) produces the OLD pin.
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';

const REPO = '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const FILE = 'packages/main/src/cli-engine.ts';
const GUARD = 'packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts';

// Resolve typescript exactly as the guard module would (from packages/main).
const reqMain = createRequire(`${REPO}/packages/main/package.json`);
const tsPathMain = reqMain.resolve('typescript');
const ts = reqMain('typescript');
console.log('=== typescript resolved from packages/main:', ts.version, tsPathMain);
const reqRoot = createRequire(`${REPO}/package.json`);
console.log('=== typescript resolved from repo root  :', reqRoot('typescript').version, reqRoot.resolve('typescript'));

const fp = text => createHash('sha256')
  .update(ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed })
    .printFile(ts.createSourceFile(FILE, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)))
  .digest('hex');

const git = args => execFileSync('git', args, { cwd: REPO, maxBuffer: 128 * 1024 * 1024 }).toString();

const OLD = '699e160f4977664bebc96fc887b522f805d03128394cfab5c50ac6a6b0169271';
const NEW = '90001d2bbfc38f27f9bc06d59883b15439a72551aa8eba4a67313139c703326d';
const PRE = 'b7e4c4b28ab1b513966dbd6fb2bb579b749109dbc94d72596f69c9804bc30d19';

const revs = git(['log', '--format=%H %s', '-40', '--', FILE]).trim().split('\n');
console.log(`\n=== last ${revs.length} revisions touching ${FILE} ===`);
let oldMatch = null;
for (const line of revs) {
  const sha = line.slice(0, 40);
  const subj = line.slice(41);
  let h;
  try { h = fp(git(['show', `${sha}:${FILE}`])); } catch { continue; }
  const tag = h === OLD ? '  <== OLD PIN' : h === NEW ? '  <== PROPOSED PIN' : h === PRE ? '  (pre-opt)' : '';
  if (h === OLD && !oldMatch) oldMatch = sha;
  console.log(`${h.slice(0, 16)}  ${sha.slice(0, 10)}  ${subj.slice(0, 72)}${tag}`);
}
console.log('\n=== OLD PIN matched revision:', oldMatch ?? 'NONE in the last 40 revisions of this file');

// When was the pin line itself last changed in the guard?
console.log('\n=== commits that changed the guard pin line ===');
console.log(git(['log', '--format=%H %ad %s', '--date=short', '-8', '-S', OLD, '--', GUARD]));
