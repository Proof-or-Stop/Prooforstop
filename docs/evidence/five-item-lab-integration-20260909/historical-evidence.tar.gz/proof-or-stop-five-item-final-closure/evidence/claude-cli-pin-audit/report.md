# Claude CLI independent pin audit — `packages/main/src/cli-engine.ts`

**Verdict: APPROVED (repin to `90001d2b…`), with one mandatory correction to the stated basis.**

Auditor: Claude CLI (Opus 5), independent of the Codex Lab change author.
Date: 2026-09-09. Scope: read-only. No source, runtime, build, git, or subagent action was taken.
Only artifacts under this output directory were written.

Lab worktree audited: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`
(HEAD `1274ede9cf`, clean-of-this-audit; `cli-engine.ts` working tree == HEAD).

---

## 1. Correction to the submitted premise (material)

> Submitted premise: *"the guard rejects because identity-single-scan optimization `d2c0217584` changed the whole-file AST hash."*

**That is not what happened, and it understates the delta by one commit.**
The pin `699e160f…` had **already gone stale one commit earlier**, at `fde845bf8b`.
`d2c0217584` moved an *already-broken* pin, it did not break a good one.

Independently executed hash chain (see §2):

| canonical AST hash | revision | relation to pin |
|---|---|---|
| `699e160f4977664bebc96fc887b522f805d03128394cfab5c50ac6a6b0169271` | `2dd9e7895e` *merge: origin/main into local main* | **= the current pin at guard line 475** — this is the true last-approved source |
| `b7e4c4b28ab1b513966dbd6fb2bb579b749109dbc94d72596f69c9804bc30d19` | `fde845bf8b` *fix: pin experimental CLI identity…* | **pin went stale HERE** (never repinned) |
| `b7e4c4b2…` (unchanged) | `296d1ca401`, `cc739aa659`, `d2c0217584^` | the two revisions named in the request as "pre-optimization" — they are *already* past the pin |
| `90001d2bbfc38f27f9bc06d59883b15439a72551aa8eba4a67313139c703326d` | `d2c0217584`, `HEAD`, working tree | **= the proposed pin** |

So: **the old pin does NOT match pre-optimization source.** The `cc739aa659` / `296d1ca4014`
baselines offered as "pre-optimization ground truth" both hash to `b7e4c4b2…`, which was never
an approved value. Any re-approval comment claiming "the diff since the previous pin is
`d2c0217584` only" would be false. The comment must attribute **both** commits.

## 2. Executed hashes (independent recomputation, not quoted)

Algorithm reimplemented verbatim from the guard, `retired-authority-vocabulary-guard-smoke.ts:806-827`:
`ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)` →
`ts.createPrinter({removeComments:true, newLine:ts.NewLineKind.LineFeed}).printFile(...)` →
`sha256(...).digest('hex')`.

TypeScript resolved from the repo, from **the guard's own package** (`packages/main`) and from the
repo root — both resolve to the identical file, so there is no toolchain split:

```
typescript 5.9.3
  node_modules/.pnpm/typescript@5.9.3/node_modules/typescript/lib/typescript.js
```

Reproduction scripts, left in this directory: `recompute-fingerprints.mjs`, `locate-old-pin.mjs`.

```
90001d2bbfc38f27f9bc06d59883b15439a72551aa8eba4a67313139c703326d  working tree      (72337 bytes)
90001d2bbfc38f27f9bc06d59883b15439a72551aa8eba4a67313139c703326d  HEAD 1274ede9cf
90001d2bbfc38f27f9bc06d59883b15439a72551aa8eba4a67313139c703326d  d2c0217584
b7e4c4b28ab1b513966dbd6fb2bb579b749109dbc94d72596f69c9804bc30d19  d2c0217584^ / cc739aa659 / 296d1ca401  (72024 bytes)
699e160f4977664bebc96fc887b522f805d03128394cfab5c50ac6a6b0169271  2dd9e7895e   <= current pin
```

The proposed value `90001d2b…` **reproduces exactly** against the current source. The pin as
proposed is arithmetically correct; the dispute is only over its justification.

Provenance of the stale pin: it was last written by `82bc9c6e0a` (2026-09-04,
*"repin AST-keyed guard digests for typescript 5.9.3 (toolchain, not code)"*) — consistent with the
guard's own `origin/main merge` comment block at lines 467-474. It was correct when written and
went stale two commits later without being noticed.

## 3. Exact changed boundary vs. the truly-approved source (`2dd9e7895e` → `90001d2b`)

`git diff --stat 2dd9e7895e d2c0217584 -- packages/main/src/cli-engine.ts` → **9 insertions, 0 deletions, 0 other files.**
The entire delta is two adjacent regions:

**(a) line 1 — one static named import added:**
```ts
import {enforceExecutionImplementationPin,executionImplementationIdentity} from './core/execution-implementation.js';
```
Static ESM import specifier. Not `import()`, not `require()`.

**(b) `runCli` prologue, immediately after the options destructuring (lines 726-732):**
```ts
  const enforcedImplementationIdentity = enforceExecutionImplementationPin();
  if (process.argv.slice(2).includes('--implementation-identity')) {
    // (3 comment lines — stripped by removeComments, no hash effect)
    console.log(JSON.stringify(enforcedImplementationIdentity ?? executionImplementationIdentity()));
    return;
  }
```

Nothing else in the 72 KB file changed.

## 4. Dynamic-code and loader/initPath provenance — the actual approval basis

I compared the full dynamic surface (`import(` / `require(` / `eval(` / `new Function(` /
`createRequire` / `vm.` / `initPath` / the `runCli` anchor) across the approved revision, both
intervening revisions, and the working tree — **not** diff size.

Approved rev `2dd9e7895e`:
```
719: export async function runCli(opts?: {
722:   extraOwnershipClasses?: Readonly<Record<string, import('./core/command-policy.js').OwnershipClass>>;
814:   const initPath = new URL('./cli-init.js', import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1');
815:   await import(`file://${initPath}`);
827:   const { runDashboard } = await import('./dashboard.js');
```
Working tree / `d2c0217584`:
```
720: export async function runCli(opts?: {
723:   extraOwnershipClasses?: Readonly<Record<string, import('./core/command-policy.js').OwnershipClass>>;
823:   const initPath = new URL('./cli-init.js', import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1');
824:   await import(`file://${initPath}`);
836:   const { runDashboard } = await import('./dashboard.js');
```

Findings:

- **Exactly two dynamic loads, byte-identical text, same `runCli` anchor.** Extracted-surface
  sha256 is the same 16-byte prefix `ccad64dd62fa1ac5` at every revision sampled, including
  `2dd9e7895e`. Only line numbers moved (814/815/827 → 823/824/836, +9 = the 9 inserted lines).
- **The `initPath` producer is unchanged and remains non-influenceable.** It derives from
  `import.meta.url`, not from `process.argv`, `--root`, env, or any new input. The new branch
  reads `process.argv` but that value never reaches `initPath` or either `import()` argument.
- **Zero `eval`, zero `new Function`, zero `require()`, zero `createRequire`, zero `vm.` added,
  removed, or rewritten** in `cli-engine.ts` across both commits.
- The one new control-flow effect is an **early `return` before** the loader path — it can only
  *skip* the approved load, never redirect it. No new load path is introduced.

## 5. The identity-reuse claim, verified

The claim that the optimization stores `enforceExecutionImplementationPin()`'s return and uses it
only adjacent to `--implementation-identity` output, with no broader cache, is **confirmed**:

- `enforcedImplementationIdentity` occurs at exactly two sites in the file: its declaration
  (`cli-engine.ts:726`) and its single consumption (`cli-engine.ts:731`), five lines apart.
- It is a **function-local `const`**, not module-level state, not exported, not passed to any
  callee. Nothing else in the file can observe it.
- `enforceExecutionImplementationPin()` (`core/execution-implementation.ts:79`) returns
  `ReturnType<typeof executionImplementationIdentity> | undefined` and returns a freshly computed
  `actual` on each call — there is no memo inside it either. The `?? executionImplementationIdentity()`
  fallback correctly covers the `undefined` (`!expected && !required`) return.
- `d2c0217584` touches **only** `cli-engine.ts` (5 insertions / 2 deletions). Other execution
  boundaries keep their independent fresh scans.

## 6. Bounded caveats (not blockers, explicitly not adjudicated by me)

1. **`packages/main/src/core/execution-implementation.ts` is not in
   `PINNED_EXECUTABLE_SOURCE_FINGERPRINTS` nor in `DYNAMIC_CODE_GENERATION_FINGERPRINT_EXEMPTIONS`.**
   It is new in `fde845bf8b` (65 lines) and has been amended twice since (`6d2cb93862`,
   `1f21cceab9`). It performs its own resolution via `createRequire(join(from,'package.json'))`
   (line 43). `cli-engine.ts` now statically imports it, so an approved entrypoint reaches that
   resolution surface. This does **not** change `cli-engine.ts`'s own pinned surface and is
   therefore outside this pin decision, but whether that module's own dynamic-resolution surface
   is separately approved is a question I did not audit and is not answered by this repin.
2. This audit validates the **fingerprint and the source delta**. I did not execute the guard
   suite, build, or any negative control (out of the read-only mandate).

## 7. Required conditions on the repin

1. Write **both** coupled copies in the same commit:
   - `packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts:475`
   - `scripts/verify-process-fact-contract.mjs:2114`

   Both currently hold `699e160f…`; both must become
   `90001d2bbfc38f27f9bc06d59883b15439a72551aa8eba4a67313139c703326d`.
2. The re-approval comment must state the **correct two-commit basis** — pin last valid at
   `2dd9e7895e`, stale from `fde845bf8b`, moved again by `d2c0217584`, total delta 9 inserted
   lines — and must not repeat the "d2c0217584 only" framing.
3. Leave every other entry in `PINNED_EXECUTABLE_SOURCE_FINGERPRINTS`,
   `DYNAMIC_CODE_GENERATION_FINGERPRINT_EXEMPTIONS`, and all negative controls untouched.
   This audit found no reason to move any of them; none were inspected for staleness.

---

**Bounded reason for APPROVED:** the proposed value reproduces exactly under the guard's own
algorithm and the repo's own TypeScript 5.9.3; the complete delta from the last genuinely approved
source is 9 inserted lines in one file, consisting of one static import and one synchronous
argv-gated early-return branch; the dynamic-code surface, the two approved `import()` call sites,
the `runCli` anchor, and the `initPath` producer are byte-identical to the approved revision; and
the stored identity is a function-local value with a single adjacent use and no cache. The one
defect found is in the **justification, not the code** — the pin was stale a commit earlier than
claimed — which condition 7.2 requires be corrected in the re-approval record rather than blocking
the repin.
