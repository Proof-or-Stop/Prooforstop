// Independent reimplementation of the guard's canonicalAstFingerprint(), copied
// verbatim from packages/main/src/tasks/retired-authority-vocabulary-guard-smoke.ts
// lines 806-827, using the repo's own typescript (5.9.3).
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const REPO = '/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908';
const require = createRequire(REPO + '/package.json');
const ts = require('typescript');

const FILE = 'packages/main/src/cli-engine.ts';

function parseSource(file, text) {
  const scriptKind = file.endsWith('.tsx')
    ? ts.ScriptKind.TSX
    : file.endsWith('.jsx')
      ? ts.ScriptKind.JSX
      : /\.(?:js|mjs|cjs)$/.test(file)
        ? ts.ScriptKind.JS
        : ts.ScriptKind.TS;
  return ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, scriptKind);
}

function canonicalAstFingerprint(file, text) {
  const canonical = ts.createPrinter({
    removeComments: true,
    newLine: ts.NewLineKind.LineFeed,
  }).printFile(parseSource(file, text));
  return createHash('sha256').update(canonical).digest('hex');
}

const show = rev => execFileSync('git', ['show', `${rev}:${FILE}`], { cwd: REPO, maxBuffer: 64 * 1024 * 1024 }).toString();

const revs = {
  'worktree (uncommitted)': readFileSync(`${REPO}/${FILE}`, 'utf8'),
  'HEAD (1274ede9cf)': show('HEAD'),
  'd2c0217584 (identity opt)': show('d2c0217584'),
  'd2c0217584^ (parent)': show('d2c0217584^'),
  'cc739aa659 (preopt)': show('cc739aa659'),
  '296d1ca401': show('296d1ca401'),
};

console.log('=== ts version:', ts.version);
console.log('=== canonical AST fingerprints for', FILE);
for (const [label, text] of Object.entries(revs)) {
  console.log(`${canonicalAstFingerprint(FILE, text)}  ${label}  (bytes=${Buffer.byteLength(text)})`);
}

// Dynamic-code / loader surface extraction: every import()/require()/eval()/
// new Function()/vm line plus the initPath producer chain.
const RE = /\bimport\s*\(|\brequire\s*\(|\beval\s*\(|new\s+Function\s*\(|createRequire|\bvm\.|initPath|runCli/;
console.log('\n=== dynamic-code + loader/initPath surface ===');
for (const [label, text] of Object.entries(revs)) {
  const hits = text.split('\n')
    .map((l, i) => [i + 1, l.trim()])
    .filter(([, l]) => RE.test(l) && !l.startsWith('//') && !l.startsWith('*'));
  const surface = hits.map(([, l]) => l).join('\n');
  console.log(`--- ${label}: ${hits.length} lines, surfaceSha=${createHash('sha256').update(surface).digest('hex').slice(0, 16)}`);
  for (const [n, l] of hits) console.log(`    ${n}: ${l}`);
}
