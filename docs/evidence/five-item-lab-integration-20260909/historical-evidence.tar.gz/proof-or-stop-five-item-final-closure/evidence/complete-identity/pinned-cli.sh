#!/bin/sh
export PROOF_OR_STOP_REQUIRE_IMPLEMENTATION_PIN=1
export PROOF_OR_STOP_EXPECTED_IMPLEMENTATION_DIGEST=48454fc7155b4822da9c947209b1a49c13d583bfb8a261180a4e196b6fb4cd95
exec /opt/homebrew/bin/node /var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-root-repeat-complete-fmb27fyi/repo/packages/main/dist/cli.js "$@"
