# Independent Claude CLI completion audit — five-item final closure

Scope: bounded verification of the final claims and data for the five items at Lab
`/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908` @ `50ca0454dc8d6e2f44aa34918493da7415ee2c78`.
Read-only. No builds, no suite reruns, no source/config/Git/main mutation. Budget: 8 tool calls (7 used for evidence, 1 for this file).
This is **not** a repository-wide audit and certifies neither production Stories, deployment, global defect recall, nor absence of OS risks.

## 0. Controller identity pin (precondition)

`../complete-identity/pinned-cli.sh --implementation-identity` → **exit 0**.

| field | captured | `owner-strict.json` |
|---|---|---|
| digest | `48454fc7155b4822da9c947209b1a49c13d583bfb8a261180a4e196b6fb4cd95` | identical |
| fileCount | 1659 | identical |
| deep JSON compare | — | **equal on every field** (schema, runtime, entrypoint, packageVersion, implementationRoot, files) |

Pin remains set; no inventory echoed. This pins the read-only controller runtime (484/1659), which is kept distinct from the
old `6eb`/1659 and intermediate `046`/1640 identities and from the later rebuilt target.

---

## Verified before/after table

| Measure | RED (retained complete arm, `b25996f7`) | GREEN (fresh, `50ca0454`) | Source / my check |
|---|---|---|---|
| Commands per arm | 134 | 134 | `results.json` `commands[]` length |
| Exit codes | 134 × `code: 0` | 134 × `code: 0` | **268/268 = 0**, recounted |
| `timedOut` | none | none | all `None` |
| allPass / passed / failed | true / 134 / [] | true / 134 / [] | row fields |
| Timeout policy | {120k,180k,270k,290k,300k,600k,1200k} ms | **identical set, per-index identical** | 0 timeout diffs across 134 indices |
| Closest approach to a timeout | 0.647 × limit | 0.730 × limit | max(duration/timeout) |
| argv differences | — | **exactly 2**: idx40 `+--jobs=4`, idx106 `+--probe-jobs=4` | full per-index argv/label/command diff |
| Wall elapsed | 1,695,867.373167 ms | 952,471.273208 ms | matches `final-metrics.json` exactly |
| Recomputed decrease | — | **43.8357%** | equals published `43.83574516034954` |
| Sum of per-command durations | 2,643,897 ms | 2,214,357 ms | recomputed |
| Observed peak concurrency | 4 | 4 | row `peak` |
| Quorum coverage | 73 named checks + "73 checks" | `QUORUM_EXACT_COVERAGE {"cases":73,"jobs":4,"elapsedMs":228187.96825}` + "73 checks"; **no individual names** | command idx40 output |
| Probe coverage | `ACCEPTANCE_FORBIDDEN_FIELD_COVERAGE` 58 ids, jobs 1 / peak 1 | 58 ids, jobs 4 / peak 4 | **id lists compare exactly equal** |
| idx0 precheck window | 10:02:39.369 → 10:03:03.744Z | 10:51:29.139 → 10:51:58.260Z | `runtimeTrace` |
| build (idx1) window | 10:03:03.759 → 10:03:22.072Z | 10:51:58.268 → 10:51:59.575Z | `runtimeTrace` |
| Consumers starting before build end | **0 of 132** | **0 of 132** | recomputed from timestamps |
| Consumers starting before idx0 end | 0 | 0 | recomputed |
| main HEAD | `cf21df09` (experiment baseline) | observed `04e66fdb…` / 0.3.285 | `main-final-audit.json`, `parallel-main-movement.json` |
| Lab HEAD | `296d1ca4` (before.json) | `50ca0454`, `labHeadIsAncestorOfMain: false` | before/after JSON |

Separate cold prefix (not part of either 134 timing): 3 commands, 73,852.338 ms, `distAbsentAtStart: true`,
`cliPresentAtEnd: true`, allPass — i.e. the guarded private `main/dist` deletion was recovered by a real rebuild and test pass.

---

## Item verdicts

### 1. Full 134-command paired validation — **supported as scoped**
Both arms execute the same production and normal test scripts; `final-source-delta.json` lists 8 changed files, all docs /
`experiments/five-item-proof/*` / `proof-or-stop.config.json` — no core source or routine test script changed since the
completed RED. All 268 results are exit 0, every original timeout is unmodified per-index, and the published elapsed values and
43.8357% figure reproduce exactly from the raw durations. `manifest.json` self-declares `formalStoryEvidence: false` and
`productionTimeoutsUnmodified: true`, consistent with what I measured.

Correctly bounded, and I confirm the framing: this is **one RED→GREEN pair on a shared host — an observation, not a causal
result**. It supports no population claim, no Story lead-time inference, and **no 48% figure**; the observed full-validation
decrease is 43.84%, and the root-routine median decrease is 42.83% (arithmetic re-derived from 156.5435 s → 89.4969 s).
One nuance worth stating explicitly: **both** arms ran at peak concurrency 4, so the delta is intra-command pooling
(`--jobs=4`, `--probe-jobs=4`) plus the precheck barrier, not "serial → parallel".

### 2. Build-order defect and the narrow exclusive precheck — **supported behaviorally; source-level classification not independently inspected**
The independent reproduction in `../claude-build-order-audit/report.md` recommended a single exclusive first-precheck barrier,
and the observable consequences hold in both complete arms: idx0 finishes before the build starts, the build finishes before
**every** one of the 132 consumers starts, and `order-proof.json` (`completeRedBuildPrecedesAllConsumers`,
`completeGreenBuildPrecedesAllConsumers`, `coldRealPrefix`, `productionScriptsUnchanged`) matches my recomputation from raw
`runtimeTrace` timestamps rather than from the summary flags.

Strong indirect evidence for the *narrowness* claim: across all 134 index pairs the effective argv differs at **exactly two**
indices — idx40 (quorum, `--jobs=4`) and idx106 (`--probe-jobs=4`). No other command was reshaped, so supersession did not leak
beyond the declared points.

**Concrete gap:** within the 8-call budget I did not read `experiments/five-item-proof/resource-audit-policy.mjs`,
`resource-audit.json` (the 21 = 14 shared + 6 writers + 1 precheck entry split), or the eight bounded controls in
`build-order-green-v2/build-order.json`, `build-order-static134.log`, `build-order-resource-contract-v2.log`.
Those specific assertions are **not certified by this audit** — they are stated by the artifacts and by the prior build-order
audit, and remain to be confirmed by direct source/control inspection. No engine refactor is indicated by anything I saw.

### 3. Root command repeat — **metrics consistent; sub-counts not independently verified**
`final-metrics.json` `rootRoutineRepeat` records 4 trials, 8 consumer invocations, 6 actual suite subprocesses, medians
156.5435 s → 89.4969 s; the 42.8294% figure re-derives exactly. This is the applicable-repeated-routine-use claim, and it must
**not** be read as elimination of aggregate-leaf duplicate coverage.

**Concrete gap:** the 2/1/1/2 execution split, the exact-eligible `routine 1/134` and `DONE 0/2` no-overlap findings, and
`audit-reading-errata.md` were not read in this pass; `root-repeat-complete-runtime.json` contains only runtime binding
(path/head `b25996f7`/main `cf21df09`, clone-on-write, independent writable dist). Per instruction I did not rerun heavy suites.

### 4. Core mechanisms, calibration, long batch — **no new certification; prior negative findings preserved**
Signature/owner-recovery/pools/supervision and the second-rename EIO controls stay where they were independently examined
(`../claude-final-mechanisms-audit/report.md`, `../claude-evidence-repair-addendum/report.md`). **N8 and N9 remain unreproduced
and unfixed OS-level risks under the cooperating-Node model and are not solved**; a blocker only becomes applicable when it
names a testable failure. The review calibration (20 calls / 21 identities) is exploratory — post-hoc oracle, mutable mtime,
ordered arms — and supports **no universal recall claim and no 39.6% Story improvement**. The 51-minute batch has **no
successful RED endpoint** and only a post-run lease-sufficiency recheck with live-path dependency: it supports no speed
percentage and no original full-trace claim. Nothing in this audit changes any of those negative verdicts.

### 5. Main repository state and archive readiness — **supported, with one mandatory phrasing correction**
`main-final-audit.json` records `mainHeadUnchanged: false` with `mainStatusUnchanged: true`; `parallel-main-movement.json`
shows main at `04e66fdbaeae…`/0.3.285 reached through a **different named Lab, `b-e40f-convergence-20260909`**, with
`labHeadIsAncestorOfMain: false`. So: **it would be wrong to say main's HEAD/version never changed.** The correct statement is
that main moved independently under another task, this Lab head is not integrated into or an ancestor of main, this experiment
stays pinned at `cf21df09`/0.3.284, and this task performed no integration, merge, rollback or release. The other task's work
must not be reverted.

Supporting byte evidence I checked: `ordered-runtime-byte-comparison.json` compares the target **after** the cold build against
the audited controller — `packages/main/src` 893, `packages/main/tests` 208, `scripts` 105 all identical, and 3557
`packages/main/dist` files identical except the generated `full-suite-build-binding.json`. That supports **identical executable
bytes only**, not identical path/Git-metadata identity.

The final archive **has not been created**. Any approval must therefore stay conditional on the packager's own
patch/bundle/unpack/hash checks actually running; nothing here may be represented as an already-verified archive.

**Concrete gap:** I read the scalar fields of `main-final-audit.json` but did not print `originalFilesCompared` /
`changedOriginalFiles` / `fileHashes`; the "original 22 file hashes and Git status remain equal" claim rests on the artifact's
own `originalFilesUnchanged`/`mainStatusUnchanged` flags plus the equal `mainStatus` string, not on my hash-by-hash recompute.

---

## Exact claims that would be mistaken, and missing proof

1. **"Main HEAD/version never changed."** False as written. Main is at `04e66fdb…`/0.3.285 via Lab `b-e40f-convergence-20260909`;
   the accurate claim is non-integration of this Lab, not immobility of main.
2. **"48% faster" / "39.6% Story improvement" / any speed % from the 51-minute batch.** Unsupported. The measured values are
   43.84% (full validation, single pair) and 42.83% (root routine median, 4 trials), both single-host observations.
3. **"GREEN archived the 73 individual quorum worker reports."** Must not be claimed. `final-evidence-selfcheck.json` is
   explicit: `greenIndividualWorkerReportsRetained: false`. I confirmed directly from the raw output that GREEN's idx40 log
   contains only the strict parent marker `QUORUM_EXACT_COVERAGE {"cases":73,…}` plus the "73 checks" line and **no individual
   names**, while RED's contains the named checks. Successful per-worker temp files are removed by the existing parent. The
   report's own statement of this is accurate.
4. **"Identical runtime identity."** Only identical executable bytes are shown (one generated dist binding file differs);
   path/Git metadata identity is not established.
5. **Causal reading of the paired arms.** Not available from one RED→GREEN pair; population and Story-speed inferences remain
   unproven.
6. **Minor unresolved discrepancy (flagging, not asserting a defect):** a crude count of indented `✓` lines in RED's idx40
   output returned 74 against the reported/aggregate 73 checks. `final-evidence-selfcheck.json` asserts
   `red73NamesMatchCurrentRegistry: true` and carries the name list. Most likely one nested or wrapped output line inflated my
   regex, but I had no call left to resolve it. **This should be confirmed by de-duplicating the parsed names against the
   registry before the count is quoted as exact.**

## Preserved negative history (must remain visible; nothing hidden)

- First root series: final **RED 180 s timeout** — retained.
- First **132/134 failed** full result — retained as a failure.
- Superseded prepared GREEN **intentionally canceled at 126 passes** because it masked the ordering defect; the valid completed
  RED was retained and the incomplete arm is not relabeled.
- The wrong floating-main copy **failed command preflight before tests** and stays documented.

## Overall

For the scope I could reach in the call budget, the evidence substantiates the reported final configuration: 268/268 passing
results, unmodified original timeouts, command identity differing only by the two permitted pool flags, published elapsed and
percentage figures reproducing exactly from raw durations, matching 73-case quorum coverage and byte-identical 58-id probe
lists, and build completion strictly preceding every consumer in both complete arms plus the real cold prefix. The remaining
required work is narrow and named above: direct inspection of `resource-audit-policy.mjs` / `resource-audit.json` (21 =
14+6+1) and the eight bounded build-order controls, the root-repeat sub-counts and `audit-reading-errata.md`, the 22 original
file hashes, and the RED 73-vs-74 name count. Those are **unverified by this audit, not verified-and-passing**.
