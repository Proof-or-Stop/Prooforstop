Claude原始审计文本的非结论性更正（不覆盖原报告）

claude-root-repeat-audit/report.md第5节说“Git silently fell back to HEAD~1..HEAD”不准确。原始Bash工具调用明确写了“git ... diff --stat 9d4..b259 ... || git ... diff ... HEAD~1 ...”，回退来自审核者自己的shell命令，并非Git行为。9d4也只有3字符，不能仅凭该失败归因为歧义。审核者随后用完整的9d4d4b93d3到b25996f711区间重查，5个文件列表与complete-runtime-delta.json一致；本报告只采用后一次明确区间的结果。

该报告称进程argv路径在fixture之外，也需要精确表述：记录的argv[1]仍位于临时fixture路径，夹具设置把其packages/main/dist链接到冻结副本；外部独立的是计数日志的位置和实际读取的实现目录。成功后fixture已删除，路径解析来源是保留的建夹具脚本与执行记录，不能声称现在还能对原fixture执行realpath。实际2/1/1/2次进程计数及消费者结果不受这两处措辞影响。
