from pathlib import Path
import subprocess,time,json
art=Path(__file__).resolve().parent
results=[]
for name in ['root-command-repeat-complete','full-complete-comparison']:
 t=time.time()
 with (art/(name+'-driver.log')).open('w') as output:
  p=subprocess.run(['node',str(art/(name+'.mjs'))],cwd=art,stdout=output,stderr=subprocess.STDOUT)
 results.append({'name':name,'startEpoch':t,'endEpoch':time.time(),'exitCode':p.returncode})
 (art/'complete-experiment-exits.json').write_text(json.dumps(results,indent=2)+'\n')
 print(results[-1],flush=True)
