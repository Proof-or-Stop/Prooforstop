# Bounded source audit — can `quorum-submit-smoke` `check()` cases be sharded into isolated processes?

Auditor: Claude CLI (independent audit, not a Story review).
Worktree read: `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908`.
Phase constraints honoured: no source/dist/config/main/Story edits, no builds, no subagents,
no runtime execution, no reads of the active `B-e40f` worktree, no commands against other worktrees.
All line numbers are from the file state read on 2026-09-09 in this worktree.

## Verdict

**Reject sharding on the current source.** Two independent blocking levels, either of which is
sufficient on its own:

- **Level I — correctness.** The suite is not a set of independent cases. A non-contiguous chain
  of 13 cases mutates one shared, module-level, irreversibly-mutated git fixture in source order,
  and one case carries a live JS value (`result`) to three downstream cases. Selection identity is
  a *substring of a free-text name*, there is no case id, no uniqueness check, and **no coverage
  assertion of any kind** — the existing `--grep` narrowing already fails **open**.
- **Level II — scheduling.** The effective root resource declaration for this command claims the
  plan-wide barrier `.proof-or-stop/runtime/validate-plan-barrier` **`exclusive`**. Under
  `claimsConflict` that conflicts with *every* other command in the plan. N shards inheriting that
  declaration run strictly serially, so a correct shard split yields **zero** wall-clock gain —
  it can only add per-shard setup. Sharding therefore cannot be demonstrated as a fix without a
  separate, separately-reviewed change to that declaration, which the Lab owner has already
  recorded as deliberately conservative and effective policy.

A feasible partition boundary *does* exist (§6), but only behind a refactor plus new mechanism
(§7); it is not available on the source as it stands.

---

## 1. What the harness actually is

`packages/main/src/tasks/quorum-submit-smoke.ts` — 3489 lines, **73 registered `check(name, fn)`
call sites** (grep of `check(` yields 74 hits: 73 call sites plus the definition at :682).

```
:676-679  GREP_FILTER  = process.argv.find(a => a.startsWith('--grep='))  → substring or null
:681      let passed = 0
:682-687  function check(name, fn) {
            if (GREP_FILTER !== null && !name.includes(GREP_FILTER)) return;   // silent skip
            fn(); passed += 1; console.log(`  ✓ ${name}`);
          }
```

The header comment at `:665-675` states `--grep` is "opt-in, additive-only narrowing". That is
true of *assertion bodies* (a selected case runs unmodified) and false of *coverage*: nothing
records which cases were skipped.

```
:3484  console.log(`\n✓ quorum_submit smoke passed (${passed} checks)`);
:3485-3489  } finally { process.chdir(previousCwd); rmSync(root,…); resetConfigCache(); }
```

**There is no strict gate and no expected-count assertion today.** `passed` is printed, never
compared. `--grep=zzz` selects zero cases, prints `passed (0 checks)`, and exits `0` green. Any
shard scheme must therefore *introduce* the all-case coverage gate the question presupposes — it
cannot inherit one.

---

## 2. Cross-case state inventory (the Level I blockers)

### B1 — shared module-level fixture, mutated irreversibly, order-dependent, **non-contiguous**

```
:764-768   const previousCwd = process.cwd();
           const { root, store, registry } = makeFixture();   // ONE fixture for the whole file
           try { process.chdir(root);
```

`makeFixture` (`:185-256`) is not cheap or idempotent: `mkdtempSync` (`:189`), a written
`proof-or-stop.config.json` (`:190`), seeded files, then `git init` / `checkout -B main` /
`add` / `commit` / `checkout -B story/<id>` / second commit / third commit (`:232-252`), then a
`StoryStore` and a full `createMainRegistry` (`:241`, `:255`).

Cases that operate on that shared `root` / `store` / `registry` — i.e. **not** on their own
`withFreshFixture` — and the dependencies between them:

| Line | Case | Shared-state effect / dependency |
|---|---|---|
| :1332 | refuses when required reviewer passes are absent | `assertQuorumRefuses(registry, store, root, …)` (:1333) |
| :1336 | numerically sufficient compatibility/retired-only receipts | writes then restores `store.writeReviewRuns/Passes` (:1376-1377, :1391-1392) |
| :1395 | refuses when reviewer passes are stale | `commitMaterialChange(root)` (:1414) — **advances shared HEAD, irreversible** |
| :1418 | machine REVIEW and quorum consume the same replay/tamper proof | mutates & restores `promptEnvelopes` (:1449, :1454); depends on :1395's material |
| :1519 | emits exactly rounds x 2 verdicts | **writes 6 verdicts into the shared fixture**; assigns `result` |
| :1665 | review_escalation_status / assurance floor report 3x2 | reads the verdicts written by :1519 |
| :1716 | auto-computed materialDigest and storyFilesHash | reads `result.materialDigest` (:1717-1718) |
| :1724 | hosts are independent by hostId/sessionId/keyId | reads `result.hosts`, `result.runIds` (:1725, :1729) |
| :1737 | never sets authorityDone/fullAuthorityDone/productionDone | reads `result.*` (:1738-1744) |
| :1752 | refuses a same-material re-submit | comment at :1753-1755 states the dependency in-source: "No material change **since the rounds=3 quorum above**" |
| :1793 | allows a fresh quorum after a material change | `commitMaterialChange(root)` (:1796) then re-quorum; depends on :1752 state |
| :1821 | `--rounds=N (N != 3)` | `commitMaterialChange(root)` (:1825); comment at :1823-1824: "Advance the material first … does not collide with the r1/r2 verdicts **already written at earlier materials**" |
| :2369 | rejects non-independent host identity before writing additional verdicts | `hostVerdictEventCount(store)` / `verdictFileCount(root)` (:2370-2371, :2384-2385) — reads the **cumulative** verdict state produced by :1519/:1793/:1821 |

The chain is **not a contiguous line range**: :2369 sits inside an otherwise
`withFreshFixture`-only region (:1955-3407). A partition by line range or by "the middle block"
would silently split it. Verified by an exhaustive scan for bare `registry|store|root|result`
references after :1858 — only :2370-2371, :2384-2385 (this case), a comment at :3208, and the
teardown at :3487 match.

Three of these cases mutate shared state with **no restore path**: `commitMaterialChange(root)` at
:1414, :1796, :1825 creates real commits. Re-running case :1821 in isolation against a fresh
fixture is *not* the same test — its stated precondition is prior verdicts at earlier materials.

### B2 — a live JS value crosses case boundaries

```
:1518  let result: any;
:1519  check('emits exactly rounds x 2 verdicts after current reviewer passes', () => { … result = … })
:1717  assert.equal(result.materialDigest, currentMaterialHash(root));
```

Selecting :1716 without :1519 — exactly what a substring shard filter permits today — dereferences
`undefined`. That does not fail closed with a selection error; it fails with a `TypeError` that
reads as a product defect. This is the sharpest existing proof that the current `--grep` mechanism
is not a safe selection primitive.

### B3 — selection identity is a free-text substring, so exactly-once is unprovable

`check` matches with `name.includes(GREP_FILTER)` (:683). There is no case id, no registry of
names, and no uniqueness assertion. Names are long English sentences with heavy shared prefixes
(21 of the 73 begin `quorum_prune `; e.g. `quorum_prune apply removes the losing set…` :2425 vs
`quorum_prune apply refuses on a dirty tree before any mutation` :2509 vs
`quorum_prune apply leaves a clean worktree…` :2649). A partition keyed on substrings cannot
mechanically guarantee a case lands in exactly one shard — a shard predicate that is a prefix of
another case's name double-runs it, and both shards report green.

The existing case registry (`story-aware-validation-domain-cases.json`, and
`story-aware-validation-domain-case-runner.mjs`) is **not** a shard mechanism and must not be read
as one: the runner spawns the *whole* smoke binary per "case" and only greps for a marker; the
`PROOF_OR_STOP_DYN5_CASE` branch (`:729-762`) is a **separate, hand-written 4-scenario block**
(`quorum:scenario-1..4`) that `process.exit(0)`s **before** the 73-case suite is ever reached
(:761). It shares no code path with `check()` and covers 4 hand-rolled scenarios, not the 73
registered ones. There is no accepted shard implementation in this source.

---

## 3. Global / process side effects (per-process, therefore *helped* by isolation)

These are genuine global mutations, but each is process-scoped and correctly restored. Isolated
processes make them safer, not riskier — they are listed for completeness and because they set the
per-shard setup cost floor.

| Effect | Lines | Note |
|---|---|---|
| `process.chdir` into the shared fixture | :768 (entry), :3486 (restore) | whole-file scope |
| `process.chdir` per fresh fixture | :278-279, :285 (restore in `finally`) | `withFreshFixture` |
| `process.chdir` in the DYN-5 branch | :731, :758 | |
| session env delete/restore + `resetSessionIdForTest()` | :407-421 (`withClearedSessionEnvironment`), :430-434 (`withSessionProvider`) | mutates `process.env[SESSION_ENV_KEYS]` |
| `resetConfigCache()` | :283, :759, :1513, :3488 | module-level cache in `core/config.ts` |
| module-level fixture creation cost | :765 → :185-256 | mkdtemp + 3 git commits + registry build, **paid once per process** |
| per-case fixture cost | every `withFreshFixture` (56 sites) | each case already builds its *own* full git fixture — this is the dominant cost and is unchanged by sharding |
| child processes | `execFileSync('/bin/sh', …)` :810, `runFixtureCli` :259-266 spawns | all `cwd` inside mkdtemp fixtures |

**No listening port is bound anywhere in this file** (no `listen`, no port literal, no server
start). Port contention is not a sharding hazard here.

---

## 4. Main-worktree / common-repo resources (shared across any shard)

```
:52  const IMPLEMENTATION_REPO_ROOT = fileURLToPath(new URL('../../../..', import.meta.url));
```

Resolved from the **dist** location, so it is the repo root of whichever worktree `packages/main/dist`
lives in. Every shard would point at the same one.

| Resource | Lines | Access | Sharding consequence |
|---|---|---|---|
| Recursive AST parse of the entire `packages/main/src` production tree (`ts.createSourceFile` per `.ts`) | :689-727, invoked by case :770 (:820) | read | Heavy fixed cost. Confined to one case → confine to one shard, or it is paid N times. Sensitive to any concurrent writer of `packages/main/src`. |
| `git cat-file -e <HISTORICAL_RED_COMMIT>` with `cwd: IMPLEMENTATION_REPO_ROOT` | :1268-1271 | read (object probe) | the only real-repo git invocation |
| repo `.gitignore` | :2657 | read | |
| `packages/main/src/cli/command-catalog.ts`, `core/process-fact-levels.ts`, `core/command-policy.ts`, `handlers/quorum-prune.ts` | :2838-2841, :3339 | read | source-contract guards |
| `<state-dir>/story/actives/B-3144/scope-contract.json` (with a legacy-dir fallback) | :2964-2966, :2996 | read | a **Story artifact** in the live repo is a test input |
| `packages/main/dist` (own execution image + `DIST_CLI_PATH`/`DIST_DIRTY_GATE_POLICY_PATH` used by fixtures) | :203, :785 | read | |

All repo-facing access is read-only, consistent with the historical
`resource-audit.json` classification `reader-with-isolated-fixtures` (lines 353-412). But two of
these — the src AST sweep and the `B-3144/scope-contract.json` read — mean shards are **not**
independent of concurrent repository mutation: a build or a Story write landing mid-window changes
the input under an already-running shard. Today that window is 641s once; with N shards it is N
overlapping windows.

---

## 5. Scheduling — why more workers, or shards, cannot be the demonstrated fix

Read as instructed, before proposing any worker count.

**Default policy** — `packages/main/src/core/validation-executor.ts`:

```
:193  export const DEFAULT_VALIDATE_PLAN_JOBS = 4;
:207-216  resolveValidatePlanJobs(): explicit `jobs` → PROOF_OR_STOP_VALIDATE_JOBS → 4
:1860  const jobs = resolveValidatePlanJobs(process.env, options.jobs);
:1881  await runScheduled(entries, jobs, …)
```

The header rationale at `:182-192` already names the mechanism: *"an undeclared command holds the
plan-wide barrier exclusively, so raising the [worker count] … keeps effective concurrency well
below 4 for long stretches of the plan; workers past that [do nothing]."*

**Claim resolution** — same file:

```
:1788  undeclared/empty  → claims = [ barrier @ EXCLUSIVE ],  exclusiveByDefault: true
:1793  declared          → claims = [ barrier @ SHARED, ...declared ]
:1722-1723  VALIDATE_PLAN_BARRIER_CLAIM_KEY = '.proof-or-stop/runtime/validate-plan-barrier'
```

**Conflict rule** — `packages/main/src/core/keyed-scheduler.ts`:

```
:136  if (a.canonicalKey === b.canonicalKey && (a.access === 'exclusive' || b.access === 'exclusive')) return true;
:22   export const MAX_JOBS = 64;
```

**Root declaration for this command** — `proof-or-stop.config.json` (block read at lines 910-955):

```
label: "quorum-submit-smoke"
args:  ["packages/main/dist/tasks/quorum-submit-smoke.js"]
timeoutMs: 1200000     cpuWeight: 4     expectedP50Ms: 643000
riskTier: "gate"       policySource: "explicit-dyn1-audit-v1"
resources: [
  { class: "fixed-path",     key: ".proof-or-stop/runtime/validate-plan-barrier", access: "exclusive" },  ← the decisive line
  { class: "git-common-dir", key: ".",                      access: "shared" },
  { class: "fixed-path",     key: "packages/main/dist",     access: "shared" },
  { class: "fixed-path",     key: "packages/main/src",      access: "shared" },
  { class: "fixed-path",     key: "proof-or-stop.config.json", access: "shared" },
]
```

**Audit record** — `experiments/five-item-proof/resource-audit.json`, `commandIndex: 40`
(lines 353-445). The historical Claude analysis (`classification: reader-with-isolated-fixtures`,
`recommendation: safe-to-declare-shared`) is **superseded** at `:414-445`:

```
supersededBy: { reference "b97fe91cb7", recordedBy "Codex Lab owner",
  classification: "exclusive-local-writer",
  reason: "Conservative local barrier retained and independently reviewed …
           historical shared recommendation is not the effective scheduling policy.",
  effectiveResources: [ … validate-plan-barrier @ exclusive … ] }
```

**The consequence, stated precisely.** Because this command declares the barrier key `exclusive`,
and every *declared* command holds the same key `shared` (:1793) while every *undeclared* command
holds it `exclusive` (:1788), `claimsConflict` (:136) makes it conflict with **every other entry in
the plan**. It runs alone. Its measured 641s/601s is therefore not a CPU-bound cost that
parallelism inside the command would absorb — it is a **plan-wide serialization interval** during
which 3 of the 4 default workers are idle by construction.

It follows mechanically that:

1. **N shards inheriting this declaration run strictly serially.** Total wall clock becomes
   `Σ(shard bodies) + N × (process boot + module import + shared-fixture `makeFixture` at :765 +
   any repeated `IMPLEMENTATION_REPO_ROOT` AST sweep) ≥ 641s`. Sharding alone is a **regression**,
   not a speedup. This is a derivation from the cited lines, not a prediction of runtime.
2. **Raising `jobs` changes nothing** for this interval — it is barrier-bound, not worker-bound.
   I therefore propose **no worker count**; the number is not the lever.
3. The only lever that converts shards into wall-clock is relaxing this command's barrier claim
   from `exclusive` to `shared` (plus per-shard claims). That is precisely the change the Lab owner
   recorded as deliberately reverted at `b97fe91cb7`. It requires its own decision and its own
   review of §4's concurrent-mutation exposure. **It must not be smuggled in as part of a sharding
   change.**

---

## 6. Feasible partition boundary (conditional, and unbalanced)

If Codex proceeds *after* the §7 preconditions, the only boundary the source supports is:

- **Shard A (atomic, ordered, one process, not splittable):** the shared-fixture chain —
  :1332, :1336, :1395, :1418, :1519, :1665, :1716, :1724, :1737, :1752, :1793, :1821, :2369.
  13 cases. Must execute in source order in a single process holding one `makeFixture` (:765).
  Note :2369 is spatially separated from the rest; the shard definition must be by case identity,
  never by line range.
- **Shard A′ (recommended separate unit):** case :770 alone — it owns the whole-`src` AST sweep
  (:689-727, :820). Isolating it stops that cost from being duplicated and keeps the file's only
  `/bin/sh` orchestration (:798-815) in one place.
- **Shards B..N (freely partitionable):** the remaining ~59 cases whose entire body is inside
  `withFreshFixture` (56 sites) or a self-owned `makeFixture` (:1043 `'global-thin'`, :1474
  `'full'`), touching no bare `root`/`store`/`registry`/`result`. Cases :829 and :842 are pure
  (:843 uses `root` only as an input *string*, no mutation) and may go anywhere.

I **cannot** assert this partition is balanced. Per-case cost is unmeasured (no runtime execution
this phase), and shard A contains the multi-round quorum work plus three `commitMaterialChange`
commits. A partition whose largest shard still costs ~500s buys nothing even if Level II were
resolved — measure before committing to a shape.

---

## 7. Preconditions before any shard implementation is admissible

1. **Give cases stable ids.** Change `check(name, fn)` to carry an explicit id, and assert at
   module load that ids are unique. Substring matching on English names (:683) cannot support an
   exactly-once claim.
2. **Add the coverage gate that does not exist.** Registration must build a manifest of all
   registered ids; each run asserts `executed ∪ deliberately-skipped == registered`, and the
   default (unfiltered) run asserts `passed === <registered count>` (currently 73) at :3484.
   Today `passed` is printed only.
3. **Make dependency violation fail closed.** Encode shard-A membership as a declared,
   non-splittable group; selecting a member without its predecessors must raise an explicit
   selection error, never the `TypeError` that :1717 produces today.
4. **Do not change the barrier claim in the same change.** §5 must be a separate, separately
   reviewed decision that re-examines §4's concurrent-mutation exposure.

---

## 8. Exact bounded negative controls required

Each must be a *failing* control that turns green only when the mechanism works. Bounded: each is a
single-case perturbation, no suite-wide rewrite.

| # | Control | Perturbation | Required observable |
|---|---|---|---|
| NC-1 | missing selection | drop exactly one id from the shard manifest | aggregate FAILS naming the unselected id; per-shard exit codes still 0 → proves the gate lives in aggregation, not in luck |
| NC-2 | duplicate selection | assign one id to two shards | aggregate FAILS naming the doubly-selected id (not "green twice") |
| NC-3 | unknown id | manifest names an id absent from source | FAIL at manifest load, before any shard spawns |
| NC-4 | rename drift | rename one registered case in source, leave manifest untouched | FAIL — this is the live drift risk once ids exist alongside names |
| NC-5 | dependency violation | select :1716 without :1519 | explicit *unsatisfied-predecessor refusal*; assert the message is **not** a `TypeError`. This is the control that proves B2 was fixed rather than hidden |
| NC-6 | assertion-inventory equality | full shard fan-out vs unfiltered single-process run | executed-id set identical AND total pass count identical (73), asserted mechanically, not eyeballed |
| NC-7 | empty shard | a shard whose selection resolves to zero cases | FAIL, not `exit 0` green — the exact hole `--grep=zzz` has today |
| NC-8 | failure propagation | inject a throwing body into one case in a non-first shard | aggregate RED; proves shard exit codes and ordering do not swallow it |
| NC-9 | shard-A atomicity | request a split of the shard-A group across two shards | REFUSED at manifest validation |
| NC-10 | barrier reality check | run the shard fan-out under the real scheduler at default `jobs=4`, unchanged declaration | measured wall clock **≥** the 641s single-command baseline — the control that prevents a "sharding worked" claim while the exclusive barrier stands |

## 9. Integration counting the measurement must include

Per the standing constraint that full-workload time includes setup/integration overhead and the
same assertion inventory:

- **Per shard:** node process boot + full dist module import graph; the module-level
  `makeFixture()` at :765 (mkdtemp, `writeConfig`, seeds, `git init`/`checkout -B`/3 commits at
  :232-252, `StoryStore` + `createMainRegistry`); teardown `rmSync` + `resetConfigCache` (:3486-3488).
  Multiply by N — this is new cost that did not exist in the 641s baseline.
- **Per case, unchanged:** each `withFreshFixture` case already pays its own full `makeFixture`
  (:277). Sharding does not reduce this; it is the suite's dominant cost and is why shard balance
  should be measured, not assumed.
- **Once, if included:** the whole-`src` TypeScript AST sweep (:689-727) — pin it to one shard and
  count it there.
- **Aggregation:** manifest load/validation, shard result collection, coverage assertion, any
  receipt signing.
- **Baseline comparison** must be measured under the real scheduler with the real declaration and
  `DEFAULT_VALIDATE_PLAN_JOBS = 4` — i.e. against the actual 641s/601s serialized interval, not
  against a hypothetical unconstrained-parallel best case.

## 10. Scope note

This is a bounded source audit. It establishes what the source and the declarations say; it does
not measure runtime, does not review a Story, and does not authorize any change. Nothing was
executed, and `experiments/five-item-proof/resource-audit.json`'s `supersededBy` record was read
as authoritative over the historical Claude recommendation it supersedes.
