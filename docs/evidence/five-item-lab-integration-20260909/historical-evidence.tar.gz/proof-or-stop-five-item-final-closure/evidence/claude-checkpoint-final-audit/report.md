# Independent audit — checkpoint anchoring repairs (`cb5263a920`)

Auditor: Claude, independent of the developing agent. Date: 2026-09-09.
Prior report `../claude-anchor-audit/report.md` is unchanged; this is a separate document.

Scope as instructed: read `1274ede9cf..HEAD`, execute the frozen experiments, independently
scrutinise the seven claimed repairs, probe for new counterexamples, verify the 51-minute
long-lease evidence without rerunning it, and measure unshimmed read cost. No Story command, no
build, no commit, no subagent, no write to the frozen repo / Lab / `main`. Every injection ran in
a private `mkdtemp` fixture deleted in a `finally` block.

- Frozen runtime executed: `/var/folders/.../pos-anchor-final-audit-4_84bjie/repo`, HEAD `cb5263a9206faa3874d91bec5cac95b1eb43bcfe`, `git status --porcelain` empty before and after.
- Environment: `git 2.50.1 (Apple Git-155)`, Node v26.8.1, repo ref backend `files`.
- My probe scripts (written here): `claude-probe.mjs`, `claude-probe-d-only.mjs`, `claude-probe-perf.mjs`. Raw output: `claude-probe.log`, `claude-probe-d.log`, `claude-probe-results.json`, `perf-prior/`, `perf-head/`, `<experiment>.log`.

---

## 1. Verdict

**The six prior findings F1–F6 are closed.** Each has a mechanism in the code that I read, and
each is independently reproduced as refused-or-repaired by execution — not by prose. The critical
F1 erasure is genuinely gone: ref resolution is now backend-neutral, and I confirmed it survives
both reftable creation and in-place `git refs migrate`.

**Not a complete closure of the surrounding problem.** Two new medium defects and two evidence-quality
defects are recorded below. Both new code defects are *fail-closed* — they refuse rather than accept
an erasure — but each leaves a story permanently unreadable with **no in-product recovery path**,
including one case where a complete, valid, signed mirror is sitting on disk unconsulted. A
measurable read-cost regression is disclosed in §6.

---

## 2. Provenance

`git diff --stat 1274ede9cf..HEAD` — 4 files, +108/−52:
`core/verification-intent-checkpoint.ts` (+152/−...), `core/process-fact-registry.ts` (rationale),
`docs/validation-performance.md`, `scripts/verify-process-fact-contract.mjs` (pattern list).

**The frozen compiled runtime is that source.** I read
`packages/main/dist/core/verification-intent-checkpoint.js` in full; it is a faithful emit of the
post-`cb5263a9` TypeScript — same `assertCheckpointChain`, `for-each-ref` resolution, `git log
--first-parent` chain load, `cat-file --batch` byte-framed payload read, `mirrorRecords`,
`checkpointState`, full-chain `writeAnchor`, `reconcileMirror`, and the unchanged-digest migration
branch in `writeIntentCheckpoint`. The old filesystem probe is absent (`grep -c packed-refs` → 0).

**Frozen experiments, actual exits (all six requested, all bounded):**

| experiment | exit | elapsed | stdout tail |
|---|---|---|---|
| `checkpoint-audit-controls.mjs` | **0** | 24 s | `CHECKPOINT_AUDIT_CONTROLS_GREEN 7` |
| `acceptance-erasure.mjs` | **0** | 6 s | `ANCHORED_ACCEPTANCE_ERASURE_GREEN: dual loss refused; actual owner CLI recovered; packed refs and GC retain evidence; main unchanged` |
| `acceptance-checkpoint.mjs` | **0** | 30 s | `CHECKPOINT_HISTORY_DELETION_REFUSED; CANONICAL_PROJECTION_FAILS_CLOSED; ACTUAL_CLI_RECOVERY_GREEN; INTERRUPTED_PUBLICATION_RECOVERED` |
| `acceptance-revision.mjs` | **0** | 17 s | `ACCEPTANCE_CHANNEL_GREEN …` |
| `publication-recovery.mjs` | **0** | 10 s | `PASS P1 canonical publication failure retries without rerunning the command` |
| `publication-restart.mjs` | **0** | 15 s | `CROSS_PROCESS_PUBLICATION_RECOVERY_GREEN` |

All seven controls passed individually:

```
PASS reftable retains and restores dual-erased history
PASS in-place ref backend migration preserves evidence
PASS interrupted mirror reconciles every generation
PASS unchanged legacy write migrates complete chain
PASS truncated root cannot masquerade as migration
PASS rollback against intact mirror refuses recovery
PASS CAS conflict is typed and preserves winner
```

---

## 3. Independent scrutiny of the seven claimed repairs

I checked each mechanism in the source, not only the passing assertion.

**Backend-neutral Git lookup (closes F1) — CLOSED.** The `existsSync(loose) || packed-refs` probe is
replaced by `git for-each-ref --format='%(refname) %(objectname)' <ref>` with an exact
`startsWith(ref+' ')` match. This asks Git, so it is backend-independent by construction, and the
two controls exercise both entry paths into reftable (`git init --ref-format=reftable` and in-place
`git refs migrate --ref-format=reftable` of an already-anchored story). Both refuse the exact
original dual-loss injection with `AMENDMENT_CHECKPOINT_PROJECTION_MISMATCH` and recover the
snapshot. The prior critical is genuinely gone, not masked.

**Full-chain migration on unchanged write (closes F3) — CLOSED.** `writeIntentCheckpoint` no longer
returns early on `previous?.dataDigest===dataDigest`; that branch now runs
`if(!anchor)writeAnchor(storyId,records,gitCwd)` plus `reconcileMirror`. The control asserts
`rev-list --count == 2` after migration and that the oldest commit carries `generation:1,
previousDigest:null` — i.e. the whole legacy chain, not a truncated tip.

**Mirror reconciliation (closes F2) — CLOSED for states this build can produce.** `reconcileMirror`
writes every missing generation from the already verified in-memory records, with `wx` + `linkSync`
and an `EEXIST`-with-equal-digest tolerance, so it is idempotent under concurrency. The control
drives the exact F2 sequence (EACCES interrupt → recover → further legitimate amendment) and
asserts the mirror is `[1,2,3]` with no gap, then deletes the ref and confirms the repaired mirror
alone still serves reads. See N1 for the states it does *not* heal.

**Unicode batch delimiter — CORRECT, independently probed.** Payloads are framed by the byte count
in the `cat-file --batch` header (`output.subarray(offset,offset+size)` on a Buffer, with an
explicit trailing-`\n` check and a final `offset!==output.length` check). Probe D put a multibyte
string *and* a decoy header line (`0123…4567 blob 9\nINJECTED\n`) inside the checkpoint JSON:

```
[OK] D1-unicode-and-fake-header :: gen=2 anchorCommits=2 byteLen(desc0)=82 charLen=79 exactRoundTrip=true
[OK] D2-canonical-read :: canonical projection read after multibyte amendments: ok
```

Byte length ≠ character length and the embedded fake header did not desynchronise the parser.
(My first attempt used CJK and was correctly refused upstream by the English-artifact gate,
`english_artifact_cjk_authoring` — that refusal is itself correct behaviour, recorded for honesty.)

**Rollback refusal (closes F5) — CLOSED.** `mirrorRecords` now compares each mirror record against
`anchored[generation-1]`: a mirror generation beyond the anchor is validated (proving it is a
genuinely signed record, not garbage) and then raises `AMENDMENT_CHECKPOINT_ROLLBACK`. The control
additionally asserts that `verification_intent_recover` is refused and the on-disk projection is
byte-unchanged, so a rewind cannot be laundered into a restore. This is stronger than the prior
build, which returned the older record unread against the mirror.

**Invalid-signature / error fallback — CORRECT.** `readAnchor` rethrows `IntentAmendmentIntegrityError`
unchanged and wraps anything else as `AMENDMENT_CHECKPOINT_ANCHOR_INVALID`; `checkpointState` calls
`readAnchor` first, so an invalid anchor throws before the mirror is ever preferred. There is no
silent downgrade to a valid mirror. `assertCheckpointChain` runs over the whole chain and enforces
`generation===index+1` plus root `previousDigest===null` (`AMENDMENT_CHECKPOINT_FIRST_PREDECESSOR`),
which is the F4 asymmetry closed — the file path and the anchor path now enforce the same invariant.

**CAS typed failure (closes F6) — CLOSED.** `writeAnchor` wraps its whole body, so a lost CAS surfaces
as `AMENDMENT_CHECKPOINT_ANCHOR_WRITE_FAILED`. The control asserts `e instanceof
IntentAmendmentIntegrityError && e.code==='AMENDMENT_CHECKPOINT_ANCHOR_WRITE_FAILED'`, that the ref
is unchanged, and that the winner's generation still reads back — safety plus typing, not typing alone.

---

## 4. New findings

### N1 — MEDIUM. States the *previous* build could produce are refused but unrepairable; a valid signed mirror goes unread

The new invariants are enforced on read, but nothing migrates a repository already sitting in a
shape the prior build produced. Both prior-audit residues are now permanent dead ends.

**Probe A** — the exact prior-audit F4/T6c shape (parentless anchor at generation 2, complete mirror):

```
[OBSERVED]      A0-state :: mirror=["000000000001.json","000000000002.json"] anchor=parentless gen2 (prior-build shape)
[REFUSED]       A1-read :: AMENDMENT_CHECKPOINT_HISTORY_GAP
[REFUSED]       A2-canonical-read :: AMENDMENT_CHECKPOINT_HISTORY_GAP
[NO-MIGRATION]  A3-unchanged-write-repair :: unchanged canonical write still refuses: AMENDMENT_CHECKPOINT_HISTORY_GAP
[NO-RECOVERY]   A4-owner-recover :: verification_intent_recover: AMENDMENT_CHECKPOINT_HISTORY_GAP
[OBSERVED]      A5-mirror-intact :: complete signed mirror still present but never consulted: ["000000000001.json","000000000002.json"]
```

**Probe B** — the exact prior-audit F2/T4c shape (mirror `[1,3]`, no anchor):

```
[OBSERVED]  B0-state :: no anchor; mirror=["000000000001.json","000000000003.json"]
[REFUSED]   B1-read :: AMENDMENT_CHECKPOINT_HISTORY_GAP
[NO-REPAIR] B2-unchanged-write-repair :: unchanged canonical write still refuses: AMENDMENT_CHECKPOINT_HISTORY_GAP
```

Cause: `writeIntentCheckpoint` begins with `checkpointState`, which throws before any repair branch
is reached. The migration path added for F3 only handles *absent* anchor plus *self-consistent*
mirror; it cannot run when the existing artefacts violate an invariant. `verification_intent_recover`
depends on the same read, so the owner escape hatch is closed too.

Direction of failure is safe — refusal, never a silent erasure — which is why this is medium, not
critical. But the control "truncated root cannot masquerade as migration" only asserts the throw;
it does not assert recoverability, and the shipped docs sentence "Missing mirror generations are
reconciled from retained signed Git objects before successful projection publication" reads as more
general than what the code does. In probe A a complete, signature-valid mirror is on disk and is
never consulted; the story is not recoverable from it by any product command.

### N2 — MEDIUM. A tampered *disposable* mirror bricks reads while the authoritative anchor is intact; deleting the mirror is the only remedy

**Probe C** modified one field in `000000000001.json` while leaving the 2-generation anchor intact:

```
[REFUSED]                C1-read-with-intact-anchor :: AMENDMENT_CHECKPOINT_MIRROR_CONFLICT (anchor=2 generations, intact)
[NO-REPAIR]              C2-write-repair :: unchanged canonical write: AMENDMENT_CHECKPOINT_MIRROR_CONFLICT
[RECOVERED-BY-DELETION]  C3-delete-mirror :: deleting the whole mirror restores canonical reads; repairing it does not
```

`mirrorRecords` raises `AMENDMENT_CHECKPOINT_MIRROR_CONFLICT` on a digest mismatch, and because it
runs inside `checkpointState`, the throw precedes `reconcileMirror` — the one function that could
overwrite the bad file from the verified anchor never executes. The resulting operator guidance is
inverted: `rm -rf` the evidence mirror and reads recover from the anchor; try to keep or repair the
mirror and the story stays unreadable. A single stray byte in a store the design calls disposable
is now a denial of canonical reads. `reconcileMirror` already knows how to detect this case
(`MIRROR_CONFLICT` on an existing path) and already holds verified authoritative bytes; the gap is
purely that detection happens on the read path with no write-path repair.

### N3 — MEDIUM (evidence quality). The 51-minute RED refusal assertion passes on a filename, not on a reason

`long-lease-worker.mjs:38` asserts the baseline refusal with
`assert.match(error,/lease|expired|stale|owner/i)`. The recorded RED error is:

```
Error: causal evidence commit refused: current causal snapshot is not reusable [causal_commit_snapshot_invalid]
    at commitCanonicalCausalEvidence (.../handlers/checklist.js:1723:19)
    ...
    at async file:///.../experiments/five-item-proof/long-lease-worker.mjs:34:12
```

I re-ran the regex against the stored string: it matches at **index 1676**, inside the stack-trace
path `long-lease-worker.mjs` — the substring "lease" in the worker's own filename. The actual
refusal code is `causal_commit_snapshot_invalid`, which contains none of the four alternatives.
The assertion therefore does not establish that the publication was refused *because* the lease expired.

The *conclusion* still stands on other, mechanical evidence I verified directly: RED's
`isLeaseStale(after)` is `true`, `heartbeatAt` is byte-identical before and after across all 53
samples (frozen at `2026-09-09T04:12:35.969Z` for the whole 51 minutes), and `evidence.length===0`.
So RED did go stale and did publish nothing. Only the causal link asserted in the script is unproven.

### N4 — LOW (claim vs evidence). "101 renewals" is not recorded in the artifacts

The owner-lease record has no `renewedAt` and no `generation` field; its keys are
`sessionId, hostname, pid, cwd, command, acquiredAt, heartbeatAt, sessionSource, leaseId`. What the
GREEN artifacts contain is 53 samples at a 60 s sampler interval with **53 distinct `heartbeatAt`
values**, first `04:12:35.983Z`, last `05:03:43.614Z`. With
`VALIDATION_EXECUTION_RUNTIME_REQUIREMENTS.ownerLeaseHeartbeatMs = 30000` and an elapsed
3 067 556.9 ms, ~102 timer beats plus the opening and closing `beat()` are *inferable*, which is
where "101 renewals" plausibly comes from — but the evidence on disk supports only **≥52 observed
renewals**. Report the measured figure or add a beat counter; do not present the inferred one as measured.

### Unverified observation (not a finding)

`readAnchor` caps `cat-file --batch` at `maxBuffer: 64*1024*1024`. Exceeding it would throw
`ENOBUFS`, which the surrounding `catch` relabels `AMENDMENT_CHECKPOINT_ANCHOR_INVALID` — a
"tampered anchor" diagnosis for what is really a size limit. I did not construct a fixture large
enough to trigger this, so I raise it as a code-reading observation only, not a reproduced defect.

---

## 5. Long-lease (51-minute) verification — no rerun

As instructed I did **not** rerun the 51-minute test. Verified from the stored artifacts and by
comparing the frozen runtimes, which still exist on disk.

| claim | verdict | evidence |
|---|---|---|
| real 3 060 000 ms child lifetime | **CONFIRMED** | RED child pid 1465 `start→complete` = **3 060 102 ms**; GREEN pid 2092 = **3 060 091 ms**; both single pid, both ≥ the requested duration |
| `clockScale: 1` = unmodified Date/timers | **CONSISTENT, not proven** | `clockScale`/`heartbeatScale` are literals the worker writes. Corroborated independently: `started.json` `04:12:35.987Z` → last GREEN heartbeat `05:03:43.614Z` (50 m 68 s of real wall clock), child epoch delta 3 060 102 ms measured in a *separate process*, `performance.now()` elapsed 3 062 457 / 3 067 557 ms, and directory mtimes 05:12 → 06:03 local. Four independent clocks agree; that is strong corroboration, not a formal proof against a doctored parent clock. |
| owner lease before/after | **CONFIRMED** | RED: `heartbeatAt` unchanged `04:12:35.969Z`, `stale:true`. GREEN: `04:12:35.983Z` → `05:03:43.614Z`, `stale:false`, `leaseId`/`sessionId`/`acquiredAt` identical before and after (only `cwd` re-stamped `/var…`→`/private/var…` by the refresh, which `refreshOwnerLeaseUnlocked` documents) |
| 101 renewals | **NOT SUPPORTED AS MEASURED** | see N4 — 53 distinct `heartbeatAt` at 60 s sampling; no renewal counter exists |
| published receipt 0 vs 1 | **CONFIRMED** | RED `evidence: []`, `published:0`; GREEN `evidence[0].result === 'pass'`, `published:1` |
| "same generation" | **NO SUCH FIELD** | the lease has no `generation`. The equivalent holds: same `leaseId`, same `sessionId`, same `acquiredAt` before/after in both runs — i.e. no re-acquisition or transfer |
| children 1 each | **CONFIRMED** | each `children.jsonl` has exactly 1 `start` and 1 `complete`, same pid |
| RED has no successful endpoint ⇒ no speed percentage | **CONFIRMED** | RED published 0 receipts and terminated in a refusal; there is no RED success time, so any speedup percentage would be undefined. None is claimed. |

**Heartbeat mechanism frozen for the long test vs latest code — NO MISMATCH.** The GREEN long-test
runtime still exists (`pos-frozen-long-GREEN-1lpuq3g7`, sourceCommit `cc739aa659`), a different
commit from the checkpoint HEAD as stated. I compared compiled bytes directly:

```
sha256 core/story-owner-lease.js  67dbe634…  GREEN runtime
sha256 core/story-owner-lease.js  67dbe634…  frozen HEAD cb5263a920
sha256 core/story-owner-lease.js  67dbe634…  RED runtime
diff GREEN vs HEAD  core/story-owner-lease.js     IDENTICAL
diff GREEN vs HEAD  core/validation-executor.js   IDENTICAL
diff GREEN vs HEAD  handlers/checklist.js         IDENTICAL
```

The renewal code — `refreshOwnerLeaseUnlocked`, the `setInterval(beat, ownerLeaseHeartbeatMs)`
holder with its ownership/staleness re-check on every beat, and `STALE_LEASE_THRESHOLD_MS = 1 800 000`
— is byte-identical between the runtime that produced the GREEN result and the current HEAD. Only
`handlers/checklist.js` and `core/verification-intent-checkpoint.js` differ **RED vs GREEN**, which
is the intended baseline delta; `story-owner-lease.js` is identical even there, so RED's failure to
renew is a missing call site, not different lease logic. No flag raised.

---

## 6. Performance — disclosed, no caching added or requested

Unshimmed (no `PATH` interposer), frozen runtimes, same host and session, medians of 15 reads after
3 warm-up reads, private fixture per measurement.

| generations | `readIntentCheckpoint` prior build `ccp3yz1s` | HEAD `cb5263a920` | `store.readChecklist` prior | HEAD |
|---|---|---|---|---|
| 1 | 142.3 ms | **140.2 ms** | 171.3 ms | **191.0 ms** |
| 5 | 428.5 ms | **598.7 ms** | 547.0 ms | **731.9 ms** |
| ratio 5÷1 | 3.01× | **4.27×** | — | — |

An earlier independent run of the same probe on HEAD gave 136.9 / 615.4 ms and a 4.50× ratio, so
treat the figures as ±10 % single-host medians, not CI-grade statistics.

Reading:

- **At 1 generation the change costs nothing measurable.** The prior report's "2× git subprocesses"
  concern does not show up as wall-clock at chain length 1.
- **At 5 generations the full-chain read adds ≈ +40 %** to `readIntentCheckpoint` (428.5 → 598.7 ms)
  and ≈ +34 % to the canonical `store.readChecklist` hot path (547.0 → 731.9 ms).
- **Most of the 5-generation cost predates this change.** The prior build already scaled 3.01×,
  because `assertIntentAmendments` re-verifies every accumulated amendment on the item. The new
  `git log` + `cat-file --batch` + per-generation `validateCheckpoint` is the marginal ~third, not
  the whole curve. Framing this as "the anchor made reads 4× slower" would be wrong.
- **The absolute number is the real disclosure**: a canonical checklist read is ~0.19 s at one
  generation and ~0.73 s at five, and grows linearly in generation count, because every generation
  is re-fetched, JSON-parsed, signature-verified and amendment-verified on **every** read. A story
  with a long amendment history will feel this on every gate evaluation and roster query.
- `writeIntentCheckpoint` still calls `checkpointState` once and then `writeAnchor`, so the
  double-`readAnchor`-per-write noted in the prior report is gone.

No caching was requested and I recommend none without an explicit safety argument: the read *is*
the verification, so memoising it would trade the property this change exists to provide.

---

## 7. Summary

| # | Severity | Status | Item |
|---|---|---|---|
| F1 | Critical | **Closed** | reftable/migrated backends — `for-each-ref` resolution; both controls pass |
| F2 | Medium | **Closed** (forward) | `reconcileMirror` repairs every missing generation; see N1 for legacy states |
| F3 | Medium | **Closed** | unchanged canonical write migrates the complete chain, root `gen 1 / previousDigest null` |
| F4 | Low | **Closed** | `assertCheckpointChain` enforces root and predecessor over the whole chain |
| F5 | Low | **Closed** | `AMENDMENT_CHECKPOINT_ROLLBACK`; recovery refused, projection unchanged |
| F6 | Low | **Closed** | `AMENDMENT_CHECKPOINT_ANCHOR_WRITE_FAILED`, typed, winner preserved |
| N1 | **Medium** | New, reproduced (probes A, B) | prior-build artefact shapes are refused but unrepairable by read, write, or `verification_intent_recover`; a complete valid mirror goes unconsulted |
| N2 | **Medium** | New, reproduced (probe C) | a tampered disposable mirror blocks all canonical reads despite an intact anchor; only deleting the mirror recovers |
| N3 | **Medium** | New, verified from stored data | RED refusal assertion matches a stack-trace filename, not the refusal reason (`causal_commit_snapshot_invalid`) |
| N4 | Low | New, verified from stored data | "101 renewals" is inferred; artifacts support ≥52 observed renewals and contain no renewal counter |
| P1 | Perf | Measured | +40 % checkpoint read / +34 % canonical read at 5 generations; linear in generation count; ~0.73 s canonical read at 5 generations |

---

## 8. Limits of this audit

- I did **not** rerun the 51-minute test; §5 is verification of stored artifacts plus byte-level
  comparison of the frozen runtimes, not re-execution.
- `clockScale: 1` is corroborated by four independent clocks but is not a formal proof that the
  parent process's `Date`/timers were unmodified.
- Concurrency and CAS were exercised through the controls' `update-ref` shim and by code reading,
  not by genuinely parallel competing processes.
- Performance figures are single-host, single-session medians of 15 with ±10 % observed run-to-run
  variance; no statistical modelling.
- The `maxBuffer` observation in §4 is code reading only, not a reproduced fixture.
- Declared out of scope, as instructed and not treated as defects: destruction of the Git ref
  store, object store, or signing key (the local trust root), and a hostile administrator.
- No patch was written. All fixtures were `mkdtemp` and deleted; the frozen repo's
  `git status --porcelain` was empty before and after, HEAD still `cb5263a9206faa38…`. Nothing was
  built, edited, or committed in the frozen repo, the Lab, or `main`; all outputs are in this directory.
