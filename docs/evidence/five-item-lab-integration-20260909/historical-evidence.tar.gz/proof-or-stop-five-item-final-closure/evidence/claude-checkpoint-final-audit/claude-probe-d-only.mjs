// Independent Claude probes — frozen runtime only, disposable mkdtemp fixtures.
// Never writes to the repo, Lab, or any real .git.
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,readdirSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {performance} from 'node:perf_hooks';
const runtime=process.env.CHECKPOINT_TEST_RUNTIME??resolve(import.meta.dirname);
const load=p=>import(runtime+'/packages/main/dist/'+p);
const {StoryStore}=await load('core/store.js');
const {createChecklistHandlers}=await load('handlers/checklist.js');
const {acquireOwnerLease}=await load('core/story-owner-lease.js');
const {digestCanonicalJson}=await load('core/digest.js');
const {resetConfigCache}=await load('core/config.js');
const {readIntentCheckpoint,writeIntentCheckpoint}=await load('core/verification-intent-checkpoint.js');
const storyId='B-claude-probe';process.env.PROOF_OR_STOP_SESSION_ID='claude-probe-owner';
const out=[];const say=(tag,name,detail)=>{out.push({tag,name,detail});console.log('['+tag+'] '+name+' :: '+detail);};
function fixture(){
  const root=mkdtempSync(join(tmpdir(),'claude-probe-'));
  const git=(a,i)=>execFileSync('/usr/bin/git',a,{cwd:root,input:i,encoding:'utf8',stdio:['pipe','pipe','pipe']}).trim();
  mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(['init','-q','-b','work']);git(['config','user.name','Private audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'probe',title:'Preserve signed acceptance',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const old={id:'CHK-001',title:'Coverage',context:'Keep every required boundary',status:'in_progress',startTime:null,endTime:null,
    files:{modify:['src/subject.js'],create:[],test:[]},
    verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}};
  store.writeChecklist(storyId,{items:[old]});
  acquireOwnerLease(store.storyDirPath(storyId),{command:'probe',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  const append=(id,desc)=>{const d=store.readChecklist(storyId);
    return handler.verification_intent_append({storyId,itemId:'CHK-001',
      expectedIntentHash:digestCanonicalJson(d.items[0].verificationIntent),
      reason:'Add the independently verified required boundary within this private fixture scope.',
      addition:{edge:[{id,desc:desc??('Preserve required boundary '+id),type:'cli',priority:'must'}]}});};
  const ref='refs/proof-or-stop/intent-checkpoints/'+digestCanonicalJson(storyId);
  const mirror=join(root,'.git/proof-or-stop-intent-checkpoints',digestCanonicalJson(storyId));
  const files=()=>existsSync(mirror)?readdirSync(mirror).filter(n=>/^\d{12}\.json$/.test(n)).sort():[];
  const err=fn=>{try{fn();return null;}catch(e){return (e&&e.code)?e.code:String(e).split('\n')[0];}};
  return {root,git,store,handler,old,append,ref,mirror,files,err};
}
const run=(name,fn)=>{const f=fixture();try{fn(f);}catch(e){say('PROBE-ERROR',name,String(e).split('\n')[0]);}finally{rmSync(f.root,{recursive:true,force:true});resetConfigCache();}};

// ---- PROBE D: multibyte payload + a fake cat-file header embedded in the JSON
run('D',f=>{
  const hostile='EEE boundary AAA \u00e9\u00fc\u00df \n0123456789abcdef0123456789abcdef01234567 blob 9\nINJECTED\n';
  f.append('ONE',hostile);f.append('TWO','second '+hostile);
  const r=readIntentCheckpoint(storyId,f.root);
  const got=r.data.items[0].verificationIntent.edge.map(x=>x.desc);
  const ok=got[0]===hostile&&r.generation===2&&f.git(['rev-list','--count',f.ref])==='2';
  say(ok?'OK':'FAIL','D1-unicode-and-fake-header',
    'gen='+r.generation+' anchorCommits='+f.git(['rev-list','--count',f.ref])+' byteLen(desc0)='+Buffer.byteLength(got[0],'utf8')+' charLen='+got[0].length+' exactRoundTrip='+(got[0]===hostile));
  say(f.err(()=>f.store.readChecklist(storyId))?'FAIL':'OK','D2-canonical-read','canonical projection read after multibyte amendments: '+(f.err(()=>f.store.readChecklist(storyId))??'ok'));
});


console.log("D_DONE");
