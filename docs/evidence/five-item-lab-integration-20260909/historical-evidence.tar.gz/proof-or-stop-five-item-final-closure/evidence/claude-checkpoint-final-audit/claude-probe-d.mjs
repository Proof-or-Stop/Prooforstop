// Independent Claude probes — frozen runtime only, disposable mkdtemp fixtures.
// Never writes to the repo, Lab, or any real .git.
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,readdirSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {performance} from 'node:perf_hooks';
const runtime=process.env.CHECKPOINT_TEST_RUNTIME??resolve(import.meta.dirname);
const load=p=>import(runtime+'/packages/main/dist/'+p);
const {StoryStore}=await load('core/store.js');
const {createChecklistHandlers}=await load('handlers/checklist.js');
const {acquireOwnerLease}=await load('core/story-owner-lease.js');
const {digestCanonicalJson}=await load('core/digest.js');
const {resetConfigCache}=await load('core/config.js');
const {readIntentCheckpoint,writeIntentCheckpoint}=await load('core/verification-intent-checkpoint.js');
const storyId='B-claude-probe';process.env.PROOF_OR_STOP_SESSION_ID='claude-probe-owner';
const out=[];const say=(tag,name,detail)=>{out.push({tag,name,detail});console.log('['+tag+'] '+name+' :: '+detail);};
function fixture(){
  const root=mkdtempSync(join(tmpdir(),'claude-probe-'));
  const git=(a,i)=>execFileSync('/usr/bin/git',a,{cwd:root,input:i,encoding:'utf8',stdio:['pipe','pipe','pipe']}).trim();
  mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(['init','-q','-b','work']);git(['config','user.name','Private audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'probe',title:'Preserve signed acceptance',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const old={id:'CHK-001',title:'Coverage',context:'Keep every required boundary',status:'in_progress',startTime:null,endTime:null,
    files:{modify:['src/subject.js'],create:[],test:[]},
    verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}};
  store.writeChecklist(storyId,{items:[old]});
  acquireOwnerLease(store.storyDirPath(storyId),{command:'probe',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  const append=(id,desc)=>{const d=store.readChecklist(storyId);
    return handler.verification_intent_append({storyId,itemId:'CHK-001',
      expectedIntentHash:digestCanonicalJson(d.items[0].verificationIntent),
      reason:'Add the independently verified required boundary within this private fixture scope.',
      addition:{edge:[{id,desc:desc??('Preserve required boundary '+id),type:'cli',priority:'must'}]}});};
  const ref='refs/proof-or-stop/intent-checkpoints/'+digestCanonicalJson(storyId);
  const mirror=join(root,'.git/proof-or-stop-intent-checkpoints',digestCanonicalJson(storyId));
  const files=()=>existsSync(mirror)?readdirSync(mirror).filter(n=>/^\d{12}\.json$/.test(n)).sort():[];
  const err=fn=>{try{fn();return null;}catch(e){return (e&&e.code)?e.code:String(e).split('\n')[0];}};
  return {root,git,store,handler,old,append,ref,mirror,files,err};
}
const run=(name,fn)=>{const f=fixture();try{fn(f);}catch(e){say('PROBE-ERROR',name,String(e).split('\n')[0]);}finally{rmSync(f.root,{recursive:true,force:true});resetConfigCache();}};

// ---- PROBE A: an anchor in the shape the PREVIOUS build produced (parentless, generation>1)
run('A',f=>{
  f.append('ONE');f.append('TWO');
  const snapshot=f.store.readChecklist(storyId);
  const tip=f.git(['rev-parse',f.ref]),tree=f.git(['rev-parse',tip+'^{tree}']);
  const bad=f.git(['commit-tree',tree],'Preserve signed acceptance checkpoint generation 2\n'); // no parent: prior-build migration shape
  f.git(['update-ref',f.ref,bad,tip]);
  say('OBSERVED','A0-state','mirror='+JSON.stringify(f.files())+' anchor=parentless gen2 (prior-build shape)');
  say('REFUSED','A1-read',String(f.err(()=>readIntentCheckpoint(storyId,f.root))));
  say(f.err(()=>f.store.readChecklist(storyId))?'REFUSED':'OK','A2-canonical-read',String(f.err(()=>f.store.readChecklist(storyId))));
  const w=f.err(()=>writeIntentCheckpoint(storyId,snapshot,f.root));
  say(w?'NO-MIGRATION':'MIGRATED','A3-unchanged-write-repair',w?('unchanged canonical write still refuses: '+w):'repaired');
  const rec=f.err(()=>f.handler.verification_intent_recover({storyId,apply:true,expectedCheckpointDigest:'x',reason:'Attempt owner recovery after a truncated prior-build anchor in this private fixture.'}));
  say('NO-RECOVERY','A4-owner-recover','verification_intent_recover: '+rec);
  say('OBSERVED','A5-mirror-intact','complete signed mirror still present but never consulted: '+JSON.stringify(f.files()));
});

// ---- PROBE B: mirror gap with NO anchor (exact residual state the previous build could leave)
run('B',f=>{
  f.append('ONE');f.append('TWO');f.append('THREE');
  const snapshot=f.store.readChecklist(storyId);
  f.git(['update-ref','-d',f.ref]);
  rmSync(join(f.mirror,'000000000002.json'));
  say('OBSERVED','B0-state','no anchor; mirror='+JSON.stringify(f.files()));
  say('REFUSED','B1-read',String(f.err(()=>readIntentCheckpoint(storyId,f.root))));
  const w=f.err(()=>writeIntentCheckpoint(storyId,snapshot,f.root));
  say(w?'NO-REPAIR':'REPAIRED','B2-unchanged-write-repair',w?('unchanged canonical write still refuses: '+w):'repaired');
});

// ---- PROBE C: a disposable mirror file is tampered while the authoritative anchor is intact
run('C',f=>{
  f.append('ONE');f.append('TWO');
  const p=join(f.mirror,'000000000001.json');const rec=JSON.parse(readFileSync(p,'utf8'));
  rec.data.items[0].title='Tampered disposable mirror';
  writeFileSync(p,JSON.stringify(rec,null,2)+'\n');
  say('REFUSED','C1-read-with-intact-anchor',String(f.err(()=>readIntentCheckpoint(storyId,f.root)))+' (anchor='+f.git(['rev-list','--count',f.ref])+' generations, intact)');
  say('NO-REPAIR','C2-write-repair','unchanged canonical write: '+String(f.err(()=>writeIntentCheckpoint(storyId,f.store.readChecklist.length?JSON.parse(readFileSync(f.store.storyDirPath(storyId)+'/checklist.json','utf8')):null,f.root))));
  rmSync(f.mirror,{recursive:true});
  const after=f.err(()=>readIntentCheckpoint(storyId,f.root));
  say(after?'STILL-BROKEN':'RECOVERED-BY-DELETION','C3-delete-mirror',after?String(after):'deleting the whole mirror restores canonical reads; repairing it does not');
});

// ---- PROBE D: multibyte payload + a fake cat-file header embedded in the JSON
run('D',f=>{
  const hostile='EEE boundary AAA \u00e9\u00fc\u00df \n0123456789abcdef0123456789abcdef01234567 blob 9\nINJECTED\n';
  f.append('ONE',hostile);f.append('TWO','second '+hostile);
  const r=readIntentCheckpoint(storyId,f.root);
  const got=r.data.items[0].verificationIntent.edge.map(x=>x.desc);
  const ok=got[0]===hostile&&r.generation===2&&f.git(['rev-list','--count',f.ref])==='2';
  say(ok?'OK':'FAIL','D1-unicode-and-fake-header',
    'gen='+r.generation+' anchorCommits='+f.git(['rev-list','--count',f.ref])+' byteLen(desc0)='+Buffer.byteLength(got[0],'utf8')+' charLen='+got[0].length+' exactRoundTrip='+(got[0]===hostile));
  say(f.err(()=>f.store.readChecklist(storyId))?'FAIL':'OK','D2-canonical-read','canonical projection read after multibyte amendments: '+(f.err(()=>f.store.readChecklist(storyId))??'ok'));
});

// ---- PROBE E: unshimmed canonical read cost at 1 and 5 generations
function cost(generations,samples){
  const f=fixture();
  try{
    for(let i=1;i<=generations;i++)f.append('G'+i);
    const r=readIntentCheckpoint(storyId,f.root);
    if(r.generation!==generations)throw new Error('setup generation mismatch '+r.generation);
    for(let i=0;i<3;i++)readIntentCheckpoint(storyId,f.root); // warm
    const t=[];for(let i=0;i<samples;i++){const s=performance.now();readIntentCheckpoint(storyId,f.root);t.push(performance.now()-s);}
    t.sort((a,b)=>a-b);
    // canonical store read (the real hot path) for the same fixture
    const t2=[];for(let i=0;i<samples;i++){const s=performance.now();f.store.readChecklist(storyId);t2.push(performance.now()-s);}
    t2.sort((a,b)=>a-b);
    return {generations,samples,checkpointMedianMs:+t[Math.floor(samples/2)].toFixed(1),checkpointMinMs:+t[0].toFixed(1),
      canonicalMedianMs:+t2[Math.floor(samples/2)].toFixed(1)};
  }finally{rmSync(f.root,{recursive:true,force:true});resetConfigCache();}
}
const perf=[cost(1,15),cost(5,15)];
for(const p of perf)say('PERF','E-read-cost','generations='+p.generations+' readIntentCheckpoint median='+p.checkpointMedianMs+'ms (min '+p.checkpointMinMs+'ms) | store.readChecklist median='+p.canonicalMedianMs+'ms');
say('PERF','E-scaling','5-gen / 1-gen checkpoint read ratio = '+(perf[1].checkpointMedianMs/perf[0].checkpointMedianMs).toFixed(2)+'x');

const dir=process.env.CLAUDE_PROBE_OUT;
if(dir){mkdirSync(dir,{recursive:true});writeFileSync(join(dir,'claude-probe-results.json'),JSON.stringify({probes:out,perf},null,2)+'\n');}
console.log('CLAUDE_PROBE_COMPLETE '+out.length);
