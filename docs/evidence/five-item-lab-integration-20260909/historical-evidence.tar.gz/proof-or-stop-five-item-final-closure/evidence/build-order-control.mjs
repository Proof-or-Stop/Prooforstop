import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync,mkdirSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {execFileSync} from 'node:child_process';
const art=import.meta.dirname,root=JSON.parse(readFileSync(join(art,'root-repeat-complete-runtime.json'),'utf8')).path;
const {executeValidationPlan}=await import(root+'/packages/main/dist/core/validation-executor.js');
const cfg=JSON.parse(readFileSync(join(root,'proof-or-stop.config.json'),'utf8'));
assert.deepEqual(cfg.validate.commands.slice(0,3).map(c=>[c.command,...c.args]),[['node','scripts/verify-lab-worktree.mjs'],['npm','--prefix','packages/main','run','build'],['node','packages/main/tests/milestone-status.test.mjs']]);
const trials=[];
for(const mode of ['RED','GREEN']){
 const fixture=mkdtempSync(join(tmpdir(),'pos-build-order-'));
 try{
  execFileSync('git',['init','-q'],{cwd:fixture});writeFileSync(join(fixture,'build.txt'),'stale');
  const scripts=[`setTimeout(()=>console.log('READONLY_PRECHECK_DONE'),250)`,`require('fs').writeFileSync('build.txt','fresh');console.log('BUILD_DONE')`,`require('assert').strictEqual(require('fs').readFileSync('build.txt','utf8'),'fresh','test must consume completed build');console.log('CURRENT_BUILD_TEST_PASS')`];
  const commands=cfg.validate.commands.slice(0,3).map((c,i)=>({label:'actual-resource-row-'+i,command:process.execPath,args:['-e',scripts[i]],timeoutMs:3000,resources:c.resources}));
  if(mode==='GREEN')commands[0].resources=[...commands[0].resources,{class:'fixed-path',key:'.proof-or-stop/runtime/validate-plan-barrier',access:'exclusive'}];
  const events=[];const result=await executeValidationPlan({provider:'lab-build-order-control',commands},fixture,undefined,undefined,{jobs:4,progress:e=>events.push(e)});
  const r={mode,allPass:result.allPass,commands:result.commands,events};trials.push(r);console.log(mode,result.allPass,result.commands.map(c=>c.code));
 }finally{rmSync(fixture,{recursive:true,force:true});}
}
writeFileSync(join(art,'build-order-results.json'),JSON.stringify({scope:'Real executor, resource rows taken exactly from actual root first three commands; bounded readonly precheck/build publication/stale-reader substitutes reveal sequencing independently of prebuilt dist.',trials},null,2)+'\n');
assert.equal(trials[0].allPass,false);assert.match(trials[0].commands[2].output,/test must consume completed build/);assert.equal(trials[1].allPass,true);console.log('BUILD_ORDER_RED_GREEN_CONFIRMED');
