# Independent audit — root-command repeat (complete series) + resource-claims delta

Auditor: Claude CLI (Opus 5), 2026-09-09. Lab-only, read-only against source; writes confined to this
audit directory and private temp fixtures. No subagents, no full-suite run, no expensive rerun.
Source worktree `Lab-five-item-proof-20260908` @ `b25996f711` (working tree carries only
`experiments/five-item-proof/README.md` modified + untracked `AGENTS.override.md` — no source mutation by me).
Frozen runtime: `…/pos-frozen-root-repeat-complete-fmb27fyi/repo`.

## Verdict (scoped)

Within the bounded scope actually examined, the two claims under review hold:

1. **The repeat experiment repeats the real registered root command.** Confirmed by source, policy,
   out-of-fixture process events, and per-run reuse records — not by trusting the summary.
2. **The resource-claims delta is a test/evidence-only change** that tightens argv to the configured
   quorum invocation, retains the parent exclusive barrier, and adds per-writer negative controls;
   44 assertions pass on my own independent run.

No universal claim is made or endorsed: this is **not** a 48%/universal-recall result, **not** an
all-134 result, and **not** a claim that all five items are unqualifiedly closed. The full 134 suite is
running elsewhere and I did not demand or wait on it.

## 1. Implementation identity — exact match, not just digest

I ran `complete-identity/pinned-cli.sh --implementation-identity` (after a guard check of the script:
it only exports the pin env vars and execs the frozen `packages/main/dist/cli.js`) into
`identity.json`, then deep-compared the **fully parsed** JSON against `complete-identity/owner-strict.json`:

| Check | Result |
|---|---|
| Top-level keys | identical (`digest, entrypoint, fileCount, files, implementationRoot, packageVersion, runtime, schema`) |
| Flattened leaves compared | 3330 vs 3330 |
| Keys only in mine / only in strict | 0 / 0 |
| Value differences | **0** |
| `a == b` (full structural equality) | **True** |
| Canonical SHA-256 of both documents | `68a4b15f751c9577a57ad57848ca8062072b4b0858d0d28fcd7198e7cdccd019` (equal) |
| `digest` | `48454fc7155b4822da9c947209b1a49c13d583bfb8a261180a4e196b6fb4cd95` ✓ expected |
| `fileCount` / `len(files)` | 1659 / 1659 ✓ expected |
| `schema` / `packageVersion` | `execution-implementation.v1` / `0.3.284` |
| `implementationRoot` | resolves under the frozen root (`/private/var/…/repo/packages/main/dist`) |

File inventory not echoed. A first-pass check reported `implementationRoot` as "not under the frozen
root"; that was my comparison against the repo root rather than the `dist` subdirectory — the path is
the frozen root's `dist`, verified above.

## 2. Root application experiment — what the evidence actually shows

Source read: `root-command-repeat-complete.mjs`. Policy read directly from the frozen root's
`proof-or-stop.config.json` (not from the experiment's summary):

- `validate.commands` = **134**; commands with `executionReuse: "exact-inputs"` = **1** → the
  experiment's `assert.equal(eligible.length,1)` selects the single genuinely eligible root command.
- Selected command is the **registered entry verbatim**: `node packages/main/dist/tasks/tool-executed-evidence-receipt-smoke.js`,
  `timeoutMs: 180000`, `resources: [{git-common-dir, ".", shared}]`, `assurance: story-selectable`,
  `riskTier: shared`, `closurePolicy: static-and-traced`, `executionReuse: exact-inputs`.
  Args, policy fields and the 180 s timeout are all retained — no wrapper, no substituted witness command.
- `doneRequiredCommands` = 2, exact overlap with the selected command = **0**, and DONE commands that
  are reuse-eligible = **0**. `results.json` records `rootDoneExactOverlap: 0`, `rootDoneReuseEligible: 0`,
  matching the config. **No invented DONE overlap.**
- `results.json.runtime` is byte-equal to `root-repeat-complete-runtime.json`, whose `path` resolves to
  the same frozen root as the identity CLI.

Four trials, pairs ordered RED,GREEN then GREEN,RED (order counterbalanced):

| pair | mode | allPass | accepted consumers | actual suite processes | elapsed |
|---|---|---|---|---|---|
| 1 | RED | true | 2 | 2 (pids 29006, 66511) | 169.7 s |
| 1 | GREEN | true | 2 | 1 (pid 66941) | 89.8 s |
| 2 | GREEN | true | 2 | 1 (pid 19899) | 89.2 s |
| 2 | RED | true | 2 | 2 (pids 90890, 42544) | 143.4 s |

I recomputed these from the raw artifacts, not from the console summary:

- Process counts come from `*-processes.jsonl` line counts (2/1/1/2 = 6 lines total), each event
  `actual-suite-process-start` with a **distinct real pid** and `argv[1]` ending in
  `/tasks/tool-executed-evidence-receipt-smoke.js` — i.e. real OS processes of the actual root task.
  These `argv[1]` paths resolve **outside** the private fixture (into the frozen root's `dist`, reached
  through the fixture's `packages/main/dist` symlink); the fixtures themselves were removed on success,
  so the recorded paths are the only surviving trace of them.
- Each trial ran **two separate `consumer-worker.mjs routine` processes** (`spawnSync` of
  `process.execPath`), and both were accepted in every trial (`successfulConsumers = 2`, `runs[*].allPass = true`).
- Per-run `reuse` records corroborate the mechanism rather than the count alone: run 1 of every trial is
  `reusable:false, lineage:"rejected", basis:"missing"` (first execution), run 2 is
  `reusable:true, lineage:"trusted-story-metadata-descendant", basis:"fresh"`. `commandExecutions` for
  run 2 is **0 in both GREEN trials** and **1 in both RED trials** — the second consumer re-executes the
  suite under RED and reuses under GREEN, which is exactly what the 2-vs-1 process counts assert.
- Recomputed timings: elapsed [169.7, 89.8, 89.2, 143.4] s, overall median **116.6 s**, total 492.1 s.
  GREEN median 89.5 s, RED median 156.5 s → **≈42.8 %** reduction at the trial level. n = 2 per arm on a
  co-loaded host; treat the percentage as indicative, not as a stable performance figure.

**Conclusion for this item:** the artifact demonstrates repeated routine validation of the *actual*
registered, reuse-eligible root command with real out-of-fixture suite processes, and it does not
manufacture DONE-suite coverage. Its own `scope` string says the same and is accurate.

## 3. Negative evidence retained (not erased)

The earlier `root-command-repeat` series remains on disk and stands: `results.json` there records only
**3 completed trials** (RED 271.2 s / GREEN 125.3 s / GREEN 137.9 s, each with 2 accepted consumers),
and `root-command-repeat-driver.log` ends in an `ERR_ASSERTION` abort on the fourth trial, with a
"timed out" record in the trial logs against the command's 180 s timeout. That series was **not fully
successful**.

The new four-trial all-pass series is **supplementary evidence, not a retraction** of that timeout. The
last-case selection (three PASS around the failing case) does **not** establish what caused the original
failure — host co-load at the time is an untested but plausible contributor, and nothing here rules it
in or out. The honest joint statement is: one earlier run of this experiment timed out under the real
180 s policy; a later run of the same experiment completed 4/4.

## 4. Disclosures (mechanism caveats)

- **Trace instrumentation is read-only and symmetric.** The tracer is injected via
  `NODE_OPTIONS=--import=<tracer>` in **both** RED and GREEN arms; the tracer only appends a JSON line
  when `process.argv[1]` ends with the smoke task path. It observes, it does not alter scheduling or reuse.
  It does, however, mean process counting depends on an env-var import surviving into child processes.
- **The admission fixture is synthetic and confers no Story authority.** Each trial builds a private
  git fixture in `$TMPDIR`, and admission is granted by
  `persistSyntheticAdmittedWindowForTest(...)` with locally derived causal hashes. This is a
  test-only affordance: it proves the repeat/reuse path, not that any real Story was certified.
- Fixtures are deleted on success, so post-hoc re-inspection of a passing trial's fixture is not possible.
- Full DONE suite and build are excluded by policy in this experiment; nothing here speaks to them.

## 5. Second delta — `validate-resource-claims.test.mjs`

Exact source diff `9d4d4b93d3..b25996f711` (5 files): `docs/validation-performance.md`,
`experiments/five-item-proof/checkpoint-owner-recovery.mjs`,
`experiments/five-item-proof/review-roster-check.py`, `experiments/five-item-proof/score-reviews-v2.mjs` (added),
`packages/main/tests/validate-resource-claims.test.mjs`. `packages/main/dist` changed only in
`full-suite-build-binding.json`. **No production JS or config change** — matching
`complete-runtime-delta.json` (`productionCoreOrConfigChanged: false`, `addedLabJsFiles: 19`).
Correction to an intermediate result of mine: an earlier `git diff 9d4..b259` printed only 2 files;
those short SHAs are ambiguous in this repo and the command silently fell back to `HEAD~1..HEAD`.
The full explicit range gives the 5 files above.

Test-file diff content:

- The audited entry changed from `node packages/main/dist/tasks/quorum-submit-smoke.js` to
  `node packages/main/dist/tasks/quorum-submit-smoke.js --jobs=4` — the **exact configured quorum argv**,
  with rationale "bounded internal shards retain the parent exclusive barrier for repository-wide probes".
  The barrier machinery itself is untouched (no removal in the diff; barrier assertions in blocks 2, 6
  and 7 remain).
- Added: a loop over **every** key of `PROVEN_UNSAFE_TO_SHARE` asserting that weakening that writer to
  `REPO_READ` is rejected — i.e. **all 10 writer negative controls**, replacing reliance on a single
  injected example.

Independent run in the frozen root-repeat copy (`/opt/homebrew/bin/node …/validate-resource-claims.test.mjs`,
cwd = a fresh temp dir; distinct from the copy hosting the running full/complete comparison; no
CLI-surface/help/build writers invoked). The frozen copy's test file is byte-identical to source. Output:

```
VI-OK B7DFF-CHK002-CONFIGURED-PLAN-CLASSIFIED configured plan: 134 commands, 134 declared, 0 exclusive by fail-closed default
VI-OK B7DFF-CHK005-AUDITED-BARRIERS-HELD 10 commands retain an effective exclusive local barrier
VI-OK B7DFF-CHK005-COLLISION-PROBE-BITES declaring an audited repo-shared writer is reported by the probe rather than silently accepted
validate-resource-claims: PASS (44 assertions)
```

**44/44 assertions pass; the barrier is not erased** (10 audited writers still hold an effective
exclusive local barrier), in ~2.8 s wall time. The frozen tree showed no dirty state attributable to
the run, consistent with the test only creating private fixtures and reading config.

## Counterexamples found

None material to the two claims audited. Two corrections to intermediate readings, both mine and both
resolved above: `implementationRoot` (dist vs repo root) and the ambiguous-short-SHA diff fallback.

## Scope not covered

Full 134-command suite; DONE-required suite and build; any cross-Story or universal recall claim;
performance stability beyond n = 2 per arm on a co-loaded host; the root cause of the original
`root-command-repeat` 180 s timeout. Earlier audits in this package are preserved and untouched;
this review is bounded to the completed proof described above.
