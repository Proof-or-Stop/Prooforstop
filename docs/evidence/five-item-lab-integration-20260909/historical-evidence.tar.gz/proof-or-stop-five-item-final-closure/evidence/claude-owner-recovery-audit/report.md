# Independent audit — intent-checkpoint owner recovery

**Auditor:** Claude CLI (Opus 5), independent review — no approval taken from author claims.
**Date:** 2026-09-09
**Frozen runtime:** `/var/folders/b1/.../pos-frozen-owner-recovery-qlo_pj5c/repo` @ `35bfa5a9072a4bd3198efcd9d14baee857b24efb`
**Runtime integrity:** `git status --porcelain` empty and HEAD unchanged before, between, and after every run. No builds, edits, git mutations, Stories, or subagents. All fault injections in private `mkdtemp` fixtures; all writes confined to this directory.

## Verdict

Both prior findings are **CLOSED**. The candidate's own suites are green and, more importantly, they hold up under controls I designed independently. The mechanism is conservative in the right direction: every refusal I could produce preserved bytes and wrote nothing.

**One NEW concrete defect** (N3, liveness, no data loss) plus two minor NEW defects (N4 doc, N5 hygiene). None is a data-destruction defect. N3 is a *product* defect, not a lost-history case: the signed evidence is fully present and provably sufficient, but the governed handler declines to use it.

## What I ran

| Suite | Result | Wall |
|---|---|---|
| `experiments/five-item-proof/checkpoint-owner-recovery.mjs` | 6/6 PASS, `CHECKPOINT_OWNER_RECOVERY_GREEN 6` | 17.7 s |
| `experiments/five-item-proof/checkpoint-audit-controls.mjs` | 7/7 PASS, `CHECKPOINT_AUDIT_CONTROLS_GREEN 7` | 15.7 s |
| `independent-negative-controls.mjs` (mine, 5 controls) | 5/5 PASS | ~15 s |
| `probe-nc4-codes.mjs` (mine, code/liveness probe) | see N3 | ~8 s |

Run with `CHECKPOINT_TEST_RUNTIME` pointed at the frozen tree, so the `dist/` under audit is the code exercised. Raw results: `run-output/`, `independent-negative-controls.json`. The 51-minute experiment was not rerun, per scope.

## Prior findings

### N1 — complete signed mirror + old parentless generation-2 anchor unrecoverable → **CLOSED**

`readAnchor(..., inspectLegacyRoot=true)` admits the legacy shape only when `records.length===1 && records[0].generation>1` (`verification-intent-checkpoint.ts:78`). `checkpointRecoveryPlan` then requires the independently validated, chain-complete mirror's **tip** to digest-equal that single anchor record, else `AMENDMENT_CHECKPOINT_LEGACY_TIP_MISMATCH` (`:150-152`). Repair republishes the whole chain under one `update-ref` CAS against the observed anchor commit (`:182` → `:119`).

Independently confirmed: the migration planner is reached and is byte-inert on inspect (my NC-1); a 2-commit truncated chain is rejected as `HISTORY_GAP`, not migrated (author `truncated root cannot masquerade as migration`); a missing middle generation is rejected (author test 5); a mismatched tip is rejected (my NC-4). Closure is exact-tip-match only — see N3 for the adjacent state.

### N2 — corrupt mirror + valid anchor unrecoverable → **CLOSED**

The planner reads every `\d{12}.json`, treats only `SyntaxError` / signature-invalid / `TypeError` as corruption, and never lets a damaged file short-circuit the scan (`:157-170`). Repair builds a replacement directory, `rename`s the original aside to `<digest>.quarantine-<uuid>`, then `rename`s the replacement in (`:184-191`).

Independently confirmed with a partial-write shape the author's suite does not use: a **zero-byte** tip mirror file plus an orphaned `.tmp` sibling (my NC-5). Result: planner reports `quarantine-mirror`, inspection leaves the zero-byte file untouched, apply restores the pre-fault checklist exactly, the zero-byte bytes and the orphan `.tmp` are both present in quarantine, the live mirror is clean, and the next append advances to generation 3.

## Required checks

| Claim | Verdict | Basis |
|---|---|---|
| Corrupt bytes retained, never deleted | **Confirmed** | Author test 2; my NC-5 (zero-byte + orphan `.tmp` both quarantined, none deleted) |
| Signed newer / contradictory mirror refuses even when another file is corrupt | **Confirmed** | `:167-170` inspects all files after corruption; author test 4 (`ROLLBACK` with a corrupt sibling); my NC-3 — a *genuinely signed* gen-2 record replayed into the gen-1 slot yields `AMENDMENT_CHECKPOINT_SIGNED_MIRROR_CONFLICT`, bytes preserved, `.git` unchanged |
| Only the precisely prior parentless format migrates, using the exact full signed mirror | **Confirmed, and tighter than claimed** | `:78`, `:150-152`; three independent rejection shapes (2-commit chain, missing generation, mismatched tip) |
| Inspection performs zero writes | **Confirmed at a stronger standard** | My NC-1: sha256+size ledger of *every file under `.git`* before/after inspection in both planner states — zero created, modified, or deleted. Structurally corroborated: `verifyValidationArtifact` → `readTrustedPublicKey` never creates a key; only the write path's `readPrivateKeyForSigning` does (`validation-artifact-signing.ts:48-73`) |
| Failed / stale / foreign / terminal paths preserve data | **Confirmed** | Author tests 3 and 6 (`STALE_OR_MISSING`, `AMENDMENT_OWNER_REQUIRED` in a foreign session, `AMENDMENT_RECOVERY_ACTIVE_STORY_REQUIRED` in `DONE`); my NC-3/NC-4 add whole-`.git` ledger assertions to the refusal paths. Handler ordering is correct: phase → owner lease → dispatched-agent check → inspect; `apply` additionally needs a ≥30-char reason, and the digest is checked before any write (`checklist.ts:3269-3280`, `:180`) |
| CAS | **Sound** | Every `writeAnchor` supplies an explicit old value: legacy rebuild → observed anchor commit; create-from-mirror → 40 zeros (must-not-exist); normal append → `anchor.commit` (`:109-120`). Author's PATH-shim test forces a wrong old value and confirms a typed `ANCHOR_WRITE_FAILED` with the winner intact. Objects written before a losing `update-ref` are unreferenced garbage — harmless |
| Partial-write recovery | **Sound, one nit (N5)** | Per-file publish is `O_EXCL` temp + `link` (atomic); quarantine is build-then-two-renames. My NC-2 crash-simulates the window *between* the two renames (live dir absent, quarantine + replacement present) — the retained anchor still supports full recovery, the snapshot is restored exactly, and quarantined originals survive. This validates the claim in the code comment at `:187-189`, which nothing in the author's suite tests |

## NEW findings

### N3 — **OPEN, new defect.** Legacy parentless anchor behind a complete signed mirror wedges the story with no governed repair path

**State:** parentless anchor holding generation 2; mirror holding generations 1–3, all validly signed and chain-complete. The mirror is a strict, signed *superset* of the anchor.

**Measured** (`probe-nc4-codes.mjs`):

```
mirror   : 000000000001.json,000000000002.json,000000000003.json
read     : AMENDMENT_CHECKPOINT_HISTORY_GAP
inspect  : AMENDMENT_CHECKPOINT_LEGACY_TIP_MISMATCH
apply    : AMENDMENT_CHECKPOINT_LEGACY_TIP_MISMATCH
append   : AMENDMENT_CHECKPOINT_HISTORY_GAP
rewrite  : AMENDMENT_CHECKPOINT_HISTORY_GAP
readChecklist : AMENDMENT_CHECKPOINT_HISTORY_GAP
```

Every owner action fails closed. The story cannot be read, amended, repaired, or advanced.

**Why this is a product defect and not a lost-history case:** the evidence is present *and demonstrably sufficient*. Deleting the stale anchor ref — raw git surgery, outside the governed handler — makes the identical on-disk state fully readable and recoverable:

```
after `git update-ref -d <ref>`  ->  read: generation 3, inspect: OK (restore plan emitted)
```

So the refusal is not caused by missing evidence. `checkpointRecoveryPlan` compares only `records.at(-1)` against the anchor record (`:151`). Because the legacy format is single-tip by construction, it carries no history with which to distinguish "mirror legitimately advanced past a stale legacy anchor" from "anchor rolled back" — and the planner resolves that ambiguity by refusing everything. A rule that instead required *the anchor record to appear at its own generation index in the complete signed mirror chain* would admit this state safely: the mirror validates independently end-to-end and contains the anchor record verbatim at slot 2.

**Reachability — stated honestly:** I constructed this state; I did not demonstrate a legacy writer producing it. It requires (a) a repo still on the parentless anchor format and (b) the anchor ref trailing the mirror. (b) is squarely in the in-scope accidental-corruption class — a lost or truncated loose ref falling back to an older `packed-refs` value, or a legacy write that reconciled the mirror before updating the ref. The conjunction makes it uncommon, not implausible.

**Severity:** moderate. No evidence loss, fails closed, and the same fix shape as N1. But it is exactly the N1 failure class one step over, and the escape hatch is manual `git update-ref -d`, which is what this subsystem exists to make unnecessary.

### N4 — **OPEN, new defect (documentation, governance-critical surface).** `verification_intent_recover` docstring describes behavior the handler does not have

`packages/main/src/handlers/checklist.ts:3260-3267` documents the handler as: *"Reconstructs ONLY missing verificationIntent lanes from existing PASSING verificationEvidence… synthesized intents are priority='should' so the backfill can never retroactively weaponize the hard coverage gate."*

The implementation synthesizes nothing. It inspects the checkpoint and restores the exact signed snapshot (`:3274-3280`). On a handler whose whole purpose is that no acceptance requirement is manufactured or discarded, a docstring claiming it manufactures `should`-priority intents from evidence is materially misleading to any reviewer reading top-down. Trivial to fix; worth fixing before sign-off.

### N5 — **OPEN, minor (hygiene, no correctness impact).** Interrupted quarantine leaks an unreclaimed `.replacement-<uuid>` directory

Confirmed by NC-2: after a crash between the two renames, the leftover `<digest>.replacement-<uuid>` directory is never reclaimed or reused by the subsequent successful recovery — it simply accumulates in `.git/proof-or-stop-intent-checkpoints/` alongside each `<digest>.quarantine-<uuid>`. No correctness impact: `checkpointPath` resolves the exact digest name only, so neither directory is ever read. Repeated fault/recovery cycles grow this directory without bound.

## Considered and cleared

- **Confirmation-token binding.** `expectedCheckpointDigest` binds `dataDigest` only, not `(generation, dataDigest)`. Non-adjacent generations can share a `dataDigest` (adjacent duplicates are prevented by the early return at `:210`), so a stale token could authorize applying a later generation. Inert: when the digests match, the restored content is byte-identical to what the operator confirmed.
- **Unordered `readdirSync`** in the corruption scan (`:157`) — safe, because corrupt entries `continue` and *any* valid non-matching record throws regardless of visit order.
- **Read failures (EACCES) during the scan** propagate untyped rather than being treated as corruption. That is the correct call — the comment at `:158` is right that an unreadable file is not permission to replace storage — though the error reaching the caller untyped is a small polish item.

## Cost note (not required this round)

The unbounded git-per-signature cost is **not fully retired**. `verification-intent-checkpoint.ts` caches `git rev-parse --git-common-dir` per `gitCwd` (`:16-26`), but the trust-boundary module does not: `validation-artifact-signing.ts:30-42` spawns `git rev-parse --git-common-dir` on **every** `verifyValidationArtifact` call, and `readTrustedPublicKey` re-reads the key file and re-derives the public key each time. Cost scales with generations × items × amendments per read. Not measured this round and not a blocker at fixture scale (13 fixtures, ~33 s total), but the caching fix applied upstream was not applied here.

## Artifacts in this directory

- `independent-negative-controls.mjs` / `.json` — my five controls (NC-1 … NC-5)
- `probe-nc4-codes.mjs` — exact typed codes and liveness measurement behind N3
- `run-output/` — author-suite JSON results from this run
