/** Focused probe: exact typed codes + whether any owner action survives NC-3/NC-4 states. */
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,readdirSync}from 'node:fs';
import {execFileSync}from 'node:child_process';import {join,resolve}from 'node:path';import {tmpdir}from 'node:os';
const runtime=process.env.CHECKPOINT_TEST_RUNTIME;
const {StoryStore}=await import(runtime+'/packages/main/dist/core/store.js');
const {createChecklistHandlers}=await import(runtime+'/packages/main/dist/handlers/checklist.js');
const {acquireOwnerLease}=await import(runtime+'/packages/main/dist/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(runtime+'/packages/main/dist/core/digest.js');
const {resetConfigCache}=await import(runtime+'/packages/main/dist/core/config.js');
const {readIntentCheckpoint}=await import(runtime+'/packages/main/dist/core/verification-intent-checkpoint.js');
const storyId='B-anchor-controls';process.env.PROOF_OR_STOP_SESSION_ID='anchor-controls-owner';
const cap=fn=>{try{const v=fn();return 'OK '+(typeof v==='string'?v.slice(0,60):'');}catch(e){return (e.code??'')+' | '+String(e.message??e).slice(0,120);}};
function fixture(){
 const root=mkdtempSync(join(tmpdir(),'probe-nc4-'));
 const git=(a,i)=>execFileSync('/usr/bin/git',a,{cwd:root,input:i,encoding:'utf8',stdio:['pipe','pipe','pipe']}).trim();
 mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
 writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
 writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
 git(['init','-q','-b','work','--ref-format=files']);git(['config','user.name','Probe']);git(['config','user.email','p@example.test']);
 git(['add','.']);git(['commit','-qm','fixture']);resetConfigCache();
 const store=new StoryStore(root);
 store.writeStory(storyId,{storyId,name:'anchor',title:'t',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
 const old={id:'CHK-001',title:'Coverage',context:'Keep every required boundary',status:'in_progress',startTime:null,endTime:null,
  files:{modify:['src/subject.js'],create:[],test:[]},verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}};
 store.writeChecklist(storyId,{items:[old]});acquireOwnerLease(store.storyDirPath(storyId),{command:'fixture',cwd:root});
 const handler=createChecklistHandlers({store,root,scanRoot:root});
 const append=id=>{const d=store.readChecklist(storyId);return handler.verification_intent_append({storyId,itemId:'CHK-001',
  expectedIntentHash:digestCanonicalJson(d.items[0].verificationIntent),reason:'Add the independently verified required boundary within this private fixture scope.',
  addition:{edge:[{id,desc:'Preserve required boundary '+id,type:'cli',priority:'must'}]}});};
 const ref='refs/proof-or-stop/intent-checkpoints/'+digestCanonicalJson(storyId);
 const mirror=join(root,'.git/proof-or-stop-intent-checkpoints',digestCanonicalJson(storyId));
 append('ONE');return {root,git,store,handler,append,ref,mirror,old};
}
// NC-3 exact code
let f=fixture();f.append('TWO');
writeFileSync(join(f.mirror,'000000000001.json'),readFileSync(join(f.mirror,'000000000002.json'),'utf8'));
console.log('NC-3 inspect :',cap(()=>f.handler.verification_intent_recover({storyId})));
console.log('NC-3 read    :',cap(()=>readIntentCheckpoint(storyId,f.root)));
rmSync(f.root,{recursive:true,force:true});resetConfigCache();
// NC-4 exact codes + liveness of every owner action
f=fixture();f.append('TWO');f.append('THREE');
const snap=f.store.readChecklist(storyId);
const chain=f.git(['rev-list','--first-parent',f.ref]).split('\n');
const bad=f.git(['commit-tree',f.git(['rev-parse',chain[1]+'^{tree}'])],'Prior experimental parentless anchor\n');
f.git(['update-ref',f.ref,bad,chain[0]]);
console.log('NC-4 mirror  :',readdirSync(f.mirror).filter(n=>/^\d{12}\.json$/.test(n)).sort().join(','));
console.log('NC-4 read    :',cap(()=>readIntentCheckpoint(storyId,f.root)));
console.log('NC-4 inspect :',cap(()=>f.handler.verification_intent_recover({storyId})));
console.log('NC-4 apply   :',cap(()=>f.handler.verification_intent_recover({storyId,apply:true,expectedCheckpointDigest:digestCanonicalJson(snap),
 reason:'Recover the signed authoritative snapshot after a bounded private-fixture fault injection.'})));
console.log('NC-4 append  :',cap(()=>f.append('FOUR')));
console.log('NC-4 rewrite :',cap(()=>f.store.writeChecklist(storyId,snap)));
console.log('NC-4 readCkl :',cap(()=>JSON.stringify(f.store.readChecklist(storyId)).length+' bytes'));
// Control: is the same state recoverable once the stale anchor ref is simply deleted?
f.git(['update-ref','-d',f.ref]);
console.log('NC-4 after ref delete -> read   :',cap(()=>readIntentCheckpoint(storyId,f.root).generation+''));
console.log('NC-4 after ref delete -> inspect:',cap(()=>f.handler.verification_intent_recover({storyId})));
rmSync(f.root,{recursive:true,force:true});resetConfigCache();
