/**
 * Independent negative controls for intent-checkpoint owner recovery.
 * Designed by the auditing agent; not derived from the candidate's own suite.
 * Read-only against the frozen runtime; every fixture is a private mkdtemp.
 */
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,readdirSync,chmodSync,existsSync,renameSync,cpSync,statSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join,resolve,relative} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
const runtime=process.env.CHECKPOINT_TEST_RUNTIME??resolve(import.meta.dirname,'../..');
const {StoryStore}=await import(runtime+'/packages/main/dist/core/store.js');
const {createChecklistHandlers}=await import(runtime+'/packages/main/dist/handlers/checklist.js');
const {acquireOwnerLease}=await import(runtime+'/packages/main/dist/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(runtime+'/packages/main/dist/core/digest.js');
const {resetConfigCache}=await import(runtime+'/packages/main/dist/core/config.js');
const {readIntentCheckpoint}=await import(runtime+'/packages/main/dist/core/verification-intent-checkpoint.js');
const storyId='B-anchor-controls';process.env.PROOF_OR_STOP_SESSION_ID='anchor-controls-owner';
const results=[];

/** Byte-exact ledger of every file under .git, so "zero writes" is measured, not asserted about two paths. */
function gitLedger(root){
 const base=join(root,'.git'),out=new Map();
 const walk=dir=>{for(const e of readdirSync(dir,{withFileTypes:true})){const p=join(dir,e.name);
  if(e.isDirectory())walk(p);
  else if(e.isFile())out.set(relative(base,p),createHash('sha256').update(readFileSync(p)).digest('hex')+':'+statSync(p).size);
  else out.set(relative(base,p),'non-file');}};
 walk(base);return out;
}
function ledgerDiff(before,after){
 const diff=[];
 for(const [k,v] of after)if(before.get(k)!==v)diff.push((before.has(k)?'MODIFIED ':'CREATED ')+k);
 for(const k of before.keys())if(!after.has(k))diff.push('DELETED '+k);
 return diff.sort();
}

function run(name,fn){
 const root=mkdtempSync(join(tmpdir(),'indep-control-'));
 const git=(args,input)=>execFileSync('/usr/bin/git',args,{cwd:root,input,encoding:'utf8',stdio:['pipe','pipe','pipe']}).trim();
 try{
  mkdirSync(join(root,'src'));writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(['init','-q','-b','work','--ref-format=files']);git(['config','user.name','Independent audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);const main=git(['rev-parse','main']);resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'anchor',title:'Preserve signed acceptance',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const old={id:'CHK-001',title:'Coverage',context:'Keep every required boundary',status:'in_progress',startTime:null,endTime:null,
   files:{modify:['src/subject.js'],create:[],test:[]},verificationIntent:{happy:[{id:'OLD',desc:'Original assertion',type:'cli',priority:'must'}],edge:[],adversarial:[]}};
  store.writeChecklist(storyId,{items:[old]});acquireOwnerLease(store.storyDirPath(storyId),{command:'fixture',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  const append=id=>{const data=store.readChecklist(storyId);return handler.verification_intent_append({storyId,itemId:'CHK-001',
   expectedIntentHash:digestCanonicalJson(data.items[0].verificationIntent),
   reason:'Add the independently verified required boundary within this private fixture scope.',
   addition:{edge:[{id,desc:'Preserve required boundary '+id,type:'cli',priority:'must'}]}});};
  const ref='refs/proof-or-stop/intent-checkpoints/'+digestCanonicalJson(storyId);
  const mirror=join(root,'.git/proof-or-stop-intent-checkpoints',digestCanonicalJson(storyId));
  const projection=join(store.storyDirPath(storyId),'checklist.json');
  append('ONE');
  const note=fn({root,git,store,handler,old,append,ref,mirror,projection,gitLedger:()=>gitLedger(root)});
  assert.equal(git(['rev-parse','main']),main,'Main fixture branch must remain unchanged');
  results.push({name,passed:true,note:note??null});console.log('PASS',name,note?'— '+note:'');
 }catch(e){results.push({name,passed:false,error:String(e)});console.log('FAIL',name,String(e));}
 finally{try{chmodSync(join(root,'.git/proof-or-stop-intent-checkpoints',digestCanonicalJson(storyId)),0o700);}catch{}
  rmSync(root,{recursive:true,force:true});resetConfigCache();}
}
const REASON='Recover the signed authoritative snapshot after a bounded private-fixture fault injection.';
const inspect=f=>JSON.parse(f.handler.verification_intent_recover({storyId}));
const apply=(f,d)=>f.handler.verification_intent_recover({storyId,apply:true,expectedCheckpointDigest:d,reason:REASON});

/* NC-1: inspection must not write ANY byte anywhere under .git, in the two states
   that trigger the new repair planners (corrupt mirror, and legacy parentless anchor). */
run('NC-1 inspection writes zero bytes anywhere under .git',f=>{
 f.append('TWO');
 writeFileSync(join(f.mirror,'000000000001.json'),'{broken');
 const before=f.gitLedger();const plan=inspect(f);const diff=ledgerDiff(before,f.gitLedger());
 assert.equal(plan.storageRepair,'quarantine-mirror');assert.equal(plan.writes,0);
 assert.deepEqual(diff,[],'corrupt-mirror inspection touched .git: '+diff.join(', '));
 // Same measurement for the legacy parentless-anchor migration planner.
 apply(f,plan.expectedCheckpointDigest);
 const tip=f.git(['rev-parse',f.ref]),tree=f.git(['rev-parse',tip+'^{tree}']);
 const bad=f.git(['commit-tree',tree],'Prior experimental parentless anchor\n');f.git(['update-ref',f.ref,bad,tip]);
 const before2=f.gitLedger();const plan2=inspect(f);const diff2=ledgerDiff(before2,f.gitLedger());
 assert.equal(plan2.storageRepair,'rebuild-legacy-anchor');
 assert.deepEqual(diff2,[],'legacy-anchor inspection touched .git: '+diff2.join(', '));
 return 'both planners byte-inert across the whole .git tree';
});

/* NC-2: crash between the two quarantine renames (mirror dir gone, quarantine +
   replacement left behind). The code comment claims the retained anchor still
   supports a later owner recovery. Nothing in the candidate suite tests it. */
run('NC-2 interrupted quarantine publication still recovers from retained anchor',f=>{
 f.append('TWO');const snapshot=f.store.readChecklist(storyId);
 const quarantine=f.mirror+'.quarantine-simulated',replacement=f.mirror+'.replacement-simulated';
 cpSync(f.mirror,replacement,{recursive:true});renameSync(f.mirror,quarantine); // crash point: real dir absent
 assert.ok(!existsSync(f.mirror));
 f.store.writeJson(storyId,'checklist.json',{items:[f.old]});
 assert.throws(()=>f.store.readChecklist(storyId),/AMENDMENT_CHECKPOINT_PROJECTION_MISMATCH/);
 const plan=inspect(f);apply(f,plan.expectedCheckpointDigest);
 assert.deepEqual(f.store.readChecklist(storyId),snapshot,'signed snapshot must be restorable after interrupted quarantine');
 assert.deepEqual(readdirSync(f.mirror).filter(n=>/^\d{12}\.json$/.test(n)).sort(),['000000000001.json','000000000002.json']);
 assert.equal(readdirSync(quarantine).length,2,'quarantined originals must survive');
 return 'recovered; leftover '+(existsSync(replacement)?'replacement dir is NOT reclaimed':'replacement dir reclaimed');
});

/* NC-3: replay/misfiling. A genuinely signed generation-2 record stored in the
   generation-1 slot. Must refuse (not silently quarantine a real signed record)
   and must not touch the bytes. */
run('NC-3 validly signed record in wrong generation slot is refused, not quarantined',f=>{
 f.append('TWO');
 const two=readFileSync(join(f.mirror,'000000000002.json'),'utf8');
 writeFileSync(join(f.mirror,'000000000001.json'),two);
 const before=f.gitLedger();
 let code='NONE';try{inspect(f);}catch(e){code=String(e);}
 assert.match(code,/AMENDMENT_CHECKPOINT_(SIGNED_MIRROR_CONFLICT|GENERATION_MISMATCH|MIRROR_CONFLICT)/,'expected typed refusal, got: '+code);
 assert.equal(readFileSync(join(f.mirror,'000000000001.json'),'utf8'),two,'bytes must be preserved');
 assert.deepEqual(ledgerDiff(before,f.gitLedger()),[]);
 assert.throws(()=>apply(f,'anything'),/AMENDMENT_CHECKPOINT_/);
 assert.equal(readFileSync(join(f.mirror,'000000000001.json'),'utf8'),two);
 return code.replace(/^Error: /,'').split(':')[0];
});

/* NC-4: legacy parentless anchor pinned at generation 2 while a complete, validly
   signed mirror holds generations 1..3 (the state an interrupted mirror-first
   legacy write leaves behind). Migration must not fabricate, but is there a path? */
run('NC-4 legacy parentless anchor older than a complete signed mirror',f=>{
 f.append('TWO');f.append('THREE');const snapshot=f.store.readChecklist(storyId);
 const chain=f.git(['rev-list','--first-parent',f.ref]).split('\n');
 const tree=f.git(['rev-parse',chain[1]+'^{tree}']); // generation 2 payload
 const bad=f.git(['commit-tree',tree],'Prior experimental parentless anchor\n');
 f.git(['update-ref',f.ref,bad,chain[0]]);
 const mirrorFiles=readdirSync(f.mirror).filter(n=>/^\d{12}\.json$/.test(n)).sort();
 assert.deepEqual(mirrorFiles,['000000000001.json','000000000002.json','000000000003.json']);
 const before=f.gitLedger();
 let readCode='NONE';try{readIntentCheckpoint(storyId,f.root);}catch(e){readCode=String(e);}
 let code='NONE';try{inspect(f);}catch(e){code=String(e);}
 let applyCode='NONE';try{apply(f,digestCanonicalJson(snapshot));}catch(e){applyCode=String(e);}
 assert.deepEqual(ledgerDiff(before,f.gitLedger()),[],'refusal must not mutate .git');
 assert.deepEqual(readdirSync(f.mirror).filter(n=>/^\d{12}\.json$/.test(n)).sort(),mirrorFiles,'all signed generations retained');
 const recovered=code==='NONE';
 return 'read='+readCode.replace(/^Error: /,'').split(':')[0]+' inspect='+code.replace(/^Error: /,'').split(':')[0]
  +' apply='+applyCode.replace(/^Error: /,'').split(':')[0]+' recovered='+recovered;
});

/* NC-5: interrupted write leaving a zero-byte tip mirror file plus an orphaned
   .tmp sibling — the literal partial-write shape reconcileMirror can produce. */
run('NC-5 zero-byte tip mirror file and orphan tmp recover with bytes retained',f=>{
 f.append('TWO');const snapshot=f.store.readChecklist(storyId);
 writeFileSync(join(f.mirror,'000000000002.json'),'');
 writeFileSync(join(f.mirror,'000000000002.json.orphan-uuid.tmp'),'{"partial":');
 f.store.writeJson(storyId,'checklist.json',{items:[f.old]});
 const plan=inspect(f);assert.equal(plan.storageRepair,'quarantine-mirror');
 assert.equal(readFileSync(join(f.mirror,'000000000002.json'),'utf8'),'','inspection must retain the damaged bytes');
 apply(f,plan.expectedCheckpointDigest);
 assert.deepEqual(f.store.readChecklist(storyId),snapshot);
 const parent=join(f.mirror,'..'),q=readdirSync(parent).filter(n=>n.startsWith(digestCanonicalJson(storyId)+'.quarantine-'));
 assert.equal(q.length,1);
 assert.equal(readFileSync(join(parent,q[0],'000000000002.json'),'utf8'),'','damaged bytes must be quarantined, not deleted');
 const orphanKept=existsSync(join(parent,q[0],'000000000002.json.orphan-uuid.tmp'));
 f.append('FOUR');assert.equal(readIntentCheckpoint(storyId,f.root).generation,3);
 return 'orphan tmp '+(orphanKept?'quarantined':'LOST')+'; live mirror clean='+!existsSync(join(f.mirror,'000000000002.json.orphan-uuid.tmp'));
});

writeFileSync(resolve(import.meta.dirname,'independent-negative-controls.json'),JSON.stringify(results,null,2)+'\n');
console.log('INDEPENDENT_CONTROLS',results.filter(r=>r.passed).length+'/'+results.length);
