# Independent Claude CLI evidence audit — three retained empirical claims

Auditor: independent Claude Opus 5 CLI session, 2026-09-09. Lab-only. No subagents.
Writes confined to `claude-evidence-audit/` except two disclosed side effects (§0.3).
No source, build, Git, main or Story mutation. The pin was never unset.

**This is not a product-completion verdict.** It covers exactly the three claims below.
The full 134-item benchmark was still running during this audit and is explicitly out of scope.

---

## 0. Execution identity gate (precondition)

### 0.1 Handshake actually executed

    /Users/jek/.codex/artifacts/.../final-identity/pinned-cli.sh --implementation-identity

Ran it as the first action. **exit 0**, stderr **0 bytes**, stdout saved here as `identity.json`.

### 0.2 Full parsed-JSON comparison against `owner-strict.json`

Not a digest-only comparison. I deep-compared every key, every nested object and the entire
1,640-entry file inventory element-by-element:

| check | result |
|---|---|
| top-level key sets identical | yes (symmetric difference empty) |
| recursive deep diff over whole document | **0 differences** |
| `digest` == pinned `046d27c4…40d4` | yes |
| `fileCount` 1640 == `len(files)` == distinct paths | yes (1640/1640/1640) |
| `runtime.entrypointDigest` == `files["core/cli.js"].digest` | yes (internally consistent) |
| frozen target `…/pos-frozen-root-reuse-o31fjlkk/repo` HEAD | `9d4d4b93d3…` as pinned, clean tree |

Gate satisfied. (File list not printed, per instruction.)

### 0.3 Disclosed side effects outside my directory

1. `review-roster-check.py` **writes `review-benchmark/roster-verified.json`** as part of its
   normal operation. Running the instructed command therefore created/updated that file
   (mtime 10:32). No other benchmark file changed.
2. Rerunning `long-causality-recheck/verify.mjs` rewrites its own `result.json`. I copied the
   original to `claude-evidence-audit/original-recheck-result.json` first, reran, and the new
   output was **byte-identical** to the original — nothing was overwritten with different content.

---

## 1. Claim 1 — 21 enrolled participants, full identity equality, 20 witnessed handshakes

**VERDICT: SUPPORTED, at the stated scope.**

`review-roster-check.py` executed against `review-benchmark`, **true exit 0** (measured without a
pipe masking the status). Output: `owner 1`, `reviewers 20`, `participants 21`,
`completeFullIdentityMatch: true`, `actualCliExitZero: 20`, all **7 negative controls rejected**,
each with a distinct reason.

The checker really does fix the two defects the earlier audit recorded (its D4):

- **Not digest-only.** `row['identity'] == owner` is a full parsed-document equality over the whole
  1,659-entry inventory, plus `owner['fileCount'] == len(owner['files']) > 0`.
- **Owner not hardcoded.** `participants` is `1 + len(rows)` only *after* the owner file has been
  opened and matched to `preregistered.runtimeDigest`; the `missing owner` control (owner=None) is
  rejected.
- **Execution is witnessed, not asserted.** For each reviewer it locates the *first* `Bash`
  `tool_use` in the retained stream, requires the matching `tool_result` by `tool_use_id`, requires
  it non-error, regex-matches the command against the two literal pinned-CLI invocation forms
  (an `echo` of the wrapper name cannot satisfy it), and requires the result body to *begin* with
  `exit=0`.

Control #6, **"failed CLI masked by successful later shell command"**, is the one that matters
here, and it is genuine: it rewrites `exit=0` → `exit=1` in the tool results and is rejected with
`CLI exit zero not witnessed`. Because the checker anchors on `^exit=0` in the *first* Bash result
rather than scanning for any success anywhere in the stream, a later successful command cannot
launder a failed handshake.

**Exact allowed claim.** "All 21 enrolled participants of the retained review calibration (owner +
20 independent Claude reviewer calls) emitted full-document-identical implementation identity, and
20 of them have a witnessed first-Bash pinned-CLI invocation with exit 0." Scope: this roster only.
Not a census of unrelated live Stories, not hostile-host attestation.

### Evidence issues (claim 1)

- **NEW — the roster claim is about a *different* runtime than today's pin.** The calibration's
  identity is `digest 6eb84016…`, **1,659 files**. Today's pinned frozen root is `046d27c4…`,
  **1,640 files**. Both are internally consistent, but my live §0 handshake does **not** re-attest
  the calibration roster; it attests the current implementation. Any sentence that puts the
  "21 participants" figure next to today's digest without naming `6eb84016…/1659` is misleading.
- **NEW — the checker's own gate is `python -O`-removable.** Every check is a bare `assert`
  (lines 6–30). Under `python -O` the script would emit the same passing `roster-verified.json`
  with zero checks performed. This is the identical failure mode the earlier audit raised against
  `run-review-benchmark.py:23`, now reproduced in the checker built to fix it.
- **NEW (minor) — control coverage is single-row.** All five mutation controls perturb `rows[0]`
  only. Positive detection is demonstrated, per-row uniformity is not.
- **Preserved.** The owner's own handshake has no execution trace in the roster (only 20 streams
  exist), which is why the claim says 20 and not 21 witnessed handshakes. Correct as worded.
- **Preserved.** The checker trusts the retained `stream.jsonl` as faithful. Log authenticity is
  outside its threat model — consistent with the declared "no hostile-host attestation" scope.

---

## 2. Claim 2 — RED/GREEN wallclock, redundant wave, post-hoc scorer, 8/8 and 1,416 cases

**VERDICT: SUPPORTED AS RESTATED — and the restatement is mandatory, not optional.**

Every number recomputed from `wave-results.json` / `scored-results.json`:

| quantity | claimed | recomputed | match |
|---|---|---|---|
| RED wallclock | 442.139 s | 442.139 s | ✅ |
| GREEN wallclock | 267.097 s | 267.097 s | ✅ |
| extra RED wave | 123.052 s | 123.052 s | ✅ |
| residual (delta − extra wave) | 51.99 s | 175.042 − 123.052 = **51.990 s** | ✅ |
| reviewer calls | 20 | 12 RED + 8 GREEN = 20, all `exitCode 0`, `reportPresent`, `sourceUnchanged`, one identity digest and one source sha per wave | ✅ |

- **"An actually redundant extra wave" is correct.** RED/first, RED/extra and GREEN/first each
  independently yield `knownDefectsFound` = all 8 with `missingKnownDefects: []`. The third wave
  added no incremental recall; it added 123.052 s of cost.
- **"51.99 s is matched-wave variability" is correct as a *characterisation*, not as a measurement.**
  RED/first 126.743 vs GREEN/first 115.784 and RED/final 192.345 vs GREEN/final 151.313 are the
  *same* configuration (arm is an output-path component only), so the residual cannot be a treatment
  effect. But n=1 per cell: this is a bound on interpretation, not an estimated variance.
- **Post-hoc scorer — disclosed and required.** `preregistered.json` mtime 05:40:47;
  `scored-results.json` 05:56:00; the earlier audit's timeline puts `score-reviews.mjs` at 05:53:48,
  after 19 of 20 reviewer outputs. Any citation of 8/8 must carry this disclosure.
- **Fixture is finite and the artifacts say so.** `preregistered.json.scope` and
  `scored-results.json.scope` both state a finite pure-helper fixture, no universal recall, no
  Story lead time. Both strings are accurate as written.

**Exact allowed claim.** "On one exploratory 10-function pure-helper fixture with 8 planted defects
and 2 clean controls, all three pre-fix waves independently found 8/8 defects via executable
counterexamples, with 97/97 findings classified `validated_defect`, 0 unsupported findings, 0
clean-control flags and 0 findings against the fixed code; an independent 1,416-case in-domain
corpus reproduces exactly the same 8-defective/2-clean partition with 0 failures after the fix.
The scoring oracle was authored after 19/20 reviewer outputs existed."

**Not claimable:** universal or production defect recall; correctness of the fixed code beyond the
enumerated domain; **any Story-level speed figure — in particular the 39.6 % implied by
175.042/442.139**, which is one extra wave plus uncounterbalanced ordering noise.

Per instruction I did **not** demand population-level or generalized proof for this finite claim.
The finite claim is met on its own terms.

### Evidence issues (claim 2)

- **Preserved (still open in the artifact).** `scored-results.json` still reports
  `identityParticipants: 21` from the scorer's hardcoded `1 + reviews.length`; the scorer still
  never opens `owner-identity.json`. Claim 1's checker fixes this **externally**, in a separate
  script; the scored artifact a reader would cite is unchanged. The earlier D4 finding stands as
  written and must not be recorded as "fixed in the scorer."
- **Preserved.** Pre-registration is bound only by mutable filesystem mtimes — no content hash, VCS
  commit or signed timestamp ties `preregistered.json` to a point in time. The post-hoc-scorer
  finding therefore rests on evidence that is itself weaker than the claim it qualifies.
- **Preserved.** Arm ordering is uncounterbalanced and fully confounded with time (all RED waves
  precede all GREEN waves), while `benchmark-identity.py` does counterbalance — so the technique was
  available and not applied here.
- **Scope note on my own coverage.** I recomputed the wave/score numbers directly, but I did **not**
  re-execute `independent-corpus.mjs`; the 1,416-case / 8-defect / 0-after-failure figures are
  carried forward from the prior audit's artifact, not independently re-derived in this session.

---

## 3. Claim 3 — corrected RED assertion and the long-causality recheck

**VERDICT: SUPPORTED, as post-run sufficiency evidence only.**

### 3.1 Provenance of the diagnostic copies — independently verified

| production source (frozen `pos-frozen-long-RED-4u3q6fpj`) | provenance sha256 | recomputed |
|---|---|---|
| `dist/handlers/checklist.js` | `5be040e9…2a0ac` | ✅ identical |
| `dist/core/causal-evidence.js` | `563f9cc5…a5293` | ✅ identical |

Line-diff of each production file against its `.diagnostic.mjs` copy:

- `checklist.js`: 43 changed lines — **0** that are not an `import … from` rewrite or the single
  added `export { probeCausalPreflightFacts };`
- `causal-evidence.js`: 7 changed lines — **0** non-import/export, plus
  `export { preflightChecksForFacts };`

So `provenance.json`'s "relative import specifiers made absolute; private function exported;
function body unchanged" is **exactly true**: the predicate bodies under test are the retained RED
production bodies, byte-for-byte.

### 3.2 Rerun

`node verify.mjs` → **exit 0**, `LONG_LEASE_CAUSALITY_RECHECK_PASS`, `published: 0`, and the emitted
`result.json` byte-identical to the retained one. Its four load-bearing assertions all hold:

- `failed(originalChecks) == []` — the original recorded facts were **fully ready**.
- `failed(currentChecks) == [writerLease: lease_invalid lease_stale]` — **only** the lease fails now.
- `failed(counterfactual) == failed(currentChecks)` — substituting **only** `writerLease` into the
  original ready facts reproduces the failure exactly; all 8 other checks still pass.
- `current.gitMaterial == before.gitMaterial` and `current.gitIndex == before.gitIndex` — same
  `headHash bc6e8d99…`, same `materialHash 3302039a…`, same index digest `sha256:6cf86761…`.

### 3.3 The corrected assertion

The original RED assertion matched a **stack-trace filename**, which is a real false-positive risk.
The corrected worker asserts the **exact first line**:
`Error: causal evidence commit refused: current causal snapshot is not reusable [causal_commit_snapshot_invalid]`
— confirmed to match `long-51-minute-RED/result.json` exactly — **plus** the stale-unchanged lease
(`after.heartbeatAt == before.heartbeatAt`, both `04:12:35.969Z`). The historical raw result is
preserved unmodified. This is a strict tightening, correctly done.

### 3.4 Raw-result claim accuracy (from `result.json` / `children.jsonl` / `lease-samples.jsonl`)

| claim | measured | verdict |
|---|---|---|
| both children ran 3,060,000 ms | `durationMs 3060000` both; child wall RED **3,060,102 ms**, GREEN **3,060,091 ms** | ✅ (setpoint exact; observed wall ~0.1 s over, as expected) |
| RED published 0 / GREEN 1 | RED `evidence: []`, run.log `"published":0`; GREEN `evidence` len 1, `"published":1` | ✅ |
| ≥52 observed renewals, **not** 101 measured | GREEN: 53 samples, **52** heartbeat transitions, 53 distinct heartbeats. RED: **0** transitions (stale by design) | ✅ — 52 is a sampling-derived **lower bound**; a 101/102 figure would be inferred from interval arithmetic, not observed. Correctly declined. |
| stable `leaseId` / `sessionId` / `acquiredAt` | each **exactly 1 distinct value across all 53 samples**, in both arms | ✅ |
| no `generation` field | absent from every lease sample in both arms | ✅ |
| no speed % because RED has no success endpoint | RED terminates in the refusal error with 0 published; GREEN elapsed (3,067,557 ms) is in fact *larger* than RED (3,062,457 ms) | ✅ — a ratio here would be meaningless, and would point the wrong way |

**Exact allowed claim.** "Re-running the exact retained RED readiness predicate against the retained
RED fixture today shows a single failing check — `writerLease` (`lease_invalid lease_stale`) — while
the recorded git material and index bindings still match, and injecting only the current
`writerLease` into the original ready facts reproduces that failure exactly. Lease staleness is
therefore **sufficient** to explain the refusal." This is post-run sufficiency evidence. It is
**not** an original post-execution trace and does not claim one — `result.json.causalConclusion`
says so in its own words, correctly.

### Evidence issues (claim 3)

- **NEW — the recheck depends on a live, non-frozen path.** `verify.mjs:7` sets
  `process.argv[1]` to
  `/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-proof-20260908/experiments/five-item-proof/long-lease-worker.mjs`,
  and `currentFacts.cli` passes because that path exists on this machine **today**. The `cli`
  readiness check is thus not evaluated purely against the frozen fixture. If that worktree is
  moved or deleted, `cli` would also fail and "only `writerLease` fails" would no longer hold —
  through an artifact of the harness, not a change in the causal story. The conclusion survives
  (the counterfactual isolates `writerLease` regardless), but the "only one check fails" phrasing
  is environment-dependent and should be stated with that dependency.
- **NEW (minor) — some current facts are freshly probed, not replayed.** `evidenceTarget.writable`,
  `resources` and `providerCapability` are re-measured today against the retained fixture. They
  agree with the recorded facts, but they are today's observations, so "all other readiness checks
  still pass" means "still pass *now*," not "were re-derived from the original run."
- **Sufficiency, not necessity.** The evidence shows lease staleness is sufficient to force the
  refusal. It does not establish that the original run refused *for that reason and no other* — the
  original worker did not capture every post-execution snapshot branch. The artifact states this;
  any downstream summary must keep the sufficiency/necessity distinction.

---

## 4. Summary

| claim | verdict | binding scope |
|---|---|---|
| 1 — 21 participants, full identity equality, 20 witnessed handshakes | **SUPPORTED** | that roster only, on runtime `6eb84016…`/1,659 files — *not* today's pin |
| 2 — wallclock decomposition, redundant wave, 8/8 with post-hoc scorer disclosed | **SUPPORTED AS RESTATED** | one finite 10-helper fixture; no universal recall, no 39.6 % speed claim |
| 3 — corrected assertion + causality recheck | **SUPPORTED** | post-run sufficiency evidence; not an original post-execution trace |

New evidence issues raised here: the runtime-mismatch scope trap (§1), the `python -O`-removable
checker gate (§1), single-row control coverage (§1), the scorer artifact still carrying the
hardcoded `1 +` (§2), and the recheck's dependence on a live non-frozen worktree path (§3).

Earlier negative findings are preserved as originally recorded, not rewritten: post-hoc scoring
oracle, mtime-only pre-registration binding, uncounterbalanced arm ordering, removable `assert`
gates, and the campaign tooling's digest-string identity check.

**No product-completion verdict is given or implied.** The 134-item benchmark is still running and
is reserved for a separate audit.
