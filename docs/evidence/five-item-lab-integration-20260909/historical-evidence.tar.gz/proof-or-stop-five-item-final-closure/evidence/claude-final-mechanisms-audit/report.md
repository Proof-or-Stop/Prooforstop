# Independent audit — final four mechanisms (batched signature verification, owner recovery closure, quorum process supervision, basis probe pool)

**Auditor:** Claude CLI (Opus 5, 1M context), independent review. No approval taken from author claims; every verdict below rests on the frozen source I read or on a control I ran.
**Date:** 2026-09-09
**Frozen candidate (read-only):** `/var/folders/b1/.../pos-frozen-full-final-k5_v9dgb/repo` @ `9d4d4b93d33732041fb7c3fee344442f468b87c9`
**Baselines compared:** `35bfa5a907` (items 1, 2), `8478514475` (item 3), `90cb35f7e3` (item 4). Bounded to those deltas, not the whole repo.

**Runtime integrity.** `git rev-parse HEAD` returned `9d4d4b93d3` before, between and after every run; tracked-tree `git status --porcelain` (excluding untracked runtime artifacts from the unrelated full134 benchmark) was empty throughout. I built nothing, edited no source/dist/git/config, ran no second full suite, launched no Story or subagent, and touched no main worktree. Every fault injection was in a private `mkdtemp` fixture; every file I created is in this directory.

## Verdict summary

| # | Claim | Verdict |
|---|---|---|
| 1 | Batched trusted-key resolution retains every signature / lineage / current binding; no caller key, no trusted-result cache | **CLOSED** |
| 2 | Prior owner-recovery findings N1–N5 closed; N3 migration is index-exact; destructive cleanup is bounded | **CLOSED** (2 new minor defects) |
| 3 | Quorum supervision kills/reaps POSIX process groups on failure/INT/TERM; no resource relaxation; root `--jobs=4` gates full-73 only | **CLOSED** (2 new low defects) |
| 4 | Basis pool retains all 58 checks; error/signal/timeout guard, explicit 58 count, peak and HEAD assertions added; no tests dropped; digest move caused only by the two argv flags | **CLOSED** |

No new **high** or **data-loss** defect was found in any of the four deltas. Four new defects are recorded, all low/minor, all fail-closed or inert. Two are liveness/hygiene, one is a process-signalling hazard I could not demonstrate, one is a vacuous-guard nit.

## What I ran

All suites run with `CHECKPOINT_TEST_RUNTIME` pointed at the frozen tree, so the `dist/` under audit is the code exercised.

| Suite | Result | Wall |
|---|---|---|
| `signature-key-controls.mjs` | `SIGNATURE_KEY_CONTROLS_GREEN` | 0.40 s |
| `signature-batch-controls.mjs` | 1/1 PASS, `SIGNATURE_BATCH_CONTROLS_GREEN`, `AMENDMENT_KEY_LOOKUPS 2` | 4.43 s |
| `checkpoint-owner-recovery.mjs` | 8/8 PASS, `CHECKPOINT_OWNER_RECOVERY_GREEN 8` | 18.14 s |
| `quorum-plan-controls.mjs` | `QUORUM_PLAN_CONTROLS_GREEN` | 0.15 s |
| `quorum-runtime-controls.mjs` | 12/12 PASS incl. SIGINT + SIGTERM descendant reaping, `QUORUM_RUNTIME_CONTROLS_GREEN` | 5.27 s |
| `independent-batch-edges.mjs` (mine, 19 probes) | **19/19 PASS** | 11.13 s |
| Inventory causality probe (mine, `buildValidationCommandInventory`) | see item 4 | <1 s |
| stdout-truncation probe (mine) | see *Considered and cleared* | <1 s |

---

## Item 1 — batched trusted-key resolution — **CLOSED**

### Source findings

`verifyValidationArtifacts` (`validation-artifact-signing.ts:97-110`) resolves the key once, verifies every envelope against that single in-memory key, then **re-reads the repository key and compares**; any inequality (replacement or deletion) returns `false` for the entire batch. The per-entry checks it inlines are an exact mirror of `verifyValidationArtifact`'s: `typeof signature === 'string'`, prefix match, non-empty encoded part, no embedded `:`, `verifyCanonical`. Nothing is skipped, no caller key parameter exists, and no memo outlives the call. `entries.length<=1` delegates to the singular function, which reads the key inside the single verification — there is no intra-batch window to protect at n=1.

`assertIntentAmendmentItems` (`verification-intent-amendment.ts:99-130`) batches **only** key resolution. Every historical check survives verbatim in the loop: schema allow-list, `storyId`, `itemId`, `previousSignature === previous?.signature ?? null`, `beforeHash === previous.afterHash`, `beforeHash === acceptanceIntentHash(record.beforeIntent)`, and the terminal `scopeHash` / `afterHash` current-intent binding.

**Index alignment is sound.** Envelopes are flattened in item order then row order; the loop consumes `verified[signatureIndex++]` in exactly that order. The pre-pass and the loop `skip`/`throw` on identical predicates (`rows === undefined` → skip; non-array / empty / missing `verificationIntent` / non-object row → `AMENDMENT_INVALID_CHAIN`), so no item can be silently consumed out of step. Every other rejection is a `throw`, which aborts the whole function — a desync cannot survive to authenticate a later row. An out-of-range `verified[i]` is `undefined`, i.e. fail-closed.

`validateCheckpoints` (`verification-intent-checkpoint.ts:35-43`) hoists shape/digest checks ahead of one batched signature verification, then batches every item's amendments across every retained generation in a single call. `readAnchor` now parses all blobs and validates them as one batch (`:77`, `:80`); the chain assertion (`assertCheckpointChain`, `:84`) is unchanged and still runs after validation.

### Controls run

`signature-key-controls.mjs` is green and non-vacuous: it proves verification creates no key, that each of five signatures is individually checked (five single-index tamper rounds), that a rotated key, a mid-batch replaced key and a deleted key all refuse, and that no previous-call result is cached.

`signature-batch-controls.mjs` is green: five amendment rows are each individually tamper-tested, the current-intent binding is tamper-tested, and `AMENDMENT_KEY_LOOKUPS 2` is observed against its `<=2` assertion.

### My independent edge probes — 19/19 (`independent-batch-edges.mjs`)

Built a three-item checklist, two genuine signed amendments per item (six envelopes in one batch), then:

- **Omitted signature** — deleted `signature` from each of the six rows in turn, in both the batched and the single-item entry point: 12 refusals, all `AMENDMENT_INVALID_SIGNATURE_OR_BINDING`. Also `null`, `42`, `{}`, `['x']`, `''`, a bare prefix with empty payload, and a legacy `sha256:` spelling — all refused.
- **Wrong binding with a *genuine* signature.** This is the probe the author's suite does not have: because the fixture holds the signing key, I re-signed tampered payloads so that the signature is real and only the binding is wrong. All refused — broken `previousSignature`, replayed `beforeHash`, a row re-bound to a different `itemId`, a row re-bound to a different `storyId`. I asserted the precondition (`verifyValidationArtifacts` returns `[true]` on the tampered row) so the refusal is provably attributable to the binding check, not to the signature check.
- **Chain shape** — dropping the first row and reversing the row order both refuse.
- **Index alignment** — a clean earlier item plus a forged later item refuses; interleaving amendment-free items around the forged one still refuses; the same interleaving with clean items still passes.
- **Mid-batch key mutation** — a getter that *deletes* the key file during the batch (fired after the batch's key read, inside `verifyCanonical`'s serialization) invalidates all four results, proving the end-of-batch re-read is load-bearing and not just the up-front read. A key mutation during a real amendment batch refuses, and the batch passes again once the key is restored, i.e. no poisoned state survives.
- **No cross-call cache** — a batch that passed, then key deletion, then the identical batch: refused. Restore: passes. Key rotation refuses every historical generation.

### Read-cost — measured only as key-lookup count, no speed claim

Per the scope, I make **no** timing or Story-speed claim; before/after read cost is a separate measurement I did not perform. Structurally: the normal read path (`readAnchor`) now resolves the key twice for all checkpoint records plus twice for all amendments across all generations. The mirror-only and recovery-inspection paths still call `validateCheckpoint` per file, each of which takes the n=1 branch and spawns `git rev-parse --git-common-dir` once per record — so per-generation subprocess cost is reduced on the hot path but not eliminated on those paths. `validation-artifact-signing.ts:30-37` still does not cache the common dir (unlike `verification-intent-checkpoint.ts:16-26`); batching, not caching, is what was applied. I consider that the safer of the two choices and not a defect.

---

## Item 2 — owner recovery closure — **CLOSED** (2 new minor defects)

Prior report: `claude-owner-recovery-audit/report.md`. N1/N2 were already closed there and I did not re-derive them.

**N3 — closed and verified.** `checkpointRecoveryPlan:156` now requires the anchor record to digest-equal the mirror record **at its own generation index** (`records[anchor.records[0].generation-1] ?? null`), not merely the mirror tip. I checked the failure directions in source: an anchor generation beyond the mirror length indexes `undefined` → `digestCanonicalJson(null)` mismatch → `AMENDMENT_CHECKPOINT_LEGACY_TIP_MISMATCH`, so rollback is still refused; `!checkpoint` still requires a non-empty mirror; `generation >= 1` and safe-integer are enforced upstream in `validateCheckpoints`, so the index cannot be negative. The mirror in this branch is read via `mirrorRecords` **without** `anchored`, i.e. every record is fully signature-validated and `assertCheckpointChain` is applied — so "later records extend the same complete signed chain" is enforced, not assumed. The relaxation is confined to `anchor.legacyTruncated`, which is itself gated to `inspectLegacyRoot && records.length === 1 && records[0].generation > 1` (`:83`). Complete anchors are untouched: `:174` still raises `ROLLBACK` / `SIGNED_MIRROR_CONFLICT` for newer or contradictory signed mirrors even when a sibling file is corrupt. Apply still requires owner + phase + reason + `expectedCheckpointDigest` and CASes against the observed legacy commit (`:203` → `:124`).

Suite control 7 (`owner advances stale legacy tip only through complete matching signed lineage`) exercises exactly the N3 state and passes; the negative mismatch directions are covered by retained controls 4 and 5 (`signed newer mirror cannot be quarantined as corruption`, `missing signed generation cannot be invented for old truncated anchor`), both green.

**N4 — closed.** `checklist.ts:3260-3262` now documents the handler as owner-governed restoration of an exact signed checkpoint that "synthesizes no intent, coverage, or PASS evidence". That matches the implementation. The obsolete backfill/`priority='should'` text is gone.

**N5 — closed.** Two mechanisms: the `try/finally` at `:210-213` reclaims the replacement directory if the rename pair does not complete, and `removeDuplicateReplacements` (`:180-193`) sweeps leftovers after a verified successful recovery.

**Destructive-cleanup boundary — inspected and bounded.** The sweep only considers `<basename>.replacement-<uuid>` siblings matching `/^[-a-f0-9]{36}$/`; `lstatSync(...).isDirectory()` is false for a symlink, so symlinks are preserved by construction; any entry that is not a plain file, is not named `\d{12}.json`, has no corresponding retained record, or fails a byte-digest comparison against that record makes `every()` false and the directory is retained. A parse failure is caught and returns `false`. The prefix is this story's own digest, so no other story's storage is in scope. Suite control 8 confirms both directions in one fixture: the verified duplicate is removed and an unrecognized `operator-note.txt` sibling survives byte-for-byte.

### New defect N6 — **OPEN, minor (vacuous guard, no data loss)**

`removeDuplicateReplacements` deletes an *empty* `<digest>.replacement-<uuid>` directory, because `[].every(...)` is `true` — no positive byte-match is required. It also deletes a *partial* replacement (say only `000000000001.json` when three generations are retained), since `every()` says nothing about completeness. Neither loses evidence — an empty directory holds none, and every file that is present is byte-verified against a retained record before removal — but the code comment's stated invariant ("only ... byte-equivalent duplicates") is satisfied vacuously in the empty case. Fix shape: require `files.length > 0` and, if completeness is intended, compare the file set to the expected generation set.

### New defect N7 — **OPEN, minor (untested boundary, fails closed)**

The `finally` at `:213` now destroys the freshly built replacement directory if the **second** `renameSync` throws after the first succeeded. In that window the live mirror directory does not exist, the originals are in `.quarantine-<uuid>`, and the replacement is gone — so the story requires a *second* governed recovery from the retained anchor rather than being one rename from correct. That is the intended fail-closed trade for N5 and I found no evidence loss, but it converts an "interrupted-but-materialized" state into "no mirror at all", and no control forces the second rename to fail. Control 8 simulates a crash externally (`cpSync` + `renameSync`) rather than exercising this branch. Recommend a fault-injection control that makes the second rename fail (e.g. a pre-existing non-empty directory at the target) and asserts anchor-driven recovery still succeeds.

---

## Item 3 — quorum process supervision — **CLOSED** (2 new low defects)

### Source findings

`quorum-case-parallel.ts` spawns shards `detached:true` and terminates via `process.kill(-pid,'SIGKILL')` on the process group, swallowing only `ESRCH`. Cancellation is triggered by: any non-zero exit, a spawn error, a synchronous spawn throw, an output-limit overflow, and a log-write failure. `SIGINT`/`SIGTERM` handlers set `interrupted` and cancel all live children; the handlers are removed in `finally`. Every promise now resolves on `close` (never rejects), so `Promise.all` always settles and the parent waits for child stdio closure before returning. `terminate` also runs on **successful** exits, so a descendant holding the pipe or a private fixture is reaped either way. Exit-code composition `(spawnError||cleanupError||overflow) ? (code||1) : (code??128)` is correct in all four states I traced. `assert.notEqual(process.platform,'win32',...)` is the first statement, and it is only reachable through the `quorumJobs>1` branch, so the **serial default is unchanged on every platform**.

**No resource relaxation.** I diffed the config rows mechanically: the quorum row retains its `exclusive` `.proof-or-stop/runtime/validate-plan-barrier` ticket plus four `shared` entries, and `timeoutMs` stays `1200000`. Zero resource or timeout drift across all 134 rows (see item 4).

**Root `--jobs=4` gates the full suite only.** `quorum-submit-smoke.ts:792` enters the parallel path only when `!listCases && GREP_FILTER === undefined && requestedCases === undefined && quorumJobs > 1`. A selected run therefore stays serial and prints `QUORUM_DIAGNOSTIC_SELECTION_PASSED (n checks)` at `:3523`; the full marker at `:3524` is unreachable from a selection. Shard hygiene is enforced at `:696` (`--case-ids` and `--result-file` must co-occur) and `:689` (result path must be absolute). The actual positive 73-case proof belongs to the running full134 candidate run; I did not and was not asked to reproduce it.

### Controls run

`quorum-runtime-controls.mjs` — 12/12 PASS, including the two new signal controls: for both SIGINT and SIGTERM, all eight owned pids (four workers plus four descendants) start, the signal is delivered, `QUORUM_INTERRUPTED <signal>` appears in output, the exit code is non-zero, and **every owned pid is confirmed dead**. `quorum-plan-controls.mjs` — green on completeness/exactly-once, atomic dependency groups, source/name drift and non-first-child failure.

### New defect N8 — **OPEN, low (process-signalling hazard; not demonstrated)**

`terminate` is invoked from the `exit` handler, which libuv fires *after* it has already `waitpid`'d the direct child. If no descendant remains in the group, the process group ceases to exist and its pgid becomes reusable as a pid. `process.kill(-pid,'SIGKILL')` then targets a pgid that the code cannot prove is still its own, and the `ESRCH` guard cannot distinguish "already gone" from "recycled by an unrelated process group". I did **not** demonstrate a misfire, and the window is narrow in this code's own flow: the `--list-cases` child exits before any shard is spawned, and the four shards are spawned in a single tick before any of them exits. Reachability is low but the guard is structurally unsound. Fix shapes: send the group kill from `close` and only when a descendant is known alive, or record descendant pids explicitly and signal those.

### New defect N9 — **OPEN, low (operator liveness)**

Installing `process.on('SIGINT'/'SIGTERM')` makes those signals non-fatal for the duration of the parallel run. Termination now depends on every shard's `close` firing. There is no timeout or escalation: a second Ctrl-C re-runs `onSignal` rather than killing the runner. In the fixture, both signals complete well inside the control's 3 s bound, and all children are SIGKILLed so they will die — so this is a small reduction in operator control, not a hang I observed. Worth a bounded wait-then-hard-exit around the post-signal `Promise.all`.

---

## Item 4 — basis probe pool — **CLOSED**

Prior report: `claude-basis-pool-audit/report.md`, which approved the serial default and made three items conditional. All three landed:

| Prior requirement | Status in `90cb35f7e3..HEAD` |
|---|---|
| **Required** — reject `killed`/`ETIMEDOUT`/signal/spawn errors *before* the loose regex | **Present.** `if(error.killed||error.signal||typeof error.code!=='number'||error.code===0)throw error;` runs first. A killed child, a signal, a string `errno` code (`ENOENT`, `ETIMEDOUT`) and a zero exit all rethrow into `probeFailures` instead of being matched. The `FORBIDDEN_PROBE_UNEXPECTED_SUCCESS` throw also has no numeric `code`, so an unexpectedly *successful* probe rethrows rather than being scored. The partial-stdout-matching-`/invalid/i` vector the prior audit identified is closed. |
| **Should fix** — explicit inventory count | **Present.** `assert.equal(probes.length,58,...)` before the pool, independent of `completedProbes`. |
| **Should fix** — assert actual concurrency | **Present.** `assert.ok(peakProbes<=probeJobs&&(probeJobs===1||peakProbes>1),...)` — a degenerate serial run at `jobs=4` now fails. |
| Not previously required | **Added:** `assert.equal(git(root,['rev-parse','HEAD']),probeHead,...)` per probe. This closes the prior report's §5 gap that `git status --porcelain` cannot see HEAD movement — at the probe level, though `fullSnapshot` itself is unchanged, as it must be. |
| `maxBuffer` loosening | **Reverted** to `1024*1024`, i.e. `execFileSync`'s default. Only the 30 s per-probe timeout remains as a delta, and it is now guarded. |

**Four full runs, evidence assessed.** `basis-paired-results.json` records four runs at jobs 1, 4, 4, 1 — all `exitCode: 0`, all against the same frozen `90cb35f7e3` clone with `independentWritableDist: true`. The per-run logs corroborate rather than merely repeat: every run emits `count: 58` with a byte-identical sorted 58-id list, `jobs: 1 → peak: 1` and `jobs: 4 → peak: 4`, and each ends with `ProofStory acceptance coverage basis Wave 1A smoke passed`. Two independent `jobs=4` full runs plus the `peak > 1` assertion together satisfy the prior audit's stated bar for enabling 4 (repeated full-run GREEN plus proof the run was actually concurrent). The `index.lock` contention the prior audit flagged did not materialize in either concurrent run; that is two samples, so I record it as *not observed*, not as *impossible*. **Opt-in 4 is supported by this evidence.**

**Timeout unchanged.** The registered `timeoutMs` for the basis row is `180000` at both baseline and HEAD — verified mechanically, not by reading the diff context.

**No tests dropped; digest causality proven.** I recomputed the inventory through `buildValidationCommandInventory` (`dist/core/validation-command-identity.js`) over the raw `validate.commands` array at `35bfa5a907` and at HEAD:

- **134 commands at both revisions.** Zero rows present at baseline with no HEAD counterpart, i.e. no test was dropped.
- **Zero rows differ beyond the two argv flags.**
- Stripping exactly `--jobs=4` and `--probe-jobs=4` from HEAD reproduces the baseline digest **bit for bit** (`9292486970f39942...` both ways). The two flags are therefore the *sole* cause of the inventory digest move — proven, not asserted.
- Zero `timeoutMs` drift and zero `resources` drift across all 134 rows.

Caveat, stated plainly: the raw-array digests I computed (`c8458dad…` / `9292486970…`) are **not** the pinned value `b29365c6a2ba…`, because `validation-tier-planner-smoke.ts` pins the digest of the *normalized* set produced through `configuredValidationCommands`, which I did not reconstruct. The pinned literal itself is asserted by that smoke, which is one of the 134 commands in the running full134 candidate run. What I proved independently is the causality and the preservation, which is the substantive claim; the exact pin value is verified by the candidate run, not by me.

---

## Considered and cleared

- **`process.exit(0)` truncating the full-suite marker.** `quorum-submit-smoke.ts:793` calls `process.exit(0)` immediately after `runParallelQuorum` returns, and the `✓ quorum_submit smoke passed (73 checks)` marker is declared gate evidence. I measured this on the audit host: with piped stdout, `process.exit(0)` truncates at exactly 131072 bytes and a trailing marker after a 3 MB write is lost — the hazard is real in general. It is **not reachable here**: in the parallel path all child output is buffered to per-shard log files and the parent writes only two short lines, far under the pipe buffer, and my probe confirms a small final line survives. Recorded as a boundary: it would become reachable if parent stdout ever exceeded ~128 KiB before the marker. The line also predates `8478514475` and is outside the audited delta.
- **Error-code observability shift in `assertIntentAmendmentItems`.** The pre-pass can now surface `AMENDMENT_INVALID_CHAIN` from a *later* item where per-item calls would have surfaced `AMENDMENT_INVALID_SIGNATURE_OR_BINDING` from an earlier one. Inert: both are `IntentAmendmentIntegrityError`, and the only caller that branches on the class (`checkpointRecoveryPlan:169`) treats them identically.
- **n=1 delegation in `verifyValidationArtifacts`.** Not a weakening: a single envelope reads the key once and uses it once, so there is no intra-batch window for an end-of-batch re-read to protect.
- **Duplicate crypto work across generations.** Each retained generation carries the full checklist, so an amendment row is verified once per generation in which it appears. That is the correct consequence of refusing a trusted-result cache; the cost is Ed25519 verifies, not subprocesses.
- **`--jobs=4` with a selection.** Cannot reach the parallel path (`:792`), so selected-case diagnostics remain diagnostics and can never emit the full-suite marker.
- **Empty `PROOF_OR_STOP_QUORUM_JOBS`.** `??` → `||` at `:690` makes an empty string select `'1'`; covered by a passing control.

## Speculative, hostile-admin, and out-of-scope limits

Separated deliberately — none of these is counted as a defect above.

- **Hostile local operator.** The signing key lives in the repository's Git metadata; anyone who can write the mirror can also read the key and forge any generation. This is the stated trust boundary (`process-fact-registry.ts`: "a local trust boundary, not hostile-host protection"). My E2 probes exploit exactly this to test bindings; they are audit instruments, not a claimed break.
- **Raw `git update-ref -d` surgery.** Still outside the governed handler, still possible for an administrator. N3's fix removes the specific state where surgery was the only escape, but it does not and cannot prevent surgery.
- **Descendant escaping the process group** via its own `setsid`. `kill(-pgid)` would miss it and `close` could hang. Not reachable for the quorum shards (same smoke, no `setsid`), so speculative for this delta.
- **`index.lock` contention at `probe-jobs=4`.** Not observed across two concurrent full runs. It would produce a false RED, never a false GREEN, but two samples is not a stability proof.
- **Per-row attribution at `probe-jobs>1`.** As the prior audit noted, `"${command} ${field} rejection is atomic"` now means "aggregate fixture state was unchanged when row *i* finished, with up to 3 peers in flight". Detection is preserved; per-row attribution is not. This is inherent to the pool, not a regression introduced since.
- **`fullSnapshot` scope** (six digests plus `git status --porcelain`) is unchanged and shared with other assertions; strengthening it remains out of the allowed scope, and the new per-probe HEAD assertion covers the specific gap the prior audit named.

## What this report does not certify

- **No overall Story speed claim.** I made no wall-clock measurement of the validation suite and none of the four items' evidence supports one. The prior read-cost measurement is separate work; the only quantity I observed is a key-lookup count in a fixture.
- **No universal recall claim.** These are bounded deltas against three named baselines. I did not audit the rest of the repository.
- **No full134 or full-73 assertion.** The candidate full134 run in the private clone carries the actual 73-case positive proof and the `b29365c6…` pin assertion; neither was reproduced here.

## Artifacts in this directory

- `independent-batch-edges.mjs` — my 19 probes (omitted signature, re-signed wrong-binding, index alignment, mid-batch key mutation, no-cache)
- `run-output/` — JSON results from the author suites and from my probes for this run
- `report.md` — this file
