// Independent audit probes for the batched signature/lineage verification path.
// Every fault is injected into a private mkdtemp fixture; nothing outside this
// directory and the fixture is written.
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,unlinkSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
const runtime=process.env.CHECKPOINT_TEST_RUNTIME??resolve(import.meta.dirname,'../..');
const {StoryStore}=await import(runtime+'/packages/main/dist/core/store.js');
const {createChecklistHandlers}=await import(runtime+'/packages/main/dist/handlers/checklist.js');
const {acquireOwnerLease}=await import(runtime+'/packages/main/dist/core/story-owner-lease.js');
const {digestCanonicalJson}=await import(runtime+'/packages/main/dist/core/digest.js');
const {resetConfigCache}=await import(runtime+'/packages/main/dist/core/config.js');
const {assertIntentAmendments,assertIntentAmendmentItems}=await import(runtime+'/packages/main/dist/core/verification-intent-amendment.js');
const {signValidationArtifact,verifyValidationArtifacts}=await import(runtime+'/packages/main/dist/core/validation-artifact-signing.js');

const storyId='B-batch-edges';process.env.PROOF_OR_STOP_SESSION_ID='batch-edges-owner';
const results=[];
const check=(name,fn)=>{try{fn();results.push({name,passed:true});console.log('PASS',name);}
  catch(e){results.push({name,passed:false,error:String(e)});console.log('FAIL',name,String(e));}};

const root=mkdtempSync(join(tmpdir(),'batch-edges-'));
try{
  const git=a=>execFileSync('/usr/bin/git',a,{cwd:root,encoding:'utf8',stdio:['pipe','pipe','pipe']}).trim();
  mkdirSync(join(root,'src'));
  writeFileSync(join(root,'src/subject.js'),'export const x=true;\n');
  writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
  writeFileSync(join(root,'.gitignore'),'.proof-or-stop/runtime/\n.proof-or-stop/locks/\n');
  git(['init','-q','-b','work']);git(['config','user.name','Private audit fixture']);git(['config','user.email','audit@example.test']);
  git(['add','.']);git(['commit','-qm','fixture']);git(['branch','main']);const main=git(['rev-parse','main']);
  resetConfigCache();
  const store=new StoryStore(root);
  store.writeStory(storyId,{storyId,name:'batch',title:'Batch edge probes',phase:'DEV',type:'chore',priority:'medium',createdAt:new Date().toISOString()});
  const item=n=>({id:'CHK-00'+n,title:'Coverage '+n,context:'Keep every required boundary',status:'in_progress',startTime:null,endTime:null,
    files:{modify:['src/subject.js'],create:[],test:[]},
    verificationIntent:{happy:[{id:'OLD'+n,desc:'Original assertion '+n,type:'cli',priority:'must'}],edge:[],adversarial:[]}});
  store.writeChecklist(storyId,{items:[item(1),item(2),item(3)]});
  acquireOwnerLease(store.storyDirPath(storyId),{command:'fixture',cwd:root});
  const handler=createChecklistHandlers({store,root,scanRoot:root});
  const append=(itemId,id)=>{const data=store.readChecklist(storyId);const target=data.items.find(i=>i.id===itemId);
    return handler.verification_intent_append({storyId,itemId,expectedIntentHash:digestCanonicalJson(target.verificationIntent),
      reason:'Add the independently verified required boundary within this private fixture scope.',
      addition:{edge:[{id,desc:'Preserve required boundary '+id,type:'cli',priority:'must'}]}});};
  for(const n of [1,2,3])for(const tag of ['A','B'])append('CHK-00'+n,tag+n);
  const items=store.readChecklist(storyId).items;
  assert.equal(items.length,3);
  for(const it of items)assert.equal(it.verificationIntentAmendments.length,2);

  // Baseline: the untouched batch validates.
  check('E0 baseline multi-item batch validates',()=>assertIntentAmendmentItems(items,storyId,root));

  // E1 — omitted signature anywhere in the batch must fail closed.
  for(let i=0;i<3;i++)for(let r=0;r<2;r++)check(`E1 omitted signature item${i+1} row${r+1}`,()=>{
    const bad=structuredClone(items);delete bad[i].verificationIntentAmendments[r].signature;
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    const one=structuredClone(items[i]);delete one.verificationIntentAmendments[r].signature;
    assert.throws(()=>assertIntentAmendments(one,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
  });
  check('E1b null / non-string signature refused',()=>{
    for(const sig of [null,42,{},['x'],'',
      'ed25519:validation-artifact-v1:','sha256:deadbeef']){
      const bad=structuredClone(items);bad[1].verificationIntentAmendments[0].signature=sig;
      assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    }
  });

  // E2 — VALIDLY RE-SIGNED but wrong lineage binding. The fixture key is local,
  // so a tampered payload can be given a genuine signature; only the lineage
  // and current-intent bindings can reject it.
  const resign=record=>{const {signature,...payload}=record;return {...payload,signature:signValidationArtifact(payload,root)};};
  check('E2a re-signed broken previousSignature refused',()=>{
    const bad=structuredClone(items);const rows=bad[2].verificationIntentAmendments;
    rows[1].previousSignature=rows[0].signature.slice(0,-4)+'AAAA';bad[2].verificationIntentAmendments[1]=resign(rows[1]);
    assert.deepEqual(verifyValidationArtifacts([{value:(({signature,...v})=>v)(bad[2].verificationIntentAmendments[1]),
      signature:bad[2].verificationIntentAmendments[1].signature}],root),[true],'probe precondition: tampered row is genuinely signed');
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
  });
  check('E2b re-signed broken beforeHash lineage refused',()=>{
    const bad=structuredClone(items);const rows=bad[0].verificationIntentAmendments;
    rows[1].beforeHash=rows[0].beforeHash;bad[0].verificationIntentAmendments[1]=resign(rows[1]);
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
  });
  check('E2c re-signed row bound to a different item refused',()=>{
    const bad=structuredClone(items);const row=structuredClone(items[0].verificationIntentAmendments[0]);
    row.itemId='CHK-002';bad[1].verificationIntentAmendments[0]=resign(row);
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
  });
  check('E2d re-signed row bound to a different story refused',()=>{
    const bad=structuredClone(items);const row=structuredClone(items[1].verificationIntentAmendments[1]);
    row.storyId='B-other-story';bad[1].verificationIntentAmendments[1]=resign(row);
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
  });
  check('E2e current-intent binding still enforced per item in a batch',()=>{
    for(let i=0;i<3;i++){const bad=structuredClone(items);bad[i].verificationIntent.happy[0].desc+=' drifted';
      assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_CURRENT_INTENT_MISMATCH/);}
  });
  check('E2f truncated / reordered chain refused',()=>{
    const drop=structuredClone(items);drop[1].verificationIntentAmendments.splice(0,1);
    assert.throws(()=>assertIntentAmendmentItems(drop,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    const swap=structuredClone(items);swap[2].verificationIntentAmendments.reverse();
    assert.throws(()=>assertIntentAmendmentItems(swap,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
  });
  check('E2g index alignment: only the tampered row may be rejected, none skipped',()=>{
    // A batch where an EARLIER item is clean and a LATER item is forged must
    // still reject; a naive shared index would consume the wrong verdict.
    const bad=structuredClone(items);
    bad[2].verificationIntentAmendments[1].reason+=' altered-without-resigning';
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    // Interleave items that carry no amendments at all around the forged one.
    const none={...structuredClone(items[0]),id:'CHK-900'};delete none.verificationIntentAmendments;
    assert.throws(()=>assertIntentAmendmentItems([none,bad[0],none,bad[2],none],storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    assertIntentAmendmentItems([none,items[0],none,items[2],none],storyId,root);
  });

  // E3 — mid-batch key mutation at the exact trust boundary.
  const keyPath=join(root,'.git/proof-story-aware-validation-artifact-v1.key');
  const trusted=readFileSync(keyPath);
  check('E3a mid-batch key DELETION invalidates the whole batch',()=>{
    const entries=[1,2,3,4].map(n=>({n})).map(value=>({value,signature:signValidationArtifact(value,root)}));
    assert.deepEqual(verifyValidationArtifacts(entries,root),[true,true,true,true]);
    const evil=structuredClone(entries);
    Object.defineProperty(evil[1].value,'n',{enumerable:true,get(){try{unlinkSync(keyPath);}catch{}return 2;}});
    assert.deepEqual(verifyValidationArtifacts(evil,root),[false,false,false,false]);
    writeFileSync(keyPath,trusted);
  });
  check('E3b mid-batch key change during a real amendment batch invalidates it',()=>{
    const bad=structuredClone(items);
    const row=bad[1].verificationIntentAmendments[0];const original=row.reason;
    Object.defineProperty(row,'reason',{enumerable:true,configurable:true,
      get(){writeFileSync(keyPath,readFileSync(keyPath));unlinkSync(keyPath);return original;}});
    assert.throws(()=>assertIntentAmendmentItems(bad,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    writeFileSync(keyPath,trusted);
    assertIntentAmendmentItems(items,storyId,root); // no poisoned cache survives
  });
  check('E3c no cross-call trusted-result cache',()=>{
    assertIntentAmendmentItems(items,storyId,root);
    unlinkSync(keyPath);
    assert.throws(()=>assertIntentAmendmentItems(items,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    writeFileSync(keyPath,trusted);
    assertIntentAmendmentItems(items,storyId,root);
  });
  check('E3d rotated key refuses every historical generation',()=>{
    writeFileSync(keyPath,Buffer.from(execFileSync('/usr/bin/head',['-c','32','/dev/urandom'])).toString('base64'));
    assert.throws(()=>assertIntentAmendmentItems(items,storyId,root),/AMENDMENT_INVALID_SIGNATURE_OR_BINDING/);
    writeFileSync(keyPath,trusted);
  });

  assert.equal(git(['rev-parse','main']),main,'fixture main branch must be unchanged');
}finally{
  const out=process.env.FIVE_ITEM_PROOF_OUTPUT;
  if(out){mkdirSync(out,{recursive:true});writeFileSync(join(out,'independent-batch-edges.json'),JSON.stringify(results,null,2)+'\n');}
  rmSync(root,{recursive:true,force:true});resetConfigCache();
}
console.log('INDEPENDENT_BATCH_EDGES',results.filter(r=>r.passed).length+'/'+results.length);
assert.ok(results.every(r=>r.passed),'INDEPENDENT_BATCH_EDGE_GAPS');
