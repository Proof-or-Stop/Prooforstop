from pathlib import Path
import subprocess,json,hashlib,datetime
art=Path(__file__).resolve().parent
main=Path('/Users/jek/Documents/GitHub/Prooforstop')
lab=main/'.worktrees/Lab-five-item-proof-20260908'
before=json.loads((art/'before.json').read_text())['main']
def git(root,args):return subprocess.check_output(['git',*args],cwd=root,text=True)
head=git(main,['rev-parse','HEAD']).strip()
status=git(main,['status','--porcelain=v1','-z','--untracked-files=all'])
files={name:hashlib.sha256((main/name).read_bytes()).hexdigest() if (main/name).exists() else None for name in before['files']}
changed=[name for name,digest in files.items() if digest!=before['files'][name]]
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mainHead':head,'baselineHead':before['head'],'mainHeadUnchanged':head==before['head'],'mainStatusUnchanged':status==before['status'],'mainStatus':status,'originalFilesCompared':len(files),'changedOriginalFiles':changed,'originalFilesUnchanged':not changed,'fileHashes':files,'labHead':git(lab,['rev-parse','HEAD']).strip(),'labStatus':git(lab,['status','--porcelain=v1','--untracked-files=all']),'version':json.loads((main/'packages/main/package.json').read_text())['version'],'scope':'Read-only comparison; records any concurrent differences and never restores/stashes/cleans main.'}
(art/'main-final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['mainStatus','fileHashes']},indent=2))
