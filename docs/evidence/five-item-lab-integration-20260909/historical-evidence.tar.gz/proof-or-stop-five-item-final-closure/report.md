本轮继续修复既有 Lab 的五项优化，并由 Claude CLI 独立审计。所有实现、私有故障夹具和计时实验均在 Lab 或从 Lab 创建的隔离副本中完成；本任务没有创建真实 Story、合入 main、升级版本或发布。固定基线为 `cf21df09c273074d7aa3227a5f436c6f5badf47a` / 0.3.284，最终候选为 `50ca0454dc8d`。期间另一任务推进了 main，详情单独列明，实验基线没有随之移动。

完整的134条对照两边均通过；五项在下表列出的Lab机制与场景已取得可核验的正确性证据，其中重复重型命令和并发验证测到了收益。最终保留候选为50ca0454dc8d，包含本轮最后发现的构建顺序修正，见[最终源码差异](evidence/final-source-delta.json)。本结论不把明确保留的范围外部署条件和未复现OS风险称为已消失。

这次解决的是五项中可在本地实验复现的具体故障及适用场景。不能把它写成“所有 Story 的小时级交付问题已经消失”：真实会话部署、实际 Story 的端到端分布、普遍缺陷召回率，均没有在本次禁止改 main 的范围内发生。各项数据不能相加，也不支持整体提速48%。

| 项目 | 修正前的具体问题 | 当前修正与证明 | 适用场景及边界 |
|---|---|---|---|
| ① 哈希准确性、执行身份和摘要开销 | 基线材料哈希已为27/27，但实际入口/helper/实现绑定仍有遗漏；严格身份输出重复扫描 | 材料哈希仍27/27；实现/依赖/入口变更拒绝旧回执；保留完整扫描，仅去掉同次严格身份输出的重复扫描。旧校准owner+20个Claude输出的完整身份逐一一致；新的开发端与最终Claude也执行固定入口核对 | 本次登记的Lab参与者与固定运行时。没有迁移或干预其他运行中的Story会话；本地摘要不是敌对主机认证 |
| ② 修复前有界收敛 | 每出现新类别就追加整波，修复前循环扩大 | 基线已有的完整首波→remediation规则及缺critic/签名/新鲜度/冒充最终认证反例通过。真实20次Claude调用测出额外波成本；有限夹具中8个已知缺陷都被找到，修后无已验证缺陷 | 首波必须完整，最终认证保留。10个纯函数、8个植入缺陷、2个正常控制的探索性实验；不能推广为任意Story不漏缺陷 |
| ③ 共享真实重型执行 | observe模式新增复用资格0/134；相同命令的消费者重复运行 | observe可独立开启共享，Lab根配置为1/134合格routine；实际根注册重型命令由两个真正routine handler进程消费，按完整身份与输入共享持久回执。篡改、缺失、输入/实现变化、旧输出和不同selector反例保留 | 同一合格命令、同一有效输入、成功且新鲜的结果。根DONE build/full-suite与该命令没有精确重合，0/2合格是保留副作用边界，不虚构重合或放宽build排除规则 |
| ④ 续租、发布、验收修订和历史恢复 | 长批处理执行完才被租约拒绝；PLAN旧绑定阻止修订；历史缺失/损坏无完整恢复途径 | 真正51分钟batch对照完成；同owner续租和代际fencing；发布事务重试/新进程恢复不重启测试。真实DEV追加、签名PLAN修订、历史完整链和受控owner恢复通过。Git后端迁移、旧截断锚点、损坏镜像、第二次rename失败均有控制。所有历史签名仍验证，批量读取可信公钥减少进程开销 | 当前有效owner、范围内修订、存在持久回执或完整可信历史。永久存储丢失且无备份不能恢复；同时销毁密钥/全部可信历史不是该本地模型能阻止的事 |
| ⑤ 完整资源配置、并发和可获益拆分 | 资源声明不全/重复；独占大套件内部串行；部分验收夹具与入口准备不完整 | routine134/134、DONE2/2有资源声明；归一化声明195→17；保留writer屏障；73条真实quorum断言按依赖组拆分，58条真实CLI拒绝探测有界并发。所有73个callback保留；独占声明撤销反例和失败/信号进程清理控制通过 | 可独立的验证分片、只读共享资源、私有fixture。保留13条有依赖断言的原子组；任意Story拆分不保证快。两个未复现OS级残余风险仍明确保留 |

证据：[材料哈希](evidence/hash-final.log)、[生产机制回归](evidence/mechanisms-final.log)、[签名/恢复/并发独立审计](evidence/claude-final-mechanisms-audit/report.md)、[身份与计时审计](evidence/claude-evidence-audit/report.md)、[证据修正与恢复追加审计](evidence/claude-evidence-repair-addendum/report.md)。早期负面审计从未覆盖删除。

性能RED表示旧策略，允许其正确通过；功能RED才要求目标断言失败。下表按同一工作负载比较，失败无成功终点时不计算提速。

| 工作负载 | RED/修正前 | GREEN/修正后 | 可得结论 |
|---|---:|---:|---|
| 严格执行身份输出；7组交错对照中位数 | 1.009秒 | 0.863秒 | 本次观察下降14.5%，1659个文件均重新读取；不是所有CLI或材料哈希算法的比例 |
| 5代验收历史的canonical读取；各2轮，每轮15次的中位数再取中位数 | 453.95毫秒 | 192.15毫秒 | 本次观察下降57.7%；5条修订公钥查询5→2，全部签名/语义/当前绑定仍检查。原探针只保存每轮统计，未保存每个样本，不给置信区间 |
| 完整73条quorum断言；2组交错对照中位数 | 1074.128秒 | 658.231秒 | 真实完整套件观察下降38.7%；同73条断言，保留13条有依赖的原子组。后续进程清理改动由当前完整工作负载验证 |
| 完整58条CLI拒绝探测及原套件断言；2组交错对照中位数 | 108.837秒 | 77.788秒 | 本次观察下降28.5%；58条全部实际运行，峰值1→4，未缩减直接handler或原子性断言 |
| 真实Claude审查的有限校准 | 12次调用，442.139秒 | 8次调用，267.097秒 | 额外整波实际用时123.052秒，未新增这组已知缺陷；余下51.990秒为相同波次间的运行差，不能算政策收益 |
| 真正51分钟batch到证据发布 | 3062.457秒后拒绝，0条发布 | 3067.557秒，1条发布 | 失败→成功，真实子进程两边都运行约3060秒；不宣称提速。观察到至少52次续租，旧owner/代际拒绝控制保留 |
| 实际根注册重型命令、两个routine消费者；2组交错对照中位数 | 156.543秒，2次执行 | 89.497秒，1次执行 | 4组均成功，8次消费者调用全部通过；该场景观察耗时下降42.8% |
| 完整134条验证；相同生产/测试脚本，原始超时，1组对照 | 1695.867秒，134/134通过 | 952.471秒，134/134通过 | 完整工作负载本次观察耗时变化：减少43.8%；不是所有代码修复的因果收益或Story速度 |

原始计时：[身份](evidence/identity-timing/results.json)、[历史读取](evidence/signature-performance.json)、[73条对照](evidence/quorum-paired-results.json)、[58条对照](evidence/basis-paired-results.json)、[Claude评分V2](evidence/review-benchmark/scored-results-v2.json)、[51分钟RED](evidence/long-51-minute-RED/result.json)、[51分钟GREEN](evidence/long-51-minute-GREEN/result.json)。计时使用实际进程/单调时钟，不使用模型自报耗时。

完整对照见[全部结果/每条输出](evidence/full-ordered-comparison/results.json)、[GREEN实际调度事件](evidence/full-ordered-comparison/events.jsonl)、[RED原始事件](evidence/full-complete-comparison/events.jsonl)及[命令、源码与范围](evidence/full-ordered-comparison/manifest.json)。RED在b25996f7114f的执行器输入中恢复CF资源声明、去掉两项内部并发参数；GREEN使用50ca0454dc8d的已审核声明、两个有界池和预检查独占屏障。两边实际生产/测试脚本相同，但Git提交和配置不同；jobs都为4，原始超时未增加，134条命令无遗漏；顶层峰值分别为4和4。两个全量计时都从已准备构建物开始；另行删除新私有副本main/dist后，实际前三条命令73.852秒全部通过，见[冷启动原始结果](evidence/full-ordered-comparison/cold-prefix.json)。[顺序断言](evidence/full-ordered-comparison/order-proof.json)核对冷启动以及完整RED/GREEN中构建均先于所有后续消费者。未声称134条全部从无dist开始。完整对照只有一组，不能排除宿主负载/缓存/顺序对绝对差值的贡献；内部完整73条和58条另有交错重复对照支持对应机制。

真实根命令复用见[4组原始结果](evidence/root-command-repeat-complete/results.json)、[重新计算的摘要](evidence/root-command-repeat-complete/summary.json)及[Claude独立审计](evidence/claude-root-repeat-audit/report.md)。计数记录实际套件进程启动，日志在fixture之外，实际实现来自只读冻结副本；两个消费者在不同Node进程运行。NODE_OPTIONS只读计数探针在两边都使用。每组使用新的私有测试准入夹具，不授予真实Story权威。根DONE没有该命令的精确重合，不宣称清除了根配置所有routine/DONE叶子测试的重复。

完整验证补出了真实的构建顺序缺陷：调度器只检查正在运行的冲突任务，可能越过排队中的build；已准备的dist会掩盖它。Claude独立复现，并对全部134条资源分析出122条可能提前启动。修正只在第一条预检查保留原资源并增加独占顺序屏障，使预检查、构建依次完成，之后恢复并行。全部11条routine writer屏障保留；历史21条reader审计现在为14条共享、6条writer及1条明确标注的预检查顺序屏障。资源分类的例外仅允许准确的第0条命令，不能推广至其他reader。证据：[Claude顺序审计](evidence/claude-build-order-audit/report.md)、[8个实际执行器RED/GREEN控制](evidence/build-order-green-v2/build-order.json)、[全134条静态资源断言](evidence/build-order-static134.log)、[审计契约反例](evidence/build-order-resource-contract-v2.log)。这些控制覆盖陈旧/缺失构建物、失败构建、撤销构建屏障；最终冷启动前缀还运行了实际构建和消费者。

为避免仅凭Git文件名推断同一工作负载，还对冷启动构建后的目标副本与已审核控制器逐文件比较：[字节核对](evidence/ordered-runtime-byte-comparison.json)中893个源码文件、208个测试文件、105个脚本全部相同；main/dist的3557个文件中唯一差异为生成的full-suite-build-binding.json。此比较不声称不同路径和不同Git提交的完整身份JSON相同。

[最终数据自检](evidence/final-evidence-selfcheck.json)逐一核对268个成功状态、原配置显式或默认超时，以及两边相同的58个拒绝探测ID。串行quorum日志的73个名称与当前注册表一致；并行父进程实际核对所有子进程的ID、callback摘要和完整覆盖后输出73条通过标记。成功分片的临时明细按原实现清理，因此最终这次GREEN日志保留的是核验后的总标记，不能声称它逐条打印并保存了73条分片明细；此前交错对照的独立分片证据仍保留。

关于此前的“DONE仍0/2未闭环”，这里修正判断：仅看资格比例不足以确认重复执行。实际根命令清单中，DONE的build/full-suite没有上述合格命令的精确重合，不能通过放宽副作用规则来制造复用。已证明的是确实适用的相同命令交集，以及当前根注册命令被重复消费的场景；根配置内所有聚合套件的叶子重叠并未因此自动消除。

不能丢掉的反证与限制：

- 早期短命令复用4.55→6.84秒，早期同范围自动拆分0.102→0.555秒，均变慢；本轮73条重型套件拆分的正收益不改变这两个反例。历史原包的复用、容量和全量负结果随附，不能只筛成功记录。
- 当前第一轮完整候选为132/134：资源审计仍匹配旧quorum argv，隔离副本漏带packages/lab/dist。修正准确命令匹配、增加10条逐项撤销屏障反例，并补齐Lab构建物后才启动新的完整对照。原记录1658.165秒及取消后续RED的原因保留在[原始完整尝试](evidence/full-final-comparison/results.json)和[取消记录](evidence/full-final-comparison/cancellation.json)，不参与成功全量收益计算。
- 第二轮已准备构建物的GREEN在126条通过、无失败时主动停止，因为构建顺序缺陷使其不能证明最终方案。其事件和[取消原因](evidence/full-complete-comparison/green-cancellation.json)完整保留；同轮已完成且顺序有效的RED134/134继续作为基准，仅用新的完整GREEN配对。第一次新副本因错误跟随浮动main，命令预检即拒绝，未启动测试；[拒绝日志](evidence/ordered-unpinned-baseline-refused.log)保留，冻结工具现固定CF。
- 第一轮真实根命令复用的三组已完成结果分别为RED271.233秒/2次，GREEN125.328秒/1次、137.940秒/1次；最后RED在180秒上限被终止，未完成配对。失败原日志保留。失败处的末尾验收用例单独复跑3次通过，不足以追溯证明原来每个分支的状态；不把有失败的初次系列写成全数稳定通过。
- 审查评分oracle在19/20个输出之后写出，原预注册只有可变文件时间记录，且RED先于GREEN。V2修复真实owner/全部20个身份的验证、Python优化模式绕过及评分来源；不能追溯改变实验设计。8/8只针对这一个公开有限夹具，不是生产召回率或39.6% Story提速。
- 51分钟RED只保留原错误，未捕获所有执行后分支。之后用原生产谓词与原夹具复查证明“过期租约足以导致拒绝”；不能声称它是当时唯一的失败原因。当前复查还依赖原Lab worker路径存在，其他就绪事实是今天重新探测。见[因果复查](evidence/long-causality-recheck/result.json)及Claude审计第3节。
- 审计N8/N9未被改写为已修复：PGID回收竞态、独立启动器在OS不交付close时无内部退出上限，仍为未复现残余风险。Claude在当前协作式Node子进程模型下未找到可执行反例，真实失败/INT/TERM控制确认清理所属进程；不覆盖逃逸进程组或内核不可中断进程。详见[审计处置](evidence/claude-evidence-repair-addendum/report.md)第4节。
- 同机其他工作负载可争用CPU和磁盘，worktree隔离不隔离硬件。没有终止其他任务。绝对耗时有波动；完整对照不是生产Story的p50/p95，也不是部署后的保证。

身份记录必须区分：早期20次审查校准为`6eb84016…`、1659文件；中间独立核心审计为`046d27c4…`、1640文件；补齐19个Lab扩展文件后的固定控制器入口为`48454fc7…`、1659文件。后者与owner的完整JSON核对，不能追溯重标前两次身份，也不能代表后来重建的50ca目标副本的全部元数据。[旧副本差异](evidence/complete-runtime-delta.json)中唯一main/dist差异为构建生成的full-suite绑定记录；之后50ca改变配置和实验契约/文档，保留同一生产/测试脚本，另有[完整运行清单](evidence/full-ordered-comparison/manifest.json)。冻结副本各自独立，未在运行中替换源码。

Claude CLI对核心机制、身份/审查/51分钟证据、证据修正与第二次rename故障、真实根命令及资源声明分别独立核验；最后的[完成审计](evidence/claude-completion-audit/report.md)核对本报告与完整134条原始数据。原始审核者文本中的两处非结论性措辞更正见[审计阅读更正](evidence/audit-reading-errata.md)，不覆盖其原报告。

主分支只读核验记录见[main核对](evidence/main-final-audit.json)和[并行任务变更记录](evidence/parallel-main-movement.json)。本任务没有main集成、版本升级或push；但不能写成main一直没变化：期间main通过另一项Lab b-e40f-convergence-20260909的提交推进到04e66fdbaeae、版本0.3.285。本Lab候选不是main的祖先；原始22个文件哈希及开工Git状态仍相同。本实验固定使用CF基线0.3.284，未追随浮动main。提交列表见[Lab本地提交](evidence/repair-commits.txt)。

交付包包含相对路径报告、全部明确结论/工具输出/失败日志、原始计时、源码补丁、增量Git bundle和逐文件SHA-256。Claude私有思考块和本地签名私钥不随包分发。补丁从CF基线重建后逐个核对所有候选跟踪文件，再解包检查整个包。复现要求见包内README及Lab `experiments/five-item-proof/README.md`；冻结执行前先准备main、utils、graph、lab构建物，不能与正在使用该dist的实验同时重建。

[清理后重放验证](evidence/sanitized-review-replay.json)使用打包器的实际日志清理函数，在新临时副本重新计算审查评分；完整评分对象与原结果相同，21个参与者、97条发现和全部27个身份拒绝控制保留。清理没有改变实验结果，也没有改变其探索性边界。

包外package-verification.json记录最终归档SHA-256、补丁重建和解包逐文件校验；包内verification.json、SHA256SUMS及transcript-verification.json分别记录源码、文件和审核日志的校验。未用于任何结论的大型探索性CPU profile不随包重复分发，其哈希/大小/排除理由被记录，原机文件仍保留。

Claude最终补审已完成：[补审报告](evidence/claude-completion-addendum/report.md)和[独立计算结果](evidence/claude-completion-addendum/addendum-findings.json)逐项核实了首次完成审计未覆盖的资源分类与约束、13项变异探测、8组构建顺序控制、真实复用子进程计数、22个原文件哈希及73条断言名称。补审未发现这些限定范围内的适用缺陷；其中writer名单由策略函数与契约断言共同约束，不能仅保留策略函数而删除契约。

补审同时纠正首次审计的一项推断：两边峰值均为4，不能推导差异仅来自内部并发参数；实际有26条资源声明改变，平均并行命令数（命令耗时之和/墙钟耗时）为1.559→2.325。仍然只能报告单组完整验证的观察差值。首次审计的原文完整保留，以补审的具体更正为准。

为使审计对象可追溯，[实际受审正文](evidence/report-as-audited.md)保留了补审前报告的全部字节；当前报告只在该正文后追加本说明，未改动受审的数据、结论或候选代码。追加记录见[报告版本校验](evidence/final-report-provenance.json)。最终归档的实际校验结果在包外package-verification.json及包内verification.json、SHA256SUMS、transcript-verification.json中，不能把审计发生时尚未创建的归档称为已由Claude亲自解包验证。
