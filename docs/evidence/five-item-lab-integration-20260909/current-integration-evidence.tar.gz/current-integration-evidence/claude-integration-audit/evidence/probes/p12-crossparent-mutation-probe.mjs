import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {execSync} from 'node:child_process';
const root='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-audit-lm4icvth/repo';
const {verifyResourceAudit,commandFor}=await import(root+'/experiments/five-item-proof/resource-audit-policy.mjs');
const config=JSON.parse(readFileSync(root+'/proof-or-stop.config.json'));
const audit=JSON.parse(readFileSync(root+'/experiments/five-item-proof/resource-audit.json'));
const hist=JSON.parse(execSync('git show 50ca0454dc8d6e2f44aa34918493da7415ee2c78:proof-or-stop.config.json',{cwd:root,encoding:'utf8',maxBuffer:1e8}));
const argvOf=c=>[c.command,...(c.args??[])].join(' ');
const QUORUM='node packages/main/dist/tasks/quorum-submit-smoke.js --jobs=2';
const histQuorum=hist.validate.commands.find(c=>argvOf(c).includes('quorum-submit-smoke.js'));
const report=[];
const probe=(name,fn)=>{try{fn();report.push([name,'GUARD-FIRED']);}catch(e){report.push([name,'NOT-CAUGHT: '+String(e.message).slice(0,140)]);}};

// Baseline must pass
const base=verifyResourceAudit(config,audit);
console.log('baseline summary:',JSON.stringify(base));

// P-A: re-import the historical monolithic prototype resource declaration onto the quorum row
probe('A: import old prototype 5-claim quorum declaration',()=>{
  const m=structuredClone(config);
  commandFor(m,QUORUM).resources=structuredClone(histQuorum.resources);
  assert.throws(()=>verifyResourceAudit(m,audit),/RESOURCE_AUDIT|DRIFT|INVALID|WITHDRAWN/);
});
// P-B: revert quorum jobs=2 -> jobs=4 (old prototype timing config)
probe('B: revert quorum --jobs=2 to --jobs=4',()=>{
  const m=structuredClone(config);
  const c=commandFor(m,QUORUM); c.args=c.args.map(a=>a==='--jobs=2'?'--jobs=4':a);
  assert.throws(()=>verifyResourceAudit(m,audit),/RESOURCE_AUDIT|DRIFT|COMMAND/);
});
// P-C: silently downgrade an audited writer's exclusive barrier to shared
probe('C: downgrade writer exclusive barrier to shared',()=>{
  const m=structuredClone(config);
  const c=commandFor(m,'node packages/main/dist/tasks/command-catalog-smoke.js');
  c.resources=c.resources.map(r=>r.key==='.proof-or-stop/runtime/validate-plan-barrier'?{...r,access:'shared'}:r);
  assert.throws(()=>verifyResourceAudit(m,audit),/RESOURCE_AUDIT/);
});
// P-D: delete the superseded quorum review entirely from the audit
probe('D: delete supersededQuorumReview record',()=>{
  const m=structuredClone(audit); m.integration.supersededQuorumReview=[];
  // resource-audit-contract asserts length===1 directly
  assert.equal(m.integration.supersededQuorumReview.length,1);
});
// P-E: remove a whole audited command from config
probe('E: remove an audited command from config',()=>{
  const m=structuredClone(config);
  const i=m.validate.commands.findIndex(c=>argvOf(c)==='node packages/main/dist/tasks/command-catalog-smoke.js');
  m.validate.commands.splice(i,1);
  assert.throws(()=>verifyResourceAudit(m,audit),/AUDITED_COMMAND_DRIFT|RESOURCE_AUDIT/);
});
for(const [n,r] of report)console.log((r==='GUARD-FIRED'?'PASS  ':'FINDING ')+n+' -> '+r);
