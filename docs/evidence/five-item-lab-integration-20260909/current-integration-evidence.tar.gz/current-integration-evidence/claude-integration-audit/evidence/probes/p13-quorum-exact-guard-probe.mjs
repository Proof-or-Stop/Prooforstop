import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync} from 'node:fs';
import {join}from 'node:path';import {tmpdir}from 'node:os';import {execSync} from 'node:child_process';
const R='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-audit-lm4icvth/repo';
const {resolveValidationPlanEntries,VALIDATE_PLAN_BARRIER_CLAIM_CLASS:BC,VALIDATE_PLAN_BARRIER_CLAIM_KEY:BK}=await import(R+'/packages/main/dist/core/validation-executor.js');
const {configuredValidationCommands}=await import(R+'/packages/main/dist/handlers/verifier.js');
const REPO_READ={class:'git-common-dir',key:'.',access:'shared'};
const isBarrier=(c,a)=>c.class===BC&&c.key===BK&&c.access===a;
// verbatim predicate from packages/main/tests/validate-resource-claims.test.mjs:265-275
const exactDeclaration=(entry)=>entry.command==='node'
 && JSON.stringify(entry.args)===JSON.stringify(['packages/main/dist/tasks/quorum-submit-smoke.js','--jobs=2'])
 && JSON.stringify(entry.resources)===JSON.stringify([REPO_READ]);
const hist=JSON.parse(execSync('git show 50ca0454dc8d6e2f44aa34918493da7415ee2c78:proof-or-stop.config.json',{cwd:R,encoding:'utf8',maxBuffer:1e8}));
const histQuorum=hist.validate.commands.find(c=>[c.command,...(c.args??[])].join(' ').includes('quorum-submit-smoke.js'));
const cfg=JSON.parse(readFileSync(R+'/proof-or-stop.config.json','utf8'));
const isQ=c=>c.command==='node'&&Array.isArray(c.args)&&c.args.includes('packages/main/dist/tasks/quorum-submit-smoke.js');
function evalConfig(label,mutate){
 const root=mkdtempSync(join(tmpdir(),'quorum-guard-'));
 const m=structuredClone(cfg); if(mutate) mutate(m.validate.commands.find(isQ));
 writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify(m));
 const configured=configuredValidationCommands(root);
 const rows=configured.filter(isQ);
 const guardOk = rows.length===1 && exactDeclaration(rows[0]);
 let resolvedOk=false;
 if(rows.length===1){const [r]=resolveValidationPlanEntries({provider:'p',commands:[rows[0]]});
  resolvedOk = r.exclusiveByDefault===false && r.resources.length===2 && isBarrier(r.resources[0],'shared')
   && r.resources[1].class===REPO_READ.class && r.resources[1].key===REPO_READ.key && r.resources[1].access===REPO_READ.access;}
 console.log(`${guardOk&&resolvedOk?'GUARD-PASSES':'GUARD-REJECTS'}  ${label}`);
 console.log(`    rows=${rows.length} exactDeclaration=${rows.length===1?exactDeclaration(rows[0]):'n/a'} resolvedShared=${resolvedOk} args=${rows.length===1?JSON.stringify(rows[0].args):'n/a'}`);
 return guardOk&&resolvedOk;
}
console.log('--- control ---');
assert.equal(evalConfig('CONTROL: unmutated candidate config'),true,'candidate config must satisfy the B-e40f exact quorum guard');
console.log('--- cross-parent mutations ---');
assert.equal(evalConfig('A: import historical prototype 5-claim declaration',q=>{q.resources=structuredClone(histQuorum.resources);}),false);
assert.equal(evalConfig('B: revert --jobs=2 to historical --jobs=4',q=>{q.args=q.args.map(a=>a==='--jobs=2'?'--jobs=4':a);}),false);
assert.equal(evalConfig('C: upgrade raw git claim to exclusive',q=>{q.resources=[{...REPO_READ,access:'exclusive'}];}),false);
assert.equal(evalConfig('D: append an extra fixed-path claim',q=>{q.resources=[REPO_READ,{class:'fixed-path',key:'packages/main/dist',access:'shared'}];}),false);
console.log('\nALL CROSS-PARENT QUORUM MUTATIONS REJECTED BY THE EXACT DECLARATION GUARD');
