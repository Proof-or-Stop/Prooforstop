import {readFileSync} from 'node:fs';
const root='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-audit-lm4icvth/repo';
const L=async p=>import(root+'/packages/main/dist/'+p);
const {resolveValidationPlanEntries,VALIDATE_PLAN_BARRIER_CLAIM_CLASS:BC,VALIDATE_PLAN_BARRIER_CLAIM_KEY:BK}=await L('core/validation-executor.js');
const {canonicalizeEntries}=await L('core/keyed-scheduler.js');
const {configuredValidationCommands}=await L('handlers/verifier.js');
const audit=JSON.parse(readFileSync(root+'/experiments/five-item-proof/resource-audit.json','utf8'));
const argvOf=c=>[c.command,...(c.args??[])].join(' ');
const cmds=configuredValidationCommands(root);
const ents=canonicalizeEntries(resolveValidationPlanEntries({provider:'p',commands:cmds}),root);
const eff=new Map(cmds.map((c,i)=>[argvOf(c),ents[i]]));
const excl=e=>e.resources.some(c=>c.class===BC&&c.key===BK&&c.access==='exclusive');
const shared=audit.entries.filter(e=>e.recommendation==='safe-to-declare-shared');
console.log('safe-to-declare-shared reviews:',shared.length);
const buckets={effectiveReader:[],localWriter:[],unmatched:[]};
for(const e of shared){const x=eff.get(e.argv);
 if(!x){buckets.unmatched.push(e.argv);continue;}
 (excl(x)?buckets.localWriter:buckets.effectiveReader).push(e.argv);}
console.log('effective readers (no exclusive barrier):',buckets.effectiveReader.length);
console.log('exclusive local barrier holders       :',buckets.localWriter.length);
buckets.localWriter.forEach(a=>console.log('   EXCL:',a));
console.log('unmatched:',buckets.unmatched);
// total exclusive barrier holders across all 135
const allExcl=cmds.filter((c,i)=>excl(ents[i])).map(argvOf);
console.log('\nTOTAL routine commands with exclusive plan barrier:',allExcl.length);
allExcl.forEach(a=>console.log('   ',a));
// first configured row = precheck?
console.log('\nfirst three configured rows:',cmds.slice(0,3).map(argvOf));
console.log('row0 exclusive barrier:',excl(ents[0]));
