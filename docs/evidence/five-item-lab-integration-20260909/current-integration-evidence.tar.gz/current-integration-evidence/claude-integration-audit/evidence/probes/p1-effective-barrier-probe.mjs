import {readFileSync} from 'node:fs';
const root='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-audit-lm4icvth/repo';
const L=async p=>import(root+'/packages/main/dist/'+p);
const {resolveValidationCommandResources,resolveValidationPlanEntries,VALIDATE_PLAN_BARRIER_CLAIM_CLASS,VALIDATE_PLAN_BARRIER_CLAIM_KEY}=await L('core/validation-executor.js');
const {canonicalizeEntries,claimsConflict}=await L('core/keyed-scheduler.js');
const {configuredValidationCommands}=await L('handlers/verifier.js');
const cfg=JSON.parse(readFileSync(root+'/proof-or-stop.config.json','utf8'));
const argvOf=c=>[c.command,...(c.args??[])].join(' ');
const isBarrier=(c,a)=>c.class===VALIDATE_PLAN_BARRIER_CLAIM_CLASS&&c.key===VALIDATE_PLAN_BARRIER_CLAIM_KEY&&c.access===a;

const commands=configuredValidationCommands(root);
const entries=canonicalizeEntries(resolveValidationPlanEntries({provider:'probe',commands}),root);
const byArgv=new Map(commands.map((c,i)=>[argvOf(c),entries[i]]));
console.log('routine commands:',commands.length);

// DONE commands
const done=cfg.doneRequiredCommands;
const doneEntries=canonicalizeEntries(resolveValidationPlanEntries({provider:'done',commands:done}),root);
console.log('DONE commands:',done.length,'all declare resources:',done.every(c=>Array.isArray(c.resources)&&c.resources.length>0));

const QUORUM='node packages/main/dist/tasks/quorum-submit-smoke.js --jobs=2';
const BUILD='npm --prefix packages/main run build';
const q=byArgv.get(QUORUM), b=byArgv.get(BUILD);
console.log('\n=== raw declared claims ===');
console.log('quorum raw :',JSON.stringify(cfg.validate.commands.find(c=>argvOf(c)===QUORUM).resources));
console.log('build  raw :',JSON.stringify(cfg.validate.commands.find(c=>argvOf(c)===BUILD).resources));
console.log('\n=== effective (resolved) claims ===');
console.log('quorum eff :',JSON.stringify(q.resources));
console.log('build  eff :',JSON.stringify(b.resources));
console.log('\nquorum has shared plan barrier:',q.resources.some(c=>isBarrier(c,'shared')));
console.log('build  has exclusive plan barrier:',b.resources.some(c=>isBarrier(c,'exclusive')));
console.log('CONFLICT quorum<->build :',claimsConflict(q,b),'/ reverse:',claimsConflict(b,q));

// Every command must conflict with the local build
const nonConflicting=entries.filter(e=>e.name!==b.name&&!claimsConflict(e,b));
console.log('\nroutine commands that do NOT conflict with local build:',nonConflicting.length,nonConflicting.map(e=>e.name).slice(0,5));
const doneNon=doneEntries.filter(e=>!claimsConflict(e,b)&&e.name!==b.name);
console.log('DONE entries that do NOT conflict with local build:',doneNon.length);

// Git-only raw claim synthetic control
const synth={label:'synthetic-git-only',command:'node',args:['synthetic.js'],resources:[{class:'git-common-dir',key:'.',access:'shared'}]};
const se=canonicalizeEntries(resolveValidationPlanEntries({provider:'p',commands:[synth,cfg.validate.commands.find(c=>argvOf(c)===BUILD)]}),root);
console.log('\nsynthetic raw-Git-only vs build conflict:',claimsConflict(se[0],se[1]));
console.log('synthetic effective:',JSON.stringify(se[0].resources));
