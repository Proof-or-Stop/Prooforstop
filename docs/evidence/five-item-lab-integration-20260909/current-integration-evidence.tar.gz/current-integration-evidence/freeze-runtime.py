import pathlib,subprocess,tempfile,json,sys
lab=pathlib.Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-integration-20260909')
art=pathlib.Path(__file__).parent
label=sys.argv[1]
def run(args, cwd=None): return subprocess.check_output(args,cwd=cwd,text=True).strip()
head=run(['git','rev-parse',sys.argv[2] if len(sys.argv)>2 else 'HEAD'],lab); main=run(['git','rev-parse','main'],lab)
root=pathlib.Path(tempfile.mkdtemp(prefix='pos-frozen-'+label+'-')).resolve()/'repo'
run(['git','clone','--quiet','--shared','--no-checkout',str(lab),str(root)])
run(['git','checkout','--quiet','--detach',head],root)
run(['git','branch','--force','main',main],root)
paths=['node_modules']
for pkg in (lab/'packages').iterdir():
 if pkg.is_dir():
  paths += [str(q.relative_to(lab)) for q in [pkg/'dist',pkg/'node_modules'] if q.exists()]
for rel in paths:
 dst=root/rel; dst.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run(['cp','-cR',str(lab/rel),str(dst)],check=True)
info={'path':str(root),'head':head,'main':main,'independentWritableDist':True,'copyMethod':'APFS clone-on-write; read-only Git object alternates; npm ci locked dependency layout','copiedPaths':paths}
status=run(['git','status','--porcelain'],root)
assert not status,status
(art/(label+'-runtime.json')).write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps(info))
