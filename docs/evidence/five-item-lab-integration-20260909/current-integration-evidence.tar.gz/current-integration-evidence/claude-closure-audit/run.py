import pathlib,subprocess,time,json,sys
out=pathlib.Path(__file__).parent
start=time.time()
with (out/'result.json').open('w') as log,(out/'stderr.log').open('w') as err:
 p=subprocess.run(['claude','-p','--output-format','json','--no-session-persistence','--permission-mode','dontAsk','--allowedTools','Bash,Read,Write,Glob,Grep','--tools','Bash,Read,Write,Glob,Grep','--add-dir',sys.argv[1]],cwd=out,input=(out/'prompt.txt').read_text(),text=True,stdout=log,stderr=err)
(out/'execution.json').write_text(json.dumps({'startEpoch':start,'endEpoch':time.time(),'exitCode':p.returncode,'runtime':sys.argv[1]},indent=2)+'\n')
sys.exit(p.returncode)
