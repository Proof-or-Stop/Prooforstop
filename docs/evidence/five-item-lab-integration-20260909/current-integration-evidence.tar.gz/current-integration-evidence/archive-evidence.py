from pathlib import Path
import json,hashlib,shutil,tarfile,tempfile,os
art=Path(__file__).resolve().parent
lab=Path('/Users/jek/Documents/GitHub/Prooforstop/.worktrees/Lab-five-item-integration-20260909')
target=lab/'docs/evidence/five-item-lab-integration-20260909/current-integration-evidence.tar.gz'
assert (art/'claude-final-disposition/report.md').is_file()
assert '0 RED / 26 GREEN' in (art/'final-registration-derivation-green.log').read_text()
assert (art/'final-failed-validation/results.json').is_file()
stage=Path(tempfile.mkdtemp(prefix='pos-current-evidence-'))
payload=stage/'current-integration-evidence';payload.mkdir()
transforms=[];excluded=[]
DROP=object()
def clean(x):
 if isinstance(x,dict):
  if x.get('type') in ['thinking','redacted_thinking','redacted-thinking','thinking_delta','signature_delta']:return DROP
  if x.get('type')=='system' and x.get('subtype')=='thinking_tokens':return DROP
  return {k:c for k,v in x.items() if (c:=clean(v)) is not DROP}
 if isinstance(x,list):return [c for v in x if (c:=clean(v)) is not DROP]
 return x
roots=[x for x in art.iterdir() if x.is_file() or (x.is_dir() and 'temp' not in x.name and x.name!='__pycache__')]
for entry in sorted(roots):
 files=[entry] if entry.is_file() else sorted(entry.rglob('*'))
 for source in files:
  if not source.is_file():continue
  rel=source.relative_to(art)
  if source.is_symlink() or any(part in ['.git','node_modules','__pycache__'] for part in rel.parts) or source.suffix in ['.key','.pem','.cpuprofile','.gz','.bundle','.patch'] or source.name in ['.DS_Store','current-archive-verification.json','native-finish.log','report.md','lab-release-notes.md','main-pending-files.json']:
   excluded.append(str(rel));continue
  dest=payload/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  original=source.read_bytes();data=original
  if source.suffix=='.json':
   try:
    value=json.loads(original);filtered=clean(value)
    if filtered!=value:data=(json.dumps(None if filtered is DROP else filtered,ensure_ascii=False,indent=2)+'\n').encode()
   except (UnicodeError,json.JSONDecodeError):pass
  elif source.suffix=='.jsonl':
   try:
    values=[json.loads(line) for line in original.decode().splitlines() if line.strip()]
    filtered=[c for v in values if (c:=clean(v)) is not DROP]
    if filtered!=values:data=('\n'.join(json.dumps(v,ensure_ascii=False) for v in filtered)+'\n').encode()
   except (UnicodeError,json.JSONDecodeError):pass
  dest.write_bytes(data)
  if data!=original:transforms.append({'path':str(rel),'sourceSha256':hashlib.sha256(original).hexdigest(),'distributedSha256':hashlib.sha256(data).hexdigest(),'reason':'Remove private reasoning blocks; preserve explicit reports and tool evidence'})
(payload/'archive-policy.json').write_text(json.dumps({'excluded':excluded,'transforms':transforms,'excludedDirectories':'All temporary execution roots, dependency trees and Git/key material. Historical and initial archives are separately preserved byte-identically.','scope':'Current integration evidence; failed and cancelled trials remain identified. Native records will be distributed after native verification without exporting the local HMAC key.'},indent=2)+'\n')
manifest=[]
for f in sorted(payload.rglob('*')):
 if f.is_file():manifest.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(payload)))
(payload/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
with tarfile.open(target,'w:gz') as tar:tar.add(payload,arcname=payload.name)
extract=stage/'verify';extract.mkdir()
with tarfile.open(target) as tar:
 for member in tar.getmembers():
  assert not member.issym() and not member.islnk() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
 tar.extractall(extract) # Every member was checked above; Python 3.9 lacks filter=.
restored=extract/payload.name
for line in (restored/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert hashlib.sha256((restored/name).read_bytes()).hexdigest()==digest,name
result={'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'payloadFilesVerified':len(manifest),'bytes':target.stat().st_size,'allHashesVerified':True,'secretKeyMaterialPackaged':False,'privateReasoningTransforms':len(transforms)}
(art/'current-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n')
(target.parent/'current-integration-evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));shutil.rmtree(stage)
