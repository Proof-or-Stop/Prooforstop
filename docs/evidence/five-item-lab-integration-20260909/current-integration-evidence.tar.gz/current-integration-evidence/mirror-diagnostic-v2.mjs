import {copyFileSync,cpSync,existsSync,lstatSync,mkdirSync,mkdtempSync,readFileSync,readlinkSync,readdirSync,realpathSync,rmSync,statSync,symlinkSync,writeFileSync} from 'node:fs';
import {execFileSync,spawnSync} from 'node:child_process';import {join,resolve,dirname,basename} from 'node:path';import {tmpdir} from 'node:os';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const repoRoot=process.argv[2],out=process.argv[3];const sha256=b=>createHash('sha256').update(b).digest('hex');
function makeMirror(prefix, { writableFiles = [], materializeDirs = [], copyDirs = [], copyTracked = false, copyTrees = [] } = {}) {
  const root = mkdtempSync(join(tmpdir(), prefix));
  const mustBeReal = new Set();
  const copied = new Set(copyDirs);
  const tracked = new Set(copyTracked ? gitRead(repoRoot,['ls-files','-z']).toString('utf8').split('\0').filter(Boolean) : []);
  const wholeTrees = new Set(copyTrees);
  const addAncestors = (rel) => {
    const parts = rel.split('/');
    for (let i = 1; i < parts.length; i += 1) mustBeReal.add(parts.slice(0, i).join('/'));
  };
  for (const rel of [...writableFiles,...tracked,...copyTrees]) addAncestors(rel);
  for (const rel of [...materializeDirs, ...copyDirs]) {
    addAncestors(rel);
    mustBeReal.add(rel);
  }
  const skip = new Set(writableFiles);
  const walk = (relDir) => {
    const inCopiedDir = copied.has(relDir);
    for (const entry of readdirSync(relDir === '' ? repoRoot : join(repoRoot, relDir))) {
      const childRel = relDir === '' ? entry : `${relDir}/${entry}`;
      if (childRel === '.git' || skip.has(childRel)) continue;
      const src = join(repoRoot, childRel);
      const dest = join(root, childRel);
      if (wholeTrees.has(childRel)) { cpSync(src,dest,{recursive:true,dereference:true}); continue; }
      if (tracked.has(childRel)) {
        if (lstatSync(src).isSymbolicLink()) symlinkSync(readlinkSync(src),dest);
        else copyFileSync(src,dest);
        continue;
      }
      if (mustBeReal.has(childRel)) {
        mkdirSync(dest);
        walk(childRel);
        continue;
      }
      if (inCopiedDir && !statSync(src).isDirectory()) {
        copyFileSync(src, dest);
        continue;
      }
      symlinkSync(src, dest);
    }
  };
  walk('');
  initializePrivateGit(root, repoRoot);
  return root;
}

function initializePrivateGit(root, sourceRoot) {
  const source = gitIdentity(sourceRoot);
  const format = gitText(sourceRoot, ['rev-parse', '--show-object-format']);
  gitRead(root, ['init', '--quiet', '--template=', `--object-format=${format}`]);
  const admin = join(root, '.git');
  const objects = realpathSync(gitText(sourceRoot, ['rev-parse', '--path-format=absolute', '--git-path', 'objects']));
  writeFileSync(join(admin, 'objects', 'info', 'alternates'), `${objects}\n`);
  // for-each-ref includes packed refs without linking either refs or packed-refs.
  const refs = gitText(sourceRoot, ['for-each-ref', '--format=%(objectname) %(refname)']);
  if (refs) gitRead(root, ['update-ref', '--stdin'], refs.split('\n').map(line => {
    const [object, ref] = line.split(' ');
    return `update ${ref} ${object}\n`;
  }).join(''));
  copyFileSync(join(source.admin, 'HEAD'), join(admin, 'HEAD'));
  copyFileSync(source.index, join(admin, 'index'));
  // A split index refers to a sharedindex.<hash> companion, which must also be
  // PRIVATE. Its bytes are copied, never shared or converted via the real index.
  const shared = gitText(sourceRoot, ['rev-parse', '--path-format=absolute', '--shared-index-path']);
  if (shared) copyFileSync(resolve(sourceRoot, shared), join(admin, basename(shared)));
}

const localGitEnvironment = (inherited = process.env) => {
  const env = { ...inherited, GIT_OPTIONAL_LOCKS: '0' };
  for (const key of ['GIT_DIR', 'GIT_COMMON_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE',
    'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[key];
  return env;
};
const gitRead = (root, args, input) => execFileSync('git', ['--no-optional-locks', ...args], {
  cwd: root, env: localGitEnvironment(), maxBuffer: 64 * 1024 * 1024,
  ...(input !== undefined ? { input } : {}),
});
const gitText = (root, args) => gitRead(root, args).toString('utf8').trim();
function gitIdentity(root) {
  return {
    admin: realpathSync(gitText(root, ['rev-parse', '--absolute-git-dir'])),
    common: realpathSync(gitText(root, ['rev-parse', '--path-format=absolute', '--git-common-dir'])),
    index: realpathSync(gitText(root, ['rev-parse', '--path-format=absolute', '--git-path', 'index'])),
  };
}
function gitSnapshot(root) {
  const identity = gitIdentity(root);
  return { ...identity, head: gitText(root, ['rev-parse', 'HEAD']),
    indexDigest: sha256(readFileSync(identity.index)),
    stagesDigest: sha256(gitRead(root, ['ls-files', '--stage', '-z'])),
  };
}
function requirePrivateGit(mirror, source) {
  const actual = gitIdentity(mirror);
  assert.notEqual(actual.admin, source.admin, 'mirror must have private Git admin, not the real repository .git');
  assert.notEqual(actual.common, source.common, 'mirror must have private Git refs/config, not a shared common directory');
  assert.notEqual(actual.index, source.index, 'mirror must have a private Git index');
  for (const path of Object.values(actual)) assert.ok(path.startsWith(`${realpathSync(mirror)}/`), 'Git administration must stay inside the private mirror');
  return actual;
}


const mirror=makeMirror('integration-mirror-real-diagnostic-',{copyTracked:true,copyTrees:['packages/main/dist','packages/utils/dist','packages/lab/dist'],copyDirs:['packages/main/tests/red'],materializeDirs:['packages/main/dist/tasks']});
try{for(const [name,args] of [['direct-list',['packages/main/dist/tasks/quorum-submit-smoke.js','--list-cases=json']],['inventory',['packages/main/tests/red/red-B-e40f-quorum-submit-harness.mjs','--case=inventory-bijection']],['ledger',['packages/main/tests/red/red-bfe8f-ledger-runtime-integrity.mjs']]]){const r=spawnSync(process.execPath,['--preserve-symlinks-main',join(mirror,args[0]),...args.slice(1)],{cwd:mirror,encoding:'utf8',env:localGitEnvironment(),timeout:90000});writeFileSync(join(out,'mirror-v2-'+name+'.log'),'EXIT '+r.status+'\n'+r.stdout+'\n'+r.stderr);console.log(name,r.status);}}finally{rmSync(mirror,{recursive:true,force:true});}
