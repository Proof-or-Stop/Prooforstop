from pathlib import Path
import json,subprocess
root=Path.cwd();base='cf21df09c273074d7aa3227a5f436c6f5badf47a';old='50ca0454dc8d6e2f44aa34918493da7415ee2c78';current='04e66fdbaeaeeb540a80c9f8e16085a5ee468f5a'
def load(ref):return json.loads(subprocess.check_output(['git','show',ref+':proof-or-stop.config.json']))
b,o,m=map(load,[base,old,current])
key=lambda c:(c['command'],*(a for a in c.get('args',[]) if not a.startswith(('--jobs=','--probe-jobs='))))
argv=lambda c:' '.join([c['command'],*c.get('args',[])])
base_by={key(c):c for c in b['validate']['commands']};old_by={key(c):c for c in o['validate']['commands']}
assert len(base_by)==134 and len(old_by)==134 and len(m['validate']['commands'])==135
conflicts=[]
for c in m['validate']['commands']:
 p=base_by.get(key(c));candidate=old_by.get(key(c))
 if p is None:continue
 for field in set(candidate)|set(p):
  if candidate.get(field)==p.get(field):continue
  if c.get(field)!=p.get(field) and c.get(field)!=candidate.get(field):
   assert key(c)==('node','packages/main/dist/tasks/quorum-submit-smoke.js') and field in ('args','resources'),(key(c),field)
   conflicts.append({'argv':argv(c),'field':field,'resolution':'preserve latest main modular coordinator'})
  elif field in candidate:c[field]=candidate[field]
  else:c.pop(field,None)
for field in set(o['validate'])|set(b['validate']):
 if field=='commands' or o['validate'].get(field)==b['validate'].get(field):continue
 assert m['validate'].get(field)==b['validate'].get(field)
 m['validate'][field]=o['validate'][field]
m['doneRequiredCommands']=o['doneRequiredCommands']
(root/'proof-or-stop.config.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(root/'experiments/five-item-integration/config-migration.json').write_text(json.dumps({'base':base,'historicalCandidate':old,'currentMain':current,'beforeCommands':135,'afterCommands':len(m['validate']['commands']),'retainedMainConflicts':conflicts,'identityKey':'executable plus argv, with only known --jobs and --probe-jobs execution-count arguments excluded'},indent=2)+'\n')
# Preserve the original Claude facts in the historical archive. This is explicitly
# an implementation migration, not a new Claude-authored source audit.
p=root/'experiments/five-item-proof/resource-audit.json';a=json.loads(p.read_text());retired=[e for e in a['entries'] if e['argv']=='node packages/main/dist/tasks/quorum-submit-smoke.js'];assert len(retired)==1
current_by={key(c):i for i,c in enumerate(m['validate']['commands'])}
for e in a['entries']:
 if 'commandIndex' not in e:continue
 e['historicalCommandIndex']=e['commandIndex']
 e['commandIndex']=current_by[key(o['validate']['commands'][e['commandIndex']])]
a['entries']=[e for e in a['entries'] if e not in retired]
a['schema']='lab-resource-integration.v1';a['integration']={'currentMain':current,'supersededQuorumReview':retired,'reason':'Main replaced the monolithic quorum task with an isolated modular coordinator. Its exact jobs=2 and shared Git claim are independently protected by red-B-e40f-lab-convergence.mjs and validate-resource-claims.test.mjs. The historical row is no longer an active source audit.','independentCurrentAudit':'pending'}
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
# Replace brittle old positions in live controls with exact command identities.
writers=[1,3,6,79,80,81,82,83,105,125];writer_argv=[argv(o['validate']['commands'][i]) for i in writers];read_argv=[argv(o['validate']['commands'][i]) for i in [117,118,119,120]]
for filename in ['capacity-config.mjs','resource-config.mjs']:
 p=root/'experiments/five-item-proof'/filename;s=p.read_text();needle="const config=JSON.parse(readFileSync("
 line=next(l for l in s.splitlines() if l.startswith(needle))
 helper="\nconst indexOf = argv => { const matches=config.validate.commands.map((c,i)=>[[c.command,...c.args].join(' '),i]).filter(([key])=>key===argv); assert.equal(matches.length,1,'UNIQUE_COMMAND_REQUIRED: '+argv); return matches[0][1]; };\n"
 s=s.replace(line,line+helper)
 if filename=='capacity-config.mjs':
  s=s.replace('const writers=[1,3,6,40,79,80,81,82,83,105,125];','const writers='+json.dumps(writer_argv)+'.map(indexOf);')
  s=s.replace('entries[117],entries[118]','entries[indexOf('+json.dumps(read_argv[0])+')],entries[indexOf('+json.dumps(read_argv[1])+')]')
  s=s.replace('commands[125].env','commands[indexOf('+json.dumps(argv(o['validate']['commands'][125]))+')].env')
 else:
  s=s.replace('{auditedReaders:21,effectivelySharedReaders:14,supersededReaders:7}','{auditedReaders:20,effectivelySharedReaders:14,supersededReaders:6}')
  s=s.replace('[1,3,6,40,79,80,81,82,83,105,125]',json.dumps(writer_argv)+'.map(indexOf)')
  s=s.replace('const indices=[117,118,119,120];','const indices='+json.dumps(read_argv)+'.map(indexOf);')
  s=s.replace('remainingRoutineWriterBarriers:11','remainingRoutineWriterBarriers:10').replace('not all 134 commands','not all 135 commands').replace('Twenty-one historical source reviews are retained; seven were superseded by explicit local barriers, leaving fourteen effectively shared readers.','Twenty current matching historical source reviews are retained; six are superseded by explicit local barriers, leaving fourteen effectively shared readers. The replaced quorum implementation has separate current main contracts.')
 p.write_text(s)
print('Migrated 135 commands, preserved main quorum; current active historical review rows',len(a['entries']))
