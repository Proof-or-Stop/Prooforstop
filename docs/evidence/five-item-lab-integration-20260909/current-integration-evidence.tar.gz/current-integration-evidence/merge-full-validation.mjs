import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,appendFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const privateTemp=join(import.meta.dirname,'merge-full-validation-temp');mkdirSync(privateTemp,{recursive:true});
for(const key of ['TMPDIR','TMP','TEMP'])process.env[key]=privateTemp;
const art=import.meta.dirname,info=JSON.parse(readFileSync(join(art,'merge-full-runtime.json'))),root=info.path;
const {executeValidationPlan}=await import(root+'/packages/main/dist/core/validation-executor.js');
const {configuredValidationCommands}=await import(root+'/packages/main/dist/handlers/verifier.js');
const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:16*1024*1024}).trim();
const commands=configuredValidationCommands(root);assert.equal(commands.length,141);
const out=join(art,'merge-full-validation');mkdirSync(out,{recursive:true});
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const manifest={runtime:info,tempEnvironment:{TMPDIR:privateTemp,TMP:privateTemp,TEMP:privateTemp},configHash:hash(join(root,'proof-or-stop.config.json')),commandCount:commands.length,commands,scope:'Current integrated candidate, actual executeValidationPlan with all 141 current routine commands and unchanged configured timeouts. Single correctness run under shared host load; not an A/B performance result or Story DONE.',head:git(['rev-parse','HEAD']),statusBefore:git(['status','--short'])};
writeFileSync(join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
const begin=performance.now();let active=0,peak=0,ended=0;
const result=await executeValidationPlan({provider:'lab-five-item-integration',commands},root,manifest.head,undefined,{jobs:2,progress:event=>{
 if(event.type==='command_start'){active++;peak=Math.max(peak,active);}if(event.type==='command_end'){active--;ended++;}
 appendFileSync(join(out,'events.jsonl'),JSON.stringify({atMs:performance.now()-begin,active,...event})+'\n');
 if(event.type==='command_end')console.log(ended+'/'+commands.length,event.commandIndex,event.code,event.elapsedMs);
}});
for(const [i,r] of result.commands.entries())writeFileSync(join(out,String(i).padStart(3,'0')+'.log'),r.output);
const record={head:manifest.head,seconds:(performance.now()-begin)/1000,peak,count:result.commands.length,passed:result.commands.filter(r=>r.code===0&&!r.timedOut).length,failed:result.commands.flatMap((r,i)=>r.code===0&&!r.timedOut?[]:[{index:i,label:r.label,code:r.code,timedOut:r.timedOut}]),statusAfter:git(['status','--short']),result};
writeFileSync(join(out,'results.json'),JSON.stringify(record,null,2)+'\n');
assert.equal(git(['rev-parse','HEAD']),manifest.head);assert.equal(hash(join(root,'proof-or-stop.config.json')),manifest.configHash);assert.equal(record.count,141);assert.equal(record.passed,141,JSON.stringify(record.failed));assert.ok(result.allPass);
console.log('CURRENT_141_INTEGRATION_VALIDATION_GREEN '+JSON.stringify({seconds:record.seconds,passed:record.passed,peak}));
