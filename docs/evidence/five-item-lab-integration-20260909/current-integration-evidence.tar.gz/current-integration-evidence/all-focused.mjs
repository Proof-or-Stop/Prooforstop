import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {join} from 'node:path';
const root=process.argv[2],out=process.argv[3];mkdirSync(out,{recursive:true});const head=()=>execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();const before=head();const results=[];
for(const [i,file] of JSON.parse(readFileSync(join(root,'experiments/five-item-integration/checks.json'))).entries()){
 const dir=join(out,String(i).padStart(2,'0'));mkdirSync(dir,{recursive:true});const t=performance.now();const r=spawnSync(process.execPath,[file],{cwd:root,encoding:'utf8',timeout:180000,maxBuffer:16*1024*1024,env:{...process.env,FIVE_ITEM_PROOF_OUTPUT:dir,CHECKPOINT_TEST_RUNTIME:root}});writeFileSync(join(dir,'stdout.log'),r.stdout??'');writeFileSync(join(dir,'stderr.log'),r.stderr??'');results.push({file,exitCode:r.status,signal:r.signal,error:r.error?.message,seconds:(performance.now()-t)/1000});writeFileSync(join(out,'results.json'),JSON.stringify({before,after:head(),results},null,2));console.log(JSON.stringify(results.at(-1)));}
if(head()!==before||results.some(r=>r.exitCode!==0||r.signal||r.error))process.exitCode=1;
