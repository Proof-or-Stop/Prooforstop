// POSITIVE CONTROL for F-2: prove the net.Server.listen observer used by
// verify-missing-client-no-listener.mjs is actually live. Same observer text,
// same NODE_OPTIONS --import mechanism, but WITH the client present, so the
// graph server DOES listen. If listens.jsonl appears, a non-appearance in the
// negative control is real refusal, not a dead instrument.
import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {existsSync,mkdtempSync,mkdirSync,cpSync,writeFileSync,rmSync,readFileSync} from 'node:fs';
import {join,basename} from 'node:path';
import {tmpdir,homedir} from 'node:os';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const lab='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-verified-audit-9ij8sbbk/repo';
const {StoryStore}=await import(lab+'/packages/main/dist/core/store.js');
const root=mkdtempSync(join(tmpdir(),'graph-listen-positive-'));
try {
 mkdirSync(join(root,'packages'),{recursive:true});cpSync(join(lab,'packages/graph'),join(root,'packages/graph'),{recursive:true});
 writeFileSync(join(root,'proof-or-stop.config.json'),JSON.stringify({scanRoot:'.',rootDir:'src',storyDir:'.proof-or-stop/story/actives'}));
 const store=new StoryStore(root);store.writeStory('B-positive',{storyId:'B-positive',name:'Listen observer positive control',title:'Must listen',description:'Private test fixture',type:'chore',phase:'DEV',priority:'medium',createdAt:new Date().toISOString()});store.writeChecklist('B-positive',{items:[]});
 execFileSync('git',['init','-q'],{cwd:root});
 // assets/app.html deliberately LEFT IN PLACE
 assert.ok(existsSync(join(root,'packages/graph/assets/app.html')),'positive control needs the client present');
 const observer=join(root,'listen-observer.mjs'),listenLog=join(root,'listens.jsonl');
 writeFileSync(observer,`import net from 'node:net';import fs from 'node:fs';const original=net.Server.prototype.listen;net.Server.prototype.listen=function(...args){fs.appendFileSync(${JSON.stringify(listenLog)},JSON.stringify({pid:process.pid})+'\\n');return Reflect.apply(original,this,args);};`);
 const result=spawnSync(process.execPath,[join(lab,'bin/proof-or-stop.js'),'graph','--no-open','--port=0','--root='+root],{cwd:root,encoding:'utf8',timeout:60000,env:{...process.env,NODE_OPTIONS:[process.env.NODE_OPTIONS??'','--import='+JSON.stringify(pathToFileURL(observer).href)].join(' ')}});
 console.log('spawn status=',result.status,'signal=',result.signal);
 console.log('listens.jsonl exists =',existsSync(listenLog));
 if(existsSync(listenLog)) console.log('listen records:',readFileSync(listenLog,'utf8').trim().split('\n').length);
 assert.ok(existsSync(listenLog),'OBSERVER_DEAD: the instrument never recorded a listen even with a working client');
 console.log('LISTEN_OBSERVER_IS_LIVE');
} finally {rmSync(root,{recursive:true,force:true});const cache=join(homedir(),'.cache/proof-or-stop-graph',basename(root)+'-'+createHash('sha256').update(root).digest('hex').slice(0,12));rmSync(cache,{recursive:true,force:true});}
