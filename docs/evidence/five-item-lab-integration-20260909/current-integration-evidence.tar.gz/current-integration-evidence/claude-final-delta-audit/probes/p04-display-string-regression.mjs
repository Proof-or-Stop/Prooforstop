// RED control for item 6: the "same display string, different executable/argv split"
// mutation. PRIOR policy (3b55ae70) must ACCEPT it; CURRENT policy (a3622e02) must REFUSE.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const R='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-verified-audit-9ij8sbbk/repo';
const P='/Users/jek/.codex/artifacts/proof-or-stop-five-item-integration-20260909/claude-final-delta-audit/probes';
const config=JSON.parse(readFileSync(R+'/proof-or-stop.config.json','utf8'));
const reader='node packages/main/dist/tasks/command-catalog-smoke.js';

const mutate=(cfg,commandFor)=>{
  const c=structuredClone(cfg), cmd=commandFor(c,reader);
  const beforeDisplay=[cmd.command,...cmd.args].join(' ');
  cmd.command+=' '+cmd.args.shift();
  const afterDisplay=[cmd.command,...cmd.args].join(' ');
  assert.equal(beforeDisplay,afterDisplay,'the mutation must be display-string-invariant');
  console.log('  mutated row: command='+JSON.stringify(cmd.command)+' args='+JSON.stringify(cmd.args));
  console.log('  display string unchanged:',JSON.stringify(afterDisplay));
  return c;
};

console.log('=== PRIOR policy 3b55ae70 (with its own audit.json) ===');
const prior=await import(P+'/prior-3b55ae70/resource-audit-policy.mjs');
const priorAudit=JSON.parse(readFileSync(P+'/prior-3b55ae70/resource-audit.json','utf8'));
console.log('  baseline (unmutated) summary:',JSON.stringify(prior.verifyResourceAudit(config,priorAudit)));
const priorMutated=mutate(config,prior.commandFor);
let priorResult;
try { priorResult=prior.verifyResourceAudit(priorMutated,priorAudit); console.log('  RESULT: ACCEPTED (no throw) ->',JSON.stringify(priorResult)); }
catch (error) { console.log('  RESULT: refused ->',error.message); }
assert.ok(priorResult!==undefined,'EXPECTED the prior policy to accept the display-string mutation');

console.log('=== CURRENT policy a3622e02 (with current audit.json) ===');
const current=await import(R+'/experiments/five-item-proof/resource-audit-policy.mjs');
const currentAudit=JSON.parse(readFileSync(R+'/experiments/five-item-proof/resource-audit.json','utf8'));
console.log('  baseline (unmutated) summary:',JSON.stringify(current.verifyResourceAudit(config,currentAudit)));
const currentMutated=mutate(config,current.commandFor);
let refused=false;
try { current.verifyResourceAudit(currentMutated,currentAudit); }
catch (error) { refused=true; console.log('  RESULT: REFUSED ->',error.message.split('\n')[0]); }
assert.ok(refused,'EXPECTED the current policy to refuse the display-string mutation');
console.log('DISPLAY_STRING_REGRESSION_CONFIRMED: prior=accepted, current=refused');
