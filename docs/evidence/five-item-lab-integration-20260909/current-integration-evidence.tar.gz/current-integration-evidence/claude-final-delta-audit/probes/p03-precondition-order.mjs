// F-2 ordering proof: with the graph client absent, verify-missing-client-no-listener.mjs
// must fail with PRECONDITION_FAILED and must NOT have performed any fixture mutation
// (no mkdtemp fixture root, no cache dir). The client is a gitignored build output;
// it is moved aside and restored byte-identically here, in a private frozen runtime.
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,renameSync,readdirSync,existsSync} from 'node:fs';
import {tmpdir,homedir} from 'node:os';
import {join} from 'node:path';
const R='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-verified-audit-9ij8sbbk/repo';
const asset=join(R,'packages/graph/assets/app.html');
const aside=join(R,'packages/graph/assets/.app.html.auditor-aside');
const before=createHash('sha256').update(readFileSync(asset)).digest('hex');
const fixturesBefore=readdirSync(tmpdir()).filter(n=>n.startsWith('graph-no-assets-'));
const cacheDir=join(homedir(),'.cache/proof-or-stop-graph');
const cacheBefore=existsSync(cacheDir)?readdirSync(cacheDir):[];
console.log('asset sha256 before =',before);
console.log('pre-existing graph-no-assets- fixture dirs =',fixturesBefore.length);
let out;
renameSync(asset,aside);
try {
  out=execFileSync(process.execPath,[join(R,'packages/graph/scripts/verify-missing-client-no-listener.mjs')],
    {encoding:'utf8',stdio:['ignore','pipe','pipe']});
  console.log('UNEXPECTED exit 0:',out);
} catch (error) {
  console.log('exit status =',error.status);
  const text=(error.stdout??'')+(error.stderr??'');
  console.log('contains PRECONDITION_FAILED =',text.includes('PRECONDITION_FAILED: build graph client first'));
  console.log('contains GRAPH_MISSING_ASSETS_REFUSED_BEFORE_LISTEN =',text.includes('GRAPH_MISSING_ASSETS_REFUSED_BEFORE_LISTEN'));
  console.log('---first 6 lines of output---');
  console.log(text.split('\n').slice(0,6).join('\n'));
} finally {
  renameSync(aside,asset);
}
const after=createHash('sha256').update(readFileSync(asset)).digest('hex');
console.log('asset sha256 after  =',after,'RESTORED =',before===after);
const fixturesAfter=readdirSync(tmpdir()).filter(n=>n.startsWith('graph-no-assets-'));
console.log('NEW fixture roots created by the refused run =',fixturesAfter.filter(n=>!fixturesBefore.includes(n)).length);
const cacheAfter=existsSync(cacheDir)?readdirSync(cacheDir):[];
console.log('NEW graph cache dirs created                 =',cacheAfter.filter(n=>!cacheBefore.includes(n)).length);
console.log('git status (must be empty):');
console.log(execFileSync('git',['status','--porcelain'],{cwd:R,encoding:'utf8'})||'(clean)');
