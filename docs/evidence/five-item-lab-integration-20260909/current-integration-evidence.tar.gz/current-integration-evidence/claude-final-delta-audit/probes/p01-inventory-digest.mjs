// Independent recomputation of the REAL 135-command inventory via the production path.
const R='/var/folders/b1/89qtvzk15r91rzn6hk10g8g00000gn/T/pos-frozen-integration-verified-audit-9ij8sbbk/repo';
const {configuredValidationCommands}=await import(R+'/packages/main/dist/handlers/verifier.js');
const {buildValidationCommandInventory}=await import(R+'/packages/main/dist/core/validation-command-identity.js');
const commands=configuredValidationCommands(R);
const inv=buildValidationCommandInventory({commands});
console.log('configuredValidationCommands length =',commands.length);
console.log('inventory entries              =',inv.entries.length);
console.log('commandSetDigest               =',inv.commandSetDigest);
console.log('warnings mentioning absolute   =',inv.warnings.filter(w=>/absolute/i.test(w)).length);
const keys=inv.entries.map(e=>e.id);
console.log('unique inventory ids           =',new Set(keys).size);
const PIN='63f9234131b7473f03917a37de401db5dcfbab11a38e4b53a2d7c9fa961565d4';
console.log('MATCHES SOURCE PIN             =',inv.commandSetDigest===PIN);
const HIST='b29365c6a2ba5e50d50e05fd12654e505922413117531f37ce76e7716d859653';
console.log('equals historical 134 digest   =',inv.commandSetDigest===HIST);
