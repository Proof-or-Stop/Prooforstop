import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
const art=import.meta.dirname,info=JSON.parse(readFileSync(join(art,'closure-full-runtime.json'))),root=info.path;
const out=join(art,'failure-disposition');mkdirSync(out,{recursive:true});
const temp=join(art,'failure-disposition-temp');mkdirSync(temp,{recursive:true});
for(const key of ['TMPDIR','TMP','TEMP']) process.env[key]=temp;
const {runValidationCommand}=await import(root+'/packages/main/dist/core/validation-executor.js');
const {configuredValidationCommands}=await import(root+'/packages/main/dist/handlers/verifier.js');
const commands=configuredValidationCommands(root);const results=[];
for(const number of [19,79,81,89,139,141]){
 const start=performance.now(), c=commands[number-1];
 const r=await runValidationCommand(c,root);
 writeFileSync(join(out,String(number)+'.log'),r.output);
 results.push({number,command:c,code:r.code,timedOut:r.timedOut,seconds:(performance.now()-start)/1000});
 writeFileSync(join(out,'results.json'),JSON.stringify({runtime:info,results},null,2)+'\n');console.log(JSON.stringify(results.at(-1)));
}
